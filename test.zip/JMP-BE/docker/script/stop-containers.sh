#!/bin/sh

# Stop all the containers without removing them
echo -e "\033[31m Stopping all containers... \033[0m"
docker-compose -f docker/docker-compose.yml stop
