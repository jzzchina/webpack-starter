#!/bin/sh

# Stop any running containers
pnpm container:stop

# Create and start MySQL container
echo -e "\033[31m Starting MySQL container... \033[0m"
docker-compose -f docker/docker-compose.yml up -d mysql


# Wait for the mysql container to start
docker-compose  -f docker/docker-compose.yml logs mysql | while read line; do
  if [[ $line == *"mysql is ready for connections"* ]]; then
    break;
  fi
done
