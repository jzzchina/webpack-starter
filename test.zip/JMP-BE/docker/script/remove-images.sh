#!/bin/sh

echo -e "\033[31m Removing images and containers... \033[0m"

# Remove images and containers
docker-compose -f docker/docker-compose.yml down --rmi all --volumes --remove-orphans "$@"
