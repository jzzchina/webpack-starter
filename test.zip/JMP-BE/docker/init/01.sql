CREATE DATABASE IF NOT EXISTS `todo_test`;
GRANT ALL ON `todo_test`.* TO 'myuser'@'%';
