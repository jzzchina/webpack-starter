import type { Config } from 'jest'

// * Jest Config for Integration Testing

const config: Config = {
  verbose: true,
  testEnvironment: 'node',
  preset: 'ts-jest',
  transform: {
    '^.+\\.tsx?$': 'ts-jest',
  },
  testMatch: ['**/test/integration/**/*.test.ts'],
  maxWorkers: 1,
  modulePathIgnorePatterns: [
    'build',
    'node_modules',
    'coverage',
    'docker',
    'api-docs',
    'migrations',
  ],
  testPathIgnorePatterns: [
    'build',
    'node_modules',
    'coverage',
    'docker',
    'api-docs',
    'migrations',
  ],
  collectCoverage: true,
  collectCoverageFrom: ['src/**/*.ts'],
  coverageReporters: [
    'clover',
    'lcov',
    'text-summary',
    'html',
    ['text', { skipFull: false }],
  ],
  coverageThreshold: {
    global: {
      branches: 100,
      functions: 100,
      lines: 100,
      statements: 100,
    },
  },
}

export default config
