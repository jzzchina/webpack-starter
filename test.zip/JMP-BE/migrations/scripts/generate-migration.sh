#!/bin/sh
pnpm typeorm-cli migration:generate -n Dw_m_business_days
pnpm typeorm-cli migration:generate -n Dw_m_partner_company
pnpm typeorm-cli migration:generate -n Dw_m_personnel_price
pnpm typeorm-cli migration:generate -n Dw_m_personnel
pnpm typeorm-cli migration:generate -n Dw_m_project
pnpm typeorm-cli migration:generate -n Dw_m_role
pnpm typeorm-cli migration:generate -n Dw_t_operation_plan
pnpm typeorm-cli migration:generate -n Dw_t_operation

