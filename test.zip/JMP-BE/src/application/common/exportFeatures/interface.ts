export interface RowData {
  [key: string]: string | number
}
