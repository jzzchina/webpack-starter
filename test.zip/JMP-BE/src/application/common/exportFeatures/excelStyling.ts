import ExcelJS from 'exceljs'
import { cellStyles } from './constant'

export const applyBordersToCells = (worksheet: ExcelJS.Worksheet) => {
  const lastRow = worksheet.lastRow?.number || 1
  const lastColumn = worksheet.columns.length

  for (let rowNum = 1; rowNum <= lastRow; rowNum++) {
    const row = worksheet.getRow(rowNum)
    for (let colNum = 1; colNum <= lastColumn; colNum++) {
      const cell = row.getCell(colNum)
      cell.alignment = cellStyles.ALIGNMENT
      cell.style.font = cellStyles.FONT
      cell.border = {
        top: cellStyles.BORDER_STYLE,
        left: cellStyles.BORDER_STYLE,
        bottom: cellStyles.BORDER_STYLE,
        right: cellStyles.BORDER_STYLE,
      }
    }
  }
}
export const BorderSelfCell = (row: ExcelJS.Row): void => {
  row.eachCell((cell) => {
    cell.border = {
      top: cellStyles.BORDER_STYLE,
      left: cellStyles.BORDER_STYLE,
      bottom: cellStyles.BORDER_STYLE,
      right: cellStyles.BORDER_STYLE,
    }
  })
}

export const styleRow = (
  worksheet: ExcelJS.Worksheet,
  rowNumber: number
): void => {
  const row = worksheet.getRow(rowNumber)
  row.font = cellStyles.BOLD_FONT
  row.alignment = cellStyles.ALIGNMENT
  row.eachCell((cell) => {
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: cellStyles.FILL_COLOR,
    }
  })
}
export const styleSelfRow = (selfRow: ExcelJS.Row): void => {
  selfRow.font = cellStyles.BOLD_FONT
  selfRow.alignment = cellStyles.ALIGNMENT
  selfRow.eachCell((cell) => {
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: cellStyles.FILL_COLOR,
    }
    cell.border = {
      top: cellStyles.BORDER_STYLE,
      left: cellStyles.BORDER_STYLE,
      bottom: cellStyles.BORDER_STYLE,
      right: cellStyles.BORDER_STYLE,
    }
  })
}

export const setWrapTextForWorksheet = (worksheet: ExcelJS.Worksheet) => {
  worksheet.eachRow((row) => {
    row.eachCell((cell) => {
      cell.alignment = {
        wrapText: true,
        vertical: 'middle',
        horizontal: 'left',
      }
    })
  })
}

export const toalCostStyleRow = (
  worksheet: ExcelJS.Worksheet,
  rowNumber: number
) => {
  const row = worksheet.getRow(rowNumber)
  row.alignment = cellStyles.HEADER_ALIGNMENT
  row.eachCell((cell) => {
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: cellStyles.TOTAL_FILL_COLOR,
    }
  })
}

export const styleTotalRowWithStartCol = (
  worksheet: ExcelJS.Worksheet,
  rowNumber: number,
  startCol: number
) => {
  const row = worksheet.getRow(rowNumber)
  row.alignment = cellStyles.ALIGNMENT
  row.eachCell((cell: ExcelJS.Cell, colNumber: number) => {
    if (colNumber >= startCol) {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: cellStyles.TOTAL_FILL_COLOR,
      }
    }
  })
}

export const styleTotalRow = (
  worksheet: ExcelJS.Worksheet,
  rowNumber: number,
  startCol: number
) => {
  styleTotalRowWithStartCol(worksheet, rowNumber, startCol)

  for (let colNumber = 1; colNumber <= worksheet.columns.length; colNumber++) {
    const cell = worksheet.getCell(rowNumber, colNumber)
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: cellStyles.TOTAL_FILL_COLOR,
    }
  }
}

export const styleHeaderCells = (
  worksheet: ExcelJS.Worksheet,
  rowNumbers: number[]
) => {
  rowNumbers.forEach((rowNumber) => {
    const row = worksheet.getRow(rowNumber)
    row.eachCell((cell) => {
      cell.alignment = { ...cellStyles.HEADER_ALIGNMENT, wrapText: true }
      cell.font = cellStyles.BOLD_FONT
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: cellStyles.FILL_COLOR,
      }
      cell.border = {
        top: cellStyles.BORDER_STYLE,
        left: cellStyles.BORDER_STYLE,
        bottom: cellStyles.BORDER_STYLE,
        right: cellStyles.BORDER_STYLE,
      }
    })
  })
}
