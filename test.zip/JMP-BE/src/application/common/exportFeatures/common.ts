import { cellStyles, currencySymbols, exportConstantValues } from './constant'
import labels from './labels'
import ExcelJS from 'exceljs'

export const getYearRange = (from: Date, to: Date) => {
  const years = []
  const start = new Date(from.getFullYear(), from.getMonth(), 1)
  const end = new Date(to.getFullYear(), to.getMonth(), 1)

  let currentYear = start.getFullYear()
  years.push(`${currentYear}${labels.YEAR}`)

  while (start < end) {
    start.setMonth(start.getMonth() + 1)
    if (start.getFullYear() !== currentYear) {
      currentYear = start.getFullYear()
      years.push(`${currentYear}${labels.YEAR}`)
    } else {
      years.push('')
    }
  }

  return years
}

export const getMonthRange = (from: Date, to: Date): string[] => {
  const months = []
  const start = new Date(from.getFullYear(), from.getMonth(), 1)
  const end = new Date(to.getFullYear(), to.getMonth(), 1)

  while (start <= end) {
    const month = ('0' + (start.getMonth() + 1)).slice(-2)
    months.push(`${month}${labels.MONTH}`)
    start.setMonth(start.getMonth() + 1)
  }

  return months
}

export const getYearMonthRange = (from: Date, to: Date) => {
  const months = []
  const start = new Date(from.getFullYear(), from.getMonth(), 1)
  const end = new Date(to.getFullYear(), to.getMonth(), 1)
  while (start <= end) {
    const year = start.getFullYear()
    const month = ('0' + (start.getMonth() + 1)).slice(-2)
    const day = ('0' + start.getDate()).slice(-2)
    const formattedDate = `${year}-${month}-${day}`
    months.push(formattedDate)
    start.setMonth(start.getMonth() + 1)
  }

  return months
}

export const mergeCells = (
  worksheet: ExcelJS.Worksheet,
  startRow: number,
  startColumn: number,
  endRow: number,
  endColumn: number
) => {
  try {
    worksheet.mergeCells(startRow, startColumn, endRow, endColumn)
  } catch {
    console.log('Error while merging cells')
  }
}

export const mergeYearHeaderCells = (
  worksheet: ExcelJS.Worksheet,
  from: Date,
  to: Date,
  startColumn?: number
) => {
  const start = new Date(from.getFullYear(), from.getMonth(), 1)
  const end = new Date(to.getFullYear(), to.getMonth(), 1)
  let currentCell = startColumn
    ? startColumn
    : exportConstantValues.START_COLUMN
  // Loop over years
  for (let year = start.getFullYear(); year <= end.getFullYear(); year++) {
    // Determine the starting month for the current year
    const startMonth = year === start.getFullYear() ? start.getMonth() : 0

    // Determine the ending month for the current year
    const endMonth =
      year === end.getFullYear()
        ? end.getMonth()
        : exportConstantValues.MONTHS_IN_YEAR - 1
    mergeCells(
      worksheet,
      1,
      currentCell,
      1,
      currentCell + endMonth - startMonth
    )
    // Align text to the left for the merged cells
    for (
      let col = currentCell;
      col <= currentCell + endMonth - startMonth;
      col++
    ) {
      worksheet.getCell(1, col).alignment = cellStyles.HEADER_ALIGNMENT
    }

    // Update the current cell position
    currentCell = currentCell + endMonth - startMonth + 1
  }
}

export const getValueOrDefault = (
  value: number | string | null | undefined,
  defaultValue = ''
): string => {
  if (value === null || value === undefined) return defaultValue
  if (typeof value === 'number') return value.toFixed(2)
  return value.toString()
}

export const getCurrencySymbol = (currencyTypeCode: number): string => {
  switch (currencyTypeCode) {
    case 0:
      return currencySymbols.YEN
    case 1:
      return currencySymbols.DOLLAR
    default:
      return currencySymbols.DEFAULT
  }
}

/**
 * Automatically adjusts the column widths based on the content.
 * @param {ExcelJS.Worksheet} worksheet - The worksheet to adjust the column widths.
 */
export const adjustColumnWidths = (worksheet: ExcelJS.Worksheet): void => {
  worksheet.columns.forEach((column) => {
    if (!column) return

    let maxLength = 0
    column.eachCell?.({ includeEmpty: true }, (cell) => {
      const columnLength = cell.value ? cell.value.toString().length : 10
      if (columnLength > maxLength) {
        maxLength = columnLength
      }
    })

    column.width = maxLength
  })
}
