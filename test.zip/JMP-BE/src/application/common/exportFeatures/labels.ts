export default {
  PROJECT_NAME: 'プロジェクト名',
  WBS_CODE: 'WBSコード',
  WBS_TITLE: 'WBS件名',
  BEFORE_TAX: '合計金額 (税抜き)',
  AFTER_TAX: '合計金額 (税込み)',
  TOTAL_BEFORE_TAX: '期間合計金額 (税抜き)',
  TOTAL_AFTER_TAX: '期間合計金額 (税込み)',
  YEAR_MONTH: '年月',
  MONTH_RANGE: '期間',
  TOTAL_COST: '期間合計金額',
  SUB_TOTAL: '上記の合計',
  PROJECT_COST: 'プロジェクト\n合計金額',
  COMPANY_NAME: '会社名',
  NAME: '名前(漢字)',
  YEAR: '年',
  MONTH: '月',
  TYPE: 'タイプ',
  AMOUNT: '金額',
  TYPE_0: '月額固定（税込・円）',
  TYPE_1: '月額固定（非課税・ドル)',
  TYPE_2: '時間単価',
  EXPECTED_RESULT: '予実',
  SCHEDULE: '予定',
  ACHIEVEMENTS: '実績',
  TOTAL_ALL: '上記の合計',
  PROJECT_TOTAL_AMOUNT: 'プロジェクト合計金額',
  TOTAL: '合計',
}

// Sheet names for export
export const SHEET_NAME = {
  WBS_COSTS: 'WBS総額',
  OPERATION_COSTS: '費用実績',
  OPERATION_PLAN: '要員検索・稼働計画',
  OPERATION: '稼働実績',
  OPERATION_COST_PLAN: '費用計画',
}

// File names for export
export const FILE_NAME = {
  WBS_COSTS: 'wbs',
  OPERATION_COSTS: 'operation-cost',
  OPERATION_PLAN: 'operation-plan',
  OPERATION: 'operation',
  OPERATION_COST_PLAN: 'operation-cost-plan',
}
