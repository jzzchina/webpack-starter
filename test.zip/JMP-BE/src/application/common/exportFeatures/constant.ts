import * as ExcelJS from 'exceljs'
import labels from './labels'

export const currencySymbols = {
  YEN: '¥',
  DOLLAR: '$',
  DEFAULT: '',
}
export const WBS_SUBJECTS = ['OPEX', 'CAPEX', labels.TOTAL]
export const cellStyles = {
  FONT: { name: 'ＭＳ Ｐゴシック' },
  BOLD_FONT: { name: 'ＭＳ Ｐゴシック', bold: true },
  ALIGNMENT: {
    vertical: 'middle',
    horizontal: 'center',
    wrapText: true,
  } as ExcelJS.Alignment,
  HEADER_ALIGNMENT: {
    vertical: 'middle',
    horizontal: 'left',
  } as ExcelJS.Alignment,
  FILL_COLOR: { argb: 'C5D9F1' }, // Light blue
  TOTAL_FILL_COLOR: { argb: 'FFA500' }, // Light orange
  BORDER_STYLE: { style: 'thin' } as ExcelJS.Border,
}
export const TOTAL_CELL_STYLE: Partial<ExcelJS.Style> = {
  font: {
    bold: true,
  },
  alignment: {
    vertical: 'middle',
    horizontal: 'center',
    wrapText: true,
  },
  border: {
    top: {
      style: 'thin',
    },
    left: {
      style: 'thin',
    },
    bottom: {
      style: 'thin',
    },
    right: {
      style: 'thin',
    },
  },
}
export const SUB_TOTAL_CELL_STYLE: Partial<ExcelJS.Style> = {
  fill: {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFA500' },
    bgColor: { argb: 'FFA500' },
  },
  alignment: {
    vertical: 'middle',
    horizontal: 'center',
    wrapText: true,
  },
  border: {
    top: {
      style: 'thin',
    },
    left: {
      style: 'thin',
    },
    bottom: {
      style: 'thin',
    },
    right: {
      style: 'thin',
    },
  },
}
export const exportConstantValues = {
  MONTHS_IN_YEAR: 12,
  START_COLUMN: 4, // usually starts from 4 for all the sheets due to the first 3 columns being reserved then the year columns
  TAX: 1.1,
}

/**
 * constants used for price calculation
 */
export const DEFAULT_BUSINESS_DAYS = 20
export const DEFAULT_WORK_TIME_OF_DAY = 8
