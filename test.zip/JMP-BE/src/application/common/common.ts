/**
 * Converts a Date object to a string format of "yyyy-mm".
 * @param date The Date object to convert.
 * @returns A string representing the date in "yyyy-mm" format.
 */
export function convertDateToYYYYMM(date: Date): string {
  // Extract year from the date
  const year = date.getFullYear()
  // Extract month from the date and ensure it has two digits
  const month = ('0' + (date.getMonth() + 1)).slice(-2)
  // Return the formatted date string
  return `${year}-${month}`
}
