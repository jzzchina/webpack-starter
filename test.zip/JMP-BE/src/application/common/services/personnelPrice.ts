import { PersonnelPrice } from '../../../domain/models/PersonnelPrice'
import { Dw_m_personnel_price } from '../../../infrastructure/orm/typeorm/entities/Dw_m_personnel_price'

/**
 * Maps an array of personnel prices to an array of personnel price objects with selected properties.
 * @param personnelPrices - An array of personnel prices.
 * @returns An array of personnel price objects with selected properties.
 * @description Maps an array of personnel prices to an array of personnel price objects with selected properties.
 */
export const buildPersonnelPrices = (
  personnelPrices?: Dw_m_personnel_price[]
): PersonnelPrice[] => {
  // the function returns an array of PersonnelPrice objects
  return personnelPrices
    ?.map((personnelPrice) => ({
      contractPatternCode: personnelPrice?.contract_pattern_code,
      personnelPriceId: personnelPrice?.personnel_price_id,
      priceStartDate: personnelPrice?.price_start_date,
      priceAmount: personnelPrice?.price_amount,
      currencyTypeCode: personnelPrice?.currency_type_code,
    }))
    .sort(
      (a, b) =>
        new Date(a.priceStartDate).getTime() -
        new Date(b.priceStartDate).getTime()
    ) as PersonnelPrice[]
  // map the array of personnel prices to an array of PersonnelPrice objects
}
