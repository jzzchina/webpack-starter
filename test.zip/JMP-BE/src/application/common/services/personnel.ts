import { Dw_t_operation_plan } from '../../../infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
/**
 *
 * @param operationPlans
 * @returns  an array of personnel IDs
 * @description Returns an array of personnel IDs from an array of operation plans.
 */
export const getAllPersonnelIds = (
  operationPlans?: Dw_t_operation_plan[]
): number[] => {
  const personnelIds = operationPlans
    // get the array of operation plans
    ?.map((plan) => plan?.dw_m_personnel?.personnel_id)
    // map the array to an array of personnel IDs
    ?.filter((personnel) => personnel)
  // filter out any undefined personnel IDs

  return [...new Set(personnelIds)] as number[]
}
