import { Dw_t_operation_plan } from '../../../infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
/**
 *
 * @param operationPlans
 * @returns  an array of project IDs
 * @description Returns an array of project IDs from an array of operation plans.
 */
export const getAllProjectIds = (
  operationPlans?: Dw_t_operation_plan[]
): number[] => {
  // the function returns an array of project IDs
  const projectIds = operationPlans
    // get the array of operation plans
    ?.map((plan) => plan?.dw_m_project?.project_id)
    // map the array to an array of project IDs
    ?.filter((project) => project)
    // filter out any undefined project IDs
    ?.sort((a, b) => {
      // sort the array of project IDs
      if (!a || !b) {
        // if either a or b is undefined, return 0
        return 0
      }
      // if neither a nor b is undefined, return the difference between a and b
      return a - b
    })
  return [...new Set(projectIds)] as number[]
  // return the array of project IDs without duplicates
}
