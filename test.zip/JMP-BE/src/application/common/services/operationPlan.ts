import { OperationPlanPersonnelTotal } from '../../../infrastructure/repositories/operationPlan/interface'
import { Dw_t_operation_plan } from '../../../infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import { CreateOperationPlanDto } from '../../../interface/routes/operationPlan/dto/operationPlans.dto'
import { OperationPlanRepositoryPort } from '../../port/repositories/operationPlan/OperationPlanRepositoryPort'
import logger from '../../../infrastructure/logger/logger'

/**
 * This function takes an array of operation plans and returns an object that groups
 * them by month of year, with each group containing the total number of man months
 * for that month. If `showOnlyManMonthNumber` is true, the object only contains the
 * man month number for each month, otherwise it also contains the role ID and name
 * for each month.
 *
 * @param operationPlans An array of operation plans to group by month of year.
 * @param showOnlyManMonthNumber Whether to only show the man month number for each month.
 * @returns An object that groups the operation plans by month of year, with the total number of man months for each month.
 * @description This function takes an array of operation plans and returns an object that groups
 */
export const buildOperationPlansManMonthNumberGroup = (
  operationPlans?: Dw_t_operation_plan[], // an optional array of Dw_t_operation_plan objects
  showOnlyManMonthNumber = false // a flag indicating whether to include only man-month numbers in the result object
): OperationPlanPersonnelTotal => {
  // the function returns an object of type OperationPlanPersonnelTotal

  return (
    operationPlans
      // sort and reduce the array of objects to the desired result
      ?.sort(sortOperationPlanByMonthOfYear)
      // sort the objects in the array by month of year
      ?.reduce((operationPlan, currentOperationPlan) => {
        // reduce the array to an object, grouping by month of year
        const monthOfYear = currentOperationPlan?.month_of_year_date.toString()
        // extract the month of year from the current object
        const manMonthNumber = Number(currentOperationPlan.man_month_number)
        // extract the man-month number from the current object

        if (monthOfYear && !operationPlan[monthOfYear]) {
          // if the month of year is not already in the result object, create a new entry for it
          operationPlan[monthOfYear] = {
            // create a new entry for the month of year
            operationPlanId: currentOperationPlan?.operation_plan_id, // set the operation plan ID for the current object,
            manMonthNumber: manMonthNumber, // set the man-month number for the current object
          }

          if (!showOnlyManMonthNumber) {
            // if the flag is not set to true, also add the roleId and roleName properties to the new entry
            Object.assign(operationPlan[monthOfYear], {
              operationPlanId: currentOperationPlan?.operation_plan_id,
              roleId: currentOperationPlan?.dw_m_role?.role_id,
              roleName: currentOperationPlan?.dw_m_role?.role_name,
            })
          }
        } else {
          // if the month of year is already in the result object, add the current object's man-month number to the existing entry
          operationPlan[monthOfYear].manMonthNumber += manMonthNumber
        }

        return operationPlan // return the updated result object
      }, {} as OperationPlanPersonnelTotal) as OperationPlanPersonnelTotal
  ) // initialize the result object as an empty object of type OperationPlanPersonnelTotal
}
/**
 * This function sorts two operation plans by month of year.
 * @param a The first operation plan to compare.
 * @param b The second operation plan to compare.
 * @param order The order in which to sort the operation plans. Defaults to 'ASC'.
 * @returns A number indicating the order of the operation plans (
 * -1: monthYearDate of A < B
 * 0: monthYearDate of A = B
 * 1: monthYearDate of A > B
 * ).
 * @description This function sorts two operation plans by month of year.
 */

export const sortOperationPlanByMonthOfYear = (
  a: Dw_t_operation_plan,
  b: Dw_t_operation_plan,
  order?: 'ASC' | 'DES'
): number => {
  if (a?.month_of_year_date < b?.month_of_year_date) {
    return order === 'DES' ? 1 : -1
  }

  if (a?.month_of_year_date > b?.month_of_year_date) {
    return order === 'DES' ? -1 : 1
  }

  return 0
}

/**
 * Return false when validation failed.
 * Details: https://dev.azure.com/JERA-Organization/JMP-BE/_workitems/edit/74433
 */
export const overWorkValidation = async (
  operationPlanInput: CreateOperationPlanDto[],
  OperationPlanRepository: Pick<
    OperationPlanRepositoryPort,
    'findMany' | 'create' | 'findAllOperationPlansByPersonnelId'
  >
): Promise<boolean> => {
  // Check if there are operation plan changes that lets the total reaches more than 1.0 per personnel.
  const personnelIds = Array.from(
    new Set(operationPlanInput.map(({ personnelId }) => personnelId))
  )

  for (const personnelId of personnelIds) {
    const allOperationPlanByPersonnel = await OperationPlanRepository.findAllOperationPlansByPersonnelId(
      personnelId
    )
    const inputByPersonnel = operationPlanInput.filter(
      (input) => input.personnelId === personnelId
    )
    logger.info(`PersonnelId: ${personnelId}`)

    const totalByPersonnelByYearMonth = {} as Record<string, number>

    allOperationPlanByPersonnel.forEach((operationPlan) => {
      // Calculate for edited or existing operatoin plans.
      const edited = inputByPersonnel.filter(
        (input) => input.operationPlanId === operationPlan.operation_plan_id
      )[0]
      const value = edited
        ? edited.manMonthNumber
        : operationPlan.man_month_number
      logger.info(
        `[${edited ? 'Edited' : 'Existing'}] operatoinId: ${
          operationPlan.operation_plan_id
        } personnelId: ${personnelId} yearMonth: ${
          operationPlan.month_of_year_date
        } value: ${value}`
      )
      if (
        totalByPersonnelByYearMonth[
          String(operationPlan.month_of_year_date)
        ] === undefined
      ) {
        totalByPersonnelByYearMonth[
          String(operationPlan.month_of_year_date)
        ] = 0
      }
      totalByPersonnelByYearMonth[
        String(operationPlan.month_of_year_date)
      ] += value
    })

    // operationPlanId is 0 if it's a new one.
    const newOperationPlans = inputByPersonnel.filter(
      (input) => input.operationPlanId === 0
    )
    newOperationPlans.forEach((operationPlan) => {
      // Calculate for new operatoin plans.
      logger.info(
        `[new] operatoinId: ${operationPlan.operationPlanId} personnelId: ${personnelId} yearMonth: ${operationPlan.yearOfMonthDate} value: ${operationPlan.manMonthNumber}`
      )
      if (
        totalByPersonnelByYearMonth[operationPlan.yearOfMonthDate] === undefined
      ) {
        totalByPersonnelByYearMonth[operationPlan.yearOfMonthDate] = 0
      }
      totalByPersonnelByYearMonth[operationPlan.yearOfMonthDate] +=
        operationPlan.manMonthNumber
    })
    logger.info('Calculation results: ', totalByPersonnelByYearMonth)
    for (const total of Object.values(totalByPersonnelByYearMonth)) {
      if (total > 1) {
        return false
      }
    }
  }
  return true
}
