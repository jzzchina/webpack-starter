import { WbsCostListResponse } from '../../../interface/routes/wbs/dto/wbsCosts'
import { buildWbsCostListResponse } from '../../helpers/wbs.helpers'
import { WbsRepositoryPort } from '../../port/repositories/wbs/wbsRepositoryPort'

/**
 * @description use case for searching wbs cost
 * @param limit limit used for pagination
 * @param offset  offset used for pagination
 * @param from  from date of project start date
 * @param to    to date of project end date
 * @param companyId  company id that is used for filtering
 * @param wbsRepository repository to get service used for searching wbs cost
 * @returns wbs costlist response under specific format
 */
export const searchWbsCostsUseCase = async (
  limit: number,
  offset: number,
  from: string,
  to: string,
  companyId: number,
  wbsRepository: Pick<WbsRepositoryPort, 'searchWbsCosts'>
): Promise<WbsCostListResponse> => {
  const { personnel } = await wbsRepository.searchWbsCosts(
    limit,
    offset,
    from,
    to,
    companyId
  )
  // return the result in specific format
  return buildWbsCostListResponse(personnel, from, to, offset, limit, companyId)
}
