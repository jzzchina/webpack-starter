import { v4 as uuidv4 } from 'uuid'
import { uploadFileToAzureBlob } from '../../../infrastructure/azure/config/azureBlobStorageConnection'
import ExcelJS, { Row } from 'exceljs'
import CustomError from '../../errors/CustomError'
import messages from '../../errors/messages'
import {
  WBSAggregatedData,
  WbsPeriodData,
  WbsPeriodItem,
} from '../../../interface/routes/wbs/dto/wbsCosts'
import Labels, {
  FILE_NAME,
  SHEET_NAME,
} from '../../common/exportFeatures/labels'

import {
  SUB_TOTAL_CELL_STYLE,
  WBS_SUBJECTS,
  currencySymbols,
  exportConstantValues,
} from '../../common/exportFeatures/constant'
import logger from '../../../infrastructure/logger/logger'
import {
  BorderSelfCell,
  styleSelfRow,
} from '../../common/exportFeatures/excelStyling'
import { mergeCells } from '../../common/exportFeatures/common'
import { WBSBySubject } from '../../../domain/types/WBSTypes'

const getValueOrDefault = (value: string | number, defaultValue = ''): string =>
  value !== undefined && value !== null ? String(value) : defaultValue

const getCurrencySymbol = (currencyTypeCode: number): string => {
  switch (currencyTypeCode) {
    case 0:
      return currencySymbols.YEN
    case 1:
      return currencySymbols.DOLLAR
    default:
      return currencySymbols.DEFAULT
  }
}

const transformItemData = (
  item: WbsPeriodData
): Record<string, string | number>[] => {
  if (!item.wbs || !Array.isArray(item.wbs)) return []
  return item.wbs.map((wbs: WbsPeriodItem) => {
    const amountBeforeTax = parseFloat(wbs.amount.toFixed(2))
      .toString()
      .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    const amountAfterTax = parseFloat((wbs.amount * 1.1).toFixed(2))
      .toString()
      .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    return {
      [Labels.PROJECT_NAME]: getValueOrDefault(wbs.projectName),
      [Labels.WBS_CODE]: getValueOrDefault(wbs.wbsCode),
      [Labels.WBS_TITLE]: getValueOrDefault(wbs.wbsTitle),
      month: item.month,
      amountBeforeTax: `${amountBeforeTax}`,
      amountAfterTax: `${amountAfterTax}`,
      currency_type_code: wbs.currency_type_code,
      amountBeforeTaxRaw: wbs.amount,
      amountAfterTaxRaw: wbs.amount * exportConstantValues.TAX,
      subject: wbs.subject,
    }
  })
}

export const exportDataSearchWbsCostsUseCase = async (data: {
  from: string
  to: string
  items: WbsPeriodData[]
}): Promise<string> => {
  if (!data.items || data.items.length === 0) {
    throw new CustomError(messages.exportDatanotExists, 'Not Found')
  }

  const flattenedData = data.items.flatMap(transformItemData)
  const months = data.items.map((item) => item.month)
  const uniqueMonths = Array.from(new Set(months))
  const subTotalAmount: WBSBySubject = {
    OPEX: [],
    CAPEX: [],
    合計: [],
  }
  const aggregatedData = flattenedData.reduce(
    (acc: Record<string, WBSAggregatedData>, item) => {
      const currencySymbol = getCurrencySymbol(
        item.currency_type_code as number
      )
      const key = `${item[Labels.PROJECT_NAME]}-${item[Labels.WBS_CODE]}-${
        item[Labels.WBS_TITLE]
      }`
      if (!acc[key]) {
        acc[key] = {
          [Labels.PROJECT_NAME]: getValueOrDefault(item[Labels.PROJECT_NAME]),
          [Labels.WBS_CODE]: getValueOrDefault(item[Labels.WBS_CODE]),
          [Labels.WBS_TITLE]: getValueOrDefault(item[Labels.WBS_TITLE]),
          currency_type_code: item.currency_type_code as number,
          amountBeforeTaxTotal: '0',
          amountAfterTaxTotal: '0',
          subject: item.subject.toString(),
        }
      }
      const amountBeforeTaxTotal =
        parseFloat(acc[key].amountBeforeTaxTotal.replace(/,/g, '')) || 0
      const amountAfterTaxTotal =
        parseFloat(acc[key].amountAfterTaxTotal.replace(/,/g, '')) || 0
      const itemBeforeTaxRaw =
        parseFloat(item.amountBeforeTaxRaw.toString()) || 0
      const itemAfterTaxRaw = parseFloat(item.amountAfterTaxRaw.toString()) || 0
      acc[key][
        `${item.month} ${Labels.BEFORE_TAX}`
      ] = `${currencySymbol}${item.amountBeforeTax}`
      acc[key][
        `${item.month} ${Labels.AFTER_TAX}`
      ] = `${currencySymbol}${item.amountAfterTax}`
      acc[key].amountBeforeTaxTotal = (amountBeforeTaxTotal + itemBeforeTaxRaw)
        .toFixed(2)
        .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
      acc[key].amountAfterTaxTotal = (amountAfterTaxTotal + itemAfterTaxRaw)
        .toFixed(2)
        .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
      return acc
    },
    {}
  )
  const columns = [
    { header: Labels.PROJECT_NAME, key: Labels.PROJECT_NAME, width: 16 },
    { header: Labels.WBS_CODE, key: Labels.WBS_CODE, width: 13 },
    { header: Labels.WBS_TITLE, key: Labels.WBS_TITLE, width: 13 },
    ...uniqueMonths.flatMap((month) => [
      {
        header:
          month === uniqueMonths[0] ? Labels.BEFORE_TAX : Labels.BEFORE_TAX,
        key: `${month} ${Labels.BEFORE_TAX}`,
        width: 27,
      },
      {
        header: Labels.AFTER_TAX,
        key: `${month} ${Labels.AFTER_TAX}`,
        width: 27,
      },
    ]),
  ]

  const workbook = new ExcelJS.Workbook()
  const worksheet = workbook.addWorksheet(SHEET_NAME.WBS_COSTS)

  const fromDate = new Date(data.from)
  const toDate = new Date(data.to)
  const fromYearMonth = `${fromDate.getFullYear()}-${(
    '0' +
    (fromDate.getMonth() + 1)
  ).slice(-2)}`
  const toYearMonth = `${toDate.getFullYear()}-${(
    '0' +
    (toDate.getMonth() + 1)
  ).slice(-2)}`
  worksheet.columns = columns
  const projectDataMap = new Map<string, WBSAggregatedData[]>()
  WBS_SUBJECTS.forEach((subject) => {
    Object.values(aggregatedData).forEach((item: WBSAggregatedData) => {
      if (!projectDataMap.has(subject)) {
        projectDataMap.set(subject, [])
      }

      if (item.subject === subject) {
        projectDataMap.get(subject)?.push(item)
      }
    })
  })

  WBS_SUBJECTS.forEach((subject) => {
    worksheet.addRow([''])
    worksheet.addRow([subject])

    const rowValues = [
      Labels.YEAR_MONTH,
      `${fromYearMonth} 〜 ${toYearMonth}`,
      '',
    ]
    for (const month of uniqueMonths) {
      rowValues.push(month, '')
    }
    const addedRowValues: Row = worksheet.addRow(rowValues)
    const addedRowNumber: number = addedRowValues.number
    styleSelfRow(addedRowValues)
    const columnRow = worksheet.addRow([...columns.map((col) => col.header)])
    styleSelfRow(columnRow)
    for (let i = 1; i < rowValues.length; i += 2) {
      mergeCells(worksheet, addedRowNumber, i + 1, addedRowNumber, i + 2)
    }
    projectDataMap.get(subject)!.forEach((item) => {
      const currencySymbol = getCurrencySymbol(item.currency_type_code)
      const dataRows: Row = worksheet.addRow({
        ...item,
        amountBeforeTaxTotal: `${currencySymbol}${item.amountBeforeTaxTotal}`,
        amountAfterTaxTotal: `${currencySymbol}${item.amountAfterTaxTotal}`,
      })

      BorderSelfCell(dataRows)
    })
    const dataSource: WBSAggregatedData[] = (() => {
      if (subject === Labels.TOTAL) {
        return Object.values(aggregatedData)
      } else {
        return projectDataMap
          .get(subject)!
          .filter((item) => item.subject === subject)
      }
    })()

    uniqueMonths.forEach((month) => {
      let sumOfAmountBeforeTax = 0
      let sumOfAmountAfterTax = 0
      dataSource.forEach((item) => {
        if (!item[`${month} ${Labels.BEFORE_TAX}`]) return
        const currencySymbol = getCurrencySymbol(item.currency_type_code)
        sumOfAmountBeforeTax += Number(
          item[`${month} ${Labels.BEFORE_TAX}`]
            .toString()
            .replace(/,/g, '')
            .split(currencySymbol)[1]
        )

        sumOfAmountAfterTax += Number(
          item[`${month} ${Labels.AFTER_TAX}`]
            .toString()
            .replace(/,/g, '')
            .split(currencySymbol)[1]
        )
      })

      subTotalAmount[subject].push(
        `${currencySymbols.YEN}` +
          sumOfAmountBeforeTax.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ','),
        `${currencySymbols.YEN}` +
          sumOfAmountAfterTax.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
      )
    })

    const subtotalRow = worksheet.addRow([
      Labels.SUB_TOTAL,
      '',
      '',
      ...subTotalAmount[subject],
    ])
    subtotalRow.eachCell((cell) => {
      cell.style = SUB_TOTAL_CELL_STYLE
    })

    mergeCells(worksheet, subtotalRow.number, 0, subtotalRow.number, 3)
  })

  worksheet.views = [{ state: 'frozen', ySplit: 2 }]
  worksheet.getRow(1).eachCell((cell) => {
    cell.value = ''
  })

  worksheet.eachRow((row) => {
    row.eachCell((cell) => {
      if (cell.value === Labels.TOTAL_ALL) {
        cell.alignment = {
          vertical: 'middle',
          horizontal: 'center',
          wrapText: true,
        }
      } else {
        cell.alignment = {
          vertical: 'middle',
          horizontal: 'left',
          wrapText: true,
        }
      }
    })
  })
  const excelBuffer = await workbook.xlsx.writeBuffer()
  const buffer = Buffer.from(excelBuffer)
  const fileName = `${FILE_NAME.WBS_COSTS}${uuidv4()}.xlsx`
  logger.info(`Uploading file to Azure Blob Storage: ${fileName}`)
  const url = await uploadFileToAzureBlob(buffer, fileName)
  return url
}
