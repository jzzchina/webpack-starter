import { OperationCostPlanRepositoryPort } from '../../port/repositories/operationCostPlan/OperationCostPlanRepositoryPort'

import { OperationCostPlanProjectListResponse } from '../../../interface/routes/operationCostPlan/dto/operationCostPlan.dto'
import { buildOperationCostPlanProjectListResponse } from '../../helpers/operationCostPlan.helpers'

/**
 * @description use case for searching operation cost plans by project
 * @param limit limit used for pagination
 * @param offset  offset used for pagination
 * @param from  from date of project start date
 * @param to    to date of project end date
 * @param projectId  project id that is used for filtering
 * @param companyId  company id that is used for filtering
 * @param operationPlanRepository repository to get service used for searching operation cost plans by project
 * @returns operation cost plan project list response under specific format
 */
export const searchOperationCostPlanByProjectsUseCase = async (
  limit: number,
  offset: number,
  from: string,
  to: string,
  projectId: number | null,
  companyId: number | null,
  operationPlanRepository: Pick<
    OperationCostPlanRepositoryPort,
    'searchOperationCostPlansByProject'
  >
): Promise<OperationCostPlanProjectListResponse> => {
  // destructuring the result from operation cost plan repository
  const {
    totalItems,
    projects,
  } = await operationPlanRepository.searchOperationCostPlansByProject(
    limit,
    offset,
    from,
    to,
    projectId,
    companyId
  )
  // return the result in specific format
  return buildOperationCostPlanProjectListResponse(
    projects,
    totalItems,
    from,
    to,
    offset,
    limit
  )
}
