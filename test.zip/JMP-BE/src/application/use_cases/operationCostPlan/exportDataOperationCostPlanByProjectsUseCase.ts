import { v4 as uuidv4 } from 'uuid'
import { uploadFileToAzureBlob } from '../../../infrastructure/azure/config/azureBlobStorageConnection'
import CustomError from '../../errors/CustomError'
import messages from '../../errors/messages'
import Labels, {
  FILE_NAME,
  SHEET_NAME,
} from '../../common/exportFeatures/labels'
import ExcelJS from 'exceljs'
import {
  adjustColumnWidths,
  getCurrencySymbol,
  getMonthRange,
  getYearMonthRange,
  getYearRange,
  mergeCells,
  mergeYearHeaderCells,
} from '../../common/exportFeatures/common'
import { convertDateToYYYYMM } from '../../common/common'
import { OperationCostPlanProject } from '../../../interface/routes/operationCostPlan/dto/operationCostPlan.dto'
import {
  applyBordersToCells,
  styleRow,
  styleTotalRowWithStartCol,
} from '../../common/exportFeatures/excelStyling'
import {
  DEFAULT_BUSINESS_DAYS,
  DEFAULT_WORK_TIME_OF_DAY,
  currencySymbols,
  exportConstantValues,
} from '../../common/exportFeatures/constant'
import { BusinessDaysObject } from '../../../interface/routes/businessDays/dto/businessDays.dto'
import { PersonnelPrice } from '../../../domain/models/PersonnelPrice'

type MergeCell = {
  startRow: number
  startColumn: number
  endRow: number
  endColumn: number
}

type SPItem = {
  code?: number
  num1?: number
  num2?: number
}

function getFirstDayStrOfYearMonth(yearMonthStr?: string): string {
  if (!yearMonthStr) return ''

  return yearMonthStr + '-01'
}

/**
 * find the businessDaysNumber from the fragment by yearMonthStr
 * the yearMonthStr is always parsed the YYYY-MM part only
 * ex: if the yearMonthStr is 2022-01-23, then it find a key 2022-01-01 from the fragment
 *
 * @param {string} yearMonthStr
 * @param {BusinessDaysFragment} businessDays
 * @param {number} defaultDays
 */
function getBusinessDaysDateStr(
  yearMonthStr: string | undefined,
  businessDays: BusinessDaysObject | undefined,
  defaultDays: number
): number {
  if (yearMonthStr === undefined || !businessDays) return defaultDays
  const firstDayOfTheMonth = getFirstDayStrOfYearMonth(yearMonthStr)
  const days = businessDays[firstDayOfTheMonth]?.businessDaysNumber
  return typeof days === 'number' ? days : defaultDays
}

/**
 * calc a monthly work time
 * @param {number} businessDays
 * @param {number} dailyWorkTime
 */
function calcMonthlyWorkHours(
  businessDays: number,
  dailyWorkTime: number
): number {
  return businessDays * dailyWorkTime
}

const numToString = (num: number): string => {
  if ((!num || isNaN(num)) && num !== 0) return ''
  return Number(num).toLocaleString()
}

const getPriceLabel = (
  businessDays: BusinessDaysObject,
  priceItem: PersonnelPrice,
  workHoursIfSet?: number
): string => {
  if (!priceItem) return ''

  const currencySymbol = getCurrencySymbol(priceItem.currencyTypeCode)
  const hoursOrMonths = !workHoursIfSet
    ? workHoursIfSet === 0
      ? 0
      : 1
    : workHoursIfSet

  const priceAmount = priceItem.priceAmount
  if (!priceAmount || isNaN(priceItem.priceAmount)) return ''

  if (priceItem.contractPatternCode === 1) {
    return currencySymbol + numToString(priceItem.priceAmount * hoursOrMonths)
  } else if (priceItem.contractPatternCode === 2) {
    const isWorkHoursNotPassed = !workHoursIfSet && workHoursIfSet !== 0
    const businessDaysOfThisMonth = getBusinessDaysDateStr(
      priceItem.priceStartDate.toString(),
      businessDays,
      DEFAULT_BUSINESS_DAYS
    )
    const workHoursOfThisMonth = calcMonthlyWorkHours(
      businessDaysOfThisMonth,
      DEFAULT_WORK_TIME_OF_DAY
    )
    const monthlyPriceMultiply = isWorkHoursNotPassed
      ? workHoursOfThisMonth
      : hoursOrMonths

    return (
      `${currencySymbol}${numToString(priceItem.priceAmount * hoursOrMonths)}` +
      '/' +
      `${currencySymbol}${numToString(
        priceItem.priceAmount * monthlyPriceMultiply
      )}`
    )
  } else {
    return (
      `${currencySymbol}${numToString(priceItem.priceAmount * hoursOrMonths)}` +
      '/' +
      `${currencySymbol}${numToString(
        Math.floor(
          priceItem.priceAmount * hoursOrMonths * exportConstantValues.TAX
        )
      )}`
    )
  }
}

function replaceAll(
  str: string,
  search: string | RegExp,
  replacement: string
): string {
  if (typeof search === 'string') {
    return str.split(search).join(replacement)
  } else if (search instanceof RegExp) {
    return str.replace(new RegExp(search.source, 'g'), replacement)
  }

  return str
}

function getProjectSumCost(sums: { [key: string]: SPItem[] }): string {
  let totalNum0 = -1
  let totalNum1 = -1
  let totalNum2 = -1
  let totalDola = -1
  Object.keys(sums).map((k: string) => {
    sums[k].forEach((s) => {
      if (Object.keys(s).length > 0) {
        if (s.code === 1) {
          if (s.num1 && !isNaN(s.num1))
            totalDola = (totalDola < 0 ? 0 : totalDola) + s.num1
        } else if (s.code === 2) {
          if (s.num1 && !isNaN(s.num1))
            totalNum2 = (totalNum2 < 0 ? 0 : totalNum2) + s.num1
        } else {
          if (s.num1 && !isNaN(s.num1))
            totalNum0 = (totalNum0 < 0 ? 0 : totalNum0) + s.num1
          if (s.num1 && !isNaN(s.num1))
            totalNum1 = (totalNum1 < 0 ? 0 : totalNum1) + s.num1
        }
      }
    })
  })

  let totalLabel =
    totalNum0 > -1
      ? `${currencySymbols.YEN}${numToString(totalNum0)}/${
          currencySymbols.YEN
        }${numToString(totalNum1 * exportConstantValues.TAX)}`
      : ''
  if (totalDola > -1) {
    totalLabel = `${totalLabel}\n${currencySymbols.DOLLAR}${numToString(
      totalDola
    )} `
  }
  if (totalNum2 > -1) {
    totalLabel = `${totalLabel}\n${currencySymbols.YEN}${numToString(
      totalNum2
    )} `
  }

  return totalLabel
}

function getProjectMonthSumCost(
  sums: { [key: string]: SPItem[] },
  yearMonthKeys: string[]
): string[] {
  return yearMonthKeys.map((month) => {
    let sumNum0 = -1
    let sumNum1 = -1
    let sumNum2 = -1
    let sumDola = -1
    if (sums[month] && Array.isArray(sums[month])) {
      sums[month].forEach((s) => {
        if (Object.keys(s).length > 0) {
          if (s.code === 1) {
            if (s.num1 && !isNaN(s.num1))
              sumDola = (sumDola < 0 ? 0 : sumDola) + s.num1
          } else if (s.code === 2) {
            if (s.num1 && !isNaN(s.num1))
              sumNum2 = (sumNum2 < 0 ? 0 : sumNum2) + s.num1
          } else {
            if (s.num1 && !isNaN(s.num1))
              sumNum0 = (sumNum0 < 0 ? 0 : sumNum0) + s.num1
            if (s.num2 && !isNaN(s.num2))
              sumNum1 = (sumNum1 < 0 ? 0 : sumNum1) + s.num2
          }
        }
      })
    }
    let sumLabel =
      sumNum0 > -1
        ? `${currencySymbols.YEN}${numToString(sumNum0)}/${
            currencySymbols.YEN
          }${numToString(sumNum1 * exportConstantValues.TAX)}`
        : ''
    if (sumDola > -1) {
      sumLabel = `${sumLabel}\n${currencySymbols.DOLLAR}${numToString(
        sumDola
      )} `
    }
    if (sumNum2 > -1) {
      sumLabel = `${sumLabel}\n${currencySymbols.YEN}${numToString(sumNum2)} `
    }

    return sumLabel
  })
}

function getEmptyRow(projectName: string, yearMonthKeys: string[]): string[] {
  const rowValues: string[] = []
  rowValues.push(projectName)
  rowValues.push('')
  rowValues.push('')
  rowValues.push('')

  yearMonthKeys.map(() => {
    rowValues.push('')
  })

  return rowValues
}

function getRowValues(
  i: OperationCostPlanProject,
  projectName: string,
  yearMonthKeys: string[]
): [{ [key: string]: SPItem[] }, string[][]] {
  if (!i.personnel || i.personnel.length <= 0) {
    return [{}, []]
  }

  const sums: { [key: string]: SPItem[] } = {}
  const rows = i.personnel.map((per) => {
    const rowValues: string[] = []
    const companyName = per.companyName
    const name = `${per.name}\n${per.nameJpn}`

    rowValues.push(projectName)
    rowValues.push(companyName)
    rowValues.push(name)
    rowValues.push('')

    let pp: PersonnelPrice = {
      personnelPriceId: 0,
      priceStartDate: new Date(),
      contractPatternCode: 0,
      priceAmount: 0,
      currencyTypeCode: 0,
      personnelId: 0,
    }
    const ocp = per.operationCostPlans ? per.operationCostPlans : {}
    yearMonthKeys.map((month) => {
      let price = ''

      const assignPeriod =
        per.registeredDate.toString() <= month &&
        (!per.unregisteredDate || per.unregisteredDate.toString() >= month)

      let op = per.prices?.find(
        (psd) => psd.priceStartDate.toString() === month
      )

      if (!op && per.prices) {
        const ps = per.prices.filter(
          (pp) => pp.priceStartDate.toString() < month
        )
        op = ps[ps.length - 1]
      }

      if (assignPeriod && op) pp = op
      const np = ocp ? ocp[month] : undefined
      if (np) {
        price = getPriceLabel(
          per.businessDays,
          pp,
          pp.contractPatternCode === 2 ? np.hoursNumber : np.manMonthNumber
        )
        const sum = sums[month]
        const ps = price.indexOf('/') ? price.split('/') : [price]
        const sp: SPItem = {}
        if (Array.isArray(ps) && ps.length > 0 && ps[0]) {
          sp.code = pp.contractPatternCode
          if (sp.code === 1) {
            sp.num1 = Number(
              replaceAll(ps[0].replace(currencySymbols.DOLLAR, ''), ',', '')
            )
          } else if (sp.code === 2) {
            if (ps.length > 1) {
              price = ps[1]
              sp.num1 = Number(
                replaceAll(ps[1].replace(currencySymbols.YEN, ''), ',', '')
              )
            }
          } else {
            sp.num1 = Number(
              replaceAll(ps[0].replace(currencySymbols.YEN, ''), ',', '')
            )
            if (ps.length > 1) {
              sp.num2 = Number(
                replaceAll(ps[1].replace(currencySymbols.YEN, ''), ',', '')
              )
            }
          }
        }
        if (sum) {
          sum.push(sp)
        } else {
          sums[month] = []
          sums[month].push(sp)
        }
      }

      rowValues.push(price)
    })

    return rowValues
  })

  return [sums, rows]
}

function getCostRow(
  sums: { [key: string]: SPItem[] },
  yearMonthKeys: string[]
) {
  const rowValues: string[] = []
  rowValues.push('')
  rowValues.push(Labels.TOTAL_ALL)
  rowValues.push('')
  rowValues.push(getProjectSumCost(sums))
  rowValues.push(...getProjectMonthSumCost(sums, yearMonthKeys))

  return rowValues
}

const sheetColumns = (yearMonthKeys: string[], monthKeys: string[]) => [
  { header: Labels.PROJECT_NAME, key: Labels.PROJECT_NAME, width: 30 },
  { header: Labels.COMPANY_NAME, key: Labels.COMPANY_NAME, width: 20 },
  { header: Labels.NAME, key: Labels.NAME, width: 20 },
  {
    header: Labels.PROJECT_TOTAL_AMOUNT,
    key: Labels.PROJECT_TOTAL_AMOUNT,
    width: 15,
  },
  ...yearMonthKeys.map((yearMonthKey, index) => ({
    header: monthKeys[index],
    key: yearMonthKey,
    width: 15,
  })),
]

export const exportDataOperationCostPlanByProjectsUseCase = async (data: {
  from: string
  to: string
  items: OperationCostPlanProject[]
}): Promise<string> => {
  if (!data.items || data.items.length === 0) {
    throw new CustomError(messages.exportDatanotExists, 'Not Found')
  }

  const fromDate = new Date(data.from)
  const toDate = new Date(data.to)
  const monthKeys = getMonthRange(fromDate, toDate)
  const yearKeys = getYearRange(fromDate, toDate)
  const yearMonthKeys = getYearMonthRange(fromDate, toDate)

  let startRow = 3
  const dataRows: string[][] = []
  const mergeCellList: MergeCell[] = []
  const fillColorRowList: number[] = []

  data.items.map((i) => {
    const projectEndDate = i.projectEndDate ? i.projectEndDate : ''
    const projectName = `${i.projectName} (${i.projectStartDate}〜${projectEndDate})`

    let sums: { [key: string]: SPItem[] } = {}
    if (!i.personnel || i.personnel.length <= 0) {
      dataRows.push(getEmptyRow(projectName, yearMonthKeys))
    } else {
      const [s, rows] = getRowValues(i, projectName, yearMonthKeys)
      dataRows.push(...rows)
      sums = s
    }

    dataRows.push(getCostRow(sums, yearMonthKeys))

    const endRow = 3 + dataRows.length - 1
    mergeCellList.push({
      startRow: startRow,
      startColumn: 1,
      endRow: endRow,
      endColumn: 1,
    })
    mergeCellList.push({
      startRow: endRow,
      startColumn: 2,
      endRow: endRow,
      endColumn: 3,
    })
    mergeCellList.push({
      startRow: startRow,
      startColumn: 4,
      endRow: endRow - 1,
      endColumn: 4,
    })
    fillColorRowList.push(endRow)

    startRow = endRow + 1
  })

  const workbook = new ExcelJS.Workbook()
  const worksheet = workbook.addWorksheet(SHEET_NAME.OPERATION_COST_PLAN)
  const columns = sheetColumns(yearMonthKeys, monthKeys)

  worksheet.addRow([''])

  const rowValues = [
    Labels.YEAR_MONTH,
    `${convertDateToYYYYMM(fromDate)} 〜 ${convertDateToYYYYMM(toDate)}`,
    '',
    '',
    ...yearKeys.map((yearKeys) => yearKeys),
  ]
  worksheet.addRow(rowValues)
  worksheet.addRow(columns.map((col) => col.header))
  worksheet.addRows(dataRows)

  // Apply column widths after adding rows
  worksheet.columns = columns

  applyBordersToCells(worksheet)

  styleRow(worksheet, 2)
  styleRow(worksheet, 3)
  worksheet.views = [{ state: 'frozen', ySplit: 2 }]
  worksheet.spliceRows(1, 1)

  mergeCells(worksheet, 1, 2, 1, 4)
  mergeCellList.forEach((cell) => {
    mergeCells(
      worksheet,
      cell.startRow,
      cell.startColumn,
      cell.endRow,
      cell.endColumn
    )
  })

  fillColorRowList.forEach((row) => {
    styleTotalRowWithStartCol(worksheet, row, 2)
  })

  mergeYearHeaderCells(worksheet, fromDate, toDate, 5)

  adjustColumnWidths(worksheet)

  const projectTotalWidth =
    worksheet.columns.find((col) => col.key === Labels.PROJECT_TOTAL_AMOUNT)
      ?.width ?? 0
  worksheet.columns.forEach((column) => {
    if (!column) return

    const key = column.key
    if (key?.includes && yearMonthKeys.includes(key)) {
      column.width = projectTotalWidth
    }
  })
  worksheet.eachRow((row) => {
    row.eachCell((cell) => {
      if (cell.value === Labels.TOTAL_ALL) {
        // Center align if the cell value matches any of the labels
        cell.alignment = {
          vertical: 'middle',
          horizontal: 'center',
          wrapText: true,
        }
      } else {
        // Left align if the cell value does not match any of the labels
        cell.alignment = {
          vertical: 'middle',
          horizontal: 'left',
          wrapText: true,
        }
      }
    })
  })

  const excelBuffer = await workbook.xlsx.writeBuffer()
  const buffer = Buffer.from(excelBuffer)
  const fileName = `${FILE_NAME.OPERATION_COST_PLAN}${uuidv4()}.xlsx`
  const url = await uploadFileToAzureBlob(buffer, fileName)

  return url
}
