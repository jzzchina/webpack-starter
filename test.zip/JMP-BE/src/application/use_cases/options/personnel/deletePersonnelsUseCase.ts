import CustomError from '../../../errors/CustomError'
import messages from '../../../errors/messages'
import { PersonnelRepositoryPort } from './../../../port/repositories/personnel/PersonnelRepositoryPort'
import logger from '../../../../infrastructure/logger/logger'

export const deletePersonnelsUseCase = async (
  personnelIds: number[],
  personnelRepository: Pick<
    PersonnelRepositoryPort,
    'deletePersonnels' | 'findPersonnelByAssignment'
  >
): Promise<void> => {
  const assignedPersonnel = await personnelRepository.findPersonnelByAssignment(
    personnelIds
  )
  logger.debug('Delete Personnel ids' + JSON.stringify(assignedPersonnel))

  if (assignedPersonnel > 0) {
    throw new CustomError(messages.personnelIsAssigned, 'Bad Request')
  }
  return personnelRepository.deletePersonnels(personnelIds)
}
