import { OperationPlanRepositoryPort } from '../../../port/repositories/operationPlan/OperationPlanRepositoryPort'

import { SearchExistenceOfOperationResponse } from '../../../../interface/routes/options/personnel/dto/personnel.dto'
import { Dw_t_operation_plan } from '../../../../infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import { OperationCostRepositoryPort } from '../../../port/repositories/operationCost/OperationCostRepositoryPort'
import { Dw_t_operation } from '../../../../infrastructure/orm/typeorm/entities/Dw_t_operation'
import { PersonnelRepositoryPort } from '../../../port/repositories/personnel/PersonnelRepositoryPort'
import { Dw_m_personnel } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_personnel'
import CustomError from '../../../errors/CustomError'
import messages from '../../../errors/messages'

export const searchExistenceOfOperationUseCase = async (
  from: string,
  to: string,
  personnelId: number,
  personnelRepository: Pick<PersonnelRepositoryPort, 'findOneById'>,
  operationPlanRepository: Pick<
    OperationPlanRepositoryPort,
    'findOperationPlansByPersonnelId'
  >,
  operationCostRepository: Pick<
    OperationCostRepositoryPort,
    'searchOperationCostsByPersonnelId'
  >
): Promise<SearchExistenceOfOperationResponse> => {
  const personnel: Dw_m_personnel | null = await personnelRepository.findOneById(
    personnelId
  )
  if (!personnel) {
    throw new CustomError(messages.personnelDoesNotExist, 'Not Found')
  }

  const [operationPlanResp, operationCostResp]: [
    Dw_t_operation_plan[],
    Dw_t_operation[]
  ] = await Promise.all([
    operationPlanRepository.findOperationPlansByPersonnelId(
      from,
      to,
      personnelId
    ),

    operationCostRepository.searchOperationCostsByPersonnelId(
      from,
      to,
      personnelId
    ),
  ])

  return {
    operationPlan: !!operationPlanResp.length,
    operation: !!operationCostResp.length,
  }
}
