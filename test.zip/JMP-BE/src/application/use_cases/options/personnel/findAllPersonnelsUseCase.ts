import { PersonnelRepositoryPort } from '../../../port/repositories/personnel/PersonnelRepositoryPort'
import {
  PaginatedPersonnelList,
  PersonnelSearchCriteria,
} from '../../../../domain/models/Personnel'

import { FindAllPersonnelSQLResponse } from '../../../../infrastructure/repositories/options/personnel/interface'

import { buildFindAllPersonnelResponse } from '../../../helpers/project.helpers'
import logger from '../../../../infrastructure/logger/logger'

/**
 * @description use case to find all personnel with search criteria
 * @param searchCriteria the search criteria used to find personnel
 * @param personnelRepository  the repository used to get services to find personnel
 * @returns  object of personnel list response in specific format
 */
export const findAllPersonnelUseCase = async (
  searchCriteria: PersonnelSearchCriteria,
  personnelRepository: Pick<PersonnelRepositoryPort, 'findAll'>
): Promise<PaginatedPersonnelList> => {
  // destructuring the result from personnel repository
  const {
    result,
    count,
  }: FindAllPersonnelSQLResponse = await personnelRepository.findAll(
    searchCriteria
  )
  const { limit, offset } = searchCriteria

  const resultLimit: number = (() => {
    if (limit !== undefined && limit !== null && !Number.isNaN(limit)) {
      return limit
    } else {
      return count
    }
  })()
  const resultOffset: number = (() => {
    if (offset !== undefined && offset !== null && !Number.isNaN(offset)) {
      // if valid, set the result offset to offset
      return offset
    } else {
      // if not valid, set the result offset to 0
      return 0
    }
  })()

  logger.debug('Find All Personnel ' + JSON.stringify(result))
  // build the result in specific format and return it
  return buildFindAllPersonnelResponse(result, resultLimit, resultOffset, count)
}
