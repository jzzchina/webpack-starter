import { PersonnelRepositoryPort } from '../../../port/repositories/personnel/PersonnelRepositoryPort'

import { Dw_m_personnel } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_personnel'

import {
  Personnel,
  PersonnelCreateResponse,
} from '../../../../interface/routes/options/personnel/dto/personnel.dto'
import {
  buildPersonnelCreateQuery,
  buildPersonnelIdentifiers,
  buildPersonnelResponse,
} from '../../../helpers/personnel.helpers'
import logger from '../../../../infrastructure/logger/logger'

/**
 * @description use case to create personnel
 * @param personnelList  list of personnel data to be created
 * @param userInformation  user information that will be used to create personnel
 * @param PersonnelRepositoryPort  repository to get services to create personnel
 * @returns  list of personnel that were created
 */
export const createPersonnelUseCase = async (
  personnelList: Personnel[],
  userInformation: Record<string, unknown>,
  PersonnelRepositoryPort: Pick<PersonnelRepositoryPort, 'findMany' | 'create'>
): Promise<PersonnelCreateResponse[]> => {
  const insertResult = await PersonnelRepositoryPort.create(
    buildPersonnelCreateQuery(personnelList, userInformation)
  )
  logger.debug('Create Personnel ids' + JSON.stringify(insertResult))
  const listOfPersonnelIds: number[] = (() => {
    if (insertResult !== undefined) {
      return buildPersonnelIdentifiers(insertResult)
    }
    return []
  })()

  const result: Dw_m_personnel[] = await PersonnelRepositoryPort.findMany(
    listOfPersonnelIds
  )
  logger.debug('Create Personnel list' + JSON.stringify(result))
  return buildPersonnelResponse(result)
}
