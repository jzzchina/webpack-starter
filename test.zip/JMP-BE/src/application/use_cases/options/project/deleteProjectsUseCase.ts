import { ProjectRepositoryPort } from '../../../port/repositories/project/ProjectRepositoryPort'

export const deleteProjectsUseCase = async (
  projectIds: number[],
  repository: Pick<ProjectRepositoryPort, 'deleteProjects'>
): Promise<void> => {
  await repository.deleteProjects(projectIds)
}
