import { ProjectSearchCriteria } from '../../../../domain/models/Project'
import { ProjectListResponse } from '../../../../interface/routes/options/project/dto/projects.dto'
import { buildProjectListResponse } from '../../../helpers/project.helpers'
import { OperationCostRepositoryPort } from '../../../port/repositories/operationCost/OperationCostRepositoryPort'
import { ProjectRepositoryPort } from '../../../port/repositories/project/ProjectRepositoryPort'
import logger from '../../../../infrastructure/logger/logger'

export const findAllProjectsUseCase = async (
  projectRepository: Pick<ProjectRepositoryPort, 'findAll'>,
  operationCostRepository: Pick<
    OperationCostRepositoryPort,
    'searchOperationCostsByProjectId'
  >,
  searchCriteria: ProjectSearchCriteria
): Promise<Partial<ProjectListResponse>> => {
  const { result, count } = await projectRepository.findAll(searchCriteria)
  const { limit, offset } = searchCriteria

  const resultLimit = (() => {
    if (limit !== undefined && limit !== null && !Number.isNaN(limit)) {
      return limit
    } else {
      return count
    }
  })()

  const resultOffset = (() => {
    if (offset !== undefined && offset !== null && !Number.isNaN(offset)) {
      return offset
    } else {
      return 0
    }
  })()

  const operationsByProjectPromises = result.map(async ({ project_id }) => ({
    project_id,
    operations: await operationCostRepository.searchOperationCostsByProjectId(
      project_id
    ),
  }))
  const operationsByProject = await Promise.all(operationsByProjectPromises)
  logger.debug('All Projects ' + JSON.stringify(result))
  return buildProjectListResponse(
    result,
    resultLimit,
    resultOffset,
    count,
    operationsByProject
  )
}
