import {
  CreateProjectDto,
  ProjectDtoResponse,
} from '../../../../interface/routes/options/project/dto/projects.dto'
import { ProjectRepositoryPort } from '../../../port/repositories/project/ProjectRepositoryPort'
import { Dw_m_project } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_project'
import {
  buildProjectDtoResponse,
  buildProjectsCreateQueryParams,
  buildWbsListQueryParams,
} from '../../../helpers/project.helpers'
import { Dw_m_wbs } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_wbs'
import { WbsRepositoryPort } from '../../../port/repositories/wbs/wbsRepositoryPort'
import logger from '../../../../infrastructure/logger/logger'

export const createProjectsUseCase = async (
  userName: string,
  projectList: CreateProjectDto[],
  repository: Pick<ProjectRepositoryPort, 'createProjects'>,
  wbsRepository: Pick<WbsRepositoryPort, 'createWbs'>
): Promise<ProjectDtoResponse[]> => {
  const projectsToBeInserted = buildProjectsCreateQueryParams(
    projectList,
    userName
  )
  const entities = (await repository.createProjects(
    projectsToBeInserted
  )) as Dw_m_project[]
  logger.debug('Create Projects ' + JSON.stringify(entities))

  const projectIds = entities.map((project) => project.project_id)

  const wbsObject = buildWbsListQueryParams(projectIds, projectList, userName)

  const wbsAddedList = (await wbsRepository.createWbs(wbsObject)) as Dw_m_wbs[]

  return entities.map((el) => buildProjectDtoResponse(el, wbsAddedList))
}
