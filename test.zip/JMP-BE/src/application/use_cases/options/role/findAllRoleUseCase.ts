import {
  Role,
  RoleListResponse,
} from './../../../../infrastructure/repositories/options/role/interface'
import { RoleRepositoryPort } from '../../../port/repositories/role/RoleRepositoryPort'
import { Dw_m_role } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_role'
/**
 * @description use case for finding all roles
 * @param roleRepository  repository to get service used for finding all roles
 * @returns  object of role list response in specific format
 */
export const findAllRolesUseCase = async (
  roleRepository: Pick<RoleRepositoryPort, 'findAll'>
): Promise<RoleListResponse> => {
  // get all roles from role repository
  const roles = await roleRepository.findAll()
  // build the result in specific format and return it
  return buildRoleListResponse(roles)
}
/**
 * @description build the response object for role list in specific format
 * @param roles  the role list was found from database
 * @returns  object of role list response in specific format
 */
const buildRoleListResponse = (
  roles: Partial<Dw_m_role>[]
): Partial<RoleListResponse> => {
  return {
    // return the result in specific format
    items: roles?.map((role) => ({
      roleId: role?.role_id,
      roleName: role?.role_name,
    })) as Role[],
  }
}
