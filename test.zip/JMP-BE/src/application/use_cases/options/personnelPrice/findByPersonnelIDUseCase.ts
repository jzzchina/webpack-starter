import { Dw_m_personnel_price } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_personnel_price'
import { PersonnelPriceList } from '../../../../interface/routes/options/personnelPrice/dto/personnelPrice.dto'
import { buildPersonnelPricesList } from '../../../helpers/personnelPrice.helpers'
import { PersonnelPriceRepositoryPort } from '../../../port/repositories/personnelPriceRepositoryPort.ts/PersonnelPriceRepositoryPort'
import logger from '../../../../infrastructure/logger/logger'
export const findByPersonnelIDUseCase = async (
  personnelId: number,
  personnelPriceRepository: Pick<
    PersonnelPriceRepositoryPort,
    'findByPersonnelID'
  >
): Promise<PersonnelPriceList> => {
  const personnelPrices: Dw_m_personnel_price[] = await personnelPriceRepository.findByPersonnelID(
    personnelId
  )
  logger.debug('Personnel Price list ' + JSON.stringify(personnelPrices))
  return buildPersonnelPricesList(personnelPrices)
}
