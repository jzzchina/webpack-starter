import { InsertResult } from 'typeorm'

import { PersonnelPrice } from '../../../../domain/models/PersonnelPrice'
import { PersonnelPriceRepositoryPort } from '../../../port/repositories/personnelPriceRepositoryPort.ts/PersonnelPriceRepositoryPort'
import {
  buildPersonnelPricesDTO,
  buildPersonnelPricesResponse,
  updateOperationCost,
} from '../../../helpers/personnelPrice.helpers'
import { OperationCostRepositoryPort } from '../../../port/repositories/operationCost/OperationCostRepositoryPort'
import logger from '../../../../infrastructure/logger/logger'

export const createPersonnelPriceUseCase = async (
  personnelPrices: PersonnelPrice[],
  userInfo: Record<string, unknown>,
  personnelPriceRepository: Pick<
    PersonnelPriceRepositoryPort,
    'createPersonnelPrice' | 'findMany'
  >,
  operationCostRepository: Pick<
    OperationCostRepositoryPort,
    'updateCostAmountByPersonnelAndDate'
  >
): Promise<PersonnelPrice[]> => {
  const personnelPricesToBeCreated = buildPersonnelPricesDTO(
    personnelPrices,
    userInfo
  )
  const creationResult = await personnelPriceRepository.createPersonnelPrice(
    personnelPricesToBeCreated
  )
  logger.debug('Create Personnel Price ' + JSON.stringify(creationResult))

  const identifiers = (creationResult as InsertResult).identifiers.map(
    (item) => item.personnel_price_id
  )
  const personnelPricesCreated = await personnelPriceRepository.findMany(
    identifiers
  )
  logger.debug('Create Personnel Price ' + JSON.stringify(creationResult))

  await updateOperationCost(personnelPricesToBeCreated, operationCostRepository)
  return buildPersonnelPricesResponse(personnelPricesCreated)
}
