import { PersonnelPriceKey } from '../../../../infrastructure/repositories/options/personnelPrice/interface'
import { PersonnelPriceRepositoryPort } from '../../../port/repositories/personnelPriceRepositoryPort.ts/PersonnelPriceRepositoryPort'

export const deletePersonnelPriceUseCase = async (
  personnelId: number,
  priceStartDate: string,
  personnelPriceRepository: Pick<PersonnelPriceRepositoryPort, 'delete'>
): Promise<void> => {
  const personnelPriceKey: PersonnelPriceKey = {
    personnel_id: personnelId,
    price_start_date: new Date(priceStartDate),
  }
  await personnelPriceRepository.delete(personnelPriceKey)
}
