import { PartnerCompanyRepositoryPort } from '../../../port/repositories/partnerCompany/PartnerCompanyRepositoryPort'
import { Dw_m_partner_company } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_partner_company'

import {
  PartnerCompanyBodyRequest,
  PartnerCompanyCreateResponse,
} from '../../../../interface/routes/options/partnerCompany/dto/partnerCompany.dto'
import {
  buildPartnerCompanyCreateQuery,
  buildPartnerCompanyIdentifiers,
  buildPartnerCompanyResponse,
  salesManQueryParser,
} from '../../../helpers/partnerCompany.helpers'
import { SalesManRepositoryPort } from '../../../port/repositories/salesMan/SalesManRepositoryPort'
import { SalesMan } from '../../../../domain/models/SalesMan'
import { salesManIdentifierBuilder } from '../../../helpers/salesMan.helpers'
import logger from '../../../../infrastructure/logger/logger'

/**
 * @description the use case that will be used to create partner company from the repository and return the created partner company
 * @param companyList
 * @param userInformation
 * @param PartnerCompanyRepositoryPort
 * @returns  the list of partner company that were created
 */
export const createPartnerCompanyUseCase = async (
  companyList: PartnerCompanyBodyRequest[],
  userInformation: Record<string, unknown>,
  PartnerCompanyRepositoryPort: Pick<
    PartnerCompanyRepositoryPort,
    'findMany' | 'create'
  >,
  salesManRepositoryPort: Pick<
    SalesManRepositoryPort,
    'createSalesMan' | 'findSalesManByIds'
  >
): Promise<PartnerCompanyCreateResponse[]> => {
  // the function returns a list of partner company
  const insertResult = await PartnerCompanyRepositoryPort.create(
    buildPartnerCompanyCreateQuery(companyList, userInformation)
  )
  logger.debug('Create Partner Company ids ' + JSON.stringify(insertResult))

  const listOfCompanyIds: number[] = (() => {
    if (insertResult !== undefined) {
      return buildPartnerCompanyIdentifiers(insertResult)
    }
    return []
  })()
  if (insertResult === undefined) {
    return []
  }
  const salesManList: SalesMan[] = companyList.flatMap((item) => item.salesMan)
  const salesManInsertResult = await salesManRepositoryPort.createSalesMan(
    salesManQueryParser(insertResult, salesManList, userInformation)
  )
  const salesManIds = salesManIdentifierBuilder(salesManInsertResult)
  logger.debug('Sales man ids ' + JSON.stringify(salesManIds))

  const CreatedSalesManList = await salesManRepositoryPort.findSalesManByIds(
    salesManIds
  )
  // get the created partner companies by the builded identifiers
  const result: Dw_m_partner_company[] = await PartnerCompanyRepositoryPort.findMany(
    listOfCompanyIds
  )
  logger.debug('created partner companies ' + JSON.stringify(result))
  // build the response that will be returned
  return buildPartnerCompanyResponse(result, CreatedSalesManList)
}
