import { PartnerCompanyRepositoryPort } from '../../../port/repositories/partnerCompany/PartnerCompanyRepositoryPort'
/**
 * @description the use case that will be used to delete partner companies from the repository
 * @param companyIds  the list of company ids that will be used to delete the partner companies
 * @param partnerCompanyRepository  repository that will be used to delete the partner companies
 * @returns  void
 */
export const deletePartnerCompaniesUseCase = async (
  companyIds: number[],
  partnerCompanyRepository: Pick<
    PartnerCompanyRepositoryPort,
    'deletePartnerCompanies'
  >
): Promise<void> => {
  // the function returns nothing and will delete the partner companies from the repository
  return partnerCompanyRepository.deletePartnerCompanies(companyIds)
}
