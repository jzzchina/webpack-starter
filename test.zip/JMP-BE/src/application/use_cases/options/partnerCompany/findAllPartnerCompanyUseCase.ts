import { PartnerCompanyRepositoryPort } from '../../../port/repositories/partnerCompany/PartnerCompanyRepositoryPort'
import { PartnerCompanyListResponse } from '../../../../interface/routes/options/partnerCompany/dto/partnerCompany.dto'
import { buildPartnerCompanyListResponse } from '../../../helpers/partnerCompany.helpers'
import logger from '../../../../infrastructure/logger/logger'
/**
 * @description the use case that will be used to find all partner company under specific conditions
 * @param partnerCompanyRepository  repository that will be used to find all partner company
 * @param companyId  the id of the company that belongs to the partner company for filtering
 * @param companyName  the name of the company that belongs to the partner company for filtering
 * @param contractPatternCode  the code of the contract pattern that belongs to the partner company for filtering
 * @param limit  the limit of the result
 * @param offset  the offset of the result
 * @returns  object of partner company list response in specific format
 */
export const findAllPartnerCompanyUseCase = async (
  partnerCompanyRepository: Pick<PartnerCompanyRepositoryPort, 'findAll'>,
  companyId: number,
  companyName: string,
  contractPatternCode: number,
  limit: number,
  offset: number
): Promise<Partial<PartnerCompanyListResponse>> => {
  const { result, count } = await partnerCompanyRepository.findAll(
    companyId,
    companyName,
    contractPatternCode,
    limit,
    offset
  )
  const resultOffset: number = (() => {
    if (offset !== undefined && offset !== null && !Number.isNaN(offset)) {
      return offset
    } else {
      return 0
    }
  })()
  logger.debug('Partner Company Lists ' + JSON.stringify(result))
  return buildPartnerCompanyListResponse(result, resultOffset, count)
  // build and return the result in specific format
}
