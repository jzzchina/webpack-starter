import { v4 as uuidv4 } from 'uuid'
import { uploadFileToAzureBlob } from '../../../infrastructure/azure/config/azureBlobStorageConnection'
import CustomError from '../../errors/CustomError'
import messages from '../../errors/messages'
import ExcelJS from 'exceljs'
import Labels, {
  FILE_NAME,
  SHEET_NAME,
} from '../../common/exportFeatures/labels'
import {
  applyBordersToCells,
  styleRow,
} from '../../common/exportFeatures/excelStyling'
import {
  OperationPlanPersonnel,
  OperationPlanProject,
} from '../../../infrastructure/repositories/operationPlan/interface'
import {
  getMonthRange,
  getYearMonthRange,
  getYearRange,
  mergeCells,
  mergeYearHeaderCells,
} from '../../common/exportFeatures/common'
import { RowData } from '../../common/exportFeatures/interface'
import logger from '../../../infrastructure/logger/logger'
import { TOTAL_CELL_STYLE } from '../../common/exportFeatures/constant'

const getValueOrDefault = (
  value: string | number | Date | null,
  defaultValue = ''
): string =>
  value !== undefined && value !== null ? String(value) : defaultValue

const transformPersonData = (
  person: OperationPlanPersonnel,
  yearMonthKeys: string[]
) => {
  if (!person.projects) {
    return []
  }

  return person.projects.flatMap((project: OperationPlanProject): RowData[] => {
    const row: RowData = {
      [Labels.COMPANY_NAME]: getValueOrDefault(person.companyName),
      [Labels.NAME]: `${getValueOrDefault(person.name)}\n${getValueOrDefault(
        person.nameJpn
      )}`,
      [Labels.PROJECT_NAME]: `${getValueOrDefault(
        project.projectName
      )}(${getValueOrDefault(project.projectStartDate)}~${getValueOrDefault(
        project.projectEndDate
      )})`,
    }

    yearMonthKeys.forEach((yearMonthKeys) => {
      const manMonthNumber =
        project.operationPlans?.[yearMonthKeys]?.manMonthNumber
      row[`${yearMonthKeys}_manMonthNumber`] = manMonthNumber || 0
      row[`${yearMonthKeys}`] = manMonthNumber || 0
    })
    row[`TotalByProject`] = Object.values(project.operationPlans || {})
      .reduce((acc, curr) => {
        return acc + (curr?.manMonthNumber || 0)
      }, 0)
      .toFixed(2)
    return [row]
  })
}

export const exportDataOperationPlanByPersonnelsUseCase = async (data: {
  from: string
  to: string
  items: OperationPlanPersonnel[]
}): Promise<string> => {
  if (!data.items || data.items.length === 0) {
    throw new CustomError(messages.exportDatanotExists, 'Not Found')
  }

  const fromDate = new Date(data.from)
  const toDate = new Date(data.to)
  const monthKeys = getMonthRange(fromDate, toDate)
  const yearKeys = getYearRange(fromDate, toDate)
  const yearMonthKeys = getYearMonthRange(fromDate, toDate)

  const flattenedData = data.items.flatMap((person) =>
    transformPersonData(person, yearMonthKeys)
  )
  const columns = [
    { header: Labels.COMPANY_NAME, key: Labels.COMPANY_NAME, width: 16 },
    { header: Labels.NAME, key: Labels.NAME, width: 16 },
    { header: Labels.PROJECT_NAME, key: Labels.PROJECT_NAME, width: 29 },
    ...yearMonthKeys.map((yearMonthKey, index) => ({
      header: monthKeys[index], // Use monthKey as the header
      key: yearMonthKey, // Use yearMonthKey as the key for the column
      width: 10,
    })),
    { header: '', key: '', width: 10 },
  ]

  const workbook = new ExcelJS.Workbook()
  const worksheet = workbook.addWorksheet(SHEET_NAME.OPERATION_PLAN)
  worksheet.addRow([''])
  const fromYearMonth = `${fromDate.getFullYear()}-${(
    '0' +
    (fromDate.getMonth() + 1)
  ).slice(-2)}`
  const toYearMonth = `${toDate.getFullYear()}-${(
    '0' +
    (toDate.getMonth() + 1)
  ).slice(-2)}`

  const rowValues = [
    Labels.YEAR_MONTH,
    `${fromYearMonth} 〜 ${toYearMonth}`,
    '',
    ...yearKeys.map((yearKeys) => yearKeys),
    Labels.TOTAL,
  ]
  worksheet.addRow(rowValues)
  worksheet.addRow(columns.map((col) => col.header))

  flattenedData.forEach((row) => {
    worksheet.addRow([
      row[Labels.COMPANY_NAME],
      row[Labels.NAME],
      row[Labels.PROJECT_NAME],
      ...yearMonthKeys.map(
        (yearMonthKey) => row[`${yearMonthKey}_manMonthNumber`]
      ),
      row[`TotalByProject`],
    ])
  })

  const sumByMonths = {}
  yearMonthKeys.forEach((row) => {
    const rowIndex: string = row.toString()
    Object.assign(sumByMonths, {
      [rowIndex]: flattenedData
        .reduce((acc, curr) => {
          return acc + Number(curr[rowIndex])
        }, 0)
        .toFixed(2),
    })
  })
  const totalOverall = flattenedData
    .reduce((acc, curr) => {
      return acc + Number(curr[`TotalByProject`])
    }, 0)
    .toFixed(2)
  worksheet.addRow([
    Labels.TOTAL,
    '',
    '',
    ...Object.values(sumByMonths),
    totalOverall,
  ])

  // Apply column widths after adding rows
  worksheet.columns = columns

  applyBordersToCells(worksheet)
  styleRow(worksheet, 2)
  styleRow(worksheet, 3)
  worksheet.views = [{ state: 'frozen', ySplit: 2 }]
  worksheet.spliceRows(1, 1)
  mergeCells(worksheet, 1, 2, 1, 3)
  const rowCount = worksheet.rowCount
  mergeYearHeaderCells(worksheet, fromDate, toDate)
  mergeCells(worksheet, rowCount, 0, rowCount, 3)
  worksheet.getRow(rowCount).getCell(1).style = TOTAL_CELL_STYLE

  // Apply cell alignment
  worksheet.eachRow({ includeEmpty: true }, (row, rowNumber) => {
    row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
      if (colNumber <= 3 || rowNumber <= 2) {
        cell.alignment = {
          horizontal: 'left',
          vertical: 'middle',
          wrapText: true,
        }
      } else {
        cell.alignment = {
          horizontal: 'center',
          vertical: 'middle',
          wrapText: true,
        }
      }
    })
  })

  // Generate a unique file name
  const fileName = `${FILE_NAME.OPERATION_PLAN}${uuidv4()}.xlsx`
  logger.info(`Uploading file to Azure Blob Storage: ${fileName}`)
  const excelBuffer = await workbook.xlsx.writeBuffer()
  const buffer = Buffer.from(excelBuffer)
  //Upload the buffer to Azure Blob Storage
  const fileUrl = await uploadFileToAzureBlob(buffer, fileName)
  return fileUrl
}
