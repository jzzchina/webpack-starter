import { OperationPlanRepositoryPort } from '../../../application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { OperationPlan } from '../../../domain/models/OperationPlan'
import { OperationCostRepositoryPort } from '../../port/repositories/operationCost/OperationCostRepositoryPort'
import CustomError from '../../errors/CustomError'
import messages from '../../errors/messages'

export const deleteMultiOperationPlanUseCase = async (
  inputs: Partial<OperationPlan>[],
  operationPlanRepository: Pick<
    OperationPlanRepositoryPort,
    'deleteOperationPlans' | 'findMany'
  >,
  operationRepository: Pick<
    OperationCostRepositoryPort,
    'findOperationBelongsToOperationPlan'
  >
): Promise<void | CustomError> => {
  const operationBelongsToOperationPlan = await operationRepository.findOperationBelongsToOperationPlan(
    inputs.map((item) => item.personnel_id) as number[],
    inputs.map((item) => item.project_id) as number[]
  )
  const existingOperationPlan = await operationPlanRepository.findMany(inputs)
  if (existingOperationPlan?.length != inputs.length) {
    throw new CustomError(messages.recordsDoesNotExist, 'Not Found')
  }

  if (operationBelongsToOperationPlan) {
    throw new CustomError(
      messages.operationPerformanceExist,
      'Method Not Allowed'
    )
  }

  return operationPlanRepository.deleteOperationPlans(inputs)
}
