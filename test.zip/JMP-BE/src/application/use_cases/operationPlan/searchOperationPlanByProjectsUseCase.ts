import { OperationPlanRepositoryPort } from '../../port/repositories/operationPlan/OperationPlanRepositoryPort'
import { SkillList } from '../../../domain/models/Personnel'
import { OperationPlanProjectResponse } from '../../../infrastructure/repositories/operationPlan/interface'
import { buildOperationPlanProjectResponseObject } from '../../helpers/operationPlan.helpers'

/**
 * @description use case to search operation plan by projects
 * @param to  to date of project end date
 * @param from  from date of project start date
 * @param offset  offset used for pagination
 * @param limit  limit used for pagination
 * @param projectId  project id that is used for filtering
 * @param companyId  company id that is used for filtering
 * @param skills    JSON object of skills that is used for filtering
 * @param operationPlanRepository  repository to get services used for searching operation plan by projects
 * @returns  object of operation plan by projects response in specific format
 */
export const searchOperationPlanByProjectsUseCase = async (
  to: string,
  from: string,
  offset: number,
  limit: number,
  projectId: number | null,
  companyId: number | null,
  skills: SkillList,
  operationPlanRepository: Pick<
    OperationPlanRepositoryPort,
    'findOperationPlansByProject'
  >
): Promise<OperationPlanProjectResponse> => {
  // destructuring the result from operation plan repository
  const {
    items,
    totalItems,
  } = await operationPlanRepository.findOperationPlansByProject(
    to,
    from,
    offset,
    limit,
    projectId,
    companyId,
    skills
  )
  // build the result in specific format
  return buildOperationPlanProjectResponseObject(
    items,
    totalItems,
    to,
    from,
    offset
  )
}
