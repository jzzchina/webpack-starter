import { InsertResult } from 'typeorm'
import { OperationPlanRepositoryPort } from '../../port/repositories/operationPlan/OperationPlanRepositoryPort'
import { Dw_t_operation_plan } from '../../../infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import {
  CreateOperationPlanDto,
  CreateOperationPlanResponse,
} from '../../../interface/routes/operationPlan/dto/operationPlans.dto'
import {
  buildCreateOperationPlanResponse,
  buildOperationPlanCreateQueryParams,
} from '../../helpers/operationPlan.helpers'
import { overWorkValidation } from '../../common/services/operationPlan'
import CustomError from '../../errors/CustomError'
import logger from '../../../infrastructure/logger/logger'
import messages from '../../errors/messages'

export const createOperationPlanUseCase = async (
  operationPlanInput: CreateOperationPlanDto[],
  OperationPlanRepository: Pick<
    OperationPlanRepositoryPort,
    'findMany' | 'create' | 'findAllOperationPlansByPersonnelId'
  >,
  userInformation: Record<string, unknown>
): Promise<CreateOperationPlanResponse[]> => {
  const operationPlanCreateListInputParams = buildOperationPlanCreateQueryParams(
    operationPlanInput,
    userInformation
  )
  if (operationPlanInput.length != 0) {
    logger.info('Start the validation for the over work')
    const overWorkResult = await overWorkValidation(
      operationPlanInput,
      OperationPlanRepository
    )
    if (!overWorkResult) {
      console.error(
        'Overwork validation failed. There were records that reaches more than 1.0 total.'
      )
      throw new CustomError(messages.totalValueExceedsOne, 'Bad Request')
    }
    logger.info('The validation for the over work passed!')

    const createOperationPlanResult: InsertResult | void = await OperationPlanRepository.create(
      operationPlanCreateListInputParams
    )
    if (!createOperationPlanResult) {
      return []
    }
    const identifiers = (createOperationPlanResult as InsertResult).identifiers.map(
      (item) => ({
        operation_plan_id: item.operation_plan_id,
        month_of_year_date: item.month_of_year_date,
      })
    )
    const insertedOperationPlans: Partial<Dw_t_operation_plan>[] = await OperationPlanRepository.findMany(
      identifiers
    )
    return buildCreateOperationPlanResponse(insertedOperationPlans)
  }
  return []
}
