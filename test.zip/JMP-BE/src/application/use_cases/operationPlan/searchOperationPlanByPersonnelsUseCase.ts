import { OperationPlanRepositoryPort } from '../../port/repositories/operationPlan/OperationPlanRepositoryPort'
import { SkillList } from '../../../domain/models/Personnel'
import { OperationPlanPersonnelResponse } from '../../../infrastructure/repositories/operationPlan/interface'
import { buildOperationPlanPersonnelResponseObject } from '../../helpers/operationPlan.helpers'
/**
 *
 * @param to to date of unregister date of personnel
 * @param from  from date of registered date of personnel
 * @param offset  offset used for pagination
 * @param limit  limit used for pagination
 * @param projectId  project id that is used for filtering
 * @param companyId  company id that is used for filtering
 * @param skills  a JSON object that contains skill name and skill level to filter personnel
 * @param operationPlanRepository  repository to get services used for searching operation plan by personnel
 * @returns object of operation plan by personnel response in specific format
 */
export const searchOperationPlanByPersonnelsUseCase = async (
  to: string,
  from: string,
  offset: number,
  limit: number,
  projectId: number | null,
  companyId: number | null,
  skills: SkillList,
  operationPlanRepository: Pick<
    OperationPlanRepositoryPort,
    'findOperationPlansByPersonnel'
  >
): Promise<OperationPlanPersonnelResponse> => {
  // destructuring the result from operation plan repository
  const {
    items,
    totalItems,
  } = await operationPlanRepository.findOperationPlansByPersonnel(
    to,
    from,
    offset,
    limit,
    projectId,
    companyId,
    skills
  )
  // return the result in specific format
  return buildOperationPlanPersonnelResponseObject(
    items,
    totalItems,
    to,
    from,
    offset
  )
}
