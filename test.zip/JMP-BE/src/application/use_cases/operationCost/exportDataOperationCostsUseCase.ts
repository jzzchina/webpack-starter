import { v4 as uuidv4 } from 'uuid'
import { uploadFileToAzureBlob } from '../../../infrastructure/azure/config/azureBlobStorageConnection'
import CustomError from '../../errors/CustomError'
import messages from '../../errors/messages'
import ExcelJS from 'exceljs'
import Labels, {
  FILE_NAME,
  SHEET_NAME,
} from '../../common/exportFeatures/labels'
import {
  applyBordersToCells,
  styleRow,
  styleTotalRowWithStartCol,
} from '../../common/exportFeatures/excelStyling'
import {
  getMonthRange,
  getYearMonthRange,
  getYearRange,
  mergeCells,
  mergeYearHeaderCells,
} from '../../common/exportFeatures/common'
import {
  DEFAULT_BUSINESS_DAYS,
  DEFAULT_WORK_TIME_OF_DAY,
  currencySymbols,
  exportConstantValues,
} from '../../common/exportFeatures/constant'
import {
  OperationCostListResponse,
  ProjectOperationCost,
} from '../../../interface/routes/operationCost/dto/operationCost.dto'
import { PersonnelPrice } from '../../../domain/models/PersonnelPrice'
import { convertDateToYYYYMM } from '../../common/common'
import { BusinessDaysObject } from '../../../interface/routes/businessDays/dto/businessDays.dto'

type SumResult = {
  [key: string]: {
    sumFirst?: number
    sumSecond?: number
    sum?: number
  }
}

type MergeCell = {
  startRow: number
  startColumn: number
  endRow: number
  endColumn: number
}

type SPItem = {
  code?: number
  num1?: number
  num2?: number
  cpc?: number
  ctc?: number
}

interface ProjectOperationWithWbs extends ProjectOperationCost {
  wbs: {
    wbsCode: string
    wbsTitle: string
  }
}

export const CURRENCY = [
  { value: 0, regx: currencySymbols.YEN },
  { value: 1, regx: currencySymbols.DOLLAR },
]

const getStrYearMonth = (date: string): string => {
  if (!date) return date
  const c = date?.match(/-/g)?.length
  return c && c > 1 ? date.substring(0, date.lastIndexOf('-')) : date
}

const getFirstDayStrOfYearMonth = (yearMonthStr?: string): string => {
  if (!yearMonthStr) return ''
  return yearMonthStr + '-01'
}

const numToString = (num: number): string => {
  if ((!num || isNaN(num)) && num !== 0) return ''
  return Number(num).toLocaleString()
}

const getProjectSumCost = (sums: { [key: string]: SPItem[] }): string => {
  let totalNum0 = -1
  let totalNum1 = -1
  let totalNum2 = -1
  let totalDola = -1
  Object.keys(sums).map((month: string) => {
    const sumClone = getSum(sums, month)
    if (!sumClone) return
    if (
      sumClone &&
      Object.keys(sumClone)?.every((key) => sumClone?.[key] === undefined)
    )
      return

    sums[month].forEach((item) => {
      if (Object.keys(item).length > 0) {
        if (item.code === 1) {
          if (item.num1 && !isNaN(item.num1))
            totalDola = (totalDola < 0 ? 0 : totalDola) + item.num1
        } else if (item.code === 2) {
          if (item.num1 && !isNaN(item.num1))
            totalNum2 = (totalNum2 < 0 ? 0 : totalNum2) + item.num1
        } else {
          if (item.num1 && !isNaN(item.num1))
            totalNum0 = (totalNum0 < 0 ? 0 : totalNum0) + item.num1
          if (item.num1 && !isNaN(item.num1))
            totalNum1 = (totalNum1 < 0 ? 0 : totalNum1) + item.num1
        }
      }
    })
  })

  let totalLabel =
    totalNum0 > -1
      ? `${currencySymbols.YEN}${numToString(totalNum0)}/${
          currencySymbols.YEN
        }${numToString(totalNum1 * exportConstantValues.TAX)}`
      : ''
  if (totalDola > -1) {
    totalLabel = `${totalLabel}\n${currencySymbols.DOLLAR}${numToString(
      totalDola
    )} `
  }
  if (totalNum2 > -1) {
    totalLabel = `${totalLabel}\n${currencySymbols.YEN}${numToString(
      totalNum2
    )} `
  }

  return totalLabel
}

const getProjectMonthSumCost = (
  sums: { [key: string]: SPItem[] },
  yearMonthKeys: string[]
): string[] => {
  return yearMonthKeys.map((month) => {
    const sumClone = getSum(sums, month)

    let sumNum0 = -1
    let sumNum1 = -1
    let sumNum2 = -1
    let sumDola = -1
    if (sums[month] && Array.isArray(sums[month])) {
      sums[month].forEach((item) => {
        if (Object.keys(item).length > 0) {
          if (item.code === 1) {
            if (item.num1 && !isNaN(item.num1))
              sumDola = (sumDola < 0 ? 0 : sumDola) + item.num1
          } else if (item.code === 2) {
            if (item.num1 && !isNaN(item.num1))
              sumNum2 = (sumNum2 < 0 ? 0 : sumNum2) + item.num1
          } else {
            if (item.num1 && !isNaN(item.num1))
              sumNum0 = (sumNum0 < 0 ? 0 : sumNum0) + item.num1
            if (item.num2 && !isNaN(item.num2))
              sumNum1 = (sumNum1 < 0 ? 0 : sumNum1) + item.num2
          }
        }
      })
    }
    let sumLabel =
      sumNum0 > -1
        ? `${currencySymbols.YEN}${numToString(sumNum0)}/${
            currencySymbols.YEN
          }${numToString(sumNum1)}`
        : ''
    if (sumDola > -1) {
      sumLabel = `${sumLabel}\n${currencySymbols.DOLLAR}${numToString(
        sumDola
      )} `
    }
    if (sumNum2 > -1) {
      sumLabel = `${sumLabel}\n${currencySymbols.YEN}${numToString(sumNum2)} `
    }
    if (!sumClone) return ' '
    if (
      sumClone &&
      Object.keys(sumClone)?.every((key) => sumClone?.[key] === undefined)
    )
      return ' '
    return sumLabel
  })
}

const getBusinessDaysDateStr = (
  yearMonthStr: string | undefined,
  businessDays: BusinessDaysObject | undefined,
  defaultDays: number
): number => {
  if (yearMonthStr === undefined || !businessDays) return defaultDays
  const firstDayOfTheMonth = getFirstDayStrOfYearMonth(yearMonthStr)
  const days = businessDays[firstDayOfTheMonth]?.businessDaysNumber
  return typeof days === 'number' ? days : defaultDays
}

const calcMonthlyWorkHours = (
  businessDays: number,
  dailyWorkTime: number
): number => {
  return businessDays * dailyWorkTime
}

const getCostRow = (
  sums: { [key: string]: SPItem[] },
  yearMonthKeys: string[]
) => {
  const rowValues: string[] = []
  rowValues.push('')
  rowValues.push('')
  rowValues.push('')
  rowValues.push(Labels.TOTAL_ALL)
  rowValues.push('')
  rowValues.push(getProjectSumCost(sums))
  rowValues.push(...getProjectMonthSumCost(sums, yearMonthKeys))

  return rowValues
}

const getEmptyRow = (
  projectName: string,
  yearMonthKeys: string[]
): string[] => {
  const rowValues: string[] = []
  rowValues.push(projectName)
  rowValues.push('')
  rowValues.push('')
  rowValues.push('')

  yearMonthKeys.map(() => {
    rowValues.push('')
  })

  return rowValues
}

const getPriceLabel = (
  businessDays: BusinessDaysObject,
  priceItem: PersonnelPrice,
  workHoursIfSet?: number
): string => {
  if (!priceItem) return ''
  const ctc = CURRENCY.find((c) => c.value === priceItem.currencyTypeCode)
  const hoursOrMonths = !workHoursIfSet
    ? workHoursIfSet === 0
      ? 0
      : 1
    : workHoursIfSet

  const priceAmount = priceItem.priceAmount
  if (!priceAmount || isNaN(priceItem.priceAmount)) return ''
  if (priceItem.contractPatternCode === 1) {
    const currencySymbol = ctc?.regx ?? ''
    return currencySymbol + numToString(priceItem.priceAmount * hoursOrMonths)
  } else if (priceItem.contractPatternCode === 2) {
    const currencySymbol = ctc?.regx ?? ''
    const isWorkHoursNotPassed = !workHoursIfSet && workHoursIfSet !== 0
    const businessDaysOfThisMonth = getBusinessDaysDateStr(
      priceItem.priceStartDate.toString(),
      businessDays,
      DEFAULT_BUSINESS_DAYS
    )
    const workHoursOfThisMonth = calcMonthlyWorkHours(
      businessDaysOfThisMonth,
      DEFAULT_WORK_TIME_OF_DAY
    )
    const monthlyPriceMultiply = isWorkHoursNotPassed
      ? workHoursOfThisMonth
      : hoursOrMonths

    return (
      `${currencySymbol}${numToString(priceItem.priceAmount * hoursOrMonths)}` +
      '/' +
      `${currencySymbol}${numToString(
        priceItem.priceAmount * monthlyPriceMultiply
      )}`
    )
  } else {
    const currencySymbol = ctc?.regx ?? ''
    return (
      `${currencySymbol}${numToString(priceItem.priceAmount * hoursOrMonths)}` +
      '/' +
      `${currencySymbol}${numToString(
        Number(priceItem.priceAmount * hoursOrMonths * exportConstantValues.TAX)
      )}`
    )
  }
}

const getRowValues = (
  projectOperationWithWbsDetail: ProjectOperationWithWbs,
  projectName: string,
  yearMonthKeys: string[],
  actualSums: { [key: string]: SPItem[] }
): [{ [key: string]: SPItem[] }, string[][]] => {
  if (
    !projectOperationWithWbsDetail.personnel ||
    projectOperationWithWbsDetail.personnel.length <= 0
  ) {
    return [{}, []]
  }

  const sumsActualPrice: { [key: string]: SPItem[] } = {}

  const rows = projectOperationWithWbsDetail.personnel.map((per) => {
    const rowValues: string[] = []
    const companyName = per.companyName
    const name = `${per.name}\n${per.nameJpn}`
    const wbsCode = projectOperationWithWbsDetail?.wbs?.wbsCode
      ? projectOperationWithWbsDetail?.wbs?.wbsCode
      : ''
    const wbsTitle = projectOperationWithWbsDetail?.wbs?.wbsTitle
      ? projectOperationWithWbsDetail?.wbs?.wbsTitle
      : ''

    rowValues.push(projectName)
    rowValues.push(wbsCode)
    rowValues.push(wbsTitle)
    rowValues.push(companyName)
    rowValues.push(name)
    rowValues.push('')

    let personnelPriceValue: PersonnelPrice = {
      personnelPriceId: 0,
      priceStartDate: new Date(),
      contractPatternCode: 0,
      priceAmount: 0,
      currencyTypeCode: 0,
      personnelId: 0,
    }
    const operationCostAmount = per.operations ? per.operations : {}
    yearMonthKeys.map((month) => {
      let price1 = ''
      const assignPeriod =
        getStrYearMonth(per.registeredDate.toString()) <= month &&
        (!per.unregisteredDate ||
          getStrYearMonth(per.unregisteredDate.toString()) >= month)
      let personnelPriceItem = per.prices?.find(
        (personnelPrice) => personnelPrice.priceStartDate.toString() === month
      )

      if (!personnelPriceItem && per.prices) {
        const ps = per.prices.filter(
          (item) => item.priceStartDate.toString() < month
        )
        personnelPriceItem = ps[ps?.length - 1] || []
      }

      if (assignPeriod && personnelPriceItem) {
        personnelPriceValue = personnelPriceItem
      }
      const personnelCostAmount = operationCostAmount
        ? operationCostAmount[month]
        : undefined
      if (personnelCostAmount) {
        const clonePersonalPriceValue = {
          ...personnelPriceValue,
          priceAmount: personnelCostAmount.costAmount,
        }
        price1 = getPriceLabel(per.businessDays, clonePersonalPriceValue)

        const sumActualPrice = sumsActualPrice[month]
        const priceWithUnit = price1.indexOf('/') ? price1.split('/') : [price1]

        const priceInfoActualPrice: SPItem = {}
        const actualPrice: SPItem = {}
        if (
          Array.isArray(priceWithUnit) &&
          priceWithUnit.length > 0 &&
          priceWithUnit[0]
        ) {
          priceInfoActualPrice.code = personnelPriceValue.contractPatternCode

          priceInfoActualPrice.num1 = personnelCostAmount.costAmount

          if (personnelPriceValue.contractPatternCode === 2) {
            priceInfoActualPrice.num2 = Number(
              personnelCostAmount.costAmount.toFixed(11)
            )
          } else if (personnelPriceValue.contractPatternCode === 0) {
            priceInfoActualPrice.num2 = Number(
              (personnelCostAmount.costAmount * 1.1).toFixed(1)
            )
          }
          // cpc equal to currency type: 0 is Yen, 1 is Dollar
          priceInfoActualPrice.cpc = personnelPriceValue.contractPatternCode
          priceInfoActualPrice.ctc = personnelPriceValue.currencyTypeCode
        }
        // condition to calculate the sum of the actual price
        if (
          Array.isArray(priceWithUnit) &&
          priceWithUnit.length > 0 &&
          priceWithUnit[0]
        ) {
          actualPrice.num1 = personnelCostAmount.costAmount
          if (personnelPriceValue.contractPatternCode === 2) {
            actualPrice.num2 = Number(personnelCostAmount.costAmount.toFixed(1))
          } else if (personnelPriceValue.contractPatternCode === 0) {
            actualPrice.num2 = Number(
              (personnelCostAmount.costAmount * 1.1).toFixed(1)
            )
          }
          actualPrice.cpc = personnelPriceValue.contractPatternCode
          actualPrice.ctc = personnelPriceValue.currencyTypeCode
        }

        if (actualPrice && !actualSums[month]) {
          actualSums[month] = [actualPrice]
        } else if (actualSums[month] && actualPrice) {
          actualSums[month] = [...actualSums[month], actualPrice]
        }

        if (sumActualPrice) {
          sumActualPrice.push(priceInfoActualPrice)
        } else {
          sumsActualPrice[month] = []
          sumsActualPrice[month].push(priceInfoActualPrice)
        }
      }
      rowValues.push(price1)
    })

    return rowValues
  })

  return [sumsActualPrice, rows]
}

const sheetColumns = (yearMonthKeys: string[], monthKeys: string[]) => [
  { header: Labels.PROJECT_NAME, key: Labels.PROJECT_NAME, width: 30 },
  { header: Labels.WBS_CODE, key: Labels.WBS_CODE, width: 20 },
  { header: Labels.WBS_TITLE, key: Labels.WBS_TITLE, width: 20 },
  { header: Labels.COMPANY_NAME, key: Labels.COMPANY_NAME, width: 20 },
  { header: Labels.NAME, key: Labels.NAME, width: 20 },
  {
    header: Labels.PROJECT_TOTAL_AMOUNT,
    key: Labels.PROJECT_TOTAL_AMOUNT,
    width: 25,
  },
  ...yearMonthKeys.map((yearMonthKey, index) => ({
    header: monthKeys[index],
    key: yearMonthKey,
    width: 20,
  })),
]

const getSum = (
  sums: { [key: string]: SPItem[] },
  month: string
): SumResult => {
  const arrayOfSPItem = sums[month]
  const resultInit: SumResult = {
    cpc0: { sumFirst: 0, sumSecond: 0 },
    cpc1: { sum: 0 },
    cpc2: { sum: 0 },
  }

  return (
    arrayOfSPItem?.reduce(
      (acc: SumResult, item: SPItem) => {
        if (Object.keys(item).length > 0) {
          if (item.cpc === 0) {
            return {
              ...acc,
              ...(Number.isInteger(item.num1) && Number.isInteger(item.num2)
                ? {
                    cpc0: {
                      sumFirst:
                        (acc.cpc0?.sumFirst || 0) + (item.num1 ? item.num1 : 0),
                      sumSecond:
                        (acc.cpc0?.sumSecond || 0) +
                        (item.num2 ? item.num2 : 0),
                    },
                  }
                : {}),
            }
          } else if (item.cpc === 1) {
            return {
              ...acc,
              ...(Number.isInteger(item.num1)
                ? {
                    cpc1: {
                      sum: (acc.cpc1?.sum || 0) + (item.num1 ? item.num1 : 0),
                    },
                  }
                : {}),
            }
          } else if (item.cpc === 2) {
            return {
              ...acc,
              ...(Number.isInteger(item.num2)
                ? {
                    cpc2: {
                      sum: (acc.cpc2?.sum || 0) + (item.num2 ? item.num2 : 0),
                    },
                  }
                : {}),
            }
          }
        }
        return acc
      },
      { ...resultInit }
    ) || { ...resultInit }
  )
}

export const exportDataOperationCostUseCase = async (
  data: OperationCostListResponse
): Promise<string> => {
  if (!data.items || data.items.length === 0) {
    throw new CustomError(messages.exportDatanotExists, 'Not Found')
  }

  const fromDate = new Date(data.from)
  const toDate = new Date(data.to)
  const monthKeys = getMonthRange(fromDate, toDate)
  const yearKeys = getYearRange(fromDate, toDate)
  const yearMonthKeys = getYearMonthRange(fromDate, toDate)

  let startRow = 3
  const dataRows: string[][] = []
  const mergeCellList: MergeCell[] = []
  const fillColorRowList: number[] = []

  data.items.map((project) => {
    const projectEndDate = project.projectEndDate ? project.projectEndDate : ''
    const projectName = `${project.projectName} (${project.projectStartDate} ~ ${projectEndDate})`
    let sums: { [key: string]: SPItem[] } = {}
    const actualSums: { [key: string]: SPItem[] } = {}
    if (!project.personnel || project.personnel.length <= 0) {
      dataRows.push(getEmptyRow(projectName, yearMonthKeys))
    } else {
      const [sumsActualPrice, rows] = getRowValues(
        project as ProjectOperationWithWbs,
        projectName,
        yearMonthKeys,
        actualSums
      )
      dataRows.push(...rows)
      sums = sumsActualPrice
    }
    dataRows.push(getCostRow(sums, yearMonthKeys))

    const endRow = 3 + dataRows.length - 1
    mergeCellList.push({
      startRow: startRow,
      startColumn: 1,
      endRow: endRow,
      endColumn: 1,
    })
    mergeCellList.push({
      startRow: startRow,
      startColumn: 2,
      endRow: endRow,
      endColumn: 2,
    })
    mergeCellList.push({
      startRow: startRow,
      startColumn: 3,
      endRow: endRow,
      endColumn: 3,
    })
    mergeCellList.push({
      startRow: endRow,
      startColumn: 2,
      endRow: endRow,
      endColumn: 3,
    })
    mergeCellList.push({
      startRow: endRow,
      startColumn: 4,
      endRow: endRow,
      endColumn: 5,
    })
    fillColorRowList.push(endRow)
    startRow = endRow + 1
  })

  const workbook = new ExcelJS.Workbook()
  const worksheet = workbook.addWorksheet(SHEET_NAME.OPERATION_COSTS)
  const columns = sheetColumns(yearMonthKeys, monthKeys)

  worksheet.addRow([''])

  const rowValues = [
    Labels.YEAR_MONTH,
    '',
    '',
    `${convertDateToYYYYMM(fromDate)} 〜 ${convertDateToYYYYMM(toDate)}`,
    '',
    '',
    ...yearKeys.map((yearKeys) => yearKeys),
  ]
  worksheet.addRow(rowValues)
  worksheet.addRow(columns.map((col) => col.header))
  worksheet.addRows(dataRows)

  // Apply column widths after adding rows
  worksheet.columns = columns

  applyBordersToCells(worksheet)
  styleRow(worksheet, 2)
  styleRow(worksheet, 3)

  worksheet.views = [{ state: 'frozen', ySplit: 2 }]
  worksheet.spliceRows(1, 1)

  mergeCells(worksheet, 1, 4, 1, 6)
  mergeCellList.forEach((cell) => {
    mergeCells(
      worksheet,
      cell.startRow,
      cell.startColumn,
      cell.endRow,
      cell.endColumn
    )
  })

  fillColorRowList.forEach((row) => {
    styleTotalRowWithStartCol(worksheet, row, 4)
  })

  mergeYearHeaderCells(worksheet, fromDate, toDate, 7)

  worksheet.eachRow((row) => {
    row.eachCell((cell) => {
      cell.alignment = {
        vertical: 'middle',
        horizontal: 'left',
        wrapText: true,
      }
    })
  })

  const excelBuffer = await workbook.xlsx.writeBuffer()
  const buffer = Buffer.from(excelBuffer)
  const fileName = `${FILE_NAME.OPERATION_COSTS}${uuidv4()}.xlsx`
  const url = await uploadFileToAzureBlob(buffer, fileName)

  return url
}
