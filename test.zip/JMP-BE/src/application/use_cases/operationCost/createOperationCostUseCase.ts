import { OperationCostRepositoryPort } from '../../port/repositories/operationCost/OperationCostRepositoryPort'
import {
  CreateOperationCostDto,
  CreateOperationCostResponse,
} from '../../../interface/routes/operationCost/dto/operationCost.dto'
import {
  buildCreateOperationCostResponse,
  buildOperationCreateQueryParams,
} from '../../helpers/operationCost.helpers'
import logger from '../../../infrastructure/logger/logger'
/**
 * @description Function used to create operation cost
 * @param arrayBody  the body of the HTTP request
 * @param operationCostRepositoryPort  the repository that will be used to create the operation cost
 * @param userInformation  the information of the user who created the operation cost
 * @returns  the list of operation cost that were created
 */
export const createOperationCostUseCase = async (
  arrayBody: CreateOperationCostDto[],
  userInformation: Record<string, unknown>,
  operationCostRepositoryPort: Pick<OperationCostRepositoryPort, 'create'>
): Promise<CreateOperationCostResponse[]> => {
  // the function returns a list of operation cost
  const inserts = await operationCostRepositoryPort.create(
    buildOperationCreateQueryParams(arrayBody, userInformation)
  )
  logger.debug('Operation Cost ' + JSON.stringify(inserts))
  // create the operation cost in the repository and get the identifiers of the created operation cost
  return buildCreateOperationCostResponse(inserts)
  // build the response that will be returned
}
