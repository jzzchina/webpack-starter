import { v4 as uuidv4 } from 'uuid'
import { uploadFileToAzureBlob } from '../../../infrastructure/azure/config/azureBlobStorageConnection'
import CustomError from '../../errors/CustomError'
import messages from '../../errors/messages'
import ExcelJS from 'exceljs'
import Labels, {
  FILE_NAME,
  SHEET_NAME,
} from '../../common/exportFeatures/labels'
import logger from '../../../infrastructure/logger/logger'
import {
  getYearMonthRange,
  getValueOrDefault,
} from '../../common/exportFeatures/common'
import {
  applyBordersToCells,
  setWrapTextForWorksheet,
  styleHeaderCells,
  styleTotalRow,
} from '../../common/exportFeatures/excelStyling'
import {
  PersonnelOperationCost,
  ProjectOperationCost,
  PersonalDataAchivement,
} from '../../../infrastructure/repositories/operationPlan/interface'

export const exportDataOperationUseCase = async (
  from: string | undefined,
  to: string | undefined,
  data: { items: ProjectOperationCost[] }
): Promise<string> => {
  if (!data.items || data.items.length === 0) {
    throw new CustomError(messages.exportDatanotExists, 'Not Found')
  }

  const fromDate = new Date(from || '')
  const toDate = new Date(to || '')

  const monthRange = getYearMonthRange(fromDate, toDate)
  const columns = monthRange.map((month) => month)

  const flattenedData = data.items.flatMap((project: ProjectOperationCost) => {
    const personnelData =
      project.personnel?.flatMap((person: PersonnelOperationCost) => {
        const personDataAchievements: PersonalDataAchivement = {
          project: getValueOrDefault(project.projectName),
          company_name: getValueOrDefault(person.companyName),
          name: `${getValueOrDefault(person.name)} ${getValueOrDefault(
            person.nameJpn
          )}`,
          project_total: '',
        }
        monthRange.forEach((month) => {
          personDataAchievements[month] =
            getValueOrDefault(person.operations?.[month]?.hoursNumber, '0') +
            'h'
        })

        return personDataAchievements
      }) || []

    const projectTotalAchievements = personnelData.reduce(
      (total: { [key: string]: number }, person: { [key: string]: string }) => {
        monthRange.forEach((month) => {
          const achievementValue = Number(person[month].replace('h', '')) || 0
          total[month] = (Number(total[month]) || 0) + achievementValue
        })
        return total
      },
      {}
    )

    const projectTotalAchievementsSum = monthRange.reduce(
      (sum, month) => sum + (Number(projectTotalAchievements[month]) || 0),
      0
    )

    const projectTotalEntryAchievements = {
      project: getValueOrDefault(project.projectName),
      company_name: '',
      name: Labels.TOTAL_ALL,
      project_total: projectTotalAchievementsSum.toFixed(2) + 'h',
      ...Object.fromEntries(
        Object.entries(projectTotalAchievements).map(([key, value]) => [
          key,
          Number(value).toFixed(2) + 'h',
        ])
      ),
    }

    const result = []
    if (!project.personnel || project.personnel.length === 0) {
      result.push({
        project: getValueOrDefault(project.projectName),
        company_name: '',
        name: '',
        project_total: '',
      })
    }
    result.push(...personnelData, projectTotalEntryAchievements)
    return result
  })

  const workbook = new ExcelJS.Workbook()
  const worksheet = workbook.addWorksheet(SHEET_NAME.OPERATION)

  const headers = [
    'project',
    'company_name',
    'name',
    'project_total',
    ...columns,
  ]
  worksheet.columns = headers.map((header) => ({
    header,
    key: header,
  }))

  // Insert a new row at the top
  worksheet.insertRow(1, [])

  // Merge the first four cells in the top row
  worksheet.mergeCells('A1:A2')
  worksheet.mergeCells('B1:B2')
  worksheet.mergeCells('C1:C2')
  worksheet.mergeCells('D1:D2')

  worksheet.getCell('A1').value = Labels.PROJECT_NAME
  worksheet.getCell('B1').value = Labels.COMPANY_NAME
  worksheet.getCell('C1').value = Labels.NAME
  worksheet.getCell('D1').value = Labels.PROJECT_TOTAL_AMOUNT

  flattenedData.forEach((data) => {
    const row = worksheet.addRow(data)
    if (data['name'] === Labels.TOTAL_ALL) {
      const totalText = Labels.TOTAL_ALL
      worksheet.mergeCells(`B${row.number}:C${row.number}`)
      const mergedCell = worksheet.getCell(`B${row.number}`)
      mergedCell.value = totalText
      const startCell = 3
      styleTotalRow(worksheet, row.number, startCell)
    }
  })
  // Add and style year headers in the 1st row and date headers in the 2nd row
  let currentColumn = 5 // Starting from column E
  const monthCount = monthRange.reduce((acc, month) => {
    const year = new Date(month).getFullYear().toString()
    if (acc[year]) {
      acc[year] += 1
    } else {
      acc[year] = 1
    }
    return acc
  }, {} as { [key: string]: number })

  Object.entries(monthCount).forEach(([year, count]) => {
    const startCell = worksheet.getCell(1, currentColumn)
    const endCell = worksheet.getCell(1, currentColumn + count - 1)
    worksheet.mergeCells(startCell.address, endCell.address)
    startCell.value = `${year} ${Labels.YEAR}`

    for (let i = 0; i < count; i++) {
      const cell = worksheet.getCell(2, currentColumn + i)
      const monthValue = new Date(columns[currentColumn - 5 + i]).getMonth() + 1
      cell.value = `${monthValue} ${Labels.MONTH}`
    }
    currentColumn += count
  })

  // Apply borders and wrap text styles to all cells
  applyBordersToCells(worksheet)
  setWrapTextForWorksheet(worksheet)

  worksheet.columns.forEach((column) => {
    let maxLength = 0
    column.eachCell?.({ includeEmpty: true }, (cell) => {
      const columnLength = cell.value ? cell.value.toString().length : 10
      if (columnLength > maxLength) {
        maxLength = columnLength
      }
    })
    column.width =
      column.key === Labels.PROJECT_TOTAL_AMOUNT ||
      column.key === Labels.PROJECT_NAME
        ? 30
        : maxLength + 2
  })

  worksheet.views = [{ state: 'frozen', ySplit: 2 }] // Adjusted to account for the top row

  const dataStartRow = 4 // Starting row for data

  // Merge cells with the same value in the first column
  let currentMergeStart = dataStartRow - 1 // Starting from the row before data starts
  let currentValue = worksheet.getCell(`A${currentMergeStart}`).value

  for (let i = dataStartRow; i <= worksheet.rowCount; i++) {
    const cellValue = worksheet.getCell(`A${i}`).value
    if (cellValue !== currentValue) {
      if (i - 1 > currentMergeStart) {
        worksheet.mergeCells(`A${currentMergeStart}:A${i - 1}`)
      }
      currentMergeStart = i
      currentValue = cellValue
    }
  }
  // Final check to merge the last set of rows
  if (
    worksheet.rowCount >= dataStartRow &&
    worksheet.getCell(`A${currentMergeStart}`).value === currentValue
  ) {
    worksheet.mergeCells(`A${currentMergeStart}:A${worksheet.rowCount}`)
  }

  // Merge cells with the same value in column D, but only within the same project
  currentMergeStart = dataStartRow - 1 // Starting from the row before data starts
  currentValue = worksheet.getCell(`D${currentMergeStart}`).value
  let currentProject = worksheet.getCell(`A${currentMergeStart}`).value

  for (let i = dataStartRow; i <= worksheet.rowCount; i++) {
    const cellValue = worksheet.getCell(`D${i}`).value
    const projectValue = worksheet.getCell(`A${i}`).value
    if (cellValue !== currentValue || projectValue !== currentProject) {
      if (i - 1 > currentMergeStart) {
        worksheet.mergeCells(`D${currentMergeStart}:D${i - 1}`)
      }
      currentMergeStart = i
      currentValue = cellValue
      currentProject = projectValue
    }
  }
  // Final check to merge the last set of rows
  if (
    worksheet.rowCount >= dataStartRow &&
    worksheet.getCell(`D${currentMergeStart}`).value === currentValue &&
    worksheet.getCell(`A${currentMergeStart}`).value === currentProject
  ) {
    worksheet.mergeCells(`D${currentMergeStart}:D${worksheet.rowCount}`)
  }

  // Apply styles to header cells
  styleHeaderCells(worksheet, [1, 2])
  worksheet.getColumn('A').width = 20
  worksheet.getColumn('D').width = 25

  worksheet.eachRow((row) => {
    row.eachCell((cell) => {
      if (cell.value === Labels.TOTAL_ALL) {
        cell.alignment = {
          vertical: 'middle',
          horizontal: 'center',
          wrapText: true,
        }
      } else {
        cell.alignment = {
          vertical: 'middle',
          horizontal: 'left',
          wrapText: true,
        }
      }
    })
  })

  const fileName = `${FILE_NAME.OPERATION}${uuidv4()}.xlsx`
  const buffer = (await workbook.xlsx.writeBuffer()) as Buffer
  logger.info(`Uploading file to Azure Blob Storage: ${fileName}`)
  const fileUrl = await uploadFileToAzureBlob(buffer, fileName)
  return fileUrl
}
