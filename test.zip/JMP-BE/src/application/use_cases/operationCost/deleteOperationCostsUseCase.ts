import { OperationCostKeys } from '../../../interface/routes/operationCost/dto/operationCost.dto'
import { buildOperationCostInputs } from '../../helpers/operationCost.helpers'
import { OperationCostRepositoryPort } from '../../port/repositories/operationCost/OperationCostRepositoryPort'
/**
 * @description the use case that will be used to delete operation costs from the repository
 * @param operationCostInput the operation cost input that will be used to delete the operation costs
 * @param operationCostRepository the services that will be used to delete the operation costs from the repository
 * @returns void
 * @throws IDDoesntExistError if the operation cost doesn't exist
 */
export const deleteOperationCostsUseCase = async (
  operationCostInput: OperationCostKeys[],
  operationCostRepository: Pick<
    OperationCostRepositoryPort,
    'deleteOperationCosts'
  >
): Promise<void> => {
  // the function returns nothing

  return operationCostRepository.deleteOperationCosts(
    buildOperationCostInputs(operationCostInput)
  )
}
