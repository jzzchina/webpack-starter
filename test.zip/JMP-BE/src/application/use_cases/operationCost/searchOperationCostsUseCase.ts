import { OperationCostRepositoryPort } from '../../port/repositories/operationCost/OperationCostRepositoryPort'
import { OperationCostListResponse } from '../../../interface/routes/operationCost/dto/operationCost.dto'
import {
  buildOperationCostListResponse,
  getUniqueListOfOperationCosts,
} from '../../helpers/operationCost.helpers'
import logger from '../../../infrastructure/logger/logger'
/**
 * @description use case for searching operation costs
 * @param limit  limit used for pagination
 * @param offset  offset used for pagination
 * @param from  from date of project start date
 * @param to    to date of project end date
 * @param projectId project id that is used for filtering
 * @param companyId company id that is used for filtering
 * @param operationCostRepository operation cost repository to get service used for searching operation costs
 * @returns operation cost list response
 */
export const searchOperationCostsUseCase = async (
  limit: number,
  offset: number,
  from: string,
  to: string,
  projectId: number | null,
  companyId: number | null,
  operationCostRepository: Pick<
    OperationCostRepositoryPort,
    'searchOperationCosts'
  >
): Promise<OperationCostListResponse> => {
  const {
    totalItems,
    projects,
  } = await operationCostRepository.searchOperationCosts(
    limit,
    offset,
    from,
    to,
    projectId,
    companyId
  )
  logger.debug('Operation Cost Projects ' + JSON.stringify(projects))
  return buildOperationCostListResponse(
    //build unique list of operation costs by project
    getUniqueListOfOperationCosts(projects),
    totalItems,
    from,
    to,
    offset,
    limit
  )
}
