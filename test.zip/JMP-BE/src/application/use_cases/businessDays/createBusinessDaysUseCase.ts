import logger from '../../../infrastructure/logger/logger'
import { BusinessDaysKey } from '../../../infrastructure/repositories/businessDays/interface'
import { BusinessDaysList } from '../../../interface/routes/businessDays/dto/businessDays.dto'
import {
  buildBusinessDaysListDTO,
  buildBusinessDaysListResponse,
} from '../../helpers/businessDays.helpers'
import { BusinessDaysRepositoryPort } from '../../port/repositories/businessDays/BusinessDaysRepositoryPort'
/**
 * @description the use case that will be used to create business days from the repository and return the created business days
 * @param businessDays list of business days to be created
 * @param nameOfUser  name of the user who created the business days
 * @param repo         the services that will be used to create the business days from the repository
 * @returns          the list of business days that were created
 */
export const createBusinessDaysUseCase = async (
  businessDays: BusinessDaysList,
  nameOfUser: string,
  repo: Pick<BusinessDaysRepositoryPort, 'create' | 'findMany'>
): Promise<BusinessDaysList> => {
  // the function returns a list of business days
  const businessDaysDTO = buildBusinessDaysListDTO(businessDays, nameOfUser)
  // build the DTO that will be used to create the business days
  const creationResult = await repo.create(businessDaysDTO)
  logger.debug(
    'Business Days Creation Result ' + JSON.stringify(creationResult)
  )
  // create the business days in the repository and get the identifiers of the created business days
  const identifiers = creationResult.identifiers as BusinessDaysKey[]
  // get the identifiers of the created business days
  const createdBusinessDays = await repo.findMany(identifiers)
  // get the created business days from the repository using the identifiers
  logger.debug(
    'Business Days From identifiers ' +
      JSON.stringify(identifiers) +
      ' ' +
      JSON.stringify(createdBusinessDays)
  )
  return buildBusinessDaysListResponse(createdBusinessDays)
  // build the response that will be returned
}
