import { BusinessListResponse } from '../../../interface/routes/businessDays/dto/businessDays.dto'
import { businessDaysListResponseFactory } from '../../helpers/businessDays.helpers'
import { BusinessDaysRepositoryPort } from '../../port/repositories/businessDays/BusinessDaysRepositoryPort'
import logger from '../../../infrastructure/logger/logger'
/**
 * @description the use case that will be used to find all business days from the repository and return the found business days
 * @param companyID the id of the company that belongs to the business days
 * @param repo the services that will be used to find all business days from the repository
 */
export const findAllBusinessDaysUseCase = async (
  companyID: number,
  repo: Pick<BusinessDaysRepositoryPort, 'findAll'>
): Promise<BusinessListResponse> => {
  // the function returns a list of business days
  const foundBusinessDays = await repo.findAll(companyID)
  // find all business days from the repository using the company ID
  logger.debug(
    'Business Days From Company ID ' +
      JSON.stringify(companyID) +
      ' ' +
      JSON.stringify(foundBusinessDays)
  )
  return businessDaysListResponseFactory(foundBusinessDays)
  // return the builded founded business days
}
