import { BusinessDaysRepositoryPort } from '../../port/repositories/businessDays/BusinessDaysRepositoryPort'
import CustomError from '../../errors/CustomError'
import messages from '../../errors/messages'

export const deleteBusinessDaysUseCase = async (
  companyId: number,
  monthOfYearDate: string,
  businessDaysRepository: Pick<BusinessDaysRepositoryPort, 'delete'>
): Promise<void> => {
  const result = await businessDaysRepository.delete(companyId, monthOfYearDate)
  if (result.affected === 0) {
    throw new CustomError(messages.businessDaysDoesNotExist, 'Not Found')
  }
}
