type Messages = Record<string, string>

const messages: Messages = {
  unexpectedError: 'Unexpected error occurred',
  foreignKeyConstraintError: 'Foreign key constraint error',
  methodNotAllowed: 'Method not allowed',
  recordsDoesNotExist: 'Records does not exist',
  foreignKeyNotFound: 'Foreign key not found',
  noForeignKeyMatched: 'No Foreign Key matched',
  monthOfYearIsNotBetween:
    'The month of year date is not between the registered date and unregistered date',
  registeredDateAfterMonthOfYearDate:
    'The registered date is after the month of year date',
  totalValueExceedsOne: '合計値が1.0を超過するため保存できません。',
  targetOperationCostNotFound: 'The target operationCost does not exist',
  operationPerformanceExist:
    '稼働実績が存在しているため稼働計画の削除ができません。',
  requestedCompanyIdNotFound: 'The requested company_id not found',
  personnelDoesNotExist: 'Personnel does not exist',
  personnelForeignKeyNotFound: 'Personnel foreign key not found',
  personnelIsAssigned: 'Personnel is assigned to a project(s)',
  targetPersonnelNotFound: 'The target personnel does not exist',
  personnelPriceNotFound: 'PersonnelPrice not found',
  projectNotFound: 'Project not found',
  businessDaysDoesNotExist: 'Business days does not exist',
  exportDatanotExists: 'No data available to export',
}

export default messages
