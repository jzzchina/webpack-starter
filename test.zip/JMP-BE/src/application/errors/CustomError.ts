import statusCodes from './statusCodes'

class CustomError extends Error {
  readonly message: string
  readonly statusCode: number

  constructor(message: string, statusCode: keyof typeof statusCodes) {
    super()
    this.message = message
    this.statusCode = statusCodes[statusCode]
  }
}

export default CustomError
