import { OperationPlanRepositoryPort } from '../port/repositories/operationPlan/OperationPlanRepositoryPort'
import { RoleRepositoryPort } from './repositories/role/RoleRepositoryPort'
import { PersonnelRepositoryPort } from './repositories/personnel/PersonnelRepositoryPort'
import { PersonnelPriceRepositoryPort } from './repositories/personnelPriceRepositoryPort.ts/PersonnelPriceRepositoryPort'
import { ProjectRepositoryPort } from './repositories/project/ProjectRepositoryPort'
import { OperationCostPlanRepositoryPort } from './repositories/operationCostPlan/OperationCostPlanRepositoryPort'
import { OperationCostRepositoryPort } from './repositories/operationCost/OperationCostRepositoryPort'
import { PartnerCompanyRepositoryPort } from './repositories/partnerCompany/PartnerCompanyRepositoryPort'
import { BusinessDaysRepositoryPort } from './repositories/businessDays/BusinessDaysRepositoryPort'
import { WbsRepositoryPort } from './repositories/wbs/wbsRepositoryPort'
import { SalesManRepositoryPort } from './repositories/salesMan/SalesManRepositoryPort'
export type Repositories = {
  operationPlanRepository: OperationPlanRepositoryPort
  roleRepository: RoleRepositoryPort
  personnelRepository: PersonnelRepositoryPort
  personnelPriceRepository: PersonnelPriceRepositoryPort
  projectRepository: ProjectRepositoryPort
  partnerCompanyRepository: PartnerCompanyRepositoryPort
  operationCostPlanRepository: OperationCostPlanRepositoryPort
  operationCostRepository: OperationCostRepositoryPort
  businessDaysRepository: BusinessDaysRepositoryPort
  wbsRepository: WbsRepositoryPort
  salesManRepository: SalesManRepositoryPort
}
