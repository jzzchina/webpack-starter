import { DeleteResult, InsertResult, ObjectLiteral } from 'typeorm'

import { BusinessDaysDBList } from '../../../../infrastructure/repositories/businessDays/interface'

export type BusinessDaysRepositoryPort = {
  findAll: (companyID: number) => Promise<BusinessDaysDBList>
  create: (
    businessDaysToBeInserted: BusinessDaysDBList
  ) => Promise<InsertResult>
  findMany: (businessDaysKeys: ObjectLiteral[]) => Promise<BusinessDaysDBList>
  delete: (companyId: number, monthOfYearDate: string) => Promise<DeleteResult>
}
