import { Dw_m_role } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_role'

export type RoleRepositoryPort = {
  findAll: () => Promise<Partial<Dw_m_role>[]>
}
