import { PersonnelSearchCriteria } from '../../../../domain/models/Personnel'
import { Dw_m_personnel } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_personnel'
import {
  FindAllPersonnelSQLResponse,
  PersonnelQueryCreateInput,
  PersonnelRepositorySaveResult,
} from '../../../../infrastructure/repositories/options/personnel/interface'

export type PersonnelRepositoryPort = {
  findAll: (
    searchCriteria: PersonnelSearchCriteria
  ) => Promise<FindAllPersonnelSQLResponse>

  findMany: (personnelIds: number[]) => Promise<Dw_m_personnel[]>

  create: (
    personnelList: PersonnelQueryCreateInput[]
  ) => Promise<PersonnelRepositorySaveResult | void>

  deletePersonnels: (personnelIds: number[]) => Promise<void>

  findOneById: (personnelId: number) => Promise<Dw_m_personnel | null>
  findPersonnelByAssignment:(personnelIds: number[]) => Promise<number >  
}
