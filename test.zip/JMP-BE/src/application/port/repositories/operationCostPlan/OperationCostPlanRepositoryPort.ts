import { Dw_m_project } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_project'

export type OperationCostPlanRepositoryPort = {
  searchOperationCostPlansByProject: (
    limit: number,
    offset: number,
    from: string,
    to: string,
    projectId: number | null,
    companyId: number | null
  ) => Promise<{ totalItems: number; projects: Partial<Dw_m_project>[] }>
}
