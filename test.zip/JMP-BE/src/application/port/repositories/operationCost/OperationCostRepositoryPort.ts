import { OperationCostCreateRequest } from './../../../../infrastructure/repositories/operationCost/interface'
import { Dw_m_project } from './../../../../infrastructure/orm/typeorm/entities/Dw_m_project'
import { Dw_t_operation } from '../../../../infrastructure/orm/typeorm/entities/Dw_t_operation'
import { Operation } from '../../../../domain/models/Operation'
import { DeleteOperationCostSQLRequest } from '../../../../interface/routes/operationCost/dto/operationCost.dto'

export type OperationCostRepositoryPort = {
  create: (arrayBody: OperationCostCreateRequest[]) => Promise<Dw_t_operation[]>

  findMany: (
    arrayOcs: Pick<Operation, 'personnelId' | 'projectId' | 'yearOfMonthDate'>[]
  ) => Promise<Dw_t_operation[]>

  searchOperationCosts: (
    limit: number,
    offset: number,
    from: string,
    to: string,
    projectId: number | null,
    companyId: number | null
  ) => Promise<{ totalItems: number; projects: Partial<Dw_m_project>[] }>

  searchOperationCostsByPersonnelId: (
    from: string,
    to: string,
    personnelId: number
  ) => Promise<Dw_t_operation[]>

  searchOperationCostsByProjectId: (
    projectId: number
  ) => Promise<Dw_t_operation[]>

  deleteOperationCosts: (
    operationCostInputs: DeleteOperationCostSQLRequest
  ) => Promise<void>
  findOperationBelongsToOperationPlan: (
    personnelIds: number[],
    projectIds: number[]
  ) => Promise<boolean>
  updateCostAmountByPersonnelAndDate: (
    personnelId: number,
    monthYearDate: string,
    personnelPrice: number
  ) => Promise<void>
}
