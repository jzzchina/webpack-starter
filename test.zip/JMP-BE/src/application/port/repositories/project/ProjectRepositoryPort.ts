import { ProjectSearchCriteria } from '../../../../domain/models/Project'
import { Dw_m_project } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_project'
import {
  CreateProjectsSQLResponse,
  SearchProjectsSQLResponse,
} from '../../../../infrastructure/repositories/options/project/interface'

export type ProjectRepositoryPort = {
  findAll: (
    searchCriteria: ProjectSearchCriteria
  ) => Promise<SearchProjectsSQLResponse>

  createProjects: (
    projects: Partial<Dw_m_project>[]
  ) => CreateProjectsSQLResponse

  deleteProjects: (projectIds: number[]) => Promise<void>

  findManyByIds: (projectIds: number[]) => Promise<Partial<Dw_m_project>[]>
}
