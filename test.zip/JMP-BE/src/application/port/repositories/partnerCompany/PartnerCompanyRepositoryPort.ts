import { Dw_m_partner_company } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_partner_company'
import {
  FindAllPartnerCompanySQLResponse,
  PartnerCompanyQueryCreateInput,
  PartnerCompanyRepositorySaveResult,
} from '../../../../infrastructure/repositories/options/partnerCompany/interface'

export type PartnerCompanyRepositoryPort = {
  findAll: (
    companyId: number,
    companyName: string,
    contractPatternCode: number,
    limit: number,
    offset: number
  ) => Promise<FindAllPartnerCompanySQLResponse>
  deletePartnerCompanies: (companyIds: number[]) => Promise<void>
  findMany: (companyIds: number[]) => Promise<Dw_m_partner_company[]>
  create: (
    companyList: PartnerCompanyQueryCreateInput[]
  ) => Promise<PartnerCompanyRepositorySaveResult | void>
}
