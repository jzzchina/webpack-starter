import { Dw_m_personnel } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { Dw_m_wbs } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_wbs'

export type WbsRepositoryPort = {
  searchWbsCosts: (
    limit: number,
    offset: number,
    from: string,
    to: string,
    companyId: number
  ) => Promise<{ totalItems: number; personnel: Partial<Dw_m_personnel>[] }>

  createWbs: (wbsList: Partial<Dw_m_wbs>[]) => Promise<Partial<Dw_m_wbs>[]>
}
