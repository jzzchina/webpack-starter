import { InsertResult } from 'typeorm'
import { OperationPlan } from '../../../../domain/models/OperationPlan'
import { SkillList } from '../../../../domain/models/Personnel'
import { Dw_m_personnel } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { Dw_m_project } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_project'
import { Dw_t_operation_plan } from '../../../../infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import { ListQueryResponseBase } from '../../../../infrastructure/repositories/common/interface'

export type OperationPlanRepositoryPort = {
  deleteOperationPlans: (arrayOps: Partial<OperationPlan>[]) => Promise<void>

  findMany: (
    arrayOps: Partial<OperationPlan>[]
  ) => Promise<Partial<Dw_t_operation_plan>[]>

  findOperationPlansByProject: (
    to: string,
    from: string,
    offset: number,
    limit: number,
    projectId: number | null,
    companyId: number | null,
    skills: SkillList
  ) => Promise<ListQueryResponseBase<Dw_m_project[]>>

  findOperationPlansByPersonnel: (
    to: string,
    from: string,
    offset: number,
    limit: number,
    projectId: number | null,
    companyId: number | null,
    skills: SkillList
  ) => Promise<ListQueryResponseBase<Dw_m_personnel[]>>

  findOperationPlansByPersonnelId: (
    from: string,
    to: string,
    personnelId: number
  ) => Promise<Dw_t_operation_plan[]>

  findAllOperationPlansByPersonnelId: (
    personnelId: number
  ) => Promise<Dw_t_operation_plan[]>

  create: (
    arrayBody: Partial<Dw_t_operation_plan>[]
  ) => Promise<InsertResult | void>
}
