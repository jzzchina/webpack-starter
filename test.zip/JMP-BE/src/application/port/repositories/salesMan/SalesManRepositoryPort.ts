import { InsertResult } from 'typeorm'
import { Dw_m_sales_man } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_sales_man'

export type SalesManRepositoryPort = {
  createSalesMan: (
    salesManData: Partial<Dw_m_sales_man>[]
  ) => Promise<InsertResult>
  findSalesManByIds: (
    salesManIds: number[]
  ) => Promise<Partial<Dw_m_sales_man>[]>
}
