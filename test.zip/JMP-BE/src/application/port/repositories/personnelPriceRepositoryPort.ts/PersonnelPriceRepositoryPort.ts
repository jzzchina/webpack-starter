import { DeleteResult, InsertResult } from 'typeorm'
import { Dw_m_personnel_price } from '../../../../infrastructure/orm/typeorm/entities/Dw_m_personnel_price'
import {
  PersonnelPriceFindResult,
  PersonnelPriceKey,
} from '../../../../infrastructure/repositories/options/personnelPrice/interface'

export type PersonnelPriceRepositoryPort = {
  findByPersonnelID: (personnelId: number) => PersonnelPriceFindResult
  createPersonnelPrice: (
    personnelPrices: Partial<Dw_m_personnel_price>[]
  ) => Promise<void | InsertResult>
  findMany: (personnelPricesKeys: number[]) => Promise<Dw_m_personnel_price[]>
  delete: (
    personnelPricesKey: PersonnelPriceKey
  ) => Promise<void | DeleteResult>
}
