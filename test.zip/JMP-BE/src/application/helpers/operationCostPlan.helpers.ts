import { Personnel } from '../../domain/models/Personnel'
import { OperationCostPlanTotal } from '../../domain/types/operationPlan.type'
import { Dw_m_business_days } from '../../infrastructure/orm/typeorm/entities/Dw_m_business_days'
import { Dw_m_project } from '../../infrastructure/orm/typeorm/entities/Dw_m_project'
import { Dw_t_operation_plan } from '../../infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import {
  OperationCostPlanProject,
  OperationCostPlanProjectListResponse,
} from '../../interface/routes/operationCostPlan/dto/operationCostPlan.dto'
import { sortOperationPlanByMonthOfYear } from '../common/services/operationPlan'
import { buildPersonnelPrices } from '../common/services/personnelPrice'
import { buildBusinessDaysObject } from './businessDays.helpers'

/**
 * @description build operation cost plan project list response
 * @param projects  list of projects
 * @param totalItems  total items
 * @param from date from project start date
 * @param to  date to project end date
 * @param offset  the number of items should be skipped
 * @param limit  limit max of items should be returned
 * @returns operation cost plan project list response
 */
export const buildOperationCostPlanProjectListResponse = (
  projects: Partial<Dw_m_project>[],
  totalItems: number,
  from: string,
  to: string,
  offset: number,
  limit: number
): OperationCostPlanProjectListResponse => {
  /**
   * @description build unique list of personnel
   * @param personnel list of personnel
   * @returns  unique list of personnel
   */
  const getUniqueListByPersonnel = (personnel: Personnel[]) => {
    const personnelUniqueList: Personnel[] = []
    // loop through the list of personnel
    personnel.forEach((personnel: Personnel) => {
      // check if personnel is already in the list
      const isExist = personnelUniqueList.find(
        (uniquePersonnel) =>
          uniquePersonnel.personnelId === personnel.personnelId
      )
      // if personnel is not in the list, push it to the list
      if (!isExist) {
        personnelUniqueList.push(personnel)
      }
    })
    // return unique list of personnel
    return personnelUniqueList
  }

  return {
    from,
    to,
    offset,
    length: limit,
    totalLength: totalItems,

    items: projects.map((project) => {
      const personnel = buildOperationCostPlanPersonnels(
        project.dw_t_operation_plan
      )
      return {
        projectId: project.project_id,
        projectName: project.project_name,
        projectContact: project.project_contact,
        projectContact2: project.project_contact2,
        projectContact3: project.project_contact3,
        projectContact4: project.project_contact4,
        projectStartDate: project.project_start_date,
        projectEndDate: project.project_end_date,
        note: project.notes,
        personnel: getUniqueListByPersonnel(personnel) ?? [],
      }
    }) as OperationCostPlanProject[],
  }
}
/**
 * @description build total operation cost plans
 * @param operationPlan  list of operation plan
 * @returns  total operation cost plans
 */
export const buildTotalOperationCostPlans = (
  operationPlan?: Dw_t_operation_plan[]
): OperationCostPlanTotal => {
  // return the result in specific format
  return (
    operationPlan
      // sort the list of operation plan by month of year
      ?.sort(sortOperationPlanByMonthOfYear)
      // reduce the list of operation plan to total operation cost plan
      .reduce((operationCostPlan, currentOperationPlan) => {
        // get month of year
        const monthOfYear = currentOperationPlan?.month_of_year_date.toString()
        // get hours numbers
        const hoursNumber = Number(currentOperationPlan?.hours_number)
        // get man month numbers
        const manMonthNumber = Number(currentOperationPlan?.man_month_number)
        // check if month of year is not exist in the total operation cost plan
        if (monthOfYear && !operationCostPlan[monthOfYear]) {
          // add month of year to the total operation cost plan
          operationCostPlan[monthOfYear] = {
            hoursNumber: hoursNumber ?? 0,
            manMonthNumber: manMonthNumber ?? 0,
          }
        } else {
          //  hours number of operation cost plan of month of year equal sum of hours number of operation cost plan of month of year and hours number of current operation plan
          operationCostPlan[monthOfYear].hoursNumber += hoursNumber ?? 0
          // manMonthNumber of operation cost plan of month of year equal sum of manMonthNumber of operation cost plan of month of year and manMonthNumber of current operation plan
          operationCostPlan[monthOfYear].manMonthNumber += manMonthNumber ?? 0
        }
        // return total operation cost plan
        return operationCostPlan
      }, {} as OperationCostPlanTotal) as OperationCostPlanTotal
  )
}
/**
 * @description build operation cost plan by personnel
 * @param operationPlans  list of operation plans
 * @returns  list of operation cost plan  by personnel in specific format
 */
export const buildOperationCostPlanPersonnels = (
  operationPlans?: Dw_t_operation_plan[]
): Personnel[] => {
  // return the result in specific format
  return operationPlans
    ?.map((operationPlan) => ({
      companyId: operationPlan.dw_m_personnel?.dw_m_partner_company?.company_id,
      contractPatternCode:
        operationPlan.dw_m_personnel?.dw_m_partner_company
          ?.contract_pattern_code,
      companyName:
        operationPlan.dw_m_personnel?.dw_m_partner_company?.company_name,
      personnelId: operationPlan.dw_m_personnel?.personnel_id,
      name: operationPlan.dw_m_personnel?.name,
      nameJpn: operationPlan.dw_m_personnel?.name_jpn,
      email: operationPlan.dw_m_personnel?.email,
      registeredDate: operationPlan.dw_m_personnel?.registered_date,
      unregisteredDate: operationPlan.dw_m_personnel?.unregistered_date,
      skillList: operationPlan.dw_m_personnel?.skill_list,
      prices:
        buildPersonnelPrices(
          operationPlan.dw_m_personnel?.dw_m_personnel_price
        ) ?? [],
      businessDays: buildBusinessDaysObject(
        operationPlan.dw_m_personnel?.dw_m_partner_company
          ?.dw_m_business_day as Dw_m_business_days[]
      ),

      operationCostPlans: buildTotalOperationCostPlans(
        operationPlan.dw_m_personnel?.dw_t_operation_plan
      ),
      // construct the operation cost plan by personnel in specific format
    }))
    .filter((personnel) => personnel.personnelId) as Personnel[]
}
