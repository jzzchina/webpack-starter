import { Dw_m_business_days } from '../../infrastructure/orm/typeorm/entities/Dw_m_business_days'
import { Dw_m_partner_company } from '../../infrastructure/orm/typeorm/entities/Dw_m_partner_company'
import { BusinessDaysDBList } from '../../infrastructure/repositories/businessDays/interface'
import {
  BusinessDaysList,
  BusinessDaysObject,
  BusinessListResponse,
} from '../../interface/routes/businessDays/dto/businessDays.dto'

/**
 * @description this function will build the DTO that will be used to create the business days
 * @param businessDays   list of business days to be created
 * @param nameOfUser   name of the user who created the business days
 * @returns list of business days DTO
 */
export const buildBusinessDaysListDTO = (
  businessDays: BusinessDaysList,
  nameOfUser: string
): BusinessDaysDBList => {
  // the function returns a list of business days DTO
  const mappedBusinessDays = businessDays.map((businessDay) => ({
    // map the list of business days to a list of business days DTO
    dw_m_partner_company: (businessDay.companyId as unknown) as Dw_m_partner_company,
    // get the company ID from the business day and cast it to the type of the company ID in the business days DTO
    month_of_year_date: businessDay.monthOfYearDate as Date,
    // get the month of year date from the business day and cast it to the type of the month of year date in the business days DTO
    business_days_number: businessDay.businessDaysNumber,
    // get the business days number from the business day and cast it to the type of the business days number in the business days DTO
    business_days_id: businessDay.businessDaysId,
    // get the business days ID from the business day and cast it to the type of the business days ID in the business days DTO
    created_by: nameOfUser,
    // get the name of the user who created the business days and cast it to the type of the created by in the business days DTO
    updated_by: nameOfUser,
    // get the name of the user who created the business days and cast it to the type of the updated by in the business days DTO
  }))

  return mappedBusinessDays
}
/**
 * @description this function will build the response that will be returned
 * @param businessDays list of business days that were created
 * @returns array of builded business days under specific format
 */
export const buildBusinessDaysListResponse = (
  businessDays: BusinessDaysDBList
): BusinessDaysList => {
  // the function returns a list of business days
  const mappedBusinessDays = businessDays.map((businessDay) => ({
    // map the list of business days to a list of business days DTO
    companyId: businessDay.dw_m_partner_company?.company_id as number,
    // get the company ID from the business day and cast it to the type of the company ID in the business days DTO
    monthOfYearDate: businessDay.month_of_year_date as Date,
    // get the month of year date from the business day and cast it to the type of the month of year date in the business days DTO
    businessDaysNumber: businessDay.business_days_number as number,
    // get the business days number from the business day and cast it to the type of the business days number in the business days DTO
  }))

  return mappedBusinessDays
  // return the list of business days
}

/**
 * Function that transforms a list of business days into a list of business days DTOs.
 *
 * @param {BusinessDaysDBList} businessDays - The list of business days to be transformed.
 * @return {BusinessListResponse} The list of business days DTOs.
 */
export const businessDaysListResponseFactory = (
  businessDays: BusinessDaysDBList
): BusinessListResponse => {
  // the function returns a list of business days
  const mappedBusinessDays = businessDays.map((businessDay) => ({
    // map the list of business days to a list of business days DTO
    companyId: businessDay.dw_m_partner_company?.company_id as number,
    // get the company ID from the business day and cast it to the type of the company ID in the business days DTO
    monthOfYearDate: businessDay.month_of_year_date as Date,
    // get the month of year date from the business day and cast it to the type of the month of year date in the business days DTO
    businessDaysNumber: businessDay.business_days_number as number,
    // get the business days number from the business day and cast it to the type of the business days number in the business days DTO
    businessDaysId: businessDay.business_days_id as number,
  }))

  return {
    items: mappedBusinessDays,
  }
  // return the list of business days that were found
}

/**
 * @description build personnel prices formatted by month of year
 * @param businessDays  list of business days
 * @returns  personnel prices formatted by month of year
 */
export const buildBusinessDaysObject = (
  businessDays: Dw_m_business_days[]
): BusinessDaysObject =>
  // reduce the list of business days
  businessDays?.reduce(
    (businessDaysObject, businessDay: Dw_m_business_days) => {
      // return the result in specific format
      return {
        ...businessDaysObject,
        [businessDay.month_of_year_date.toString()]: {
          businessDaysNumber: businessDay.business_days_number,
        },
      }
    },
    {}
  )
