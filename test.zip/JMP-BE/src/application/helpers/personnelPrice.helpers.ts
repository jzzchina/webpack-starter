import { PersonnelPrice } from '../../domain/models/PersonnelPrice'
import { Dw_m_personnel } from '../../infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { Dw_m_personnel_price } from '../../infrastructure/orm/typeorm/entities/Dw_m_personnel_price'
import dateUtils from '../../infrastructure/repositories/utils/dateUtils'
import { PersonnelPriceList } from '../../interface/routes/options/personnelPrice/dto/personnelPrice.dto'
import { OperationCostRepositoryPort } from '../port/repositories/operationCost/OperationCostRepositoryPort'

export const buildPersonnelPricesList = (
  personnelPrices: Dw_m_personnel_price[]
): PersonnelPriceList => {
  return {
    items: personnelPrices.map((personnelPrice) => ({
      personnelId: personnelPrice.dw_m_personnel?.personnel_id,
      priceStartDate: personnelPrice.price_start_date,
      priceAmount: personnelPrice.price_amount,
      currencyTypeCode: personnelPrice.currency_type_code,
      contractPatternCode: personnelPrice.contract_pattern_code,
    })) as PersonnelPrice[],
  }
}

export const buildPersonnelPricesResponse = (
  personnelPrices: Dw_m_personnel_price[]
): PersonnelPrice[] => {
  const personnelPriceList = personnelPrices.map((personnelPrice) => {
    return {
      personnelPriceId: personnelPrice.personnel_price_id,
      personnelId: personnelPrice?.dw_m_personnel?.personnel_id,
      priceStartDate: personnelPrice.price_start_date,
      priceAmount: personnelPrice.price_amount,
      currencyTypeCode: personnelPrice.currency_type_code,
      contractPatternCode: personnelPrice.contract_pattern_code,
    }
  })

  return personnelPriceList
}
/**
 * Updates the operation cost for each personnel based on their price.
 *
 * @param {Dw_m_personnel_price[]} personnelPrices - The list of personnel prices.
 * @param {OperationCostRepositoryPort} operationCostRepository - The repository to update the operation cost.
 * @returns {Promise<void>} - A Promise that resolves when the operation cost has been updated.
 */
export const updateOperationCost = async (
  personnelPrices: Partial<Dw_m_personnel_price>[],
  operationCostRepository: Pick<
    OperationCostRepositoryPort,
    'updateCostAmountByPersonnelAndDate'
  >
): Promise<void> => {
  const updatePromises = personnelPrices
    .filter((personnelPrice) => personnelPrice.dw_m_personnel)
    .map((personnelPrice) => {
      const personnelId = Number(personnelPrice.dw_m_personnel)
      const priceStartDate = personnelPrice.price_start_date as Date
      return operationCostRepository.updateCostAmountByPersonnelAndDate(
        personnelId,
        dateUtils.extractDateFromDateTime(priceStartDate),
        Number(personnelPrice.price_amount)
      )
    })
  await Promise.all(updatePromises)
}

export const buildPersonnelPricesDTO = (
  personnelPrices: PersonnelPrice[],
  userInfo: Record<string, unknown>
): Partial<Dw_m_personnel_price>[] => {
  const personnelPriceList: Partial<Dw_m_personnel_price>[] = personnelPrices.map(
    (personnelPrice) => {
      const personnelPriceDTO: Partial<Dw_m_personnel_price> = {
        personnel_price_id: personnelPrice.personnelPriceId,
        dw_m_personnel: (personnelPrice.personnelId as unknown) as Dw_m_personnel,
        price_start_date: personnelPrice.priceStartDate,
        price_amount: personnelPrice.priceAmount,
        currency_type_code: personnelPrice.currencyTypeCode,
        contract_pattern_code: (personnelPrice.contractPatternCode as unknown) as number,
        created_by: (userInfo.name as unknown) as string,
        updated_by: (userInfo.name as unknown) as string,
        create_at: new Date(),
        update_at: new Date(),
        process_at: new Date(),
        process_id: null,
      }

      return personnelPriceDTO
    }
  )

  return personnelPriceList
}
