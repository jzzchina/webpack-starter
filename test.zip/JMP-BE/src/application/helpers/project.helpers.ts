import {
  PaginatedPersonnelList,
  Personnel,
} from '../../domain/models/Personnel'
import { WBS } from '../../domain/models/WBS'
import { Dw_m_personnel } from '../../infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { Dw_m_project } from '../../infrastructure/orm/typeorm/entities/Dw_m_project'
import { Dw_m_wbs } from '../../infrastructure/orm/typeorm/entities/Dw_m_wbs'
import { Dw_t_operation } from '../../infrastructure/orm/typeorm/entities/Dw_t_operation'
import { Dw_t_operation_plan } from '../../infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import {
  CreateProjectDto,
  Project,
  ProjectDtoResponse,
  ProjectListResponse,
} from '../../interface/routes/options/project/dto/projects.dto'
import { buildPersonnelPrices } from '../common/services/personnelPrice'
import { buildBusinessDaysObject } from './businessDays.helpers'

export const buildProjectListResponse = (
  projects: Partial<Dw_m_project>[],
  limit: number,
  offset: number,
  count: number,
  operationsByProject: { project_id: number; operations: Dw_t_operation[] }[]
): ProjectListResponse => {
  return {
    offset: offset,
    length: limit,
    totalLength: count,
    items: projects?.map((project) => ({
      projectId: project?.project_id,
      projectName: project?.project_name,
      status: project?.status,
      projectStartDate: project?.project_start_date,
      projectEndDate: project?.project_end_date,
      projectManager: project?.project_manager,
      projectContact: project?.project_contact,
      projectContact2: project?.project_contact2,
      projectContact3: project?.project_contact3,
      projectContact4: project?.project_contact4,
      userPart: project?.user_part,
      note: project?.notes,
      wbs: projectsWBSObjectMapper(project.dw_m_wbs ?? []),
      operation: (() => {
        const operations = operationsByProject.find(
          ({ project_id }) => project_id === project.project_id
        )?.operations
        if (!operations) return false
        return operations.length > 0
      })(),
    })) as Project[],
  }
}

export const buildProjectsCreateQueryParams = (
  projectList: CreateProjectDto[],
  userName: string
): Partial<Dw_m_project>[] => {
  return projectList.map((project) => ({
    project_id: project.projectId ?? undefined,
    project_name: project.projectName,
    status: project.status,
    project_start_date: new Date(project.projectStartDate),
    project_end_date: project.projectEndDate
      ? new Date(project.projectEndDate)
      : null,
    project_manager: project.projectManager,
    project_contact: project.projectContact,
    project_contact2: project.projectContact2,
    project_contact3: project.projectContact3,
    project_contact4: project.projectContact4,
    user_part: project.userPart,
    notes: project.note,
    created_by: userName,
    updated_by: userName,
  }))
}

export const buildWbsListQueryParams = (
  projectIds: number[],
  projectInput: CreateProjectDto[],
  userName: string
): Partial<Dw_m_wbs>[] => {
  return projectInput.map(
    (project, index) =>
      (({
        dw_m_project: { project_id: projectIds[index] },
        wbs_code: project.wbsCode,
        wbs_title: project.wbsTitle,
        subject: project.wbsSubject,
        created_by: userName,
        updated_by: userName,
      } as unknown) as Dw_m_wbs)
  )
}
export const buildProjectDtoResponse = (
  project: Dw_m_project,
  wbs: Partial<Dw_m_wbs & { project_id: number }>[]
): ProjectDtoResponse => {
  const wbsObject = wbs.find(
    (item) => item?.dw_m_project?.project_id === project.project_id
  ) as Dw_m_wbs
  return {
    projectId: project.project_id,
    projectName: project.project_name,
    status: project.status,
    projectStartDate: project.project_start_date.toISOString().split('T')[0],
    projectEndDate: (project.project_end_date as string | null) ?? null,
    projectManager: project.project_manager ? project.project_manager : '',
    projectContact: project.project_contact,
    projectContact2: project.project_contact2,
    projectContact3: project.project_contact3,
    projectContact4: project.project_contact4,
    userPart: project.user_part,
    note: project.notes as string,
    wbsCode: wbsObject.wbs_code,
    wbsTitle: wbsObject.wbs_title,
    wbsSubject: wbsObject.subject,
    createdBy: project.created_by,
    createdAt: project.create_at?.toISOString(),
    updatedBy: project.updated_by,
    updateAt: project.update_at ? project.update_at.toISOString() : null,
    processAt: project.process_at ? project.process_at.toISOString() : null,
    processId: project.process_id ? project.process_id : null,
  }
}
export const projectsWBSObjectMapper = (
  wbs: Partial<Dw_m_wbs>[]
): Partial<WBS>[] => {
  if (!wbs) return []
  return wbs.map((wbsItem) => {
    return {
      wbsId: wbsItem.wbs_id,
      wbsCode: wbsItem.wbs_code,
      wbsTitle: wbsItem.wbs_title,
      wbsSubject: wbsItem.subject,
    }
  })
}
/**
 * @description build the response object for personnel list in specific format
 * @param personnel  the personnel list was found from database with search criteria
 * @param limit  limit used for pagination
 * @param offset offset used for pagination
 * @param count  total count of personnel list
 * @returns object of personnel list response in specific format
 */
export const buildFindAllPersonnelResponse = (
  personnel: Partial<Dw_m_personnel>[],
  limit: number,
  offset: number,
  count: number
): PaginatedPersonnelList => {
  // build the result in specific format and return it
  return {
    offset: offset,
    length: limit,
    totalLength: count,
    items: personnel.map((personnel) => ({
      // loop through the personnel list and build the personnel object in specific format as below
      personnelId: personnel?.personnel_id,
      name: personnel?.name,
      nameJpn: personnel?.name_jpn,
      email: personnel?.email,
      registeredDate: personnel?.registered_date,
      unregisteredDate: personnel?.unregistered_date,
      companyId: personnel.dw_m_partner_company?.company_id,
      businessDays: buildBusinessDaysObject(
        personnel.dw_m_partner_company?.dw_m_business_day ?? []
      ),
      contractPatternCode:
        personnel.dw_m_partner_company?.contract_pattern_code,
      companyName: personnel.dw_m_partner_company?.company_name,
      skillList: personnel?.skill_list,
      prices: buildPersonnelPrices(personnel.dw_m_personnel_price),
      allAssignedProjects: buildAllAssignedPrjectsObject(
        personnel.dw_t_operation_plan as Dw_t_operation_plan[]
      ),
    })) as Personnel[],
  }
}
/**
 * @description build the object of assigned projects with sorted and unique projects
 * @param operationPlans {Dw_t_operation_plan[]} array of operation plan that contained the projects
 * @returns {string[]}- Array of assigned projects names
 */
export const buildAllAssignedPrjectsObject = (
  operationPlans: Dw_t_operation_plan[]
): string[] => {
  // get all projects from operation plans
  const projects: Dw_m_project[] = operationPlans.map(
    (operationPlan) => operationPlan.dw_m_project as Dw_m_project
  )
  // filter out the null projects and sort the projects by project start date and project name
  return (
    projects
      // filter out the duplicate projects
      .filter(
        (project, index, self) =>
          project !== null &&
          index ===
            self.findIndex((t) => t?.project_name === project?.project_name)
      )
      // sort the projects by project start date and project name
      .sort((a, b) => (a?.project_start_date < b?.project_start_date ? 1 : -1))
      .sort((a, b) => a.project_name.localeCompare(b.project_name))
      // get the project name
      .map((project) => project.project_name)
  )
}
