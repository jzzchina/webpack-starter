import { Dw_m_business_days } from '../../infrastructure/orm/typeorm/entities/Dw_m_business_days'
import { Dw_m_personnel } from '../../infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { Dw_m_project } from '../../infrastructure/orm/typeorm/entities/Dw_m_project'
import { Dw_t_operation } from '../../infrastructure/orm/typeorm/entities/Dw_t_operation'
import {
  OperationPlanPersonnel,
  OperationPlanPersonnelResponse,
  OperationPlanPersonnelTotal,
  OperationPlanProject,
  OperationPlanProjectResponse,
} from '../../infrastructure/repositories/operationPlan/interface'
import { getAllPersonnelIds } from '../common/services/personnel'
import { getAllProjectIds } from '../common/services/project'
import { buildPersonnelPrices } from '../common/services/personnelPrice'
import { buildBusinessDaysObject } from './businessDays.helpers'
import { Dw_t_operation_plan } from '../../infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import {
  CreateOperationPlanDto,
  CreateOperationPlanResponse,
} from '../../interface/routes/operationPlan/dto/operationPlans.dto'
import { JwtPayload } from 'jsonwebtoken'

/**
 * This function sorts two operation plans by month of year.
 * @param a The first operation plan to compare.
 * @param b The second operation plan to compare.
 * @param order The order in which to sort the operation plans. Defaults to 'ASC'.
 * @returns A number indicating the order of the operation plans (
 * -1: monthYearDate of A < B
 * 0: monthYearDate of A = B
 * 1: monthYearDate of A > B
 * ).
 * @description This function sorts two operation plans by month of year.
 */

export const sortOperationPlanByMonthOfYear = (
  a: Dw_t_operation_plan,
  b: Dw_t_operation_plan,
  order?: 'ASC' | 'DES'
): number => {
  if (a?.month_of_year_date < b?.month_of_year_date) {
    return order === 'DES' ? 1 : -1
  }

  if (a?.month_of_year_date > b?.month_of_year_date) {
    return order === 'DES' ? -1 : 1
  }

  return 0
}

/**
 * This function takes an array of operation plans and returns an object that groups
 * them by month of year, with each group containing the total number of man months
 * for that month. If `showOnlyManMonthNumber` is true, the object only contains the
 * man month number for each month, otherwise it also contains the role ID and name
 * for each month.
 *
 * @param operationPlans An array of operation plans to group by month of year.
 * @param showOnlyManMonthNumber Whether to only show the man month number for each month.
 * @returns An object that groups the operation plans by month of year, with the total number of man months for each month.
 * @description This function takes an array of operation plans and returns an object that groups
 */
const buildOperationPlansManMonthNumberGroup = (
  operationPlans?: Dw_t_operation_plan[], // an optional array of Dw_t_operation_plan objects
  showOnlyManMonthNumber = false // a flag indicating whether to include only man-month numbers in the result object
): OperationPlanPersonnelTotal => {
  // the function returns an object of type OperationPlanPersonnelTotal

  return (
    operationPlans
      // sort and reduce the array of objects to the desired result
      ?.sort(sortOperationPlanByMonthOfYear)
      // sort the objects in the array by month of year
      ?.reduce((operationPlan, currentOperationPlan) => {
        // reduce the array to an object, grouping by month of year
        const monthOfYear = currentOperationPlan?.month_of_year_date.toString()
        // extract the month of year from the current object
        const manMonthNumber = Number(currentOperationPlan.man_month_number)
        // extract the man-month number from the current object

        if (monthOfYear && !operationPlan[monthOfYear]) {
          // if the month of year is not already in the result object, create a new entry for it
          operationPlan[monthOfYear] = {
            // create a new entry for the month of year
            operationPlanId: currentOperationPlan?.operation_plan_id, // set the operation plan ID for the current object,
            manMonthNumber: manMonthNumber, // set the man-month number for the current object
          }

          if (!showOnlyManMonthNumber) {
            // if the flag is not set to true, also add the roleId and roleName properties to the new entry
            Object.assign(operationPlan[monthOfYear], {
              operationPlanId: currentOperationPlan?.operation_plan_id,
              roleId: currentOperationPlan?.dw_m_role?.role_id,
              roleName: currentOperationPlan?.dw_m_role?.role_name,
            })
          }
        } else {
          // if the month of year is already in the result object, add the current object's man-month number to the existing entry
          operationPlan[monthOfYear].manMonthNumber += manMonthNumber
        }

        return operationPlan // return the updated result object
      }, {} as OperationPlanPersonnelTotal) as OperationPlanPersonnelTotal
  ) // initialize the result object as an empty object of type OperationPlanPersonnelTotal
}

/**
 * @description build projects response in specific format
 * @param personnel personnel object
 * @returns  list of projects belongs to the operation plan that linked to the personnel response in specific format
 */
export const buildProjectsResponse = (
  personnel: Partial<Dw_m_personnel>
): OperationPlanProject[] => {
  // return empty array if personnel is null or undefined
  if (!personnel?.dw_t_operation_plan?.length) {
    return []
  }
  // return the result in specific format
  const projects = personnel.dw_t_operation_plan
    ?.filter((plan) => plan.dw_m_project)
    .map((plan) => ({
      projectId: plan.dw_m_project?.project_id,
      projectName: plan.dw_m_project?.project_name,
      projectContact: plan.dw_m_project?.project_contact,
      projectStartDate: plan.dw_m_project?.project_start_date,
      projectEndDate: plan.dw_m_project?.project_end_date,
      note: plan.dw_m_project?.notes,
      operation:
        plan.dw_m_project?.dw_t_operation?.filter(
          (operation: Dw_t_operation): boolean =>
            operation?.dw_m_personnel?.personnel_id === personnel?.personnel_id
        ).length !== 0,
      roleId: plan.dw_m_role?.role_id,
      roleName: plan.dw_m_role?.role_name,
      operationPlans: buildOperationPlansManMonthNumberGroup(
        plan?.dw_m_project?.dw_t_operation_plan
      ),
    })) as OperationPlanProject[]
  // remove duplicate project
  return projects.reduce((newProjects, currentProject) => {
    // check if the project is already exist in the newProjects array
    const existProject = newProjects.find(
      (project) => project?.projectId === currentProject?.projectId
    )
    // if the project is not exist in the newProjects array, push the project to the newProjects array
    if (!existProject) {
      // push the project to the newProjects array
      newProjects.push(currentProject)
    }
    // return the newProjects array
    return newProjects
  }, [] as OperationPlanProject[])
}

/**
 *
 * @param personnels list of personnel
 * @param totalItems  total items of personnel that match the criteria
 * @param to  to date of unregister date of personnel
 * @param from  from date of registered date of personnel
 * @param offset  offset used for pagination
 * @returns  object of operation plan by personnel response in specific format
 */
export const buildOperationPlanPersonnelResponseObject = (
  personnels: Partial<Dw_m_personnel>[],
  totalItems: number,
  to: string,
  from: string,
  offset: number
): OperationPlanPersonnelResponse => {
  const items = personnels
    .map((personnel) => ({
      // return the result in specific format
      companyId: personnel.dw_m_partner_company?.company_id,
      contractPatternCode:
        personnel.dw_m_partner_company?.contract_pattern_code,
      companyName: personnel.dw_m_partner_company?.company_name,
      personnelId: personnel.personnel_id,
      name: personnel.name,
      nameJpn: personnel.name_jpn,
      registeredDate: personnel.registered_date,
      unregisteredDate: personnel.unregistered_date,
      skillList: personnel.skill_list,
      prices: personnel.dw_m_personnel_price?.map((price) => ({
        contractPatternCode: price.contract_pattern_code,
        priceStartDate: price.price_start_date,
        priceAmount: price.price_amount,
        currencyTypeCode: price.currency_type_code,
      })),
      businessDays: buildBusinessDaysObject(
        personnel.dw_m_partner_company?.dw_m_business_day ?? []
      ),
      totals: {
        operationPlans: buildOperationPlansManMonthNumberGroup(
          personnel.dw_t_operation_plan,
          true
        ),
      },
      allProjectIds: getAllProjectIds(personnel?.dw_t_operation_plan),
      projects: buildProjectsResponse(personnel),
    }))
    .filter((personnel) => personnel.personnelId) as OperationPlanPersonnel[]

  return {
    from: from,
    to: to,
    offset,
    length: personnels.length,
    totalLength: totalItems,
    items,
  }
}

/**
 *@description build operation plan project response object
 * @param projects  list of projects
 * @param totalItems  total items
 * @param to  to date of project end date
 * @param from  from date of project start date
 * @param offset  offset used for pagination
 * @returns  object of operation plan by projects response in specific format
 */
export const buildOperationPlanProjectResponseObject = (
  projects: Partial<Dw_m_project>[],
  totalItems: number,
  to: string,
  from: string,
  offset: number
): OperationPlanProjectResponse => {
  // map through the result to build the result in specific format
  const items = projects.map((project) => {
    // build the result in specific format
    return {
      projectId: project.project_id,
      projectName: project.project_name,
      projectContact: project.project_contact,
      projectContact2: project.project_contact2,
      projectContact3: project.project_contact3,
      projectContact4: project.project_contact4,
      projectStartDate: project.project_start_date,
      projectEndDate: project.project_end_date,
      note: project.notes,
      totals: {
        operationPlans: buildOperationPlansManMonthNumberGroup(
          project.dw_t_operation_plan,
          true
        ),
      },
      allPersonnelIds: getAllPersonnelIds(project?.dw_t_operation_plan),
      personnel: buildPersonnelsResponse(project),
    }
  }) as OperationPlanProject[]
  // return the result in specific format as below
  return {
    from: from,
    to: to,
    offset,
    length: projects.length,
    totalLength: totalItems,
    items,
  }
}

/**
 * @description build personnels belongs to the projects in specific format
 * @param project  project
 * @returns  list of personnels
 */
const buildPersonnelsResponse = (
  project: Partial<Dw_m_project>
): OperationPlanPersonnel[] => {
  // check if the project has operation plans
  if (!project?.dw_t_operation_plan?.length) {
    // return empty array if the project has no operation plans
    return []
  }
  // map through the operation plans to build the result in specific format
  const personnels = project.dw_t_operation_plan
    .map((plan) => ({
      companyId: plan.dw_m_personnel?.dw_m_partner_company?.company_id,
      contractPatternCode:
        plan.dw_m_personnel?.dw_m_partner_company?.contract_pattern_code,
      companyName: plan.dw_m_personnel?.dw_m_partner_company?.company_name,
      personnelId: plan.dw_m_personnel?.personnel_id,
      name: plan.dw_m_personnel?.name,
      nameJpn: plan.dw_m_personnel?.name_jpn,
      registeredDate: plan.dw_m_personnel?.registered_date,
      unregisteredDate: plan.dw_m_personnel?.unregistered_date,
      operation:
        plan.dw_m_personnel?.dw_t_operation?.filter(
          (operation: Dw_t_operation): boolean =>
            operation.dw_m_project?.project_id === project.project_id
        ).length !== 0,
      skillList: plan.dw_m_personnel?.skill_list,
      prices: buildPersonnelPrices(plan.dw_m_personnel?.dw_m_personnel_price),
      businessDays: buildBusinessDaysObject(
        plan.dw_m_personnel?.dw_m_partner_company
          ?.dw_m_business_day as Dw_m_business_days[]
      ),
      operationPlans: buildOperationPlansManMonthNumberGroup(
        plan.dw_m_personnel?.dw_t_operation_plan
      ),
    }))
    .filter((personnel) => personnel.personnelId) as OperationPlanPersonnel[]
  // build unique  list of personnels
  return personnels.reduce((newPersonnels, currentPersonnel) => {
    // check if the personnel is already exist in the list
    const existPersonnel = newPersonnels.find(
      (personnel) => personnel?.personnelId === currentPersonnel?.personnelId
    )
    // add the personnel to the list if it is not exist
    if (!existPersonnel) {
      newPersonnels.push(currentPersonnel)
    }
    // return the unique list of personnels
    return newPersonnels
  }, [] as OperationPlanPersonnel[])
}

export const buildOperationPlanCreateQueryParams = (
  arrayBody: CreateOperationPlanDto[],
  userInformation: JwtPayload
): Partial<Dw_t_operation_plan>[] => {
  // map the operation plan input data array to get the operation plan create query params
  return arrayBody.map(
    // map the operation plan input data array to get the operation plan create query params
    (item) =>
      (({
        operation_plan_id: item.operationPlanId,
        man_month_number: item.manMonthNumber,
        dw_m_personnel: item.personnelId,
        dw_m_project: item.projectId,
        dw_m_role: item.roleId,
        month_of_year_date: item.yearOfMonthDate,
        hours_number: item.hoursNumber,
        created_by: userInformation.name,
        updated_by: userInformation.name,
      } as unknown) as Dw_t_operation_plan)
  )
  // return the operation plan create query params array in the form of partial operation plan
}

/**
 * @description This method will get the cost amount from the operation
 * @param operation operation data
 * @returns cost amount
 */
export const getCostAmount = (operation: Dw_t_operation[]): number => {
  // if operation length is 0, return 0
  if (operation.length === 0) return 0
  // if operation length is not 0, return the cost amount
  return operation[0].cost_amount
}

/**
 * @description This method will build the operation plan response
 * @param operationPlans operation plan data
 * @returns operation plan response
 */
export const buildCreateOperationPlanResponse = (
  operationPlans: Partial<Dw_t_operation_plan>[]
): CreateOperationPlanResponse[] => {
  // map the operation plan data to get the operation plan response
  return operationPlans.map(
    (operationPlan) =>
      (({
        // map the operation plan data to get the operation plan response
        operationPlanId: operationPlan.operation_plan_id,
        costAmount: getCostAmount(
          operationPlan.dw_m_project?.dw_t_operation ?? []
        ),
        manMonthNumber: operationPlan.man_month_number,
        hoursNumber: operationPlan.hours_number,
        personnelId: operationPlan.dw_m_personnel?.personnel_id,
        projectId: operationPlan.dw_m_project?.project_id,
        yearOfMonthDate: operationPlan.month_of_year_date,
        roleId: operationPlan.dw_m_role?.role_id,
        roleName: operationPlan.dw_m_role?.role_name,
        createdBy: operationPlan.created_by,
        createdAt: operationPlan.create_at,
        updatedBy: operationPlan.updated_by,
        updateAt: operationPlan.update_at,
        processAt: operationPlan.process_at,
        processId: operationPlan.process_id,
      } as unknown) as CreateOperationPlanResponse)
    // return the operation plan response in the form of array of operation plan response format
  )
}
