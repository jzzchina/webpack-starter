import {
  DeleteOperationCostSQLRequest,
  OperationCostKeys,
} from '../../interface/routes/operationCost/dto/operationCost.dto'

import { JwtPayload } from 'jsonwebtoken'
import {
  CreateOperationCostDto,
  CreateOperationCostResponse,
} from '../../interface/routes/operationCost/dto/operationCost.dto'
import { OperationCostCreateRequest } from '../../infrastructure/repositories/operationCost/interface'
import { Dw_t_operation } from '../../infrastructure/orm/typeorm/entities/Dw_t_operation'
import { Dw_m_business_days } from '../../infrastructure/orm/typeorm/entities/Dw_m_business_days'
import { Dw_m_project } from '../../infrastructure/orm/typeorm/entities/Dw_m_project'
import { Dw_t_operation_plan } from '../../infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import {
  OperationCostListResponse,
  PersonnelOperationCost,
  ProjectOperationCost,
} from '../../interface/routes/operationCost/dto/operationCost.dto'
import { buildPersonnelPrices } from '../common/services/personnelPrice'
import { buildBusinessDaysObject } from './businessDays.helpers'
import {
  OperationCostAmount,
  OperationPlanManMonthNumber,
} from '../../domain/types/operation.type'

/**
 * @description Function used to build the DTO that will be used to create the operation cost
 * @param arrayBody {CreateOperationCostDto} the body of the HTTP request
 * @param userInformation {JwtPayload} the information of the user who created the operation cost
 * @returns  the list of operation cost DTO
 */
export const buildOperationCreateQueryParams = (
  arrayBody: CreateOperationCostDto[],
  userInformation: JwtPayload
): OperationCostCreateRequest[] => {
  // the function returns a list of operation cost DTO
  return arrayBody.map((item) => ({
    operation_id: item.operationId,
    hours_number: item.hoursNumber,
    cost_amount: item.costAmount,
    dw_m_personnel: item.personnelId,
    dw_m_project: item.projectId,
    month_of_year_date: item.yearOfMonthDate?.toString(),
    created_by: userInformation ? userInformation.name : '',
    updated_by: userInformation ? userInformation.name : '',
  })) as OperationCostCreateRequest[]
}

/**
 * @description Function used to build the response that will be returned
 * @param operations  the list of operation cost that were created
 * @returns  the list of operation cost that were created
 */
export const buildCreateOperationCostResponse = (
  operations: Dw_t_operation[]
): CreateOperationCostResponse[] => {
  // the function returns a list of operation cost
  // map the list of operation cost to a list of operation cost
  return operations.map(
    (operation) =>
      (({
        operationId: operation.operation_id,
        costAmount: operation.cost_amount,
        hoursNumber: operation.hours_number,
        personnelId: operation.dw_m_personnel?.personnel_id,
        projectId: operation.dw_m_project?.project_id,
        yearOfMonthDate: operation.month_of_year_date,
        createdBy: operation.created_by,
        createdAt: operation.create_at,
        updatedBy: operation.updated_by,
        updateAt: operation.update_at,
        processAt: operation.process_at,
        processId: operation.process_id,
        // cast the operation cost to the type of the operation cost response
      } as unknown) as CreateOperationCostResponse)
  )
}

/**
 *@description get formatted object of operation cost
 * @param projects list of projects
 * @param totalItems total items
 * @param from from date of project start date
 * @param to to date of project end date
 * @param offset offset used for pagination
 * @param limit limit used for pagination
 * @returns operation cost list response
 */
export const buildOperationCostListResponse = (
  projects: Partial<Dw_m_project>[],
  totalItems: number,
  from: string,
  to: string,
  offset: number,
  limit: number
): OperationCostListResponse => {
  return {
    from,
    to,
    offset,
    length: limit,
    totalLength: totalItems,
    // build operation cost list response
    items: projects.map((project) => ({
      projectId: project?.project_id,
      projectName: project?.project_name,
      projectContact: project?.project_contact,
      projectContact2: project?.project_contact2,
      projectContact3: project?.project_contact3,
      projectContact4: project?.project_contact4,
      projectStartDate: project?.project_start_date,
      projectEndDate: project?.project_end_date,
      note: project?.notes,
      personnel: buildOperationCostPersonnels(project),
      wbs: buildOperationCostWBS(project),
    })) as ProjectOperationCost[],
  }
}
/**
 * @description build Cost Amounts object
 * @param projects list of projects
 * @returns return formatted cost amount object
 */
export const buildOperationCostAmounts = (
  operations?: Partial<Dw_t_operation>[]
): OperationCostAmount => {
  return operations?.reduce((operation, currentOperation) => {
    const monthOfYear = currentOperation?.month_of_year_date?.toString()
    const hoursNumber = Number(currentOperation.hours_number)
    const costAmount = Number(currentOperation.cost_amount)

    if (monthOfYear) {
      // if month of year exists
      if (!operation[monthOfYear]) {
        // if operation does not exist on month of year
        operation[monthOfYear] = {
          operationId: Number(currentOperation.operation_id),
          costAmount: costAmount ?? 0,
          hoursNumber: hoursNumber ?? 0,
        }
      } else {
        // if operation exists on month of year
        operation[monthOfYear].costAmount += costAmount ?? 0
        // add cost amount to operation on month of year
        operation[monthOfYear].hoursNumber += hoursNumber ?? 0
        // add hours number to operation on month of year
      }
    }
    return operation
  }, {} as OperationCostAmount) as OperationCostAmount
}
/**
 * @description build unique list of operation costs
 * @param projects list of projects
 * @returns list of unique operation costs
 */
export const getUniqueListOfOperationCosts = (
  projects: Partial<Dw_m_project>[]
): Partial<Dw_m_project>[] => {
  // return a unique operation costs List  based on personnel id and company id
  projects.map((project) => {
    project.dw_t_operation_plan = project.dw_t_operation_plan?.filter(
      (operation_plan, index, self) =>
        index ===
        self.findIndex(
          // find index of operation plan
          (t) =>
            t.dw_m_personnel?.personnel_id ===
              // check if personnel id and company id is unique
              operation_plan.dw_m_personnel?.personnel_id &&
            t.dw_m_personnel?.dw_m_partner_company?.company_id ===
              operation_plan.dw_m_personnel?.dw_m_partner_company?.company_id
        )
      // return operation plan if personnel id and company id is unique
    )
  })
  return projects
}
/**
 * @description build formatted operation cost by personnel
 * @param project project object
 * @returns  list of formatted operation cost by personnel
 */
const buildOperationCostPersonnels = (
  project: Partial<Dw_m_project>
): PersonnelOperationCost[] => {
  return project.dw_t_operation_plan
    ?.map((operation_plan) => ({
      companyId:
        operation_plan.dw_m_personnel?.dw_m_partner_company?.company_id,
      contractPatternCode:
        operation_plan.dw_m_personnel?.dw_m_partner_company
          ?.contract_pattern_code,
      companyName:
        operation_plan.dw_m_personnel?.dw_m_partner_company?.company_name,
      personnelId: operation_plan.dw_m_personnel?.personnel_id,
      name: operation_plan.dw_m_personnel?.name,
      nameJpn: operation_plan.dw_m_personnel?.name_jpn,
      registeredDate: operation_plan.dw_m_personnel?.registered_date,
      unregisteredDate: operation_plan.dw_m_personnel?.unregistered_date,
      prices: buildPersonnelPrices(
        operation_plan.dw_m_personnel?.dw_m_personnel_price
      ),
      businessDays:
        // call buildBusinessDaysObject function to build business days object
        buildBusinessDaysObject(
          operation_plan.dw_m_personnel?.dw_m_partner_company
            ?.dw_m_business_day as Dw_m_business_days[]
        ) ?? {},

      operationPlans: buildOperationPlansManMonthNumber(
        operation_plan.dw_m_personnel?.dw_t_operation_plan
      ),
      operations: buildOperationCostAmounts(
        operation_plan.dw_m_personnel?.dw_t_operation
      ),
    }))
    .filter((personnel) => personnel.personnelId) as PersonnelOperationCost[]
}
const buildOperationCostWBS = (project: Partial<Dw_m_project>) => {
  const wbs = project.dw_m_wbs?.[0] // Get the first WBS object from the array
  return wbs
    ? {
        wbsTitle: wbs.wbs_title,
        wbsCode: wbs.wbs_code,
      }
    : null // Return null if there are no WBS objects
}
/**
 * @description build formatted operation plan with man month number and hours number
 * @param operationPlans list of operation plans
 * @returns object of formatted operation plans
 */
const buildOperationPlansManMonthNumber = (
  operationPlans?: Partial<Dw_t_operation_plan>[]
): OperationPlanManMonthNumber => {
  return operationPlans?.reduce((operationPlan, currentOperationPlan) => {
    const monthOfYear = currentOperationPlan?.month_of_year_date?.toString()
    const hoursNumber = Number(currentOperationPlan.hours_number)
    const manMonthNumber = Number(currentOperationPlan.man_month_number)
    if (monthOfYear) {
      if (!operationPlan[monthOfYear]) {
        operationPlan[monthOfYear] = {
          manMonthNumber: manMonthNumber ?? 0,
          hoursNumber: hoursNumber ?? 0,
        }
      } else {
        // if operation plan exists on month of year
        operationPlan[monthOfYear].manMonthNumber += manMonthNumber ?? 0
        // manMonth number of operationPlan of month of year equal sum of manMonthNumber
        operationPlan[monthOfYear].hoursNumber += hoursNumber ?? 0
        // hours number of operationPlan of month of year equal sum of hoursNumber
      }
    }
    return operationPlan
  }, {} as OperationPlanManMonthNumber) as OperationPlanManMonthNumber
}

export const buildOperationCostInputs = (
  operationCosts: OperationCostKeys[]
): DeleteOperationCostSQLRequest => {
  const ProjectIds: number[] = []
  const PersonnelIds: number[] = []
  const YearOfMonths: string[] = []
  operationCosts.forEach((operationCost) => {
    ProjectIds.push(operationCost.projectId)
    PersonnelIds.push(operationCost.personnelId)
    YearOfMonths.push(String(operationCost.yearOfMonthDate))
  })
  return {
    ProjectIds,
    PersonnelIds,
    YearOfMonths,
  }
}
