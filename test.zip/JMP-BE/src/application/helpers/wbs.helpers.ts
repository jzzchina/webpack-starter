import { Dw_m_personnel } from '../../infrastructure/orm/typeorm/entities/Dw_m_personnel'
import {
  WbsCostListResponse,
  WbsTotalItem,
  WbsTotal,
  WbsPeriodItem,
  WbsPeriodData,
} from '../../interface/routes/wbs/dto/wbsCosts'
import { convertDateToYYYYMM } from '../common/common'

/**
 * @description build wbs cost list response
 * @param personnel list of wbs info
 * @param from start date
 * @param to end date
 * @param offset the number of items should be skipped
 * @param limit limit max of items should be returned
 * @param companyId company ID
 * @returns wbs cost list
 */
export const buildWbsCostListResponse = (
  personnel: Partial<Dw_m_personnel>[],
  from: string,
  to: string,
  offset: number,
  limit: number,
  companyId: number
): WbsCostListResponse => {
  let companyName = ''

  const wbsCosts = personnel
    .flatMap((p) => {
      const operations = p.dw_t_operation
      if (!operations) return []

      const company = p.dw_m_partner_company
      if (!company) return []

      companyName = company.company_name

      return operations
        .map((o) => {
          const project = o.dw_m_project
          const wbs = project?.dw_m_wbs
          if (!wbs) return null

          const wbsPeriodItems: Array<WbsPeriodItem> = wbs.map((w) => ({
            wbsCode: w.wbs_code,
            wbsTitle: w.wbs_title,
            subject: w.subject,
            projectName: project.project_name,
            amount: o.cost_amount,
            currency_type_code:
              p.dw_m_personnel_price?.[0]?.currency_type_code ?? 0,
          }))

          const total: WbsTotal = []
          wbsPeriodItems.forEach((item) => {
            let totalItemIdx: number = total.findIndex(
              (ti: WbsTotalItem) =>
                ti.currency_type_code === item.currency_type_code
            )
            if (totalItemIdx === -1) {
              totalItemIdx =
                total.push({
                  currency_type_code: item.currency_type_code,
                  amount: 0,
                }) - 1
            }
            total[totalItemIdx].amount += item.amount
          })

          const wbsPeriodData: WbsPeriodData = {
            month: convertDateToYYYYMM(new Date(o.month_of_year_date)),
            total,
            wbs: wbsPeriodItems,
          }

          return wbsPeriodData
        })
        .filter((data) => data !== null) as WbsPeriodData[]
    })
    .flat()

  /**
   * Get result grouped by month
   */
  const groupByMonthAndWbsCode = (wbsData: WbsPeriodData[]) => {
    const map = new Map<string, Map<string, { [key: number]: WbsPeriodItem }>>()

    wbsData.forEach((item) => {
      const monthKey = item.month

      if (!map.has(monthKey)) {
        map.set(monthKey, new Map())
      }

      const monthMap = map.get(monthKey)!

      item.wbs.forEach((wbsItem) => {
        const wbsKey = wbsItem.wbsCode

        if (!monthMap.has(wbsKey)) {
          monthMap.set(wbsKey, {})
        }

        const wbsMap = monthMap.get(wbsKey)!

        if (wbsMap[wbsItem.currency_type_code]) {
          wbsMap[wbsItem.currency_type_code].amount += wbsItem.amount
        } else {
          wbsMap[wbsItem.currency_type_code] = { ...wbsItem }
        }
      })
    })

    return Array.from(map.entries()).map(([month, wbsMap]) => {
      const wbsPeriodItems = Array.from(
        wbsMap.values()
      ).flatMap((currencyMap) => Object.values(currencyMap))
      const total: WbsTotal = []
      wbsPeriodItems.forEach((item) => {
        let totalItemIdx: number = total.findIndex(
          (ti: WbsTotalItem) =>
            ti.currency_type_code === item.currency_type_code
        )
        if (totalItemIdx === -1) {
          totalItemIdx =
            total.push({
              currency_type_code: item.currency_type_code,
              amount: 0,
            }) - 1
        }
        total[totalItemIdx].amount += item.amount
      })

      return {
        month,
        total,
        wbs: wbsPeriodItems,
      }
    })
  }

  const filteredWbsCosts = wbsCosts.filter(
    (item): item is WbsPeriodData => item !== null && item.wbs.length > 0
  )
  const wbsCostsResult = groupByMonthAndWbsCode(filteredWbsCosts)
    .sort((a, b) => new Date(a.month).getTime() - new Date(b.month).getTime()) // Sort by ascending date
    .slice(offset, offset + limit)

  return {
    from,
    to,
    offset,
    length: limit,
    companyId,
    companyName,
    totalLength: wbsCostsResult.length,
    items: wbsCostsResult,
  }
}
