import { InsertResult } from 'typeorm'

/**
 * Builds an array of sales man identifiers from the given salesManPayload.
 *
 * @param {InsertResult} salesManPayload - The salesManPayload containing the identifiers.
 * @return {number[]} An array of sales man identifiers.
 */
export const salesManIdentifierBuilder = (
  salesManPayload: InsertResult
): number[] => {
  return salesManPayload?.identifiers?.map((item) => item.sales_man_id)
}
