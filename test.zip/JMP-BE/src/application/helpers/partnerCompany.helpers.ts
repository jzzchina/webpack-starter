import { SalesMan } from '../../domain/models/SalesMan'
import { Dw_m_partner_company } from '../../infrastructure/orm/typeorm/entities/Dw_m_partner_company'
import { Dw_m_sales_man } from '../../infrastructure/orm/typeorm/entities/Dw_m_sales_man'
import {
  PartnerCompanyQueryCreateInput,
  PartnerCompanyQueryResponse,
  PartnerCompanyRepositorySaveResult,
} from '../../infrastructure/repositories/options/partnerCompany/interface'
import {
  PartnerCompany,
  PartnerCompanyCreateResponse,
  PartnerCompanyListResponse,
} from '../../interface/routes/options/partnerCompany/dto/partnerCompany.dto'

/**
 * @description this function will build the list of partner company ids
 * @param insertedResult  the result of the partner company that was created by TypeORM
 * @returns  list of partner company ids
 */
export const buildPartnerCompanyIdentifiers = (
  insertedResult: PartnerCompanyRepositorySaveResult
): number[] => {
  // loop through the inserted result and get the company ids
  const identifiers: number[] = insertedResult.map((item) => item.company_id)
  // return the list of company ids
  return identifiers
}

/**
 * @description this method will build the query that will be used to create partner company in the repository
 * @param companyList list of partner company data comes from the HTTP request
 * @param userInformation  the user information that will be used to create the partner company
 * @returns  the list of partner company query that will be used to create partner company in the repository
 */
export const buildPartnerCompanyCreateQuery = (
  companyList: PartnerCompany[],
  userInformation: Record<string, unknown>
): PartnerCompanyQueryCreateInput[] => {
  // map through the list of partner company and build the query that will be used to create partner company in the repository
  return companyList.map((item) => ({
    company_id: item?.companyId,
    contract_pattern_code: item?.contractPatternCode,
    company_name: item?.companyName,
    created_by: userInformation ? userInformation.name : '',
    updated_by: userInformation ? userInformation.name : '',
  })) as PartnerCompanyQueryCreateInput[]
}

/**
  @description this method will build the response that will be returned in specific format
  @param companies  the list of partner company that was created
  @returns  the list of partner company that was created in specific format
 */
export const buildPartnerCompanyResponse = (
  companies: Dw_m_partner_company[],
  salesManData: Partial<Dw_m_sales_man>[]
): PartnerCompanyCreateResponse[] => {
  return companies.map((item) => ({
    // map through the list of partner company and build the response that will be returned
    companyId: item?.company_id,
    contractPatternCode: item?.contract_pattern_code,
    companyName: item?.company_name,
    salesMan: salesManData.map((salesMan) => ({
      salesManId: salesMan?.sales_man_id,
      name: salesMan?.name,
      emailAddress: salesMan?.email,
      phoneNumber: salesMan?.phone_number,
    })),
    createdBy: item?.created_by,
    createAt: item?.create_at,
    updatedBy: item?.updated_by,
    updateAt: item?.update_at,
    processAt: item?.process_at,
    processId: item?.process_id,
  })) as PartnerCompanyCreateResponse[]
}

/**
 * Parses a list of PartnerCompanyQueryBodyRequest objects into an array of Partial<Dw_m_sales_man> objects.
 *
 * @param {PartnerCompanyBodyRequest[]} partnerCompanyList - The list of PartnerCompanyQueryBodyRequest objects to be parsed.
 * @return {Partial<Dw_m_sales_man>[]} - The parsed array of Partial<Dw_m_sales_man> objects.
 */
export const salesManQueryParser = (
  partnerCompanyList: PartnerCompanyRepositorySaveResult,
  salesManList: SalesMan[],
  userInformation: Record<string, unknown>
): Partial<Dw_m_sales_man>[] => {
  return partnerCompanyList.flatMap((item) =>
    salesManList.map((salesMan) => ({
      sales_man_id: salesMan?.salesManId,
      name: salesMan?.name,
      dw_m_partner_company: (item.company_id as unknown) as Dw_m_partner_company,
      email: salesMan?.emailAddress,
      phone_number: salesMan?.phoneNumber,
      created_by: userInformation ? (userInformation.name as string) : '',
      create_at: new Date(),
      updated_by: userInformation ? (userInformation.name as string) : '',
    }))
  )
}
/**
 * @description build the result in specific format
 * @param partnerCompanys  list of partner company data
 * @param offset offset used for pagination
 * @param count  total items of partner company that match the criteria
 * @returns  object of partner company list response in specific format
 */
export const buildPartnerCompanyListResponse = (
  partnerCompanys: Partial<PartnerCompanyQueryResponse>[],
  offset: number,
  count: number
): PartnerCompanyListResponse => {
  return {
    offset: offset,
    length: partnerCompanys.length,
    totalLength: count,
    items: partnerCompanys.map((partnerCompany) => ({
      // map the result in specific format and return it
      companyId: partnerCompany?.company_id,
      contractPatternCode: partnerCompany?.contract_pattern_code,
      companyName: partnerCompany?.company_name,
      numberOfPersonnel: partnerCompany?.dw_m_personnel?.length,
      salesMan: partnerCompany?.dw_m_sales_man?.map((salesMan) => ({
        salesManId: salesMan?.sales_man_id,
        name: salesMan?.name,
        emailAddress: salesMan?.email,
        phoneNumber: salesMan?.phone_number,
      })),
    })) as PartnerCompany[],
  }
}
