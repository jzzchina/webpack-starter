import { Dw_m_personnel } from '../../infrastructure/orm/typeorm/entities/Dw_m_personnel'
import {
  PersonnelQueryCreateInput,
  PersonnelRepositorySaveResult,
} from '../../infrastructure/repositories/options/personnel/interface'
import {
  Personnel,
  PersonnelCreateResponse,
} from '../../interface/routes/options/personnel/dto/personnel.dto'
import { buildPersonnelPrices } from '../common/services/personnelPrice'

/**
 * @description this method will build the list of personnel ids
 * @param insertedResult  is the result of the personnel that was created by TypeORM
 * @returns  list of personnel ids
 */
export const buildPersonnelIdentifiers = (
  insertedResult: PersonnelRepositorySaveResult
): number[] => {
  const identifiers: number[] = insertedResult.map((item) => item.personnel_id)
  return identifiers
}
/**
 * @description this method will build the query that will be used to create personnel in the repository
 * @param personnelList list of personnel data comes from the HTTP request
 * @param userInformation  the user information that will be used to create the personnel
 * @returns  list of personnel query that will be used to create personnel in the repository
 */
export const buildPersonnelCreateQuery = (
  personnelList: Personnel[],
  userInformation: Record<string, unknown>
): PersonnelQueryCreateInput[] => {
  return (personnelList.map((item) => ({
    personnel_id: item?.personnelId,
    name: item?.name,
    name_jpn: item?.nameJpn,
    email: item?.email,
    registered_date: item?.registeredDate,
    unregistered_date: item?.unregisteredDate,
    skill_list: item?.skillList,
    dw_m_partner_company: item?.companyId,
    created_by: userInformation ? userInformation.name : '',
    updated_by: userInformation ? userInformation.name : '',
  })) as unknown) as PersonnelQueryCreateInput[]
}
/**
 * @description this method will build the response that will be returned
 * @param personnels list of personnel that was created
 * @returns  list of personnel that will be returned in specific format
 */
export const buildPersonnelResponse = (
  personnels: Dw_m_personnel[]
): PersonnelCreateResponse[] => {
  return (personnels.map((item) => ({
    personnelId: item?.personnel_id,
    name: item?.name,
    nameJpn: item?.name_jpn,
    email: item?.email,
    registeredDate: item?.registered_date,
    unregisteredDate: item?.unregistered_date,
    companyId: item?.dw_m_partner_company?.company_id,
    companyName: item?.dw_m_partner_company?.company_name,
    contractPatternCode: item?.dw_m_partner_company?.contract_pattern_code,
    skillList: item?.skill_list,
    prices: buildPersonnelPrices(item?.dw_m_personnel_price),
    createdBy: item?.created_by,
    createAt: item?.create_at,
  })) as unknown) as PersonnelCreateResponse[]
}
