import {
  Brackets,
  Connection,
  InsertResult,
  QueryFailedError,
  Repository,
  UpdateResult,
} from 'typeorm'

import { OperationPlanRepositoryPort } from '../../../application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { OperationPlan } from '../../../domain/models/OperationPlan'
import { SkillList } from '../../../domain/models/Personnel'
import {
  CustomQueryFailedError,
  ListQueryResponseBase,
} from '../common/interface'
import { Dw_t_operation_plan } from '../../orm/typeorm/entities/Dw_t_operation_plan'
import { Dw_m_project } from '../../orm/typeorm/entities/Dw_m_project'
import { Dw_m_personnel } from '../../orm/typeorm/entities/Dw_m_personnel'
import CustomError from '../../../application/errors/CustomError'
import messages from '../../../application/errors/messages'

export const operationPlanRepositoryMySQL = async (
  connection: Connection
): Promise<OperationPlanRepositoryPort> => ({
  deleteOperationPlans: async (arrayOps: Partial<OperationPlan>[]) => {
    const operationPlanRepository = connection.getRepository(
      Dw_t_operation_plan
    )
    for (let index = 0; index < arrayOps.length; index++) {
      const element = arrayOps[index]
      await operationPlanRepository
        .createQueryBuilder('dw_t_operation_plan')
        .softDelete()
        .where('personnel_id=:personnel_id', {
          personnel_id: element.personnel_id,
        })
        .andWhere('project_id=:project_id', { project_id: element.project_id })
        .andWhere('month_of_year_date=:month_of_year_date', {
          month_of_year_date: element.month_of_year_date,
        })
        .andWhere('deleted_at IS NULL')
        .execute()
        .then((result: UpdateResult) => {
          if (result.raw.affectedRows === 0) {
            throw new CustomError(messages.recordsDoesNotExist, 'Not Found')
          }
        })
    }
  },

  findMany: async (
    arrayOps: Partial<OperationPlan>[]
  ): Promise<Partial<Dw_t_operation_plan>[]> => {
    const operationPlanRepository = connection.getRepository(
      Dw_t_operation_plan
    )

    const operationPlans: Repository<Dw_t_operation_plan> = operationPlanRepository
    const queryBuilder = operationPlans
      .createQueryBuilder('operationPlan')
      .select('operationPlan')
      .leftJoinAndSelect('operationPlan.dw_m_project', 'project')
      .leftJoinAndSelect('operationPlan.dw_m_personnel', 'personnel')
      .leftJoinAndSelect('operationPlan.dw_m_role', 'role')
      .where('operationPlan.operation_plan_id IN (:...operationPlanIds)', {
        operationPlanIds: arrayOps.map((item) => item.operation_plan_id),
      })
      .andWhere(
        'operationPlan.month_of_year_date IN (:...month_of_year_dates)',
        { month_of_year_dates: arrayOps.map((item) => item.month_of_year_date) }
      )
    if (arrayOps.find((item) => item.project_id)) {
      queryBuilder.andWhere('operationPlan.project_id IN (:...project_ids)', {
        project_ids: arrayOps.map((item) => item.project_id),
      })
    }
    if (arrayOps.find((item) => item.personnel_id)) {
      queryBuilder.andWhere(
        'operationPlan.personnel_id IN (:...personnel_ids)',
        {
          personnel_ids: arrayOps.map((item) => item.personnel_id),
        }
      )
    }
    return queryBuilder.getMany().catch((err: QueryFailedError) => {
      throw new CustomError(err.message, 'Internal Server Error')
    })
  },

  findOperationPlansByProject: async (
    to: string,
    from: string,
    offset: number,
    limit: number,
    projectId: number | null,
    companyId: number | null,
    skills: SkillList
  ): Promise<ListQueryResponseBase<Dw_m_project[]>> => {
    const operationPlanRepository = connection.getRepository(Dw_m_project)

    const queryBuilder = operationPlanRepository
      .createQueryBuilder('project')
      .select([
        `project.project_id`,
        `project.project_name`,
        `project.project_contact`,
        `project.project_contact2`,
        `project.project_contact3`,
        `project.project_contact4`,
        `project.project_start_date`,
        `project.project_end_date`,
        `project.notes`,
        `personnel.personnel_id`,
        `personnel.name`,
        `personnel.name_jpn`,
        `personnel.registered_date`,
        `personnel.unregistered_date`,
        `personnel.skill_list`,
        'personnel_operation_plan.month_of_year_date',
        'personnel_operation_plan.man_month_number',
        'personnel_operation_plan.operation_plan_id',
        'company.company_id',
        'company.contract_pattern_code',
        'company.company_name',
        `role.role_id`,
        `role.role_name`,
      ])
      .leftJoinAndSelect(
        'project.dw_t_operation_plan',
        'operation_plan',
        'operation_plan.project_id=project.project_id'
      )
      .leftJoin(
        'operation_plan.dw_m_personnel',
        'personnel',
        'personnel.personnel_id=operation_plan.personnel_id'
      )
      .leftJoin(
        'personnel.dw_t_operation_plan',
        'personnel_operation_plan',
        'personnel_operation_plan.project_id=project.project_id AND personnel_operation_plan.personnel_id=personnel.personnel_id'
      )
      .leftJoinAndSelect(
        'personnel.dw_m_personnel_price',
        'personnel_price',
        'personnel_price.personnel_id=personnel.personnel_id'
      )
      .leftJoin(
        'personnel.dw_m_partner_company',
        'company',
        'company.company_id=personnel.company_id'
      )
      .leftJoin(
        'personnel_operation_plan.dw_m_role',
        'role',
        'role.role_id=personnel_operation_plan.role_id'
      )
      .leftJoinAndSelect(
        'company.dw_m_business_day',
        'BD',
        'BD.company_id=personnel.company_id'
      )
      .leftJoinAndSelect('personnel.dw_t_operation', 'operation')
      .leftJoinAndSelect('operation.dw_m_project', 'operation_project')

    if (from) {
      queryBuilder.where(
        new Brackets((builder) => {
          builder
            .where('project.project_end_date >= CONVERT(:from,DATE)', {
              from: from,
            })
            .orWhere('project.project_end_date IS NULL')
            .orWhere('project.project_end_date=CONVERT(:empty,DATE)', {
              empty: '',
            })
        })
      )
    }

    if (to) {
      queryBuilder.andWhere(
        new Brackets((builder) => {
          builder
            .andWhere('project.project_start_date <= CONVERT(:to,DATE)', {
              to: to,
            })
            .orWhere('project.project_start_date IS NULL')
            .orWhere('project.project_start_date=CONVERT(:empty,DATE)', {
              empty: '',
            })
        })
      )
    }

    if (projectId) {
      queryBuilder.andWhere('project.project_id=:project_id', {
        project_id: projectId,
      })
    }

    if (companyId) {
      queryBuilder.andWhere('company.company_id=:company_id', {
        company_id: companyId,
      })
    }

    if (skills !== undefined && skills !== null) {
      Object.keys(skills).forEach((skill, index) => {
        queryBuilder.andWhere(
          new Brackets((qb) => {
            if (skill && skills[skill].level !== undefined) {
              const parameterName = 'level' + index
              const lowerParameterName = 'lowestLevel'

              qb.andWhere(
                `personnel.skill_list->'$."${skill}".level' = :${parameterName}`,
                { [parameterName]: skills[skill].level }
              )
                .orWhere(
                  `personnel.skill_list->'$."${skill}".level' > :${parameterName}`,
                  { [parameterName]: skills[skill].level }
                )
                .orWhere(
                  `personnel.skill_list->'$."${skill}".level' < :${parameterName}`,
                  { [parameterName]: skills[skill].level }
                )
                .andWhere(
                  `personnel.skill_list->'$."${skill}".level' > :${lowerParameterName}`,
                  { [lowerParameterName]: 1 }
                )
            }
          })
        )
      })
    }

    const [results, count] = await queryBuilder
      .orderBy('project.project_id', 'ASC')
      .take(limit)
      .skip(offset)
      .getManyAndCount()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })

    return {
      items: results ?? [],
      totalItems: count,
    }
  },

  findOperationPlansByPersonnelId: async (
    from: string,
    to: string,
    personnelId: number
  ): Promise<Dw_t_operation_plan[]> => {
    const operationPlanRepository = connection.getRepository(
      Dw_t_operation_plan
    )
    return operationPlanRepository
      .createQueryBuilder('operation_plan')
      .where('operation_plan.personnel_id=:personnel_id', {
        personnel_id: personnelId,
      })
      .andWhere('operation_plan.month_of_year_date >= CONVERT(:from,DATE)', {
        from: from,
      })
      .andWhere('operation_plan.month_of_year_date <= CONVERT(:to,DATE)', {
        to: to,
      })
      .getMany()
      .then((results) => results)
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
  },

  findAllOperationPlansByPersonnelId: async (
    personnelId: number
  ): Promise<Dw_t_operation_plan[]> => {
    const operationPlanRepository = connection.getRepository(
      Dw_t_operation_plan
    )
    return operationPlanRepository
      .createQueryBuilder('operation_plan')
      .leftJoin('operation_plan.dw_m_project', 'project')
      .where('operation_plan.personnel_id=:personnel_id', {
        personnel_id: personnelId,
      })
      .andWhere('project.project_id IS NOT NULL')
      .getMany()
      .then((results) => results)
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
  },

  findOperationPlansByPersonnel: async (
    to: string,
    from: string,
    offset: number,
    limit: number,
    projectId: number | null,
    companyId: number | null,
    skills: SkillList
  ): Promise<ListQueryResponseBase<Dw_m_personnel[]>> => {
    const operationPlanRepository = connection.getRepository(Dw_m_personnel)

    const queryBuilder = operationPlanRepository
      .createQueryBuilder('personnel')
      .select([
        `personnel.personnel_id`,
        `personnel.name`,
        `personnel.name_jpn`,
        `personnel.registered_date`,
        `personnel.unregistered_date`,
        `personnel.skill_list`,
        `personnel_price.contract_pattern_code`,
        `personnel_price.price_start_date`,
        `personnel_price.price_amount`,
        `personnel_price.currency_type_code`,
        `operation_plan.month_of_year_date`,
        `operation_plan.operation_plan_id`,
        `operation_plan.hours_number`,
        `operation_plan.man_month_number`,
        `company.company_id`,
        `company.contract_pattern_code`,
        `company.company_name`,
        `project.project_id`,
        `project.project_name`,
        `project.project_contact`,
        `project.project_start_date`,
        `project.project_end_date`,
        `project.notes`,
        `role.role_id`,
        `project_operation_plan.month_of_year_date`,
        `project_operation_plan.operation_plan_id`,
        `project_operation_plan.hours_number`,
        `project_operation_plan.man_month_number`,
        `project_operation.month_of_year_date`,
        `project_operation.operation_id`,
        `project_operation.cost_amount`,
        `project_operation_plan_role.role_id`,
        `project_operation_plan_role.role_name`,
        `BD.month_of_year_date`,
        `BD.business_days_number`,
        `operationProjects.project_id`,
        `operationPersonnel.personnel_id`,
      ])
      .leftJoin('personnel.dw_m_partner_company', 'company')
      .leftJoin('personnel.dw_m_personnel_price', 'personnel_price')
      .leftJoin(
        'personnel.dw_t_operation_plan',
        'operation_plan',
        'personnel.personnel_id=operation_plan.personnel_id'
      )
      .leftJoin(
        'operation_plan.dw_m_project',
        'project',
        'project.project_id=operation_plan.project_id'
      )
      .leftJoin(
        'operation_plan.dw_m_role',
        'role',
        'operation_plan.role_id=role.role_id'
      )
      .leftJoin(
        'project.dw_t_operation_plan',
        'project_operation_plan',
        'project.project_id=project_operation_plan.project_id AND personnel.personnel_id=project_operation_plan.personnel_id'
      )
      .leftJoin('project.dw_t_operation', 'project_operation')
      .leftJoin(
        'project_operation_plan.dw_m_role',
        'project_operation_plan_role',
        'project_operation_plan.role_id=project_operation_plan_role.role_id'
      )
      .leftJoin(
        'company.dw_m_business_day',
        'BD',
        'BD.company_id=personnel.company_id'
      )

      .leftJoin('project_operation.dw_m_project', 'operationProjects')
      .leftJoin('project_operation.dw_m_personnel', 'operationPersonnel')

    if (from) {
      queryBuilder.where(
        new Brackets((builder) => {
          builder
            .where('personnel.unregistered_date >= CONVERT(:from,DATE)', {
              from: from,
            })
            .orWhere('personnel.unregistered_date IS NULL')
            .orWhere('personnel.unregistered_date=CONVERT(:empty,DATE)', {
              empty: '',
            })
        })
      )
    }

    if (to) {
      queryBuilder.andWhere(
        new Brackets((builder) => {
          builder
            .andWhere('personnel.registered_date <= CONVERT(:to,DATE)', {
              to: to,
            })
            .orWhere('personnel.registered_date IS NULL')
            .orWhere('personnel.registered_date=CONVERT(:empty,DATE)', {
              empty: '',
            })
        })
      )
    }

    if (projectId) {
      queryBuilder.andWhere('project.project_id=:project_id', {
        project_id: projectId,
      })
    }

    if (companyId) {
      queryBuilder.andWhere('company.company_id=:company_id', {
        company_id: companyId,
      })
    }

    if (skills) {
      Object.keys(skills).forEach((skill, index) => {
        queryBuilder.andWhere(
          new Brackets((qb) => {
            if (skill && skills[skill].level !== undefined) {
              const parameterName = 'level' + index
              const lowerParameterName = 'lowestLevel'

              qb.andWhere(
                `personnel.skill_list->'$."${skill}".level' = :${parameterName}`,
                { [parameterName]: skills[skill].level }
              )
                .orWhere(
                  `personnel.skill_list->'$."${skill}".level' > :${parameterName}`,
                  { [parameterName]: skills[skill].level }
                )
                .orWhere(
                  `personnel.skill_list->'$."${skill}".level' < :${parameterName}`,
                  { [parameterName]: skills[skill].level }
                )
                .andWhere(
                  `personnel.skill_list->'$."${skill}".level' > :${lowerParameterName}`,
                  { [lowerParameterName]: 1 }
                )
            }
          })
        )
      })
    }
    queryBuilder.andWhere('project.deleted_at IS NULL')
    const [result, itemCount] = await queryBuilder
      .orderBy('personnel.personnel_id', 'ASC')
      .take(limit)
      .skip(offset)
      .getManyAndCount()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })

    return {
      items: result ?? [],
      totalItems: itemCount,
    }
  },

  create: async (
    arrayBody: Partial<Dw_t_operation_plan>[]
  ): Promise<InsertResult | void> => {
    const operationPlanRepository = connection.getRepository(
      Dw_t_operation_plan
    )

    for (const item of arrayBody) {
      const personnel = await connection
        .getRepository(Dw_m_personnel)
        .findOne(item.dw_m_personnel)
      if (!personnel) {
        throw new CustomError(messages.methodNotAllowed, 'Method Not Allowed')
      } else {
        const bodyMontOfYearDate = item.month_of_year_date || ''
        const { registered_date, unregistered_date } = personnel

        const registeredDate = new Date(registered_date)
        const monthOfYearDate = new Date(bodyMontOfYearDate)

        if (registered_date && unregistered_date) {
          const unregisteredDate = new Date(unregistered_date)
          const isBetween =
            monthOfYearDate >= registeredDate &&
            monthOfYearDate <= unregisteredDate
          if (!isBetween) {
            throw new CustomError(
              messages.methodNotAllowed,
              'Method Not Allowed'
            )
          }
        } else if (registered_date && !unregistered_date) {
          if (monthOfYearDate < registeredDate) {
            throw new CustomError(
              messages.methodNotAllowed,
              'Method Not Allowed'
            )
          }
        }
      }
    }

    const queryResult = operationPlanRepository
      .createQueryBuilder()
      .insert()
      .into('dw_t_operation_plan')
      .values(arrayBody)
      .orUpdate({
        conflict_target: ['month_of_year_date', 'operation_plan_id'],
        overwrite: [
          'man_month_number',
          'hours_number',
          'created_by',
          'create_at',
          'updated_by',
          'update_at',
          'process_at',
          'process_id',
          'role_id',
        ],
      })
      .execute()
      .catch((err: CustomQueryFailedError) => {
        if (err.errno === 1452 && err.code === 'ER_NO_REFERENCED_ROW_2') {
          throw new CustomError(messages.methodNotAllowed, 'Method Not Allowed')
        }
      })

    return queryResult
  },
})
