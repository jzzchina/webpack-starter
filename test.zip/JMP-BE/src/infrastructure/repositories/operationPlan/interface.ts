import { SkillList } from '../../../domain/models/Personnel'
import { ListRequestBase, ListResponseBase } from '../common/interface'
import { Dw_m_partner_company } from '../../orm/typeorm/entities/Dw_m_partner_company'
import { Dw_m_personnel } from '../../orm/typeorm/entities/Dw_m_personnel'
import { Dw_m_project } from '../../orm/typeorm/entities/Dw_m_project'
import { PersonnelPrice } from '../../../domain/models/PersonnelPrice'

export interface OperationPlanQueryRequest {
  manMonthNumber: number
  personnelId: number
  projectId: number
  roleId: number
  yearOfMonthDate: string
  hoursNumber: number
}

export interface OperationPlanQueryResponse
  extends Dw_m_project,
    Dw_m_partner_company,
    Dw_m_personnel {
  from: string
  to: string
  length: number
  totalLength: number
  items?: OperationPlanQueryResponse[]
}

export type OperationPlanPersonnelTotal = Record<
  string,
  {
    manMonthNumber: number
    roleId?: number
    roleName?: string
    operationPlanId?: number
  }
>

export interface OperationPlanProject {
  projectId: number
  projectName: string
  projectContact: string
  projectContact2: string
  projectContact3: string
  projectContact4: string
  projectStartDate: Date
  projectEndDate: Date | null
  operation: boolean
  note: string
  personnel?: OperationPlanPersonnel[]
  roleId?: number
  roleName?: string
  totals?: { operationPlans?: OperationPlanPersonnelTotal }
  allPersonnelIds?: number[]
  operationPlans?: OperationPlanPersonnelTotal
}

export interface OperationPlanPersonnel {
  companyId: number
  contractPatternCode: number
  companyName: string
  personnelId: number
  name: string
  nameJpn: string
  registeredDate: Date
  unregisteredDate: Date | null
  operation: boolean
  skillList: SkillList
  prices: PersonnelPrice[]
  businessDays: Record<
    string,
    {
      businessDaysNumber: number
    }
  >
  operationPlans?: OperationPlanPersonnelTotal
  totals?: { operationPlans?: OperationPlanPersonnelTotal }
  allProjectIds?: number[]
  projects?: OperationPlanProject[]
}

export interface OperationPlanRequest extends ListRequestBase {
  skills: SkillList
}

export interface OperationPlanPersonnelResponse extends ListResponseBase {
  from: string
  to: string
  items: OperationPlanPersonnel[]
}

export interface OperationPlanProjectResponse extends ListResponseBase {
  items: OperationPlanProject[]
}

export interface ProjectOperationCost {
  projectId: number
  projectName: string
  projectContact: string
  projectStartDate: Date
  projectEndDate: Date | null
  note: string
  personnel: PersonnelOperationCost[]
}

export type PersonnelOperationCost = {
  companyId: number
  contractPatternCode: number
  companyName: string
  personnelId: number
  name: string
  nameJpn: string
  registeredDate: Date
  unregisteredDate: Date | null
  prices: PersonnelPrice[]
  operationPlans: OperationPlanManMonthNumber
  operations: OperationCostAmount
}

export type OperationCostAmount = Record<
  string,
  { operationId: number; hoursNumber: number; costAmount: number }
>

export type OperationPlanManMonthNumber = Record<
  string,
  { hoursNumber: number; manMonthNumber: number }
>

export interface PersonalDataAchivement {
  project: string
  company_name: string
  name: string
  project_total: string
  [key: string]: string // Add index signature
}
