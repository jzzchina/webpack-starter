import { Brackets, Connection, TypeORMError } from 'typeorm'

import { Dw_m_project } from '../../orm/typeorm/entities/Dw_m_project'
import { OperationCostPlanRepositoryPort } from '../../../application/port/repositories/operationCostPlan/OperationCostPlanRepositoryPort'
import { OperationCostPlansByProjectQueryResponse } from './interface'
import CustomError from '../../../application/errors/CustomError'
import messages from '../../../application/errors/messages'

export const operationCostPlanRepositoryMySQL = async (
  connection: Connection
): Promise<OperationCostPlanRepositoryPort> => ({
  searchOperationCostPlansByProject: async (
    limit: number,
    offset: number,
    from: string,
    to: string,
    projectId: number | null,
    companyId: number | null
  ): Promise<OperationCostPlansByProjectQueryResponse> => {
    const operationPlanRepository = connection.getRepository(Dw_m_project)

    const queryBuilder = operationPlanRepository
      .createQueryBuilder('project')
      .select([
        `project.project_id`,
        `project.project_name`,
        `project.project_contact`,
        `project.project_contact2`,
        `project.project_contact3`,
        `project.project_contact4`,
        `project.project_start_date`,
        `project.project_end_date`,
        `project.notes`,
        `personnel.personnel_id`,
        `personnel.name`,
        `personnel.name_jpn`,
        `personnel.registered_date`,
        `personnel.unregistered_date`,
        `personnel.skill_list`,
        'personnel.company_id',
        // `personnel_price.contract_pattern_code`,
        // `personnel_price.price_start_date`,
        // `personnel_price.price_amount`,
        // `personnel_price.currency_type_code`,
        'personnel_operation_plan.month_of_year_date',
        'personnel_operation_plan.man_month_number',
        'personnel_operation_plan.hours_number',
        'company.company_id',
        'company.contract_pattern_code',
        'company.company_name',
      ])
      .leftJoinAndSelect(
        'project.dw_t_operation_plan',
        'operation_plan',
        'operation_plan.project_id=project.project_id'
      )
      .leftJoin(
        'operation_plan.dw_m_personnel',
        'personnel',
        'personnel.personnel_id=operation_plan.personnel_id'
      )
      .leftJoin(
        'personnel.dw_t_operation_plan',
        'personnel_operation_plan',
        'personnel_operation_plan.project_id=project.project_id AND personnel_operation_plan.personnel_id=personnel.personnel_id'
      )
      .leftJoinAndSelect(
        'personnel.dw_m_personnel_price',
        'personnel_price',
        'personnel_price.personnel_id=personnel.personnel_id'
      )
      .leftJoin(
        'personnel.dw_m_partner_company',
        'company',
        'company.company_id=personnel.company_id'
      )
      .leftJoinAndSelect(
        'company.dw_m_business_day',
        'BD',
        'BD.company_id=personnel.company_id AND personnel.deleted_at IS NULL'
      )

    if (from) {
      queryBuilder.where(
        new Brackets((builder) => {
          builder
            .where('project.project_end_date >= CONVERT(:from,DATE)', {
              from: from,
            })
            .orWhere('project.project_end_date IS NULL')
            .orWhere('project.project_end_date=CONVERT(:empty,DATE)', {
              empty: '',
            })
        })
      )
    }

    if (to) {
      queryBuilder.andWhere(
        new Brackets((builder) => {
          builder
            .andWhere('project.project_start_date <= CONVERT(:to,DATE)', {
              to: to,
            })
            .orWhere('project.project_start_date IS NULL')
            .orWhere('project.project_start_date=CONVERT(:empty,DATE)', {
              empty: '',
            })
        })
      )
    }

    if (projectId) {
      queryBuilder.andWhere('project.project_id=:project_id', {
        project_id: projectId,
      })
    }

    if (companyId) {
      queryBuilder.andWhere('company.company_id=:company_id', {
        company_id: companyId,
      })
    }

    const [result, count] = await queryBuilder
      .orderBy('project.project_id')
      .skip(offset)
      .take(limit)
      .getManyAndCount()
      .catch((err: TypeORMError) => {
        const errorMessage = err.message ?? messages.unexpectedError
        throw new CustomError(errorMessage, 'Internal Server Error')
      })

    return { totalItems: count, projects: result ?? [] }
  },
})
