import { Dw_m_project } from '../../orm/typeorm/entities/Dw_m_project'

export interface OperationCostPlansByProjectQueryResponse {
  totalItems: number
  projects: Partial<Dw_m_project>[]
}

export interface OperationCostPlanProjectListRequest {
  offset: number
  limit: number
  from?: string
  to?: string
  project_id: number | null
  company_id: number | null
}
