import { OperationCostPlanRepositoryPort } from '../../../application/port/repositories/operationCostPlan/OperationCostPlanRepositoryPort'
import { Dw_m_project } from '../../orm/typeorm/entities/Dw_m_project'

/**
 * InMemory implementation takes an argument `operationCostPlans` to be testable.
 */
export const operationPlanRepositoryInMemory = (): OperationCostPlanRepositoryPort => ({
  searchOperationCostPlansByProject: async (
    _limit: number,
    _offset: number,
    _from: string,
    _to: string,
    _projectId: number | null,
    _companyId: number | null
  ): Promise<{
    totalItems: number
    projects: Partial<Dw_m_project>[]
  }> => {
    // TODO: in memory implementation
    return { totalItems: 0, projects: [] }
  },
})
