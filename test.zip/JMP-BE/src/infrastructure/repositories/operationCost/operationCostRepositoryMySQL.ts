import {
  Brackets,
  Connection,
  InsertResult,
  QueryFailedError,
  Repository,
  UpdateResult,
} from 'typeorm'

import { OperationCostRepositoryPort } from '../../../application/port/repositories/operationCost/OperationCostRepositoryPort'
import { Dw_m_project } from '../../orm/typeorm/entities/Dw_m_project'
import { Dw_t_operation } from '../../orm/typeorm/entities/Dw_t_operation'
import { Dw_m_personnel } from '../../orm/typeorm/entities/Dw_m_personnel'
import {
  OperationCostCreateRequest,
  OperationCostsQueryResponse,
} from './interface'
import { Operation } from '../../../domain/models/Operation'
import { DeleteOperationCostSQLRequest } from '../../../interface/routes/operationCost/dto/operationCost.dto'
import CustomError from '../../../application/errors/CustomError'
import { CustomQueryFailedError } from '../common/interface'
import messages from '../../../application/errors/messages'

export const operationCostRepositoryMySQL = async (
  connection: Connection
): Promise<OperationCostRepositoryPort> => ({
  searchOperationCostsByPersonnelId: async (
    from: string,
    to: string,
    personnelId: number
  ): Promise<Dw_t_operation[]> => {
    const operationRepository = connection.getRepository(Dw_t_operation)
    return operationRepository
      .createQueryBuilder('operation')
      .where('operation.personnel_id=:personnel_id', {
        personnel_id: personnelId,
      })
      .andWhere('operation.month_of_year_date >= CONVERT(:from,DATE)', {
        from: from,
      })
      .andWhere('operation.month_of_year_date <= CONVERT(:to,DATE)', { to: to })
      .getMany()
      .then((results: Dw_t_operation[]) => results)
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
  },

  searchOperationCostsByProjectId(projectId) {
    const operationRepository = connection.getRepository(Dw_t_operation)
    return operationRepository
      .createQueryBuilder('operation')
      .where('operation.project_id = :projectId', { projectId })
      .getMany()
  },

  searchOperationCosts: async (
    limit: number,
    offset: number,
    from: string,
    to: string,
    projectId: number | null,
    companyId: number | null
  ): Promise<OperationCostsQueryResponse> => {
    const operationCostRepository = connection.getRepository(Dw_m_project)

    const queryBuilder = operationCostRepository
      .createQueryBuilder('project')
      .select([
        `project.project_id`,
        `project.project_name`,
        `project.project_contact`,
        `project.project_start_date`,
        `project.project_end_date`,
        `project.notes`,
        `personnel.personnel_id`,
        `personnel.name`,
        `personnel.name_jpn`,
        `personnel.registered_date`,
        `personnel.unregistered_date`,
        // `personnel_price.contract_pattern_code`,
        // `personnel_price.price_start_date`,
        // `personnel_price.price_amount`,
        // `personnel_price.currency_type_code`,
        'company.company_id',
        'company.contract_pattern_code',
        'company.company_name',
        'wbs.wbs_code AS wbs_code',
        'wbs.wbs_title AS wbs_title',
      ])
      .leftJoinAndSelect(
        'project.dw_t_operation_plan',
        'operation_plan',
        'operation_plan.project_id=project.project_id'
      )
      .leftJoin(
        'operation_plan.dw_m_personnel',
        'personnel',
        'personnel.personnel_id=operation_plan.personnel_id'
      )
      .leftJoinAndSelect(
        'personnel.dw_m_personnel_price',
        'personnel_price',
        'personnel_price.personnel_id=personnel.personnel_id'
      )
      .leftJoin(
        'personnel.dw_m_partner_company',
        'company',
        'company.company_id=personnel.company_id'
      )
      .innerJoinAndSelect(
        'personnel.dw_t_operation_plan',
        'personnel_operation_plan',
        'personnel_operation_plan.project_id=project.project_id AND personnel_operation_plan.personnel_id=personnel.personnel_id'
      )
      .leftJoinAndSelect(
        'personnel.dw_t_operation',
        'personnel_operation',
        'personnel_operation.project_id=project.project_id AND personnel_operation.personnel_id=personnel.personnel_id'
      )
      .leftJoinAndSelect(
        'company.dw_m_business_day',
        'BD',
        'BD.company_id=personnel.company_id'
      )
      .leftJoinAndSelect(
        'project.dw_m_wbs',
        'wbs',
        'wbs.project_id = project.project_id'
      )

    if (from) {
      queryBuilder.where(
        new Brackets((builder) => {
          builder
            .where('project.project_end_date >= CONVERT(:from,DATE)', {
              from: from,
            })
            .orWhere('project.project_end_date IS NULL')
            .orWhere('project.project_end_date=CONVERT(:empty,DATE)', {
              empty: '',
            })
        })
      )
      queryBuilder.andWhere(
        'personnel_operation_plan.month_of_year_date >= CONVERT(:from,DATE)',
        {
          from: from,
        }
      )
    }

    if (to) {
      queryBuilder.andWhere('project.project_start_date <= CONVERT(:to,DATE)', {
        to: to,
      })
      queryBuilder.andWhere(
        'personnel_operation_plan.month_of_year_date <= CONVERT(:to,DATE)',
        {
          to: to,
        }
      )
    }

    if (projectId) {
      queryBuilder.andWhere('project.project_id=:project_id', {
        project_id: projectId,
      })
    }

    if (companyId) {
      queryBuilder.andWhere('company.company_id=:company_id', {
        company_id: companyId,
      })
    }

    const [result, count] = await queryBuilder
      .skip(offset)
      .take(limit)
      .getManyAndCount()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })

    return { totalItems: count, projects: result ?? [] }
  },

  deleteOperationCosts: async (
    operationCostsInputs: DeleteOperationCostSQLRequest
  ): Promise<void> => {
    const operationCostRepository = connection.getRepository(Dw_t_operation)
    const queryBuilder = operationCostRepository
      .createQueryBuilder('dw_t_operation')
      .where('project_id IN (:...project_ids) ', {
        project_ids: operationCostsInputs.ProjectIds,
      })
      .andWhere('personnel_id IN (:...personnel_ids) ', {
        personnel_ids: operationCostsInputs.PersonnelIds,
      })
      .andWhere('month_of_year_date IN (:...month_of_year_dates) ', {
        month_of_year_dates: operationCostsInputs.YearOfMonths,
      })
      .andWhere('deleted_at IS NULL')

    await queryBuilder
      .softDelete()
      .execute()
      .then((result: UpdateResult) => {
        if (result.affected === 0)
          throw new CustomError(
            messages.targetOperationCostNotFound,
            'Not Found'
          )
      })
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
  },

  findMany: async (
    arrayOcs: Pick<Operation, 'personnelId' | 'projectId' | 'yearOfMonthDate'>[]
  ): Promise<Dw_t_operation[]> => {
    const operationCostRepository = connection.getRepository(Dw_t_operation)

    const operations: Dw_t_operation[] = await operationCostRepository
      .createQueryBuilder('operation')
      .select('operation')
      .leftJoinAndSelect('operation.dw_m_project', 'project')
      .leftJoinAndSelect('operation.dw_m_personnel', 'personnel')
      .whereInIds(
        arrayOcs.map((ocs) => {
          return {
            dw_m_personnel: ocs.personnelId,
            dw_m_project: ocs.projectId,
            month_of_year_date: ocs.yearOfMonthDate,
          }
        })
      )
      .getMany()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
    return operations
  },

  create: async (
    arrayBody: OperationCostCreateRequest[]
  ): Promise<Dw_t_operation[]> => {
    const operationCostRepository = connection.getRepository(Dw_t_operation)

    for (const item of arrayBody) {
      const personnel = await connection
        .getRepository(Dw_m_personnel)
        .findOne(item.dw_m_personnel)
      if (!personnel) {
        throw new CustomError(messages.targetPersonnelNotFound, 'Not Found')
      }
      const bodyMontOfYearDate = item.month_of_year_date || ''
      const { registered_date, unregistered_date } = personnel
      const registeredDate = new Date(registered_date)
      const monthOfYearDate = new Date(bodyMontOfYearDate)

      if (registered_date && unregistered_date) {
        const unregisteredDate = new Date(unregistered_date)
        const isBetween =
          monthOfYearDate >= registeredDate &&
          monthOfYearDate <= unregisteredDate
        if (!isBetween) {
          throw new CustomError(messages.monthOfYearIsNotBetween, 'Bad Request')
        }
      } else if (registered_date && !unregistered_date) {
        if (monthOfYearDate < registeredDate) {
          throw new CustomError(
            messages.registeredDateAfterMonthOfYearDate,
            'Bad Request'
          )
        }
      }
    }

    const result = await operationCostRepository
      .createQueryBuilder()
      .insert()
      .useTransaction(true)
      .into('dw_t_operation')
      .values(arrayBody)
      .orUpdate({
        conflict_target: ['operation_id'],
        overwrite: [
          'hours_number',
          'cost_amount',
          'created_by',
          'create_at',
          'updated_by',
          'update_at',
          'process_at',
          'process_id',
        ],
      })
      .execute()
      .catch((err: CustomQueryFailedError) => {
        if (err.errno === 1452 && err.code === 'ER_NO_REFERENCED_ROW_2') {
          throw new CustomError(
            messages.foreignKeyNotFound,
            'Method Not Allowed'
          )
        }
      })

    return await operationCostRepository.find({
      relations: ['dw_m_personnel', 'dw_m_project'],
      where: (result as InsertResult).identifiers,
    })
  },
  findOperationBelongsToOperationPlan: async (
    personnelIds: number[],
    projectIds: number[]
  ): Promise<boolean> => {
    const OperationRepository: Repository<Dw_t_operation> = connection.getRepository(
      Dw_t_operation
    )
    const queryBuilder = OperationRepository.createQueryBuilder('operation')
      .select('operation')
      .leftJoinAndSelect('operation.dw_m_personnel', 'personnel')
      .leftJoinAndSelect('operation.dw_m_project', 'project')

      .where('project.project_id IN (:...project_ids)', {
        project_ids: projectIds,
      })
      .andWhere('personnel.personnel_id IN (:...personnel_ids)', {
        personnel_ids: personnelIds,
      })

      .getCount()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })

    return queryBuilder.then((result: number) => result !== 0)
  },
  updateCostAmountByPersonnelAndDate: async (
    personnelId: number,
    monthYearDate: string,
    personnelPrice: number
  ): Promise<void> => {
    const operationCostRepository = connection.getRepository(Dw_t_operation)
    await operationCostRepository
      .createQueryBuilder()
      .update(Dw_t_operation)
      .set({ cost_amount: () => `${personnelPrice}` })
      .where('personnel_id = :personnelId', { personnelId })
      .andWhere(
        new Brackets((qb) => {
          qb.where('month_of_year_date = :monthYearDate', {
            monthYearDate,
          }).orWhere('month_of_year_date > :monthYearDate', { monthYearDate })
        })
      )

      .andWhere('deleted_at IS NULL')
      .execute()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
  },
})
