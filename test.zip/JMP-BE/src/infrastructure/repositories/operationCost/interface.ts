import { Dw_m_project } from '../../orm/typeorm/entities/Dw_m_project'

export interface OperationCostCreateRequest {
  hours_number: number | null
  cost_amount: number | null
  dw_m_personnel: number
  dw_m_project: number | null
  month_of_year_date: string | null
  created_by: string
  updated_by: string
}

export interface OperationCostsQueryResponse {
  totalItems: number
  projects: Partial<Dw_m_project>[]
}
