import { Dw_m_business_days } from '../../orm/typeorm/entities/Dw_m_business_days'

export type BusinessDaysDBList = Partial<Dw_m_business_days>[]

export type BusinessDaysKey = {
  dw_m_partner_company: number
  month_of_year_date: Date
}
