import {
  Connection,
  DeleteResult,
  InsertResult,
  ObjectLiteral,
  QueryFailedError,
} from 'typeorm'

import { Dw_m_business_days } from '../../orm/typeorm/entities/Dw_m_business_days'
import { BusinessDaysRepositoryPort } from '../../../application/port/repositories/businessDays/BusinessDaysRepositoryPort'
import { BusinessDaysDBList } from './interface'
import CustomError from '../../../application/errors/CustomError'
import { CustomQueryFailedError } from '../common/interface'
import messages from '../../../application/errors/messages'

export const businessDaysRepositoryMySQL = async (
  connection: Connection
): Promise<BusinessDaysRepositoryPort> => ({
  findAll: async (companyId: number): Promise<Dw_m_business_days[]> => {
    const businessDaysRepository = connection.getRepository(Dw_m_business_days)

    return businessDaysRepository
      .createQueryBuilder('business_days')
      .select([
        'business_days.business_days_id',
        'business_days.company_id',
        'business_days.month_of_year_date',
        'business_days.business_days_number',
      ])
      .leftJoinAndSelect(
        'business_days.dw_m_partner_company',
        'Dw_m_partner_company'
      )
      .where('business_days.company_id = :companyId', { companyId })

      .orderBy('business_days.company_id', 'ASC')
      .addOrderBy('business_days.month_of_year_date', 'ASC')

      .getMany()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
  },

  create: async (businessDays: BusinessDaysDBList): Promise<InsertResult> => {
    const businessDaysRepository = connection.getRepository(Dw_m_business_days)

    const createUpdateBusinessDaysResult = (await businessDaysRepository
      .createQueryBuilder()
      .insert()
      .into(Dw_m_business_days)
      .values(businessDays)
      .orUpdate({
        conflict_target: ['company_id', 'month_of_year_date'],
        overwrite: ['business_days_number'],
      })
      .execute()
      .catch((err: CustomQueryFailedError) => {
        if (err.errno === 1452 && err.code === 'ER_NO_REFERENCED_ROW_2') {
          throw new CustomError(
            messages.requestedCompanyIdNotFound,
            'Bad Request'
          )
        }
      })) as InsertResult

    return createUpdateBusinessDaysResult
  },

  findMany: async (
    businessDaysKeys: ObjectLiteral[]
  ): Promise<Dw_m_business_days[]> => {
    const businessDaysRepository = connection.getRepository(Dw_m_business_days)

    const mappedKeys = businessDaysKeys.map((businessDaysKey) => {
      return businessDaysKey.business_days_id
    })
    const findBusinessDaysResult = businessDaysRepository
      .createQueryBuilder('businessDays')
      .select([
        'businessDays.company_id',
        'businessDays.month_of_year_date',
        'businessDays.business_days_number',
      ])
      .leftJoinAndSelect(
        'businessDays.dw_m_partner_company',
        'dw_m_partner_company'
      )

      .whereInIds(mappedKeys)

      .orderBy('businessDays.company_id', 'ASC')
      .addOrderBy('businessDays.month_of_year_date', 'ASC')

      .getMany()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })

    return findBusinessDaysResult
  },

  delete: async (
    companyId: number,
    monthOfYearDate: string
  ): Promise<DeleteResult> => {
    const formattedMonthOfYearDate = new Date(monthOfYearDate)
      .toISOString()
      .split('T')[0]

    const businessDaysRepository = connection.getRepository(Dw_m_business_days)
    return businessDaysRepository
      .createQueryBuilder()
      .softDelete()
      .from(Dw_m_business_days)
      .where(
        'company_id = :companyId and month_of_year_date = :monthOfYearDate',
        { companyId: companyId, monthOfYearDate: formattedMonthOfYearDate }
      )
      .andWhere('deleted_at IS NULL')
      .execute()
  },
})
