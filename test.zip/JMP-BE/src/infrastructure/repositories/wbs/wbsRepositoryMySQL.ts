import { Connection } from 'typeorm'
import { WbsRepositoryPort } from '../../../application/port/repositories/wbs/wbsRepositoryPort'
import { WbsCostsQueryResponse } from './interface'
import { Dw_m_personnel } from '../../orm/typeorm/entities/Dw_m_personnel'
import { Dw_m_wbs } from '../../orm/typeorm/entities/Dw_m_wbs'
import { CustomQueryFailedError } from '../common/interface'
import CustomError from '../../../application/errors/CustomError'

/**
 * wbsRepositoryMySQL
 * @param {Connection} connection - database ORM connection
 */
export const wbsRepositoryMySQL = async (
  connection: Connection
): Promise<WbsRepositoryPort> => ({
  /**
   * Search wbs cost list
   * @param {number} limit - query limit
   * @param {number}  offset - query offset
   * @param {string} from - start date
   * @param {string} to - end date
   * @param {number} companyId - company id
   * @returns {OperationCostPlansByProjectQueryResponse}
   */
  searchWbsCosts: async (
    limit: number,
    offset: number,
    from: string,
    to: string,
    companyId: number
  ): Promise<WbsCostsQueryResponse> => {
    // Get the personnel repository
    const wbsRepository = connection.getRepository(Dw_m_personnel)

    // Build the query
    const queryBuilder = wbsRepository
      .createQueryBuilder('personnel')
      .select([
        `personnel.personnel_id`,
        `personnel.company_id`,
        `personnel.registered_date`,
        `personnel.unregistered_date`,
      ])
      .leftJoinAndSelect(
        'personnel.dw_m_partner_company',
        'company',
        'company.company_id=personnel.company_id'
      )
      // join the tables and select the columns to be returned
      .leftJoinAndSelect(
        'personnel.dw_m_personnel_price',
        'personnel_price',
        'personnel_price.personnel_id=personnel.personnel_id'
      )
      .leftJoinAndSelect(
        'personnel.dw_t_operation',
        'operation',
        'operation.personnel_id=personnel.personnel_id'
      )
      .leftJoinAndSelect(
        'operation.dw_m_project',
        'project',
        'project.project_id=operation.project_id'
      )
      .leftJoinAndSelect(
        'project.dw_m_wbs',
        'wbs',
        'wbs.project_id=project.project_id'
      )

    // Build the query condition for "companyId"
    if (companyId) {
      queryBuilder.andWhere('company.company_id=:company_id', {
        company_id: companyId,
      })
    }

    // Build the query condition "from"
    if (from) {
      queryBuilder.andWhere(
        'operation.month_of_year_date >= CONVERT(:from,DATE)',
        {
          from: from,
        }
      )
    }

    // Build the query condition "to"
    if (from) {
      queryBuilder.andWhere(
        'operation.month_of_year_date <= CONVERT(:to,DATE)',
        {
          to: to,
        }
      )
    }

    const [result, count] = await queryBuilder
      // .groupBy('operation.month_of_year_date')
      .skip(offset)
      .take(limit)
      .getManyAndCount()

    return { totalItems: count, personnel: result ?? [] }
  },
  /**
   * Find wbs
   * @returns {Promise<Partial<Dw_m_wbs>[]>}
   */
  createWbs: async (
    wbsList: Partial<Dw_m_wbs>[]
  ): Promise<Partial<Dw_m_wbs>[]> => {
    const wbsRepository = connection.getRepository(Dw_m_wbs)
    for (const wbs of wbsList) {
      const project_id = wbs.dw_m_project?.project_id
      const foundWbs = await wbsRepository.findOne({
        where: [{ dw_m_project: { project_id } }],
        relations: ['dw_m_project'],
      })
      if (foundWbs) {
        wbs.wbs_id = foundWbs.wbs_id
      }
    }
    const saveResult: Partial<Dw_m_wbs>[] = await wbsRepository
      .save(wbsList)
      .catch((err: CustomQueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })

    return saveResult
  },
})
