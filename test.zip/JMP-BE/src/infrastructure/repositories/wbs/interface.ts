import { Dw_m_personnel } from '../../orm/typeorm/entities/Dw_m_personnel'

export interface WbsCostsQueryResponse {
  totalItems: number
  personnel: Partial<Dw_m_personnel>[]
}
