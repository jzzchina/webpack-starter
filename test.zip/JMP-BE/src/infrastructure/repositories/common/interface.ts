import { QueryFailedError } from 'typeorm'

// ListQueryResponseBase is use for query response from database
export interface ListQueryResponseBase<T> {
  totalItems: number
  items: T
}

// ListRequestBase is use for data response when user request from API
export interface ListRequestBase {
  from?: string
  to?: string
  offset: number
  limit: number
}

// ListResponseBase is use for data response when user request from API
export interface ListResponseBase {
  from?: string
  to?: string
  offset: number
  length: number
  totalLength: number
}

export interface CustomQueryFailedError extends QueryFailedError {
  errno: number
  code: string
}
