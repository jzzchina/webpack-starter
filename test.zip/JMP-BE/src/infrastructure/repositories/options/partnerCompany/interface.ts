import { Dw_m_personnel } from '../../../orm/typeorm/entities/Dw_m_personnel'
import { Dw_m_partner_company } from '../../../orm/typeorm/entities/Dw_m_partner_company'

export type PartnerCompanyQueryCreateInput = Partial<Dw_m_partner_company>

export type FindAllPartnerCompanySQLResponse = {
  result: Dw_m_partner_company[]
  count: number
}

export interface PartnerCompanyQueryResponse
  extends Dw_m_personnel,
    Dw_m_partner_company {
  personnelCount: number
}

export type PartnerCompanyRepositorySaveResult = Partial<Dw_m_partner_company> &
  Dw_m_partner_company[]

export type FindAllPartnerCompanyRequest = {
  company_id?: number
  company_name?: string
  contract_pattern_code?: number
  limit?: number
  offset?: number
}
