import { Connection, QueryFailedError, UpdateResult } from 'typeorm'

import { PartnerCompanyRepositoryPort } from '../../../../application/port/repositories/partnerCompany/PartnerCompanyRepositoryPort'
import { Dw_m_partner_company } from '../../../orm/typeorm/entities/Dw_m_partner_company'
import {
  FindAllPartnerCompanySQLResponse,
  PartnerCompanyQueryCreateInput,
  PartnerCompanyRepositorySaveResult,
} from './interface'
import CustomError from '../../../../application/errors/CustomError'
import messages from '../../../../application/errors/messages'

export const partnerCompanyRepositoryMySQL = async (
  connection: Connection
): Promise<PartnerCompanyRepositoryPort> => ({
  findAll: async (
    companyId: number,
    companyName: string,
    contractPatternCode: number,
    limit: number,
    offset: number
  ): Promise<FindAllPartnerCompanySQLResponse> => {
    const partnerCompanyRepository = connection.getRepository(
      Dw_m_partner_company
    )
    const queryBuilderResult = partnerCompanyRepository
      .createQueryBuilder('company')
      .select([
        'company.company_id',
        'company.contract_pattern_code',
        'company.company_name',
        'personnel.personnel_id',
        'sales_man.sales_man_id',
        'sales_man.name',
        'sales_man.email',
        'sales_man.phone_number',
      ])
      .leftJoin(
        'company.dw_m_personnel',
        'personnel',
        '(personnel.registered_date<= :registered_date AND (personnel.unregistered_date >= :unregistered_date OR personnel.unregistered_date IS NULL) ) ',
        {
          registered_date: new Date(Date.now()).toISOString().slice(0, 10),
          unregistered_date: new Date(Date.now()).toISOString().slice(0, 10),
        }
      )
      .leftJoin(
        'company.dw_m_sales_man',
        'sales_man',
        'sales_man.company_id = sales_man.company_id'
      )

      .orderBy('company.company_name', 'ASC')

    if (companyId) {
      queryBuilderResult.where('company.company_id = :company_id', {
        company_id: companyId,
      })
    }

    if (companyName) {
      queryBuilderResult.andWhere('company.company_name LIKE :company_name', {
        company_name: `%${companyName}%`,
      })
    }

    if (
      contractPatternCode !== undefined &&
      contractPatternCode !== null &&
      !Number.isNaN(contractPatternCode)
    ) {
      queryBuilderResult.andWhere(
        'company.contract_pattern_code = :contract_pattern_code',
        {
          contract_pattern_code: contractPatternCode,
        }
      )
    }

    if (offset !== undefined && offset !== null && !Number.isNaN(offset)) {
      queryBuilderResult.skip(offset)
    }

    if (limit !== undefined && limit !== null && !Number.isNaN(limit)) {
      queryBuilderResult.take(limit)
    }

    const [result, count] = await queryBuilderResult
      .getManyAndCount()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
    return { result, count }
  },
  deletePartnerCompanies: async (companyIds: number[]): Promise<void> => {
    const partnerCompanyRepository = connection.getRepository(
      Dw_m_partner_company
    )

    await partnerCompanyRepository
      .createQueryBuilder('company')
      .softDelete()
      .where('company_id IN (:...company_id)', {
        company_id: companyIds,
      })
      .andWhere('deleted_at IS NULL')
      .execute()
      .then((result: UpdateResult) => {
        if (result.affected === 0) {
          throw new CustomError(messages.recordsDoesNotExist, 'Not Found')
        }
      })
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
  },

  create: async (
    companyList: PartnerCompanyQueryCreateInput[]
  ): Promise<PartnerCompanyRepositorySaveResult | void> => {
    const partnerCompanyRepository = connection.getRepository(
      Dw_m_partner_company
    )

    const insertResult = partnerCompanyRepository
      .save(companyList)
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })

    return insertResult
  },
  findMany: async (companyIds: number[]): Promise<Dw_m_partner_company[]> => {
    const partnerCompanyRepository = connection.getRepository(
      Dw_m_partner_company
    )

    const selectedCompanies = await partnerCompanyRepository
      .createQueryBuilder()
      .select([
        'company_id',
        'contract_pattern_code',
        'company_name',
        'created_by',
        'create_at',
        'updated_by',
        'update_at',
        'process_at',
        'process_id',
      ])
      .where('company_id IN (:...company_id)', {
        company_id: companyIds,
      })
      .orderBy('company_id', 'ASC')

      .execute()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })

    return selectedCompanies
  },
})
