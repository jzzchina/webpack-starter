import { Connection, QueryFailedError } from 'typeorm'

import { Dw_m_role } from '../../../orm/typeorm/entities/Dw_m_role'
import { RoleRepositoryPort } from '../../../../application/port/repositories/role/RoleRepositoryPort'
import CustomError from '../../../../application/errors/CustomError'

export const roleRepositoryMySQL = (
  connection: Connection
): RoleRepositoryPort => ({
  findAll: (): Promise<Partial<Dw_m_role>[]> => {
    const roleRepository = connection.getRepository(Dw_m_role)
    return roleRepository
      .createQueryBuilder('role')
      .select(['role_id', 'role_name'])
      .orderBy(`role.role_id`, `ASC`)
      .execute()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
  },
})
