export interface Role {
  roleId: number | null
  roleName: string | null
}

export interface RoleListResponse {
  items?: Role[]
}
