import {
  Brackets,
  Connection,
  In,
  QueryFailedError,
  UpdateResult,
} from 'typeorm'
import { Dw_m_project } from '../../../orm/typeorm/entities/Dw_m_project'
import { ProjectRepositoryPort } from '../../../../application/port/repositories/project/ProjectRepositoryPort'
import {
  CreateProjectsSQLResponse,
  SearchProjectsSQLResponse,
} from './interface'
import { ProjectSearchCriteria } from '../../../../domain/models/Project'
import CustomError from '../../../../application/errors/CustomError'
import { CustomQueryFailedError } from '../../common/interface'
import messages from '../../../../application/errors/messages'

export const projectRepositoryMySQL = async (
  connection: Connection
): Promise<ProjectRepositoryPort> => ({
  findAll: async (
    searchCriteria: ProjectSearchCriteria
  ): Promise<SearchProjectsSQLResponse> => {
    const {
      project_id,
      project_name,
      company_id,
      user_part,
      project_manager,
      status,
      limit,
      offset,
      project_start_date,
      project_end_date,
      include_status_closed,
    } = searchCriteria

    const projectRepository = connection.getRepository(Dw_m_project)
    const queryBuilder = projectRepository
      .createQueryBuilder('project')
      .select([
        'project.project_id',
        'project.project_name',
        'project.status',
        'project.project_start_date',
        'project.project_end_date',
        'project.project_manager',
        'project.project_contact',
        'project.project_contact2',
        'project.project_contact3',
        'project.project_contact4',
        'project.user_part',
        'project.notes',
        'wbs.wbs_id',
        'wbs.wbs_title',
        'wbs.wbs_code',
        'wbs.subject',
      ])
      .leftJoinAndSelect(
        'project.dw_t_operation_plan',
        'operation_plan',
        'operation_plan.project_id=project.project_id'
      )
      .leftJoin(
        'operation_plan.dw_m_personnel',
        'personnel',
        'personnel.personnel_id=operation_plan.personnel_id'
      )
      .leftJoin(
        'personnel.dw_t_operation_plan',
        'personnel_operation_plan',
        'personnel_operation_plan.project_id=project.project_id AND personnel_operation_plan.personnel_id=personnel.personnel_id'
      )
      .leftJoin(
        'personnel.dw_m_partner_company',
        'company',
        'company.company_id=personnel.company_id'
      )
      .leftJoin(
        'project.dw_m_wbs',
        'wbs',
        'wbs.dw_m_project.project_id=project.project_id'
      )

    if (project_id) {
      queryBuilder.andWhere('project.project_id = :project_id', {
        project_id: project_id,
      })
    }

    if (project_name) {
      queryBuilder.andWhere('project.project_name LIKE :project_name', {
        project_name: `%${project_name}%`,
      })
    }

    if (status !== undefined && status !== null && !Number.isNaN(status)) {
      queryBuilder.andWhere('project.status = :status', {
        status: status,
      })
    }

    if (project_manager) {
      queryBuilder.andWhere('project.project_manager LIKE :project_manager', {
        project_manager: `%${project_manager}%`,
      })
    }

    if (company_id) {
      queryBuilder.andWhere('company.company_id=:company_id', {
        company_id: company_id,
      })
    }

    if (user_part) {
      queryBuilder.andWhere('project.user_part LIKE :user_part', {
        user_part: `%${user_part}%`,
      })
    }

    if (project_start_date) {
      queryBuilder.andWhere(
        new Brackets((builder) => {
          builder
            .andWhere(
              'project.project_start_date <= CONVERT(:project_end_date,DATE)',
              {
                project_end_date: project_end_date || '9999-12-31',
              }
            )
            .andWhere(
              'IFNULL(project.project_end_date, "9999-12-31") >= CONVERT(:project_start_date,DATE)',
              {
                project_start_date: project_start_date,
              }
            )
        })
      )
    }

    if (offset !== undefined && offset !== null && !Number.isNaN(offset)) {
      queryBuilder.skip(offset)
    }

    if (limit !== undefined && limit !== null && !Number.isNaN(limit)) {
      queryBuilder.take(limit)
    }
    if (!include_status_closed) {
      queryBuilder.andWhere('project.status != 5')
    }
    const [result, count] = await queryBuilder
      .orderBy('project.project_start_date', 'ASC')
      .addOrderBy('project.project_name', 'ASC')
      .addOrderBy('wbs.wbs_id', 'DESC')
      .getManyAndCount()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
    return { result, count }
  },

  createProjects: async (
    projectList: Partial<Dw_m_project>[]
  ): CreateProjectsSQLResponse => {
    const projectRepository = connection.getRepository(Dw_m_project)
    const saveResult = projectRepository
      .save(projectList)
      .catch((err: CustomQueryFailedError) => {
        if (err.errno === 1452 && err.code === 'ER_NO_REFERENCED_ROW_2') {
          throw new CustomError(
            messages.foreignKeyConstraintError,
            'Method Not Allowed'
          )
        } else {
          throw new CustomError(err.message, 'Internal Server Error')
        }
      })

    return saveResult
  },

  findManyByIds: async (
    projectIds: number[]
  ): Promise<Partial<Dw_m_project>[]> => {
    const repository = connection.getRepository(Dw_m_project)
    return await repository.find({ project_id: In(projectIds) })
  },

  deleteProjects: async (projectIds: number[]): Promise<void> => {
    const projectsRepository = connection.getRepository(Dw_m_project)
    await projectsRepository
      .createQueryBuilder('project')
      .softDelete()
      .where('project_id IN (:...project_id)', {
        project_id: projectIds,
      })
      .andWhere('deleted_at IS NULL')
      .execute()
      .then((result: UpdateResult) => {
        if (result.affected === 0)
          throw new CustomError(messages.projectNotFound, 'Not Found')
      })
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
  },
})
