import { Dw_m_project } from '../../../orm/typeorm/entities/Dw_m_project'

export type SearchProjectsSQLResponse = {
  result: Dw_m_project[]
  count: number
}

export type CreateProjectsSQLResponse = Promise<
  void | (Partial<Dw_m_project> & Dw_m_project)[]
>
