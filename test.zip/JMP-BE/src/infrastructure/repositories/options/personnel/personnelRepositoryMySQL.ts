import {
  Brackets,
  Connection,
  Like,
  QueryFailedError,
  UpdateResult,
} from 'typeorm'

import { PersonnelRepositoryPort } from '../../../../application/port/repositories/personnel/PersonnelRepositoryPort'
import { Dw_m_personnel } from '../../../orm/typeorm/entities/Dw_m_personnel'

import {
  FindAllPersonnelSQLResponse,
  PersonnelQueryCreateInput,
  PersonnelRepositorySaveResult,
} from './interface'
import { PersonnelSearchCriteria } from '../../../../domain/models/Personnel'
import { Dw_t_operation_plan } from '../../../orm/typeorm/entities/Dw_t_operation_plan'
import CustomError from '../../../../application/errors/CustomError'
import { CustomQueryFailedError } from '../../common/interface'
import messages from '../../../../application/errors/messages'

export const personnelRepositoryMySQL = async (
  connection: Connection
): Promise<PersonnelRepositoryPort> => ({
  findAll: async (
    searchCriteria: PersonnelSearchCriteria
  ): Promise<FindAllPersonnelSQLResponse> => {
    const {
      limit,
      offset,
      personnel_id,
      name,
      name_jpn,
      project_id,
      company_id,
      search_name,
      skills,
      includeStatusClosed,
    } = searchCriteria
    const personnelRepository = connection.getRepository(Dw_m_personnel)
    const queryBuilderResult = personnelRepository
      .createQueryBuilder(`PER`)
      .select([
        `PER.personnel_id`,
        `PER.name`,
        `PER.name_jpn`,
        `PER.skill_list`,
        `PER.company_id`,
        `PER.email`,
        `PER.registered_date`,
        `PER.unregistered_date`,
        `company.company_id`,
        `company.company_name`,
        `company.contract_pattern_code`,
        `PP.contract_pattern_code`,
        `PP.personnel_price_id`,
        `PP.price_start_date`,
        `PP.price_amount`,
        `PP.currency_type_code`,
        `OP.man_month_number`,
        `PR.project_id`,
        `PR.project_name`,
        `PR.project_start_date`,
        `BD.business_days_number`,
        `BD.month_of_year_date`,
      ])
      .leftJoin(
        `PER.dw_m_partner_company`,
        `company`,
        `PER.company_id = company.company_id`
      )
      .leftJoin(
        `PER.dw_m_personnel_price`,
        `PP`,
        `PER.personnel_id = PP.personnel_id`
      )
      .leftJoin(
        'PER.dw_t_operation_plan',
        'OP',
        'PER.personnel_id = OP.personnel_id'
      )
      .leftJoin(
        'company.dw_m_business_day',
        'BD',
        'BD.dw_m_partner_company.company_id = company.company_id'
      )
      .orderBy(`PER.name`, `ASC`)
    if (includeStatusClosed) {
      queryBuilderResult.leftJoin(
        'OP.dw_m_project',
        'PR',
        'OP.project_id = PR.project_id AND PR.status!=5'
      )
    } else {
      queryBuilderResult.leftJoin(
        'OP.dw_m_project',
        'PR',
        'OP.project_id = PR.project_id'
      )
    }
    if (limit !== undefined && limit !== null && !Number.isNaN(limit)) {
      queryBuilderResult.take(limit)
    }
    if (offset !== undefined && offset !== null && !Number.isNaN(offset)) {
      queryBuilderResult.skip(offset)
    }

    if (
      personnel_id !== undefined &&
      personnel_id !== null &&
      !Number.isNaN(personnel_id)
    ) {
      queryBuilderResult.andWhere(`PER.personnel_id = :personnel_id`, {
        personnel_id,
      })
    }

    if (name !== undefined && name !== null && name !== 'undefined') {
      queryBuilderResult.andWhere(`PER.name LIKE :name`, { name: `%${name}%` })
    }

    if (
      name_jpn !== undefined &&
      name_jpn !== null &&
      name_jpn !== 'undefined'
    ) {
      queryBuilderResult.andWhere(`PER.name_jpn LIKE :name_jpn`, {
        name_jpn: `%${name_jpn}%`,
      })
    }

    if (
      project_id !== undefined &&
      project_id !== null &&
      !Number.isNaN(project_id)
    ) {
      queryBuilderResult
        .leftJoin(
          `PER.dw_t_operation_plan`,
          `OP_PER`,
          `PER.personnel_id = OP.personnel_id`
        )
        .andWhere(`OP_PER.project_id = :project_id`, { project_id })
    }

    if (
      company_id !== undefined &&
      company_id !== null &&
      !Number.isNaN(company_id)
    ) {
      queryBuilderResult.andWhere(`PER.company_id = :company_id`, {
        company_id,
      })
    }

    if (
      search_name !== undefined &&
      search_name !== null &&
      search_name !== 'undefined'
    ) {
      const searchFieldArray = search_name.split(' ')

      const searchConditions: any = []
      searchFieldArray.map((field) => {
        searchConditions.push({
          name_jpn: Like(`%${field}%`),
        })
        searchConditions.push({
          name: Like(`%${field}%`),
        })
      })

      queryBuilderResult.andWhere(searchConditions)
    }

    if (skills !== undefined && skills !== null) {
      Object.keys(skills).forEach((skill, index) => {
        queryBuilderResult.andWhere(
          new Brackets((qb) => {
            if (skill && skills[skill].level !== undefined) {
              const parameterName = 'level' + index
              const lowerParameterName = 'lowestLevel'

              qb.andWhere(
                `PER.skill_list->'$."${skill}".level' = :${parameterName}`,
                { [parameterName]: skills[skill].level }
              )
                .orWhere(
                  `PER.skill_list->'$."${skill}".level' > :${parameterName}`,
                  { [parameterName]: skills[skill].level }
                )
                .orWhere(
                  `PER.skill_list->'$."${skill}".level' < :${parameterName}`,
                  { [parameterName]: skills[skill].level }
                )
                .andWhere(
                  `PER.skill_list->'$."${skill}".level' > :${lowerParameterName}`,
                  { [lowerParameterName]: 1 }
                )
            }
          })
        )
      })
    }

    const [result, count] = await queryBuilderResult
      .getManyAndCount()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
    return { result, count }
  },

  create: async (
    personnelList: PersonnelQueryCreateInput[]
  ): Promise<PersonnelRepositorySaveResult | void> => {
    const personnelRepository = connection.getRepository(Dw_m_personnel)
    const insertResult = personnelRepository
      .save(personnelList)
      .catch((err: CustomQueryFailedError) => {
        if (err.errno === 1452 && err.code === 'ER_NO_REFERENCED_ROW_2') {
          throw new CustomError(messages.methodNotAllowed, 'Method Not Allowed')
        }
      })

    return insertResult
  },

  findMany: async (personnelIds: number[]): Promise<Dw_m_personnel[]> => {
    const personnelRepository = connection.getRepository(Dw_m_personnel)
    return (
      personnelRepository
        .createQueryBuilder(`PER`)
        .select([
          `PER.personnel_id`,
          `PER.name`,
          `PER.name_jpn`,
          `PER.email`,
          `PER.skill_list`,
          `PER.registered_date`,
          `PER.unregistered_date`,
          `PER.company_id`,
          `company.company_id`,
          `company.company_name`,
          `company.contract_pattern_code`,
          `PP.contract_pattern_code`,
          `PP.price_start_date`,
          `PP.price_amount`,
          `PP.currency_type_code`,
        ])
        // join partner company table
        .leftJoin(
          `PER.dw_m_partner_company`,
          `company`,
          `PER.company_id = company.company_id`
        )
        // join personnel price table
        .leftJoin(
          `PER.dw_m_personnel_price`,
          `PP`,
          `PER.personnel_id = PP.personnel_id`
        )
        .where('PER.personnel_id IN (:...personnel_id)', {
          personnel_id: personnelIds,
        })
        // execute query
        .getMany()
        .catch((err: QueryFailedError) => {
          throw new CustomError(err.message, 'Internal Server Error')
        })
        .then((result: Dw_m_personnel[]) => {
          return result
        })
    )
  },

  deletePersonnels: async (personnelIds: number[]): Promise<void> => {
    const personnelRepository = connection.getRepository(Dw_m_personnel)
    await personnelRepository
      .createQueryBuilder('personnel')
      .softDelete()
      .where('personnel_id IN (:...personnel_id)', {
        personnel_id: personnelIds,
      })
      .andWhere('deleted_at IS NULL')
      .execute()
      .then((result: UpdateResult) => {
        if (result.affected === 0)
          throw new CustomError(messages.personnelDoesNotExist, 'Not Found')
      })
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
  },

  findOneById: async (personnel_id: number): Promise<Dw_m_personnel | null> => {
    const personnelRepository = connection.getRepository(Dw_m_personnel)
    return personnelRepository
      .findOne({ personnel_id })
      .then((result: Dw_m_personnel | undefined) => {
        if (!result) return null
        return result
      })
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
  },
  findPersonnelByAssignment: async (
    personnelIds: number[]
  ): Promise<number> => {
    const operationPlanRepository = connection.getRepository(
      Dw_t_operation_plan
    )
    const result = await operationPlanRepository
      .createQueryBuilder('OP')
      .select(['OP.operation_plan_id', 'OP.deleted_at'])
      .leftJoinAndSelect('OP.dw_m_personnel', 'PER')
      .where('PER.personnel_id IN (:...personnel_id) ', {
        personnel_id: personnelIds,
      })
      .getCount()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })

    return result
  },
})
