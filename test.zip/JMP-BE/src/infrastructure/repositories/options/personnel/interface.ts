import { Dw_m_partner_company } from '../../../orm/typeorm/entities/Dw_m_partner_company'
import { Dw_m_personnel } from '../../../orm/typeorm/entities/Dw_m_personnel'

export interface PersonnelQueryResponse
  extends Dw_m_personnel,
    Dw_m_partner_company {
  contract_pattern_code: number
  price_start_date: string
  price_amount: number
  currency_type_code: number
}

export type PersonnelQueryCreateInput = Partial<Dw_m_personnel>

export type PersonnelRepositorySaveResult = Partial<Dw_m_personnel> &
  Dw_m_personnel[]

export type FindAllPersonnelSQLResponse = {
  result: Dw_m_personnel[]
  count: number
}
