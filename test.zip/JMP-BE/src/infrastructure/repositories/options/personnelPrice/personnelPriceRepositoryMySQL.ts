import { Connection, QueryFailedError, UpdateResult } from 'typeorm'
import { Dw_m_personnel_price } from '../../../orm/typeorm/entities/Dw_m_personnel_price'
import { PersonnelPriceRepositoryPort } from '../../../../application/port/repositories/personnelPriceRepositoryPort.ts/PersonnelPriceRepositoryPort'
import { PersonnelPriceFindResult, PersonnelPriceKey } from './interface'
import CustomError from '../../../../application/errors/CustomError'
import messages from '../../../../application/errors/messages'

export const personnelPriceRepositoryMySQL = async (
  connection: Connection
): Promise<PersonnelPriceRepositoryPort> => ({
  findByPersonnelID: async (personnelId: number): PersonnelPriceFindResult => {
    const personnelPriceRepository = connection.getRepository(
      Dw_m_personnel_price
    )
    const findPersonnelPricesResult = personnelPriceRepository
      .createQueryBuilder('personnelPrice')
      .select([
        'personnelPrice.personnel_id',
        'personnelPrice.price_start_date',
        'personnelPrice.price_amount',
        'personnelPrice.currency_type_code',
        'personnelPrice.contract_pattern_code',
      ])
      .leftJoinAndSelect('personnelPrice.dw_m_personnel', 'dw_m_personnel')
      .where('personnelPrice.personnel_id = :personnelId', { personnelId })
      .orderBy('personnelPrice.personnel_id', 'ASC')
      .addOrderBy('personnelPrice.price_start_date', 'ASC')
      .getMany()
      .then((result: Dw_m_personnel_price[]) => {
        return result
      })
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })

    return findPersonnelPricesResult
  },

  createPersonnelPrice: async (
    personnelPrices: Partial<Dw_m_personnel_price>[]
  ) => {
    const personnelPriceRepository = connection.getRepository(
      Dw_m_personnel_price
    )
    const createUpdatePersonnelPriceResult = await personnelPriceRepository
      .createQueryBuilder()
      .insert()
      .into(Dw_m_personnel_price)
      .values(personnelPrices)
      .orUpdate({
        conflict_target: ['personnel_price_id'],
        overwrite: [
          'price_amount',
          'price_start_date',
          'currency_type_code',
          'contract_pattern_code',
        ],
      })
      .execute()
      .catch((err) => {
        if (err.errno === 1452)
          throw new CustomError(
            messages.personnelForeignKeyNotFound,
            'Method Not Allowed'
          )
      })

    return createUpdatePersonnelPriceResult
  },

  findMany: async (personnelPricesKeys: number[]) => {
    const personnelPriceRepository = connection.getRepository(
      Dw_m_personnel_price
    )

    const findPersonnelPricesResult = personnelPriceRepository
      .createQueryBuilder('personnelPrice')
      .select([
        'personnelPrice.personnel_price_id',
        'personnelPrice.personnel_id',
        'personnelPrice.price_start_date',
        'personnelPrice.price_amount',
        'personnelPrice.currency_type_code',
        'personnelPrice.contract_pattern_code',
      ])
      .leftJoinAndSelect('personnelPrice.dw_m_personnel', 'dw_m_personnel')
      .whereInIds(personnelPricesKeys)
      .orderBy('personnelPrice.personnel_id', 'ASC')
      .addOrderBy('personnelPrice.price_start_date', 'ASC')
      .getMany()
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })

    return findPersonnelPricesResult
  },

  delete: async (personnelPricesKey: PersonnelPriceKey) => {
    const personnelPriceRepository = connection.getRepository(
      Dw_m_personnel_price
    )
    const priceStartDate = personnelPricesKey.price_start_date
      .toISOString()
      .split('T')[0]
    return personnelPriceRepository
      .createQueryBuilder()
      .softDelete()
      .from(Dw_m_personnel_price)
      .where('personnel_id = :personnelId', {
        personnelId: personnelPricesKey.personnel_id,
      })
      .andWhere('price_start_date = :priceStartDate', {
        priceStartDate,
      })
      .andWhere('deleted_at IS NULL')
      .execute()
      .then((result: UpdateResult) => {
        if (result.affected === 0)
          throw new CustomError(messages.personnelPriceNotFound, 'Not Found')
        return result
      })
      .catch((err: QueryFailedError) => {
        throw new CustomError(err.message, 'Internal Server Error')
      })
  },
})
