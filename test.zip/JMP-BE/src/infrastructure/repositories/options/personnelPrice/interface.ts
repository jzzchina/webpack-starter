import { Dw_m_personnel_price } from '../../../orm/typeorm/entities/Dw_m_personnel_price'

export type PersonnelPriceKey = {
  personnel_id: number
  price_start_date: Date
}

export type PersonnelPriceFindResult = Promise<Dw_m_personnel_price[]>
