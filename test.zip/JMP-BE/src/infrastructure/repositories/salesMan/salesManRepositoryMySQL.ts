import { Connection } from 'typeorm'
import { SalesManRepositoryPort } from '../../../application/port/repositories/salesMan/SalesManRepositoryPort'
import { Dw_m_sales_man } from '../../orm/typeorm/entities/Dw_m_sales_man'

export const salesManRepositoryMySQL = async (
  connection: Connection
): Promise<SalesManRepositoryPort> => ({
  createSalesMan: async (salesManData: Partial<Dw_m_sales_man>[]) => {
    const salesManRepository = connection.getRepository(Dw_m_sales_man)
    return salesManRepository
      .createQueryBuilder()
      .insert()
      .into(Dw_m_sales_man)
      .values(salesManData)
      .orUpdate(['email', 'name', 'phone_number'], 'sales_man_id')
      .execute()
  },
  findSalesManByIds(salesManIds) {
    const salesManRepository = connection.getRepository(Dw_m_sales_man)
    return salesManRepository
      .createQueryBuilder()
      .select(['SM.sales_man_id', 'SM.name', 'SM.email', 'SM.phone_number'])
      .from(Dw_m_sales_man, 'SM')
      .whereInIds(salesManIds)
      .getMany()
  },
})
