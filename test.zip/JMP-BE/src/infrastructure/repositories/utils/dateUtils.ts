//* Function that Extracts the date (yyyy-mm-dd) from a date time (yyyy-mm-dd hh:mm:ss)

const extractDateFromDateTime = (dateTime: Date): string => {
  return dateTime.toISOString().split('T')[0]
}

const dateUtils = {
  extractDateFromDateTime,
}

export default dateUtils
