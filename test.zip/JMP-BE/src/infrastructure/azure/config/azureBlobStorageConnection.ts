import {
  BlobServiceClient,
  generateBlobSASQueryParameters,
  BlobSASPermissions,
  StorageSharedKeyCredential,
} from '@azure/storage-blob'
import { env } from '../../env'

const sharedKeyCredential = new StorageSharedKeyCredential(
  env.AZURE_STORAGE_ACCOUNT_NAME!,
  env.AZURE_STORAGE_ACCOUNT_KEY!
)
const blobServiceClient = new BlobServiceClient(
  `https://${env.AZURE_STORAGE_ACCOUNT_NAME}.blob.core.windows.net`,
  sharedKeyCredential
)

export const uploadFileToAzureBlob = async (
  buffer: Buffer,
  blobName: string
): Promise<string> => {
  const containerClient = blobServiceClient.getContainerClient(
    env.AZURE_CONTAINER_NAME!
  )
  const blockBlobClient = containerClient.getBlockBlobClient(blobName)

  await blockBlobClient.upload(buffer, buffer.byteLength)

  // Generate SAS token with appropriate permissions (read) and expiration time
  const expiresOn = new Date(new Date().getTime() + 30 * 1000) // Set expiration time to 30secs
  const sasToken = generateBlobSASQueryParameters(
    {
      containerName: env.AZURE_CONTAINER_NAME!,
      blobName: blobName,
      permissions: BlobSASPermissions.parse('r'), // Read permission
      expiresOn: expiresOn,
    },
    sharedKeyCredential
  ).toString()

  // Append SAS token to the blob URL
  const blobUrlWithSas = `${blockBlobClient.url}?${sasToken}`

  return blobUrlWithSas
}
