import { MigrationInterface, QueryRunner } from 'typeorm'

export class UpdatePersonnelSkillList1682680950000
  implements MigrationInterface {
  name = 'UpdatePersonnelSkillList1682680950000'

  public async up(queryRunner: QueryRunner): Promise<void> {
    const results = await queryRunner.query(
      'SELECT personnel_id, skill_list FROM dw_m_personnel WHERE skill_list IS NOT NULL'
    )

    const updatePromises = results.map(
      (result: {
        personnel_id: number
        skill_list: Record<string, unknown>
      }) => {
        const updatedSkillList = Object.entries(result.skill_list).reduce(
          (acc, [key, value]) => {
            const newKey = key.replace(/^.+,/, '').trim()
            acc[newKey] = value
            return acc
          },
          {} as Record<string, unknown>
        )

        return queryRunner.query(
          'UPDATE dw_m_personnel SET skill_list = ? WHERE personnel_id = ?',
          [JSON.stringify(updatedSkillList), result.personnel_id]
        )
      }
    )

    await Promise.all(updatePromises)
  }

  public async down(): Promise<void> {
    // it's a one-way migration
  }
}
