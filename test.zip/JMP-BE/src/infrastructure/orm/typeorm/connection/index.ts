import retry from 'async-retry'
import {
  Connection,
  createConnection as typeormCreateConnection,
} from 'typeorm'
import ormConfig from '../config/ormconfig'
import logger from '../../../logger/logger'

export const createConnection = async (): Promise<Connection> => {
  const maximum_retries = 10

  const connection = await retry(
    async () => {
      return await typeormCreateConnection(ormConfig)
    },
    {
      retries: maximum_retries,
      maxTimeout: 120 * 1000,
      onRetry: (e, attempt) => {
        logger.info(`${JSON.stringify(e)}`)
        logger.info(
          `Unable to connect to database; retrying (attempt: ${attempt}/${maximum_retries}).`
        )
      },
    }
  )

  return connection
}
