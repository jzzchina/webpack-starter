/**
 * A solution for an issue that decimal value is treated as string.
 * Ref: https://github.com/typeorm/typeorm/issues/873#issuecomment-424643086
 * */
export class ColumnDecimalTransformer {
  to(data: number): number {
    return data
  }
  from(data: string): number {
    return parseFloat(data)
  }
}
