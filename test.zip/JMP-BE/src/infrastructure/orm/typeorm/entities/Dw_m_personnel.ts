import {Column, PrimaryGeneratedColumn,  CreateDateColumn, Entity, UpdateDateColumn, JoinColumn, OneToMany, ManyToOne, DeleteDateColumn} from "typeorm";
import { Dw_m_partner_company } from './Dw_m_partner_company';
import { Dw_m_personnel_price } from './Dw_m_personnel_price';
import { Dw_t_operation_plan } from './Dw_t_operation_plan';
import { Dw_t_operation } from './Dw_t_operation';
import { SkillList } from "../../../../domain/models/Personnel";

@Entity()
export class Dw_m_personnel {

  @PrimaryGeneratedColumn('increment', {  type: 'int', unsigned: true, comment: '要員ID' })
  personnel_id!: number

  @ManyToOne(() => Dw_m_partner_company, (dw_m_partner_company) => dw_m_partner_company.dw_m_personnel, { onDelete: "CASCADE", persistence: false, nullable: false })
  @JoinColumn({ name: 'company_id', referencedColumnName: 'company_id' })
  dw_m_partner_company?: Dw_m_partner_company;

  @Column('varchar', { comment: '氏名', length: 200})
  name!: string

  @Column('varchar', { comment: '氏名（漢字）', length: 200, default: null, nullable: true })
  name_jpn: string | null = null

  @Column('varchar', { comment: 'Eメール', length: 200, default: null, nullable: true })
  email: string | null = null

  @Column('date',{ comment: 'プール登録開始年月' })
  registered_date!: Date

  @Column('date', { comment: 'プール登録終了年月', default: null, nullable: true})
  unregistered_date: Date | null = null

  @Column('json', { comment: 'スキルリスト'})
  skill_list!: SkillList

  @Column('varchar', { comment: '作成者'})
  created_by!: string

  @CreateDateColumn({ comment: '作成日時'})
  create_at!: Date

  @Column('varchar', { comment: '更新者', default: null, nullable: true})
  updated_by: string | null = null

  @UpdateDateColumn({ comment: '更新日時', default: null, nullable: true})
  update_at: Date | null = null

  @CreateDateColumn({ comment: '処理日時'})
  process_at!: Date

  @Column('varchar',{ comment: '処理ID',nullable: true})
  process_id: string| null = null

  @DeleteDateColumn({ comment:'論理削除日時', default: null, nullable: true})
  deleted_at: Date | null = null

  @OneToMany(() => Dw_m_personnel_price, (dw_m_personnel_price) => dw_m_personnel_price.dw_m_personnel, {persistence: false})
  dw_m_personnel_price?: Dw_m_personnel_price[]

  @OneToMany(() => Dw_t_operation_plan, (dw_t_operation_plan) => dw_t_operation_plan.dw_m_personnel, {persistence: false})
  dw_t_operation_plan?: Dw_t_operation_plan[]

  @OneToMany(() => Dw_t_operation, (dw_t_operation) => dw_t_operation.dw_m_personnel, {persistence: false})
  dw_t_operation?: Dw_t_operation[]

  // constructor(title: string, auther: string, isPublished: boolean) {
  //   this.title = title;
  //   this.auther = auther;
  //   this.isPublished = isPublished;
  // }
}
