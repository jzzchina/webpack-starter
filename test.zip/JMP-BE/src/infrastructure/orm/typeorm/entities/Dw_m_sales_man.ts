import { Entity, Column, CreateDateColumn, UpdateDateColumn, DeleteDateColumn, PrimaryGeneratedColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Dw_m_partner_company } from './Dw_m_partner_company';

@Entity()
export class Dw_m_sales_man {

    @PrimaryGeneratedColumn('increment', {  type: 'int', unsigned: true, comment: 'The id of sales man' })
    sales_man_id!: number

    @Column('varchar', { comment: 'sales man name', nullable: true, length: 255 })
    name!: string;

    @Column('varchar', { comment: 'the email of sales man', nullable: true, length: 255 })
    email!: string;

    @Column('varchar', { nullable: true, comment: 'the phone number of sales man' })
    phone_number!: string

    @ManyToOne(() => Dw_m_partner_company, (dw_m_partner_company) => dw_m_partner_company.dw_m_sales_man, { persistence: false, primary: false, onDelete: "CASCADE" })
    @JoinColumn({ name: 'company_id', referencedColumnName: 'company_id'  })
    dw_m_partner_company?: Dw_m_partner_company

    @Column('varchar', { comment: '作成者'})
    created_by!: string

    @CreateDateColumn({ comment: '作成日時'})
    create_at!: Date

    @Column('varchar', { comment: '更新者', default: null, nullable: true})
    updated_by: string | null = null

    @UpdateDateColumn({ comment: '更新日時', default: null, nullable: true})
    update_at: Date | null = null

    @CreateDateColumn({ comment: '処理日時'})
    process_at!: Date

    @Column('varchar',{ comment: '処理ID',nullable: true})
    process_id: string| null = null

    @DeleteDateColumn({ comment:'論理削除日時', default: null, nullable: true})
    deleted_at: Date | null = null
}
