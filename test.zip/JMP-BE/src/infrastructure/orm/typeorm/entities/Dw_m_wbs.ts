import { Entity, Column, ManyToOne, JoinColumn, CreateDateColumn, UpdateDateColumn, DeleteDateColumn, PrimaryGeneratedColumn } from 'typeorm';
import { Dw_m_project } from './Dw_m_project'; 

@Entity()
export class Dw_m_wbs {

    @PrimaryGeneratedColumn('increment', {  type: 'int', unsigned: true, comment: 'WBS_ID' })
    wbs_id!: number

    @Column('varchar', { comment: 'WBSコード', nullable: true, length: 255 })
    wbs_code!: string;

    @Column('varchar', { comment: 'WBSタイトル', nullable: true, length: 255 })
    wbs_title!: string;

    @Column('enum', { enum: ['CAPEX', 'OPEX'], nullable: true, comment: '科目' })
    subject!: 'CAPEX' | 'OPEX';

    @ManyToOne(() => Dw_m_project, (dw_m_project)=>dw_m_project.dw_m_wbs, {onDelete: "CASCADE", primary: false, persistence: false })
    @JoinColumn({ name: 'project_id', referencedColumnName: 'project_id'  })
    dw_m_project?: Dw_m_project;

    @Column('varchar', { comment: '作成者'})
    created_by!: string

    @CreateDateColumn({ comment: '作成日時'})
    create_at!: Date

    @Column('varchar', { comment: '更新者', default: null, nullable: true})
    updated_by: string | null = null

    @UpdateDateColumn({ comment: '更新日時', default: null, nullable: true})
    update_at: Date | null = null

    @CreateDateColumn({ comment: '処理日時'})
    process_at!: Date

    @Column('varchar',{ comment: '処理ID',nullable: true})
    process_id: string| null = null

    @DeleteDateColumn({ comment:'論理削除日時', default: null, nullable: true})
    deleted_at: Date | null = null

    // constructor(title: string, auther: string, isPublished: boolean) {
    //   this.title = title;
    //   this.auther = auther;
    //   this.isPublished = isPublished;
    // }
}
