import {Column, PrimaryColumn,  CreateDateColumn, Entity, UpdateDateColumn, JoinColumn, ManyToOne,DeleteDateColumn, PrimaryGeneratedColumn} from "typeorm";
import { Dw_m_personnel } from './Dw_m_personnel';
import { Dw_m_project } from './Dw_m_project';
import { Dw_m_role } from './Dw_m_role';
import { ColumnDecimalTransformer } from "../transformers/decimalToNumber";

@Entity()
export class Dw_t_operation_plan {

  @PrimaryGeneratedColumn('increment', {  type: 'int', unsigned: true, comment: 'OperationPlanID' })
  operation_plan_id!: number

  @ManyToOne(() => Dw_m_personnel, (dw_m_personnel) => dw_m_personnel.dw_t_operation_plan, { onDelete: "CASCADE", primary: false, persistence: false })
  @JoinColumn({ name: 'personnel_id', referencedColumnName: 'personnel_id' })
  dw_m_personnel?: Dw_m_personnel;

  @ManyToOne(() => Dw_m_project, (dw_m_project) => dw_m_project.dw_t_operation_plan, { onDelete: 'CASCADE', primary: false, persistence: false })
  @JoinColumn({ name: 'project_id', referencedColumnName: 'project_id' })
  dw_m_project?: Dw_m_project;
  @PrimaryColumn('date',{comment: '年月'})
  month_of_year_date!: Date

  @ManyToOne(() => Dw_m_role, (dw_m_role) => dw_m_role.dw_t_operation_plan, { persistence: false })
  @JoinColumn({ name: 'role_id', referencedColumnName: 'role_id' })
  dw_m_role?: Dw_m_role;

  @Column('decimal', {
    comment: '稼働計画[人月]',
    precision: 3,
    scale: 2,
    transformer: new ColumnDecimalTransformer(),
  })
  man_month_number!: number

  @Column('decimal', {
    comment: '稼働計画[時間]',
    precision: 6,
    scale: 3,
    transformer: new ColumnDecimalTransformer(),
  })
  hours_number!: number

  @Column('varchar', { comment: '作成者'})
  created_by!: string

  @CreateDateColumn({ comment: '作成日時'})
  create_at!: Date

  @Column('varchar', { comment: '更新者', default: null, nullable: true})
  updated_by: string | null = null

  @UpdateDateColumn({ comment: '更新日時', default: null, nullable: true})
  update_at: Date | null = null

  @CreateDateColumn({ comment: '処理日時'})
  process_at!: Date

  @Column('varchar',{ comment: '処理ID',nullable: true})
  process_id: string| null = null

  @DeleteDateColumn({ comment:'論理削除日時', default: null, nullable: true})
  deleted_at: Date | null = null

  // constructor(title: string, auther: string, isPublished: boolean) {
  //   this.title = title;
  //   this.auther = auther;
  //   this.isPublished = isPublished;
  // }
}
