import {Column,  CreateDateColumn, Entity, UpdateDateColumn, JoinColumn, ManyToOne, DeleteDateColumn, PrimaryGeneratedColumn} from "typeorm";
import { Dw_m_personnel } from './Dw_m_personnel';
import { Dw_m_project } from './Dw_m_project';
import { ColumnDecimalTransformer } from "../transformers/decimalToNumber";

@Entity()
export class Dw_t_operation {

  @PrimaryGeneratedColumn('increment', {  type: 'int', unsigned: true, comment: 'OperationID' })
  operation_id!: number

  @ManyToOne(() => Dw_m_personnel, (dw_m_personnel) => dw_m_personnel.dw_t_operation, {onDelete: "CASCADE", primary: false, persistence: false })
  @JoinColumn({ name: 'personnel_id', referencedColumnName: 'personnel_id' })
  dw_m_personnel?: Dw_m_personnel;

  @ManyToOne(() => Dw_m_project, (dw_m_project) => dw_m_project.dw_t_operation, { onDelete: 'CASCADE', primary: false, persistence: false })
  @JoinColumn({ name: 'project_id', referencedColumnName: 'project_id' })
  dw_m_project?: Dw_m_project;

  @Column('date',{comment: '年月'})
  month_of_year_date!: Date

  @Column('decimal', {
    comment: '稼働実績[時間]',
    precision: 7,
    scale: 3,
    transformer: new ColumnDecimalTransformer(),
  })
  hours_number!: number

  @Column('decimal', {
    comment: '費用実績[円]',
    precision: 12,
    scale: 3,
    transformer: new ColumnDecimalTransformer(),
  })
  cost_amount!: number

  @Column('varchar', { comment: '作成者'})
  created_by!: string

  @CreateDateColumn({ comment: '作成日時'})
  create_at!: Date

  @Column('varchar', { comment: '更新者', default: null, nullable: true})
  updated_by: string | null = null

  @UpdateDateColumn({ comment: '更新日時', default: null, nullable: true})
  update_at: Date | null = null

  @CreateDateColumn({ comment: '処理日時'})
  process_at!: Date

  @Column('varchar',{ comment: '処理ID',nullable: true})
  process_id: string| null = null

  @DeleteDateColumn({ comment:'論理削除日時', default: null, nullable: true})
  deleted_at: Date | null = null
  // constructor(title: string, auther: string, isPublished: boolean) {
  //   this.title = title;
  //   this.auther = auther;
  //   this.isPublished = isPublished;
  // }
}
