import {Column,  CreateDateColumn, Entity, UpdateDateColumn, JoinColumn, ManyToOne, DeleteDateColumn, PrimaryGeneratedColumn} from "typeorm";
import { Dw_m_personnel } from './Dw_m_personnel';

@Entity()
export class Dw_m_personnel_price {

  @PrimaryGeneratedColumn('increment', {  type: 'int', unsigned: true, comment: 'PersonnelPriceID' })
  personnel_price_id!: number

  @ManyToOne(() => Dw_m_personnel, (dw_m_personnel) => dw_m_personnel.dw_m_personnel_price, {onDelete: "CASCADE", primary: false, persistence: false })
  @JoinColumn({ name: 'personnel_id', referencedColumnName: 'personnel_id' })
  dw_m_personnel?: Dw_m_personnel;

  @Column('tinyint', { comment: '契約パターン', width: 1 })
  contract_pattern_code!: number

  @Column('date',{comment: '開始年月', nullable: true})
  price_start_date!: Date

  @Column('decimal', { comment: '単価',  precision: 10, scale: 2  })
  price_amount!: number

  @Column('int', { comment: '通貨タイプ' })
  currency_type_code!: number

  @Column('varchar', { comment: '作成者'})
  created_by!: string

  @CreateDateColumn({ comment: '作成日時'})
  create_at!: Date

  @Column('varchar', { comment: '更新者', default: null, nullable: true})
  updated_by: string | null = null

  @UpdateDateColumn({ comment: '更新日時', default: null, nullable: true})
  update_at: Date | null = null

  @CreateDateColumn({ comment: '処理日時'})
  process_at!: Date

  @Column('varchar',{ comment: '処理ID',nullable: true})
  process_id: string| null = null

  @DeleteDateColumn({ comment:'論理削除日時', default: null, nullable: true})
  deleted_at: Date | null = null

  // constructor(title: string, auther: string, isPublished: boolean) {
  //   this.title = title;
  //   this.auther = auther;
  //   this.isPublished = isPublished;
  // }
}
