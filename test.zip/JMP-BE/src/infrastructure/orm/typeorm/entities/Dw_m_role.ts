import {Column, PrimaryGeneratedColumn, CreateDateColumn, Entity, UpdateDateColumn, OneToMany} from "typeorm";
import { Dw_t_operation_plan } from './Dw_t_operation_plan';

@Entity()
export class Dw_m_role {
  @PrimaryGeneratedColumn('increment', {  type: 'int', unsigned: true, comment: '役割ID' })
  role_id!: number

  @Column('varchar', { comment: '役割名', length: 200 })
  role_name!: string

  @Column('varchar', { comment: '作成者'})
  created_by!: string

  @CreateDateColumn({ comment: '作成日時'})
  create_at!: Date

  @Column('varchar', { comment: '更新者', default: null, nullable: true})
  updated_by: string | null = null

  @UpdateDateColumn({ comment: '更新日時', default: null, nullable: true})
  update_at: Date | null = null

  @CreateDateColumn({ comment: '処理日時'})
  process_at!: Date

  @Column('varchar',{ comment: '処理ID',nullable: true})
  process_id: string| null = null

  @OneToMany(() => Dw_t_operation_plan, (dw_t_operation_plan) => dw_t_operation_plan.dw_m_role, {persistence: false})
  dw_t_operation_plan?: Dw_t_operation_plan[]

  // constructor(company_id: number, company_name: string, contract_pattern_code: number, created_by: string,
  //   create_at: Date, updated_by: string | null = null, update_at: Date | null = null, process_at: Date, process_id: string) {
  //   this.company_id = company_id;
  //   this.company_name = company_name;
  //   this.contract_pattern_code = contract_pattern_code;
  //   this.created_by = created_by;
  //   this.create_at = create_at;
  //   this.updated_by = updated_by;
  //   this.update_at = update_at;
  //   this.process_at = process_at;
  //   this.process_id = process_id;
  // }
}
