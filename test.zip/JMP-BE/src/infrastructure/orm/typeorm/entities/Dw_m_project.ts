import {Column, PrimaryGeneratedColumn, CreateDateColumn, Entity, UpdateDateColumn, OneToMany, DeleteDateColumn} from "typeorm";
import { Dw_t_operation } from './Dw_t_operation';
import { Dw_t_operation_plan } from './Dw_t_operation_plan';
import { Dw_m_wbs } from "./Dw_m_wbs";

@Entity()
export class Dw_m_project {
  @PrimaryGeneratedColumn('increment', {  type: 'int', unsigned: true, comment: 'プロジェクトID' })
  project_id!: number

  @Column('varchar', { comment: 'プロジェクト名', length: 200 })
  project_name!: string

  @Column('tinyint', { comment: 'ステータス', width: 1})
  status!: number

  @Column('date',{comment: 'プロジェクト開始年月'})
  project_start_date!: Date

  @Column('date', { comment: 'プロジェクト終了年月', default: null, nullable: true})
  project_end_date: Date | null = null

  @Column('varchar', { comment: 'プロジェクト名', length: 200 , default: null, nullable: true})
  project_manager!: string

  @Column('varchar', { comment: 'プロジェクト連絡先' , default: null, nullable: true})
  project_contact!: string
  @Column('varchar', { comment: 'プロジェクト連絡先' , default: null, nullable: true})
  project_contact2!: string
  @Column('varchar', { comment: 'プロジェクト連絡先' , default: null, nullable: true})
  project_contact3!: string
  @Column('varchar', { comment: 'プロジェクト連絡先' , default: null, nullable: true})
  project_contact4!: string

  @Column('varchar', { comment: 'ユーザ部門', length: 200 , default: null, nullable: true})
  user_part!: string

  @Column('varchar', { comment: '備考', default: null, nullable: true})
  notes:string| null = null

  @Column('varchar', { comment: '作成者'})
  created_by!: string

  @CreateDateColumn({ comment: '作成日時'})
  create_at!: Date

  @Column('varchar', { comment: '更新者', default: null, nullable: true})
  updated_by: string | null = null

  @UpdateDateColumn({ comment: '更新日時', default: null, nullable: true})
  update_at: Date | null = null

  @CreateDateColumn({ comment: '処理日時'})
  process_at!: Date

  @Column('varchar',{ comment: '処理ID',nullable: true})
  process_id: string| null = null

  @DeleteDateColumn({ comment:'論理削除日時', default: null, nullable: true})
  deleted_at: Date | null = null
  
  @OneToMany(() => Dw_t_operation, (dw_t_operation) => dw_t_operation.dw_m_project, {persistence: false})
  dw_t_operation?: Dw_t_operation[]

  @OneToMany(() => Dw_t_operation_plan, (dw_t_operation_plan) => dw_t_operation_plan.dw_m_project, {persistence: false})
  dw_t_operation_plan?: Dw_t_operation_plan[]

  @OneToMany(() => Dw_m_wbs, (dw_m_wbs) => dw_m_wbs.dw_m_project, {persistence: false})
  dw_m_wbs?: Dw_m_wbs[]

  // constructor(company_id: number, company_name: string, contract_pattern_code: number, created_by: string,
  //   create_at: Date, updated_by: string | null = null, update_at: Date | null = null, process_at: Date, process_id: string) {
  //   this.company_id = company_id;
  //   this.company_name = company_name;
  //   this.contract_pattern_code = contract_pattern_code;
  //   this.created_by = created_by;
  //   this.create_at = create_at;
  //   this.updated_by = updated_by;
  //   this.update_at = update_at;
  //   this.process_at = process_at;
  //   this.process_id = process_id;
  // }
}
