import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, DeleteDateColumn, OneToMany } from 'typeorm';
import { Dw_m_business_days } from './Dw_m_business_days';
import { Dw_m_personnel } from './Dw_m_personnel';
import { Dw_m_sales_man } from './Dw_m_sales_man';

@Entity()
export class Dw_m_partner_company {
  @PrimaryGeneratedColumn('increment', {  type: 'int', unsigned: true, comment: '企業ID' })
  company_id!: number

  @Column('varchar', { comment: '企業名', length: 200 })
  company_name!: string

  @Column('tinyint', { comment: '契約パターン', width: 1 })
  contract_pattern_code!: number

  @Column('varchar', { comment: '作成者'})
  created_by!: string

  @CreateDateColumn({ comment: '作成日時'})
  create_at!: Date

  @Column('varchar', { comment: '更新者', default: null, nullable: true})
  updated_by: string | null = null

  @UpdateDateColumn({ comment: '更新日時', default: null, nullable: true})
  update_at: Date | null = null

  @CreateDateColumn({ comment: '処理日時'})
  process_at!: Date

  @Column('varchar',{ comment: '処理ID',nullable: true})
  process_id: string| null = null

  @DeleteDateColumn({ comment:'論理削除日時', default: null, nullable: true})
  deleted_at: Date | null = null

  @OneToMany(() => Dw_m_business_days, (dw_m_business_day) => dw_m_business_day.dw_m_partner_company, {persistence: false})
  dw_m_business_day?: Dw_m_business_days[]

  @OneToMany(() => Dw_m_personnel, (dw_m_personnel) => dw_m_personnel.dw_m_partner_company, {persistence: false})
  dw_m_personnel?: Dw_m_personnel[]
  @OneToMany(() => Dw_m_sales_man, (Dw_m_sales_man)=>Dw_m_sales_man.dw_m_partner_company, {persistence: false })
  dw_m_sales_man?: Dw_m_sales_man[];
  // constructor(company_id: number, company_name: string, contract_pattern_code: number, created_by: string,
  //   create_at: Date, updated_by: string | null = null, update_at: Date | null = null, process_at: Date, process_id: string) {
  //   this.company_id = company_id;
  //   this.company_name = company_name;
  //   this.contract_pattern_code = contract_pattern_code;
  //   this.created_by = created_by;
  //   this.create_at = create_at;
  //   this.updated_by = updated_by;
  //   this.update_at = update_at;
  //   this.process_at = process_at;
  //   this.process_id = process_id;
  // }
}
