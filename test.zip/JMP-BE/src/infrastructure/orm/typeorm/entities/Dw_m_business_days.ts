import {Column,  CreateDateColumn, Entity, UpdateDateColumn, JoinColumn, ManyToOne, DeleteDateColumn, PrimaryGeneratedColumn} from "typeorm";
import { Dw_m_partner_company } from './Dw_m_partner_company';

@Entity()
export class Dw_m_business_days {

  @PrimaryGeneratedColumn('increment', {  type: 'int', unsigned: true, comment: 'BusinessDaysID' })
  business_days_id!: number
  
  @ManyToOne(() => Dw_m_partner_company, (dw_m_partner_company) => dw_m_partner_company.dw_m_business_day, {onDelete: "CASCADE", primary: false, persistence: false })
  @JoinColumn({ name: 'company_id', referencedColumnName: 'company_id' })
  dw_m_partner_company?: Dw_m_partner_company;

  @Column('date', {comment: '年月', nullable: true})
  month_of_year_date!: Date

  @Column('tinyint', { comment: '営業日数', width: 31 })
  business_days_number!: number

  @Column('varchar', { comment: '作成者'})
  created_by!: string

  @CreateDateColumn({ comment: '作成日時'})
  create_at!: Date

  @Column('varchar', { comment: '更新者', default: null, nullable: true})
  updated_by: string | null = null

  @UpdateDateColumn({ comment: '更新日時', default: null, nullable: true})
  update_at: Date | null = null

  @CreateDateColumn({ comment: '処理日時'})
  process_at!: Date

  @Column('varchar',{ comment: '処理ID',nullable: true})
  process_id: string| null = null

  @DeleteDateColumn({ comment:'論理削除日時', default: null, nullable: true})
  deleted_at: Date | null = null

  // constructor(title: string, auther: string, isPublished: boolean) {
  //   this.title = title;
  //   this.auther = auther;
  //   this.isPublished = isPublished;
  // }
}
