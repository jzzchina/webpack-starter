import Winston from 'winston'
const transports: Array<Winston.transport> = []

const customFormat = Winston.format.printf(({ level, message, timestamp }) => {
  const messageString =
    typeof message === 'object' ? JSON.stringify(message) : message
  return `${level}:[${timestamp}] ${messageString}`
})

transports.push(
  new Winston.transports.Console({
    format: Winston.format.combine(
      Winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
      customFormat
    ),
  })
)

const logger: Winston.Logger = Winston.createLogger({
  level: process.env['LOG_LEVEL'] || 'info',
  levels: Winston.config.npm.levels,
  format: Winston.format.combine(
    Winston.format.colorize({ all: true }),
    Winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    Winston.format.errors({ stack: true }),
    customFormat
  ),
  silent: false,
  transports,
})

export const LoggerStream = {
  write: (msg: string): void => {
    logger.info(msg.replace(/(\n)/gm, ''))
  },
}

export default logger
