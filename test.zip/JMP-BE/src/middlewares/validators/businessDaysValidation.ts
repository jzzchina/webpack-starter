import Joi from 'joi'

const getAll: Record<string, Joi.ObjectSchema> = {
  query: Joi.object().keys({
    company_id: Joi.number().positive().required(),
  }),
}

const create: Record<string, Joi.ArraySchema> = {
  body: Joi.array()
    .items(
      Joi.object().keys({
        businessDaysId: Joi.number().positive().optional(),
        companyId: Joi.number().positive().required(),
        monthOfYearDate: Joi.date().required(),
        businessDaysNumber: Joi.number().min(0).max(31).required(),
      })
    )
    .unique()
    .message('Multiple values for same Business Days for a resource')
    .min(1),
}
const deleteBusinessDays: Record<string, Joi.ObjectSchema> = {
  params: Joi.object().keys({
    companyId: Joi.number().positive().required(),
    monthOfYearDate: Joi.date().required(),
  }),
}
export const businessDaysValidation = {
  getAll,
  create,
  deleteBusinessDays,
}
