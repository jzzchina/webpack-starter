import Joi from 'joi'

import { JoiDate } from '.'

const getWbsCosts: Record<string, Joi.ObjectSchema> = {
  query: Joi.object().keys({
    limit: Joi.number().greater(0).required(),
    offset: Joi.number().min(0).required(),
    from: JoiDate.date().utc().format('YYYY-MM-DD').raw().optional(),
    to: JoiDate.date()
      .utc()
      .format('YYYY-MM-DD')
      .raw()
      .when('from', {
        is: Joi.exist(),
        then: JoiDate.date().min(Joi.ref('from')),
      })
      .optional(),
    company_id: Joi.number().required(),
  }),
}

export const wbsValidation = {
  getWbsCosts,
}
