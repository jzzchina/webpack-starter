import Joi from 'joi'

const findByPersonnelID: Record<string, Joi.ObjectSchema> = {
  query: Joi.object().keys({
    personnel_id: Joi.number().positive().required(),
  }),
}

const createPersonnelPrice: Record<string, Joi.ArraySchema> = {
  body: Joi.array()
    .items(
      Joi.object({
        personnelPriceId: Joi.number().optional(),
        personnelId: Joi.number().positive().required(),
        priceStartDate: Joi.date().required(),
        priceAmount: Joi.number().min(0).required(),
        currencyTypeCode: Joi.number().required(),
        contractPatternCode: Joi.number().required(),
      })
    )
    .unique()
    .message('Duplicate entry')
    .min(1),
}

const deletePersonnelPrice: Record<string, Joi.ObjectSchema> = {
  params: Joi.object().keys({
    personnelId: Joi.number().positive().required(),
    priceStartDate: Joi.date().required(),
  }),
}

export const personnelPriceValidation = {
  findByPersonnelID,
  createPersonnelPrice,
  deletePersonnelPrice,
}
