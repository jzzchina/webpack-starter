import Joi from 'joi'

import { JoiDate } from '.'

const project: Joi.PartialSchemaMap = {
  // required fields
  projectId: Joi.number().positive().optional(),
  projectName: Joi.string().trim().min(1).max(200).required(),
  status: Joi.number().integer().min(0).max(7).required(),
  projectStartDate: JoiDate.date().format('YYYY-MM-DD').raw().utc().required(),
  // optional fields
  projectEndDate: JoiDate.date()
    .format('YYYY-MM-DD')
    .raw()
    .utc()
    .when('projectStartDate', {
      is: Joi.exist(),
      then: JoiDate.date().min(Joi.ref('projectStartDate')),
    })
    .optional()
    .allow(''),
  projectManager: Joi.string().trim().max(200).optional().allow(''),
  projectContact: Joi.string()
    .email({ allowUnicode: false })
    .max(75)
    .allow('')
    .optional(),
  projectContact2: Joi.string()
    .email({ allowUnicode: false })
    .max(75)
    .allow('')
    .optional(),
  projectContact3: Joi.string()
    .email({ allowUnicode: false })
    .max(75)
    .allow('')
    .optional(),
  projectContact4: Joi.string()
    .email({ allowUnicode: false })
    .max(75)
    .allow('')
    .optional(),
  userPart: Joi.string().trim().max(200).optional().allow(''),
  note: Joi.string().trim().max(255).optional().allow(''),
}
const wbsFields: Joi.PartialSchemaMap = {
  wbsCode: Joi.string().optional().allow(''),
  wbsTitle: Joi.string().optional().allow(''),
  wbsSubject: Joi.string().valid('OPEX', 'CAPEX').allow(null).optional(),
}

const createUpdateProject = {
  ...project,
  ...wbsFields,
}
const createUpdateProjectsValidator = {
  body: Joi.array()
    .unique('projectId')
    .items(Joi.object().keys(createUpdateProject))
    .min(1),
}

const deleteQuery: Record<string, Joi.ObjectSchema> = {
  query: Joi.object().keys({
    project_id: Joi.array()
      .items(Joi.number().integer().min(0))
      .required()
      .single(),
  }),
}

const getProjectsQueryValidator: Record<string, Joi.ObjectSchema> = {
  query: Joi.object().keys({
    offset: Joi.number().integer().min(0).optional().allow(''),
    limit: Joi.number()
      .integer()
      .min(1)
      .when('offset', { is: Joi.exist(), then: Joi.required() })
      .optional()
      .allow(''),
    project_id: Joi.number().integer().min(0).optional().allow(''),
    project_name: Joi.string().optional().allow(''),
    status: Joi.number().integer().min(0).max(7).optional().allow(''),
    project_start_date: JoiDate.date()
      .utc()
      .format('YYYY-MM-DD')
      .raw()
      .optional(),
    project_end_date: JoiDate.date()
      .utc()
      .format('YYYY-MM-DD')
      .raw()
      .when('project_start_date', {
        is: Joi.exist(),
        then: JoiDate.date().min(Joi.ref('project_start_date')),
      })
      .optional(),
    project_manager: Joi.string().optional().allow(''),
    user_part: Joi.string().optional().allow(''),
    company_id: Joi.number().integer().min(0).optional().allow(''),
    include_status_closed: Joi.boolean().optional(),
  }),
}

export const projectValidator = {
  createUpdateProjectsValidator,
  deleteQuery,
  getProjectsQueryValidator,
}
