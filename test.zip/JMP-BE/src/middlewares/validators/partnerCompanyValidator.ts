import Joi from 'joi'

const createPartnerCompany: Record<string, Joi.ArraySchema> = {
  body: Joi.array()
    .items(
      Joi.object({
        companyId: Joi.number().positive().optional(),
        contractPatternCode: Joi.number().required().max(2),
        companyName: Joi.string().required(),
        salesMan: Joi.array()
          .items(
            Joi.object({
              salesManId: Joi.number().positive().optional(),
              name: Joi.string().required(),
              emailAddress: Joi.string().email().optional().allow(''),
              phoneNumber: Joi.string().optional().allow(''),
            })
          )
          .required(),
      })
    )
    .unique((a, b) => a.companyId === b.companyId)
    .message('Multiple values for same partner company for a resource')
    .min(1),
}

const deletePartnerCompanies: Record<string, Joi.ObjectSchema> = {
  query: Joi.object().keys({
    company_id: Joi.array().items(Joi.number().positive()).required().single(),
  }),
}

const getPartnerCompany: Record<string, Joi.ObjectSchema> = {
  query: Joi.object().keys({
    offset: Joi.number().integer().min(0).optional().allow(''),
    limit: Joi.number()
      .integer()
      .min(1)
      .when('offset', { is: Joi.exist(), then: Joi.required() })
      .optional()
      .allow(''),
    company_id: Joi.number().integer().min(0).optional().allow(''),
    company_name: Joi.string().optional().allow(''),
    contract_pattern_code: Joi.number()
      .integer()
      .min(0)
      .max(2)
      .optional()
      .allow(''),
  }),
}
export const partnerCompanyValidation = {
  createPartnerCompany,
  deletePartnerCompanies,
  getPartnerCompany,
}
