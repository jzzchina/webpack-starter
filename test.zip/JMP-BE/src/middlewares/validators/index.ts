import { Request, Response, NextFunction } from 'express'
import Joi from 'joi'
import { pick } from '../utils/functions/pick'
import dateBase from '@joi/date'

export const JoiDate = Joi.extend(dateBase)
export const validate = (
  schema: Record<string, Joi.ObjectSchema | Joi.ArraySchema>
) => (
  req: Request,
  res: Response,
  next: NextFunction
): void | Response<any, Record<string, any>> => {
  const validSchema = pick(schema, ['params', 'query', 'body'])
  const object = pick(req, Object.keys(validSchema))
  const { value, error } = Joi.compile(validSchema)
    .prefs({ errors: { label: 'key' }, abortEarly: false })
    .validate(object)

  if (error) {
    const err = {
      res: 'Validation error',
      message: error.details[0].message,
      type: error.details[0].type,
    }
    if (error.details[0].type === 'array.unique') {
      return res.status(400).json(err)
    }
    return res.status(422).json(err)
  }
  Object.assign(req, value)
  return next()
}
