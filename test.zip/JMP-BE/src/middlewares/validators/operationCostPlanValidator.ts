import Joi from 'joi'

import { JoiDate } from '.'

const getOperationCostPlansByProject: Record<string, Joi.ObjectSchema> = {
  query: Joi.object().keys({
    limit: Joi.number().greater(0).required(),
    offset: Joi.number().min(0).required(),
    from: JoiDate.date().utc().format('YYYY-MM-DD').raw().optional(),
    to: JoiDate.date()
      .utc()
      .format('YYYY-MM-DD')
      .raw()
      .when('from', {
        is: Joi.exist(),
        then: JoiDate.date().min(Joi.ref('from')),
      })
      .optional(),
    project_id: Joi.number().optional(),
    company_id: Joi.number().optional(),
  }),
}

export const operationCostPlanValidation = {
  getOperationCostPlansByProject,
}
