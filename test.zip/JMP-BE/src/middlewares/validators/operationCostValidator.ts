import Joi from 'joi'

import { JoiDate } from './index'

const getOperationCost: Record<string, Joi.ObjectSchema> = {
  query: Joi.object().keys({
    limit: Joi.number().greater(0).required(),
    offset: Joi.number().min(0).required(),
    from: JoiDate.date().utc().format('YYYY-MM-DD').raw().optional(),
    to: JoiDate.date()
      .utc()
      .format('YYYY-MM-DD')
      .raw()
      .when('from', {
        is: Joi.exist(),
        then: JoiDate.date().min(Joi.ref('from')),
      })
      .optional(),
    project_id: Joi.number().optional(),
    company_id: Joi.number().optional(),
  }),
}

const deleteOperationCost: Record<string, Joi.ArraySchema> = {
  body: Joi.array()
    .items(
      Joi.object({
        personnelId: Joi.number().required(),
        projectId: Joi.number().required(),
        yearOfMonthDate: JoiDate.date().format('YYYY-MM-DD').raw().required(),
      })
    )
    .unique()
    .message('Multiple values for same operation for a resource'),
}

const createOperationCost: Record<string, Joi.ArraySchema> = {
  body: Joi.array()
    .items(
      Joi.object({
        hoursNumber: Joi.number()
          .min(0)
          .max(9999.999)
          .precision(3)
          .options({ convert: false })
          .required(),
        personnelId: Joi.number().required(),
        projectId: Joi.number().required(),
        yearOfMonthDate: JoiDate.date().format('YYYY-MM-DD').raw().required(),
        costAmount: Joi.number().required().positive().allow(0),
        operationId: Joi.number().optional(),
      })
    )
    .unique()
    .message('Multiple values for same operation for a resource'),
}

export const operationCostValidation = {
  getOperationCost,
  deleteOperationCost,
  createOperationCost,
}
