import Joi from 'joi'

import { JoiDate } from '.'

const createPersonnel: Record<string, Joi.ArraySchema> = {
  body: Joi.array()
    .items(
      Joi.object({
        // required fields
        personnelId: Joi.number().positive().optional(),
        companyId: Joi.number().integer().positive().required(),
        name: Joi.string().required(),
        registeredDate: JoiDate.date().format('YYYY-MM-DD').raw().required(),
        skillList: Joi.object().required(),
        // optional fields
        nameJpn: Joi.string().allow('').min(1).max(200),
        email: Joi.string().email().allow('').max(200),
        unregisteredDate: JoiDate.date()
          .format('YYYY-MM-DD')
          .raw()
          .greater(Joi.ref('registeredDate'))
          .optional()
          .allow(null)
          .when('projectStartDate', {
            is: Joi.exist(),
            then: JoiDate.date().min(Joi.ref('registeredDate')),
          }),
      })
    )
    .unique()
    .message('Multiple values for same personnel for a resource')
    .min(1),
}

const deletePersonnels: Record<string, Joi.ObjectSchema> = {
  query: Joi.object().keys({
    personnel_id: Joi.array()
      .items(Joi.number().integer().min(0))
      .required()
      .single(),
  }),
}

const getAllPersonnel: Record<string, Joi.ObjectSchema> = {
  query: Joi.object().keys({
    offset: Joi.number().integer().min(0).optional().allow(''),
    limit: Joi.number()
      .integer()
      .min(1)
      .when('offset', { is: Joi.exist(), then: Joi.required() })
      .optional()
      .allow(''),
    personnel_id: Joi.number().integer().min(0).optional().allow(''),
    name: Joi.string().optional().allow(''),
    name_jpn: Joi.string().optional().allow(''),
    project_id: Joi.number().integer().min(0).optional().allow(''),
    company_id: Joi.number().integer().min(0).optional().allow(''),
    search_name: Joi.string().optional().allow(''),
    include_status_closed: Joi.boolean().optional(),
  }),
}

const searchExistenceOfOperation: Record<string, Joi.ObjectSchema> = {
  query: Joi.object().keys({
    from: JoiDate.date().format('YYYY-MM-DD').raw().utc().required(),
    to: JoiDate.date().format('YYYY-MM-DD').default('9999-12-31'),
  }),
  params: Joi.object().keys({
    personnelId: Joi.number().positive().required(),
  }),
}

export const personnelValidation = {
  createPersonnel,
  deletePersonnels,
  getAllPersonnel,
  searchExistenceOfOperation,
}
