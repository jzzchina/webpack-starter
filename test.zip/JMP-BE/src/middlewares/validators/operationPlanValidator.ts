import Joi from 'joi'

import { JoiDate } from '.'

const operationPlanPK: Joi.PartialSchemaMap = {
  operationPlanId: Joi.number().required(),
  personnelId: Joi.number().required(),
  projectId: Joi.number().required(),
  yearOfMonthDate: JoiDate.date().format('YYYY-MM-DD').raw().utc().required(),
}

const deleteOperationPlans = {
  body: Joi.array().items(Joi.object().keys(operationPlanPK)),
}

const createOperationPlans: Record<string, Joi.ArraySchema> = {
  body: Joi.array()
    .items(
      Joi.object({
        manMonthNumber: Joi.number()
          .min(0)
          .max(9.99)
          .precision(2)
          .options({ convert: false })
          .required(),
        personnelId: Joi.number().required(),
        projectId: Joi.number().required(),
        roleId: Joi.number().required(),
        yearOfMonthDate: JoiDate.date().format('YYYY-MM-DD').raw().required(),
        hoursNumber: Joi.number().min(0).max(999.999).required(),
        operationPlanId: Joi.number().optional(),
      })
    )
    .unique()
    .message('Multiple values for same operation plan for a resource'),
}

const getOperationPlansByProject: Record<string, Joi.ObjectSchema> = {
  query: Joi.object().keys({
    limit: Joi.number().integer().greater(0).required(),
    offset: Joi.number().min(0).required(),
    from: JoiDate.date().utc().format('YYYY-MM-DD').raw().optional(),
    to: JoiDate.date()
      .utc()
      .format('YYYY-MM-DD')
      .raw()
      .when('from', {
        is: Joi.exist(),
        then: JoiDate.date().min(Joi.ref('from')),
      })
      .optional(),
    project_id: Joi.number().optional(),
    company_id: Joi.number().optional(),
  }),
  body: Joi.object({ skills: Joi.object().optional() }).required(),
}

const getOperationPlansByPersonnel: Record<string, Joi.ObjectSchema> = {
  query: Joi.object().keys({
    limit: Joi.number().greater(0).required(),
    offset: Joi.number().min(0).required(),
    from: JoiDate.date().utc().format('YYYY-MM-DD').raw().optional(),
    to: JoiDate.date()
      .utc()
      .format('YYYY-MM-DD')
      .raw()
      .when('from', {
        is: Joi.exist(),
        then: JoiDate.date().min(Joi.ref('from')),
      })
      .optional(),
    project_id: Joi.number().optional(),
    company_id: Joi.number().optional(),
  }),
  body: Joi.object({ skills: Joi.object().optional() }).optional(),
}

export const operationPlanValidation = {
  deleteOperationPlans,
  getOperationPlansByProject,
  createOperationPlans,
  getOperationPlansByPersonnel,
}
