import { NextFunction, Request, Response } from 'express'
import jwt, { JwtPayload } from 'jsonwebtoken'
import logger from '../../infrastructure/logger/logger'
export const verifyToken = (
  req: Request,
  res: Response,
  next: NextFunction
): Response | void => {
  try {
    const X_AD_Token = req.headers['x-ad-token'] as string
    logger.info('x-ad-token: ' + X_AD_Token)
    logger.info({
      API: `${req.method} ${req.url}`,
      baseUrl: req.baseUrl,
      originalUrl: req.originalUrl,
      body: req.body,
      ContentType: req.headers['content-type'],
      Origin: req.headers['origin'],
    })
    if (X_AD_Token) {
      const decoded_X_AD_Token: JwtPayload | string | null = jwt.decode(
        X_AD_Token
      )
      if (decoded_X_AD_Token !== null) {
        const { name, roles } = decoded_X_AD_Token as {
          name: string
          roles: string[]
        }
        if (
          name === undefined ||
          name === null ||
          roles === undefined ||
          roles === null
        ) {
          return res
            .status(401)
            .send({ message: 'Access token is missing or invalid' })
        }

        res.locals.user = decoded_X_AD_Token
      } else {
        return res
          .status(403)
          .send({ message: 'Access token is missing or invalid' })
      }
      return next()
    } else {
      return res.status(403).send({ message: 'Forbidden' })
    }
  } catch (e) {
    throw { message: 'Internal error' }
  }
}
