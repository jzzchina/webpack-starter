import Joi from 'joi'
export const pick = (
  object: Record<string, Joi.ObjectSchema> | any,
  keys: string[]
): Record<string, any> =>
  keys.reduce((obj: any, key: string) => {
    if (object && Object.prototype.hasOwnProperty.call(object, key)) {
      obj[key] = object[key]
    }
    return obj
  }, {})
