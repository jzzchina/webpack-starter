export type deleteOperationPlanRequestBody = {
  personnelId: number
  projectId: number
  yearOfMonthDate: string
  operationPlanId: number
}

export type requestQueryOperationByProject = {
  limit: number
  offset: number
  project_id: number
  company_id: number
  from: string
  to: string
}

export type createOperationRequestBody = {
  personnelId: number
  manMonthNumber: number
  projectId: number
  roleId: number
  yearOfMonthDate: string
  hoursNumber: number
}
export type SearchOperationPlanQueryParams = {
  limit: number
  offset: number
  project_id?: number | null
  company_id?: number | null
  to: string
  from: string
}

export type OperationPlanListQueryParams = {
  month_of_year_date: string[]
  personnel_id: number[]
  project_id: number[]
}

export type OperationCostPlanTotal = Record<
  string,
  { hoursNumber: number; manMonthNumber: number }
>
