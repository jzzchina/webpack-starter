export type HeaderAuth = {
  authorization: string
  'x-ad-token': string
}
export type TimeStampCommonTypes = {
  createdBy: string
  createdAt: Date
  updatedBy: string
  updatedAt: Date
  processAt: Date
  processId: string
  deletedAt: Date
}
