export type OperationCostAmount = Record<
  string,
  { operationId: number; hoursNumber: number; costAmount: number }
>

export type OperationPlanManMonthNumber = Record<
  string,
  { hoursNumber: number; manMonthNumber: number }
>
