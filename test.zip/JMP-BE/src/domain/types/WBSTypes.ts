export enum wbsSubject {
  CAPEX,
  OPEX,
}
export interface WBSBySubject {
  [key: string]: string[]
}
