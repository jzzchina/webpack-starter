export type SearchOperationPlanQueryParams = {
  limit: number
  offset: number
  project_id: number | null
  company_id: number | null
  to: string
  from: string
}
