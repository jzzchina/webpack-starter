import { BusinessDaysObject } from '../../interface/routes/businessDays/dto/businessDays.dto'
import { OperationCostPlanTotal } from '../types/operationPlan.type'
import { PersonnelPrice } from './PersonnelPrice'

export type SkillList = Record<string, { level: number }>
export interface Personnel {
  companyId: number
  contractPatternCode: number
  companyName: string
  personnelId: number
  name: string
  nameJpn: string
  email: string
  registeredDate: Date
  unregisteredDate: Date | null
  skillList: SkillList
  prices?: PersonnelPrice[]
  operationCostPlans?: OperationCostPlanTotal
  businessDays: BusinessDaysObject
}
export type PersonnelList = {
  items: Partial<Personnel & { allAssignedProjects: string[] }>[]
}

export type PaginatedPersonnelList = PersonnelList & {
  offset: number
  length: number
  totalLength: number
}

export interface findAllPersonnelQuery {
  limit: number | undefined
  offset: number | undefined
  personnel_id: number | undefined
  name: string | undefined
  name_jpn: string | undefined
  project_id: number | undefined
  company_id: number | undefined
  search_name: string | undefined
  includeStatusClosed?: boolean
}

export interface PersonnelSearchCriteria extends findAllPersonnelQuery {
  skills: SkillList
}
