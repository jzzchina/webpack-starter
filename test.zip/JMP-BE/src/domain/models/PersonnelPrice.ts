export interface PersonnelPrice {
  personnelPriceId: number
  contractPatternCode: number | undefined
  priceStartDate: Date
  priceAmount: number
  currencyTypeCode: number
  personnelId: number | undefined
}
