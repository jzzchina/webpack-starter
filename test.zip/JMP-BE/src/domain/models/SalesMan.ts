import { TimeStampCommonTypes } from '../types/common.type'

export type SalesMan = TimeStampCommonTypes & {
  salesManId: number
  name: string
  emailAddress: string
  phoneNumber: string
}
