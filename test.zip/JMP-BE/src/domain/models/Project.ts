export interface Project {
  projectId: number
  projectName: string
  projectContact: string
  projectStartDate: Date
  projectEndDate: Date | null
  note: string
}

export interface ProjectSearchCriteria {
  project_id: number | null
  project_name: string
  company_id: number | null
  user_part: string
  project_manager: string
  status: number | null
  limit: number | null
  offset: number | null
  project_start_date: string
  project_end_date: string
  include_status_closed?: boolean
}
