import { wbsSubject } from '../types/WBSTypes'
import { TimeStampCommonTypes } from '../types/common.type'

export type WBS = TimeStampCommonTypes & {
  wbsId: number
  wbsCode: string
  wbsTitle: string
  subject: wbsSubject
  projectId: string
}
