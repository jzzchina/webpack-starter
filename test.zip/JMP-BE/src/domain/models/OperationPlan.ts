export type OperationPlan = {
  operation_plan_id: number
  personnel_id: number
  project_id: number
  month_of_year_date: string
  role_id: number
  man_month_number: number
  hours_number: number
  created_by: string
  create_at: string | null
  updated_by: string | null
  update_at: string | null
  process_at: string
  process_id: string | null
}
