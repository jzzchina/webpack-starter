export type Role = {
  role_id: number
  role_name: string
}
