export type Operation = {
  costAmount: number
  hoursNumber: number
  personnelId: number
  projectId: number
  yearOfMonthDate: Date
  createdBy: string
  createdAt: string
  updatedBy: string | null
  updateAt: string | null
  processAt: string | null
}
