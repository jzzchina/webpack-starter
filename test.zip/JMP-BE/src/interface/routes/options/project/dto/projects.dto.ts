import { WBS } from '../../../../../domain/models/WBS'

export interface CreateProjectDto {
  projectId: number | null
  projectName: string
  status: number
  projectStartDate: string
  projectEndDate: string | null
  projectManager: string
  projectContact: string
  projectContact2: string
  projectContact3: string
  projectContact4: string
  userPart: string
  note: string
  wbsCode: string
  wbsTitle: string
  wbsSubject: string | null
}
export interface Project {
  projectId: number | null
  projectName: string | null
  projectContact: string | null
  projectContact2: string | null
  projectContact3: string | null
  projectContact4: string | null
  projectStartDate: Date | null
  projectEndDate: Date | null
  notes?: string | null
  status?: number | null
  operation: boolean
  wbs: Partial<WBS>
}

export interface ProjectListResponse {
  offset: number
  length: number
  totalLength: number
  items?: Project[]
}
export interface ProjectDtoResponse extends CreateProjectDto {
  createdBy: string
  createdAt: string
  updatedBy: string | null
  updateAt: string | null
  processAt: string | null
  processId: string | null
}
