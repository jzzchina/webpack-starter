import { Router, Request, Response } from 'express'
import { ProjectRepositoryPort } from '../../../../application/port/repositories/project/ProjectRepositoryPort'
import { asyncWrapper } from '../../utils/util'
import { validate } from '../../../../middlewares/validators'
import { projectValidator } from '../../../../middlewares/validators/projectValidator'
import { verifyToken } from '../../../../middlewares/authentication/verifyToken'
import { createProjectsController } from '../../../controllers/options/project/createProjectsController'
import { WbsRepositoryPort } from '../../../../application/port/repositories/wbs/wbsRepositoryPort'

export const createProjects = (
  router: Router,
  repository: ProjectRepositoryPort,
  wbsRepository: WbsRepositoryPort
): void => {
  router.patch(
    '/projects',
    verifyToken,
    validate(projectValidator.createUpdateProjectsValidator),
    asyncWrapper(async (req: Request, res: Response) => {
      await createProjectsController(req, res, repository, wbsRepository)
    })
  )
}
