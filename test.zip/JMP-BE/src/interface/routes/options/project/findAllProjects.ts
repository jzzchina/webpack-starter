import { Request, Response, Router } from 'express'
import { asyncWrapper } from '../../utils/util'
import { verifyToken } from '../../../../middlewares/authentication/verifyToken'
import { findAllProjectsController } from '../../../controllers/options/project/findAllProjectsController'
import { ProjectRepositoryPort } from '../../../../application/port/repositories/project/ProjectRepositoryPort'
import { validate } from '../../../../middlewares/validators'
import { projectValidator } from '../../../../middlewares/validators/projectValidator'
import { OperationCostRepositoryPort } from '../../../../application/port/repositories/operationCost/OperationCostRepositoryPort'

export const findAllProjects = (
  router: Router,
  projectRepository: ProjectRepositoryPort,
  operationCostRepository: OperationCostRepositoryPort
): void => {
  router.get(
    '/projects',
    verifyToken,
    validate(projectValidator.getProjectsQueryValidator),
    asyncWrapper(async (_req: Request, res: Response) => {
      await findAllProjectsController(
        projectRepository,
        operationCostRepository,
        _req,
        res
      )
    })
  )
}
