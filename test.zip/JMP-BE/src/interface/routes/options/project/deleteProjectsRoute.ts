import { Request, Response, Router } from 'express'
import { ProjectRepositoryPort } from '../../../../application/port/repositories/project/ProjectRepositoryPort'
import { asyncWrapper } from '../../utils/util'
import { validate } from '../../../../middlewares/validators'
import { projectValidator } from '../../../../middlewares/validators/projectValidator'
import { deleteProjectsController } from '../../../controllers/options/project/deleteProjectsController'
import { verifyToken } from '../../../../middlewares/authentication/verifyToken'

export const deleteProjects = (
  router: Router,
  repository: ProjectRepositoryPort
): void => {
  router.delete(
    '/projects',
    verifyToken,
    validate(projectValidator.deleteQuery),
    asyncWrapper(async (req: Request, res: Response) => {
      await deleteProjectsController(req, res, repository)
    })
  )
}
