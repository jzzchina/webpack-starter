import { Router } from 'express'
import { asyncWrapper } from '../../utils/util'
import { verifyToken } from '../../../../middlewares/authentication/verifyToken'
import { findAllPersonnelController } from './../../../controllers/options/personnel/findAllPersonnelController'
import { PersonnelRepositoryPort } from './../../../../application/port/repositories/personnel/PersonnelRepositoryPort'
import { personnelValidation } from '../../../../middlewares/validators/personnelValidator'
import { validate } from '../../../../middlewares/validators'

export const findAllPersonnel = (
  router: Router,
  repository: PersonnelRepositoryPort
): void => {
  router.post(
    '/personnel',
    verifyToken,
    validate(personnelValidation.getAllPersonnel),
    asyncWrapper(async (req, res) => {
      await findAllPersonnelController(req, res, repository)
    })
  )
}
