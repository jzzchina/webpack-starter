import { SkillList } from '../../../../../domain/models/Personnel'
import { PersonnelPrice } from '../../../../../domain/models/PersonnelPrice'

export interface PersonnelBase {
  personnelId: number
  name: string
  nameJpn: string
  email: string
  registeredDate: string
  unregisteredDate: string
  companyId: number
  contractPatternCode: number
  companyName: string
  skillList: SkillList
  prices?: PersonnelPrice[]
}
export interface PersonnelListResponse {
  items: PersonnelBase[]
}
export type PersonnelCreateResponse = {
  personnelId: number
  name: string
  nameJpn: string
  email: string
  registeredDate: string
  unregisteredDate: string
  companyId: number
  skillList: SkillList
  companyName: string
  contractPatternCode: number
  prices?: PersonnelPrice[]
}

export interface Personnel {
  personnelId: number | null
  name: string | null
  nameJpn: string | null
  email: string | null
  registeredDate: string | null
  unregisteredDate: string | null
  companyId: number | null
  skillList: SkillList | null
}

export interface SearchExistenceOfOperationResponse {
  operationPlan: boolean
  operation: boolean
}
