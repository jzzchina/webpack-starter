import { Router } from 'express'

import { asyncWrapper } from '../../utils/util'
import { verifyToken } from '../../../../middlewares/authentication/verifyToken'
import { validate } from '../../../../middlewares/validators'
import { PersonnelRepositoryPort } from './../../../../application/port/repositories/personnel/PersonnelRepositoryPort'
import { deletePersonnelsController } from '../../../controllers/options/personnel/deletePersonnelsController'
import { personnelValidation } from '../../../../middlewares/validators/personnelValidator'

export const deletePersonnels = (
  router: Router,
  repository: PersonnelRepositoryPort
): void => {
  router.delete(
    '/personnel',
    verifyToken,
    validate(personnelValidation.deletePersonnels),
    asyncWrapper(async (req, res) => {
      await deletePersonnelsController(req, res, repository)
    })
  )
}
