import { Router } from 'express'
import { asyncWrapper } from '../../utils/util'
import { verifyToken } from '../../../../middlewares/authentication/verifyToken'
import { PersonnelRepositoryPort } from './../../../../application/port/repositories/personnel/PersonnelRepositoryPort'

import { personnelValidation } from '../../../../middlewares/validators/personnelValidator'
import { validate } from '../../../../middlewares/validators'
import { searchExistenceOfOperationController } from '../../../controllers/options/personnel/searchExistenceOfOperationController'
import { OperationPlanRepositoryPort } from '../../../../application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { OperationCostRepositoryPort } from '../../../../application/port/repositories/operationCost/OperationCostRepositoryPort'

export const searchExistenceOfOperation = (
  router: Router,
  personnelRepository: PersonnelRepositoryPort,
  operationPlanRepository: OperationPlanRepositoryPort,
  operationCostRepository: OperationCostRepositoryPort
): void => {
  router.get(
    '/personnel/:personnelId/search-existence-of-operation',
    verifyToken,
    validate(personnelValidation.searchExistenceOfOperation),
    asyncWrapper(async (req, res) => {
      await searchExistenceOfOperationController(
        req,
        res,
        personnelRepository,
        operationPlanRepository,
        operationCostRepository
      )
    })
  )
}
