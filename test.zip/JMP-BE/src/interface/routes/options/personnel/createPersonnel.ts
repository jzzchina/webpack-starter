import { Router } from 'express'

import { asyncWrapper } from '../../utils/util'
import { verifyToken } from '../../../../middlewares/authentication/verifyToken'
import { validate } from '../../../../middlewares/validators'
import { PersonnelRepositoryPort } from './../../../../application/port/repositories/personnel/PersonnelRepositoryPort'
import { createPersonnelController } from '../../../controllers/options/personnel/createPersonnelController'
import { personnelValidation } from '../../../../middlewares/validators/personnelValidator'

export const createPersonnel = (
  router: Router,
  repository: PersonnelRepositoryPort
): void => {
  router.patch(
    '/personnel',
    verifyToken,
    validate(personnelValidation.createPersonnel),
    asyncWrapper(async (req, res) => {
      await createPersonnelController(req, res, repository)
    })
  )
}
