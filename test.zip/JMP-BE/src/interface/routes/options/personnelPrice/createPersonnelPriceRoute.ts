import { Request, Response, Router } from 'express'
import { asyncWrapper } from '../../utils/util'
import { verifyToken } from '../../../../middlewares/authentication/verifyToken'
import { validate } from '../../../../middlewares/validators'
import { personnelPriceValidation } from '../../../../middlewares/validators/personnelPriceValidator'
import { createPersonnelPriceController } from '../../../controllers/options/personnelPrice/personnelPriceController'
import { PersonnelPriceRepositoryPort } from '../../../../application/port/repositories/personnelPriceRepositoryPort.ts/PersonnelPriceRepositoryPort'
import { OperationCostRepositoryPort } from '../../../../application/port/repositories/operationCost/OperationCostRepositoryPort'

export const createPersonnelPriceRoute = (
  router: Router,
  repository: PersonnelPriceRepositoryPort,
  operationCostRepository: OperationCostRepositoryPort
): void => {
  router.patch(
    '/personnel-prices',
    verifyToken,
    validate(personnelPriceValidation.createPersonnelPrice),
    asyncWrapper(async (req: Request, res: Response) => {
      await createPersonnelPriceController(
        req,
        res,
        repository,
        operationCostRepository
      )
    })
  )
}
