import { Request, Response, Router } from 'express'
import { asyncWrapper } from '../../utils/util'
import { verifyToken } from '../../../../middlewares/authentication/verifyToken'
import { validate } from '../../../../middlewares/validators'
import { personnelPriceValidation } from '../../../../middlewares/validators/personnelPriceValidator'
import { deletePersonnelPriceController } from '../../../controllers/options/personnelPrice/personnelPriceController'
import { PersonnelPriceRepositoryPort } from '../../../../application/port/repositories/personnelPriceRepositoryPort.ts/PersonnelPriceRepositoryPort'

export const deletePersonnelPriceRoute = (
  router: Router,
  repository: PersonnelPriceRepositoryPort
): void => {
  router.delete(
    '/personnel-prices/:personnelId/:priceStartDate',
    verifyToken,
    validate(personnelPriceValidation.deletePersonnelPrice),
    asyncWrapper(async (req: Request, res: Response) => {
      await deletePersonnelPriceController(req, res, repository)
    })
  )
}
