import { PersonnelPrice } from '../../../../../domain/models/PersonnelPrice'

export type PersonnelPriceList = {
  items: Partial<PersonnelPrice>[]
}
