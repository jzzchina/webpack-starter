import { Request, Response, Router } from 'express'
import { asyncWrapper } from '../../utils/util'
import { verifyToken } from '../../../../middlewares/authentication/verifyToken'
import { findByIdPersonnelController } from '../../../controllers/options/personnelPrice/personnelPriceController'
import { PersonnelPriceRepositoryPort } from '../../../../application/port/repositories/personnelPriceRepositoryPort.ts/PersonnelPriceRepositoryPort'
import { validate } from '../../../../middlewares/validators'
import { personnelPriceValidation } from '../../../../middlewares/validators/personnelPriceValidator'

export const findByPersonnelIDRoute = (
  router: Router,
  repository: PersonnelPriceRepositoryPort
): void => {
  router.get(
    '/personnel-prices',
    verifyToken,
    validate(personnelPriceValidation.findByPersonnelID),
    asyncWrapper(async (req: Request, res: Response) => {
      await findByIdPersonnelController(req, res, repository)
    })
  )
}
