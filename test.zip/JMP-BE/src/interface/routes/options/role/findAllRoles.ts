import { Request, Response, Router } from 'express'
import { asyncWrapper } from '../../utils/util'
import { verifyToken } from '../../../../middlewares/authentication/verifyToken'
import { RoleRepositoryPort } from '../../../../application/port/repositories/role/RoleRepositoryPort'
import { findAllRolesController } from '../../../controllers/options/role/findAllRolesController'
export const findAllRoles = (
  router: Router,
  repository: RoleRepositoryPort
): void => {
  router.get(
    '/roles',
    verifyToken,
    asyncWrapper(async (req: Request, res: Response) => {
      await findAllRolesController(req, res, repository)
    })
  )
}
