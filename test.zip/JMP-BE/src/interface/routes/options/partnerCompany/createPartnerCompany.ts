import { Request, Response, Router } from 'express'
import { asyncWrapper } from '../../utils/util'
import { verifyToken } from '../../../../middlewares/authentication/verifyToken'
import { validate } from '../../../../middlewares/validators'
import { partnerCompanyValidation } from './../../../../middlewares/validators/partnerCompanyValidator'
import { PartnerCompanyRepositoryPort } from './../../../../application/port/repositories/partnerCompany/PartnerCompanyRepositoryPort'
import { createPartnerCompanyController } from './../../../controllers/options/partnerCompany/createPartnerCompanyController'
import { SalesManRepositoryPort } from '../../../../application/port/repositories/salesMan/SalesManRepositoryPort'
export const createPartnerCompany = (
  router: Router,
  repository: PartnerCompanyRepositoryPort,
  salesManRepository: SalesManRepositoryPort
): void => {
  router.put(
    '/partner-companies',
    verifyToken,
    validate(partnerCompanyValidation.createPartnerCompany),
    asyncWrapper(async (req: Request, res: Response) => {
      await createPartnerCompanyController(
        req,
        res,
        repository,
        salesManRepository
      )
    })
  )
}
