import { Request, Response, Router } from 'express'
import { asyncWrapper } from '../../utils/util'
import { verifyToken } from '../../../../middlewares/authentication/verifyToken'
import { validate } from '../../../../middlewares/validators'
import { partnerCompanyValidation } from '../../../../middlewares/validators/partnerCompanyValidator'
import { PartnerCompanyRepositoryPort } from '../../../../application/port/repositories/partnerCompany/PartnerCompanyRepositoryPort'
import { deletePartnerCompaniesController } from '../../../controllers/options/partnerCompany/deletePartnerCompaniesController'
export const deletePartnerCompanies = (
  router: Router,
  repository: PartnerCompanyRepositoryPort
): void => {
  router.delete(
    '/partner-companies',
    verifyToken,
    validate(partnerCompanyValidation.deletePartnerCompanies),
    asyncWrapper(async (req: Request, res: Response) => {
      await deletePartnerCompaniesController(req, res, repository)
    })
  )
}
