import { SalesMan } from '../../../../../domain/models/SalesMan'

export type PartnerCompanyCreateResponse = {
  companyId: number
  contractPatternCode: number
  companyName: string
  createdBy: string
  salesMan: SalesMan[]
  createAt: Date | string
  updatedBy: string
  updateAt: Date | string
  processAt: Date | string
  processId: string
}
export interface PartnerCompany {
  companyId: number | null
  companyName: string | null
  contractPatternCode: number | null
  numberOfPersonnel: number
}
export interface PartnerCompanyBodyRequest extends PartnerCompany {
  salesMan: SalesMan[]
}
export interface PartnerCompanyListResponse {
  offset: number
  length: number
  totalLength: number
  items: PartnerCompany[]
}
