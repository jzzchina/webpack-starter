import { Request, Response, Router } from 'express'
import { asyncWrapper } from '../../utils/util'
import { verifyToken } from '../../../../middlewares/authentication/verifyToken'
import { PartnerCompanyRepositoryPort } from '../../../../application/port/repositories/partnerCompany/PartnerCompanyRepositoryPort'
import { findAllPartnerCompanyController } from '../../../controllers/options/partnerCompany/findAllPartnerCompanyController'
import { validate } from '../../../../middlewares/validators'
import { partnerCompanyValidation } from '../../../../middlewares/validators/partnerCompanyValidator'
export const findAllPartnerCompany = (
  router: Router,
  repository: PartnerCompanyRepositoryPort
): void => {
  router.get(
    '/partner-companies',
    verifyToken,
    validate(partnerCompanyValidation.getPartnerCompany),
    asyncWrapper(async (req: Request, res: Response) => {
      await findAllPartnerCompanyController(req, res, repository)
    })
  )
}
