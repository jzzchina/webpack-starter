import { Router } from 'express'
import { verifyToken } from '../../../middlewares/authentication/verifyToken'
import { asyncWrapper } from '../utils/util'
import { validate } from '../../../middlewares/validators/index'
import { operationCostValidation } from '../../../middlewares/validators/operationCostValidator'
import {
  operationCostsExportDataController,
  searchOperationCostsController,
  operationExportDataController,
} from '../../controllers/operationCost/searchOperationCostsController'
import { OperationCostRepositoryPort } from '../../../application/port/repositories/operationCost/OperationCostRepositoryPort'

export const searchOperationCosts = (
  router: Router,
  repository: OperationCostRepositoryPort
): void => {
  router.get(
    '/operation-costs',
    verifyToken,
    validate(operationCostValidation.getOperationCost),
    asyncWrapper(async (req, res) => {
      await searchOperationCostsController(req, res, repository)
    })
  )

  router.get(
    '/costs/export-data',
    verifyToken,
    validate(operationCostValidation.getOperationCost),
    asyncWrapper(async (req, res) => {
      await operationCostsExportDataController(req, res, repository)
    })
  )
  router.get(
    '/operation/export-data',
    verifyToken,
    validate(operationCostValidation.getOperationCost),
    asyncWrapper(async (req, res) => {
      await operationExportDataController(req, res, repository)
    })
  )
}
