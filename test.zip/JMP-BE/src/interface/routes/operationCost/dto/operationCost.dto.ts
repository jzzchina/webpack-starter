import { PersonnelPrice } from '../../../../domain/models/PersonnelPrice'
import { Project } from '../../../../domain/models/Project'
import {
  OperationCostAmount,
  OperationPlanManMonthNumber,
} from '../../../../domain/types/operation.type'
import { BusinessDaysObject } from '../../businessDays/dto/businessDays.dto'

export interface CreateOperationCostDto {
  operationId: number
  hoursNumber: number
  personnelId: number
  projectId: number
  yearOfMonthDate: string
  costAmount: number
}
export type OperationCostKeys = {
  personnelId: number
  projectId: number
  yearOfMonthDate: Date
}
export type DeleteOperationCostSQLRequest = {
  ProjectIds: number[]
  PersonnelIds: number[]
  YearOfMonths: string[]
}

export interface CreateOperationCostResponse extends CreateOperationCostDto {
  createdBy: string | null
  createdAt: Date | null
  updatedBy: string | null
  updateAt: string | null
  processAt: string | null
  processId: string | null
}
export interface DeleteOperationCostDto {
  personnelId: number
  projectId: number
  yearOfMonthDate: Date
}
export type PersonnelOperationCost = {
  companyId: number
  contractPatternCode: number
  companyName: string
  personnelId: number
  name: string
  nameJpn: string
  registeredDate: Date
  unregisteredDate: Date | null
  prices: PersonnelPrice[]
  operationPlans: OperationPlanManMonthNumber
  operations: OperationCostAmount
  businessDays: BusinessDaysObject
}

export interface ProjectOperationCost extends Project {
  personnel: PersonnelOperationCost[]
}

export interface OperationCostListRequest {
  offset: number
  limit: number
  from?: string
  to?: string
  project_id: number | null
  company_id: number | null
}

export interface OperationCostListResponse {
  from: string
  to: string
  offset: number
  length: number
  totalLength: number
  items: ProjectOperationCost[]
}
