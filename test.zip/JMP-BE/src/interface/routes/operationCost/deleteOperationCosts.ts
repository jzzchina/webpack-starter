import { Router } from 'express'
import { asyncWrapper } from '../utils/util'
import { verifyToken } from '../../../middlewares/authentication/verifyToken'
import { validate } from '../../../middlewares/validators/index'
import { operationCostValidation } from '../../../middlewares/validators/operationCostValidator'
import { OperationCostRepositoryPort } from '../../../application/port/repositories/operationCost/OperationCostRepositoryPort'
import { deleteOperationCostsController } from '../../controllers/operationCost/deleteOperationCostsController'
export const deleteOperationCosts = (
  router: Router,
  repository: OperationCostRepositoryPort
): void => {
  router.delete(
    '/operation-costs',
    verifyToken,
    validate(operationCostValidation.deleteOperationCost),
    asyncWrapper(async (req, res) => {
      await deleteOperationCostsController(req, res, repository)
    })
  )
}
