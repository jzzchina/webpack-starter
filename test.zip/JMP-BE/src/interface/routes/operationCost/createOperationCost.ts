import { asyncWrapper } from '../utils/util'
import { Request, Response, Router } from 'express'
import { createOperationCostController } from '../../controllers/operationCost/createOperationCostController'
import { OperationCostRepositoryPort } from '../../../application/port/repositories/operationCost/OperationCostRepositoryPort'
import { verifyToken } from '../../../middlewares/authentication/verifyToken'
import { validate } from '../../../middlewares/validators'
import { operationCostValidation } from '../../../middlewares/validators/operationCostValidator'

export const createOperationCost = (
  router: Router,
  repository: OperationCostRepositoryPort
): void => {
  router.patch(
    '/operation-costs',
    verifyToken,
    validate(operationCostValidation.createOperationCost),
    asyncWrapper(async (req: Request, res: Response) => {
      await createOperationCostController(req, res, repository)
    })
  )
}
