import { Router } from 'express'
import { verifyToken } from '../../../middlewares/authentication/verifyToken'
import { asyncWrapper } from '../utils/util'
import { validate } from '../../../middlewares/validators/index'
import {
  exportDataSearchWbsCostsController,
  searchWbsCostsController,
} from '../../controllers/wbs/searchWbsCostsController'
import { WbsRepositoryPort } from '../../../application/port/repositories/wbs/wbsRepositoryPort'
import { wbsValidation } from '../../../middlewares/validators/wbsValidator'

export const searchWbsCosts = (
  router: Router,
  repository: WbsRepositoryPort
): void => {
  router.get(
    '/wbs-costs',
    verifyToken,
    validate(wbsValidation.getWbsCosts),
    asyncWrapper(async (req, res) => {
      await searchWbsCostsController(req, res, repository)
    })
  )
  router.get(
    '/wbs-costs/export-data',
    verifyToken,
    validate(wbsValidation.getWbsCosts),
    asyncWrapper(async (req, res) => {
      await exportDataSearchWbsCostsController(req, res, repository)
    })
  )
}
