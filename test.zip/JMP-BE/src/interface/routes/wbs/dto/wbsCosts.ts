import {
  ListRequestBase,
  ListResponseBase,
} from '../../../../infrastructure/repositories/common/interface'

export interface WbsCostListRequest extends ListRequestBase {
  company_id: number
}

export interface WbsPeriodItem {
  wbsCode: string
  wbsTitle: string
  subject: string
  projectName: string
  amount: number
  currency_type_code: number
}

export interface WbsTotalItem {
  currency_type_code: number
  amount: number
}

export type WbsTotal = Array<WbsTotalItem>

export interface WbsPeriodData {
  month: string
  total: WbsTotal
  wbs: WbsPeriodItem[]
}

export interface WbsCostListResponse extends ListResponseBase {
  from: string
  to: string
  companyId: number
  companyName: string
  items: WbsPeriodData[]
}

export interface WBSAggregatedData {
  currency_type_code: number
  amountBeforeTaxTotal: string
  amountAfterTaxTotal: string
  [key: string]: string | number
}
