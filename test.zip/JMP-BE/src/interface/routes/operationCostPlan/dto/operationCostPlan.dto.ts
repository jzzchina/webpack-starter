import { Personnel } from '../../../../domain/models/Personnel'
import { OperationCostPlanTotal } from '../../../../domain/types/operationPlan.type'

export interface OperationCostPlanProject {
  projectId: number
  projectName: string
  projectContact: string
  projectStartDate: Date
  projectEndDate: Date | null
  note: string
  operationCostPlans?: OperationCostPlanTotal
  personnel?: Personnel[]
}
export interface OperationCostPlanProjectListResponse {
  from: string
  to: string
  offset: number
  length: number
  totalLength: number
  items: OperationCostPlanProject[]
}
