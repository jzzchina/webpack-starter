import { Request, Response, Router } from 'express'

import { verifyToken } from '../../../middlewares/authentication/verifyToken'
import { asyncWrapper } from '../utils/util'
import { validate } from './../../../middlewares/validators/index'
import { operationCostPlanValidation } from './../../../middlewares/validators/operationCostPlanValidator'
import {
  operationCostPlanByProjectsExportDataController,
  searchOperationCostPlanByProjectsController,
} from './../../controllers/operationCostPlan/searchOperationCostPlanByProjectController'
import { OperationCostPlanRepositoryPort } from './../../../application/port/repositories/operationCostPlan/OperationCostPlanRepositoryPort'

export const searchOperationCostPlansByProjects = (
  router: Router,
  repository: OperationCostPlanRepositoryPort
): void => {
  router.get(
    '/operation-cost-plans/projects',
    verifyToken,
    validate(operationCostPlanValidation.getOperationCostPlansByProject),
    asyncWrapper(async (req: Request, res: Response) => {
      await searchOperationCostPlanByProjectsController(req, res, repository)
    })
  )
  router.get(
    '/operation-cost-plans/projects/export-data',
    verifyToken,
    validate(operationCostPlanValidation.getOperationCostPlansByProject),
    asyncWrapper(async (req: Request, res: Response) => {
      await operationCostPlanByProjectsExportDataController(
        req,
        res,
        repository
      )
    })
  )
}
