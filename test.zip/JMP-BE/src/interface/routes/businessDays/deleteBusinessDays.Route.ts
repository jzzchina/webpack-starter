import { Request, Response, Router } from 'express'

import { BusinessDaysRepositoryPort } from '../../../application/port/repositories/businessDays/BusinessDaysRepositoryPort'
import { verifyToken } from '../../../middlewares/authentication/verifyToken'
import { validate } from '../../../middlewares/validators'
import { businessDaysValidation } from '../../../middlewares/validators/businessDaysValidation'
import { deleteBusinessDaysController } from '../../controllers/businessDays/deleteBusinessDaysController'
import { asyncWrapper } from '../utils/util'

export const deleteBusinessDaysRoute = (
  router: Router,
  repository: BusinessDaysRepositoryPort
): void => {
  router.delete(
    '/business-days/:companyId/:monthOfYearDate',
    verifyToken,
    validate(businessDaysValidation.deleteBusinessDays),
    asyncWrapper(async (req: Request, res: Response) => {
      await deleteBusinessDaysController(req, res, repository)
    })
  )
}
