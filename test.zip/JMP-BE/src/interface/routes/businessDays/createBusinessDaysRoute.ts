import { Router } from 'express'
import { BusinessDaysRepositoryPort } from '../../../application/port/repositories/businessDays/BusinessDaysRepositoryPort'
import { verifyToken } from '../../../middlewares/authentication/verifyToken'
import { createBusinessDaysController } from '../../controllers/businessDays/createBusinessDaysController'
import { validate } from '../../../middlewares/validators'
import { asyncWrapper } from '../utils/util'
import { businessDaysValidation } from '../../../middlewares/validators/businessDaysValidation'

export const createBusinessDaysRoute = (
  router: Router,
  repository: BusinessDaysRepositoryPort
): void => {
  router.patch(
    '/business-days',
    verifyToken,
    validate(businessDaysValidation.create),
    asyncWrapper(async (req, res) => {
      await createBusinessDaysController(req, res, repository)
    })
  )
}
