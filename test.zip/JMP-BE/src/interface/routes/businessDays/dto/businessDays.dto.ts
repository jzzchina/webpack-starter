export interface BusinessListResponse {
  items: BusinessDaysList
}
export type BusinessDaysObject = {
  [key: string]: {
    businessDaysNumber: number
  }
}
export interface BusinessDays {
  businessDaysId: number
  companyId: number
  monthOfYearDate: Date
  businessDaysNumber: number
  createdBy: string
  createdAt: string
  updatedBy: string | null
  updateAt: string | null
  processAt: string | null
}

export type BusinessDaysList = Partial<BusinessDays>[]
