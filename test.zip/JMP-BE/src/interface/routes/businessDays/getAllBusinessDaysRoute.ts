import { Request, Response, Router } from 'express'
import { BusinessDaysRepositoryPort } from '../../../application/port/repositories/businessDays/BusinessDaysRepositoryPort'
import { verifyToken } from '../../../middlewares/authentication/verifyToken'
import { findAllBusinessDaysController } from '../../controllers/businessDays/findAllBusinessDaysController'
import { validate } from '../../../middlewares/validators'
import { asyncWrapper } from '../utils/util'
import { businessDaysValidation } from '../../../middlewares/validators/businessDaysValidation'
export const getAllBusinessDaysRoute = (
  router: Router,
  repository: BusinessDaysRepositoryPort
): void => {
  router.get(
    '/business-days',
    verifyToken,
    validate(businessDaysValidation.getAll),
    asyncWrapper(async (req: Request, res: Response) => {
      await findAllBusinessDaysController(req, res, repository)
    })
  )
}
