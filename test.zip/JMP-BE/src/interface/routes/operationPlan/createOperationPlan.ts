import { createOperationPlanController } from './../../controllers/operationPlan/createOperationPlanController'
import { OperationPlanRepositoryPort } from '../../../application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { Request, Response, Router } from 'express'
import { validate } from '../../../middlewares/validators'
import { operationPlanValidation } from '../../../middlewares/validators/operationPlanValidator'
import { verifyToken } from '../../../middlewares/authentication/verifyToken'
import { asyncWrapper } from '../utils/util'

export default (
  router: Router,
  operationPlanRepository: OperationPlanRepositoryPort
): void => {
  router.patch(
    '/operation-plans',
    verifyToken,
    validate(operationPlanValidation.createOperationPlans),
    asyncWrapper(async (req: Request, res: Response) => {
      await createOperationPlanController(req, res, operationPlanRepository)
    })
  )
}
