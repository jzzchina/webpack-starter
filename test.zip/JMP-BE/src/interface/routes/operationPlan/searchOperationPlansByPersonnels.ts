import { Router } from 'express'

import { OperationPlanRepositoryPort } from '../../../application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { asyncWrapper } from '../utils/util'
import { validate } from '../../../middlewares/validators'
import { operationPlanValidation } from '../../../middlewares/validators/operationPlanValidator'
import { verifyToken } from '../../../middlewares/authentication/verifyToken'
import {
  exportDataOperationPlanByPersonnelsController,
  searchOperationPlanByPersonnelsController,
} from '../../controllers/operationPlan/searchOperationPlanByPersonnelsController'

export const searchOperationPlansByPersonnels = (
  router: Router,
  repository: OperationPlanRepositoryPort
): void => {
  router.post(
    '/operation-plans/personnel',
    verifyToken,
    validate(operationPlanValidation.getOperationPlansByPersonnel),
    asyncWrapper(async (req, res) => {
      await searchOperationPlanByPersonnelsController(req, res, repository)
    })
  )

  router.post(
    '/operation-plans/personnel/export-data',
    verifyToken,
    validate(operationPlanValidation.getOperationPlansByPersonnel),
    asyncWrapper(async (req, res) => {
      await exportDataOperationPlanByPersonnelsController(req, res, repository)
    })
  )
}
