import { Request, Response, Router } from 'express'

import { asyncWrapper } from '../utils/util'
import { validate } from '../../../middlewares/validators'
import { operationPlanValidation } from '../../../middlewares/validators/operationPlanValidator'
import { verifyToken } from '../../../middlewares/authentication/verifyToken'
import { searchOperationPlanByProjectsController } from '../../controllers/operationPlan/searchOperationPlanByProjectsController'
import { OperationPlanRepositoryPort } from '../../../application/port/repositories/operationPlan/OperationPlanRepositoryPort'

export const searchOperationPlansByProjects = (
  router: Router,
  repository: OperationPlanRepositoryPort
): void => {
  router.post(
    '/operation-plans/projects',
    verifyToken,
    validate(operationPlanValidation.getOperationPlansByProject),
    asyncWrapper(async (req: Request, res: Response) => {
      await searchOperationPlanByProjectsController(req, res, repository)
    })
  )
}
