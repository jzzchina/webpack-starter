export interface CreateOperationPlanDto {
  operationPlanId: number
  manMonthNumber: number
  personnelId: number
  projectId: number
  roleId: number
  yearOfMonthDate: string
  hoursNumber: number
}
export interface CreateOperationPlanResponse extends CreateOperationPlanDto {
  costAmount: number
  createdBy: string | null
  createdAt: string | null
  updatedBy: string | null
  updateAt: string | null
  processAt: string | null
  processId: string | null
}
