export interface OperationPlanPK {
  operationPlanId: number
  personnelId: number
  projectId: number
  yearOfMonthDate: string
}
