import { OperationPlanRepositoryPort } from '../../../application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { asyncWrapper } from '../utils/util'
import { Router } from 'express'
import { validate } from '../../../middlewares/validators'
import { operationPlanValidation } from '../../../middlewares/validators/operationPlanValidator'
import { verifyToken } from '../../../middlewares/authentication/verifyToken'
import { deleteMultiOperationPlanController } from '../../controllers/operationPlan/deleteMultiOperationPlanController'
import { OperationCostRepositoryPort } from '../../../application/port/repositories/operationCost/OperationCostRepositoryPort'
export const deleteMultiOperationPlan = (
  router: Router,
  operationPlanRepository: OperationPlanRepositoryPort,
  operationRepository: Pick<
    OperationCostRepositoryPort,
    'findOperationBelongsToOperationPlan'
  >
): void => {
  router.post(
    '/operation-plans',
    verifyToken,
    validate(operationPlanValidation.deleteOperationPlans),
    asyncWrapper(async (req, res) => {
      await deleteMultiOperationPlanController(
        req,
        res,
        operationPlanRepository,
        operationRepository
      )
    })
  )
}
