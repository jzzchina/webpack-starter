import { searchOperationCostsUseCase } from '../../../application/use_cases/operationCost/searchOperationCostsUseCase'
import { OperationCostRepositoryPort } from '../../../application/port/repositories/operationCost/OperationCostRepositoryPort'
import {
  OperationCostListRequest,
  OperationCostListResponse,
} from '../../routes/operationCost/dto/operationCost.dto'
import { Request, Response } from 'express'
import { exportDataOperationCostUseCase } from '../../../application/use_cases/operationCost/exportDataOperationCostsUseCase'
import { exportDataOperationUseCase } from '../../../application/use_cases/operationCost/exportDataOperationUseCase'

export const searchOperationCostsController = async (
  req: Request,
  res: Response,
  services: Pick<OperationCostRepositoryPort, 'searchOperationCosts'>
): Promise<Response<OperationCostListResponse>> => {
  const {
    project_id,
    company_id,
    to,
    from,
    offset,
    limit,
  } = (req.query as unknown) as OperationCostListRequest
  const result = await searchOperationCostsUseCase(
    limit,
    offset,
    from ?? '',
    to ?? '',
    project_id,
    company_id,
    services
  )

  return res.status(200).send(result)
}

export const operationCostsExportDataController = async (
  req: Request,
  res: Response,
  services: Pick<OperationCostRepositoryPort, 'searchOperationCosts'>
): Promise<Response<OperationCostListResponse>> => {
  const {
    project_id,
    company_id,
    to,
    from,
    offset,
    limit,
  } = (req.query as unknown) as OperationCostListRequest
  const result = await searchOperationCostsUseCase(
    limit,
    offset,
    from ?? '',
    to ?? '',
    project_id,
    company_id,
    services
  )

  const downloadLink = await exportDataOperationCostUseCase(result)
  return res.status(200).send({ downloadLink })
}

export const operationExportDataController = async (
  req: Request,
  res: Response,
  services: Pick<OperationCostRepositoryPort, 'searchOperationCosts'>
): Promise<Response<OperationCostListResponse>> => {
  const {
    project_id,
    company_id,
    to,
    from,
    offset,
    limit,
  } = (req.query as unknown) as OperationCostListRequest
  const operationResult = await searchOperationCostsUseCase(
    limit,
    offset,
    from ?? '',
    to ?? '',
    project_id,
    company_id,
    services
  )
  const downloadLink = await exportDataOperationUseCase(
    from,
    to,
    operationResult
  )
  return res.status(200).send({ downloadLink })
}
