import { createOperationCostUseCase } from '../../../application/use_cases/operationCost/createOperationCostUseCase'
import { OperationCostRepositoryPort } from '../../../application/port/repositories/operationCost/OperationCostRepositoryPort'
import {
  CreateOperationCostDto,
  CreateOperationCostResponse,
} from '../../routes/operationCost/dto/operationCost.dto'
import { Request, Response } from 'express'

export const createOperationCostController = async (
  req: Request,
  res: Response,
  services: Pick<OperationCostRepositoryPort, 'create' | 'findMany'>
): Promise<Response<CreateOperationCostResponse[]>> => {
  const userInformation: Record<string, unknown> = res.locals.user
  const operationInput: CreateOperationCostDto[] = req.body
  const result: CreateOperationCostResponse[] = await createOperationCostUseCase(
    operationInput,
    userInformation,
    services
  )

  return res.status(200).send(result)
}
