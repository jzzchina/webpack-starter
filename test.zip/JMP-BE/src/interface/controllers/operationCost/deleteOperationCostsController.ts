import { deleteOperationCostsUseCase } from '../../../application/use_cases/operationCost/deleteOperationCostsUseCase'
import { OperationCostRepositoryPort } from '../../../application/port/repositories/operationCost/OperationCostRepositoryPort'
import { DeleteOperationCostDto } from '../../routes/operationCost/dto/operationCost.dto'
import { Request, Response } from 'express'

export const deleteOperationCostsController = async (
  req: Request,
  res: Response,
  services: Pick<
    OperationCostRepositoryPort,
    'deleteOperationCosts' | 'findMany'
  >
): Promise<Response<void>> => {
  const deleteOperationInput: DeleteOperationCostDto[] = req.body
  await deleteOperationCostsUseCase(deleteOperationInput, services)

  return res.status(200).send({ message: 'Records deleted successfully' })
}
