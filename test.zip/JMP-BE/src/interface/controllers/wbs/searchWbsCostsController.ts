import { WbsRepositoryPort } from '../../../application/port/repositories/wbs/wbsRepositoryPort'
import { exportDataSearchWbsCostsUseCase } from '../../../application/use_cases/wbs/exportDataSearchWbsCostsUseCase'
import { searchWbsCostsUseCase } from '../../../application/use_cases/wbs/searchWbsCostsUseCase'
import {
  WbsCostListRequest,
  WbsCostListResponse,
} from '../../routes/wbs/dto/wbsCosts'
import { Request, Response } from 'express'

export const searchWbsCostsController = async (
  req: Request,
  res: Response,
  services: Pick<WbsRepositoryPort, 'searchWbsCosts'>
): Promise<Response<WbsCostListResponse>> => {
  const {
    company_id,
    to,
    from,
    offset,
    limit,
  } = (req.query as unknown) as WbsCostListRequest

  const wbsCosts = await searchWbsCostsUseCase(
    limit,
    offset,
    from ?? '',
    to ?? '',
    company_id,
    services
  )

  return res.status(200).send(wbsCosts)
}
export const exportDataSearchWbsCostsController = async (
  req: Request,
  res: Response,
  services: Pick<WbsRepositoryPort, 'searchWbsCosts'>
): Promise<Response<WbsCostListResponse>> => {
  const {
    company_id,
    to,
    from,
    offset,
    limit,
  } = (req.query as unknown) as WbsCostListRequest

  const wbsCosts = await searchWbsCostsUseCase(
    limit,
    offset,
    from ?? '',
    to ?? '',
    company_id,
    services
  )
  const downloadLink = await exportDataSearchWbsCostsUseCase(wbsCosts)
  return res.status(200).send({ downloadLink })
}
