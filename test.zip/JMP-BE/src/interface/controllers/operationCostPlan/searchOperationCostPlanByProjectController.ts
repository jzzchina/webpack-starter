import { Request, Response } from 'express'
import { OperationCostPlanRepositoryPort } from './../../../application/port/repositories/operationCostPlan/OperationCostPlanRepositoryPort'
import { searchOperationCostPlanByProjectsUseCase } from './../../../application/use_cases/operationCostPlan/searchOperationCostPlanByProjectUseCase'
import { OperationCostPlanProjectListRequest } from '../../../infrastructure/repositories/operationCostPlan/interface'
import { OperationCostPlanProjectListResponse } from '../../routes/operationCostPlan/dto/operationCostPlan.dto'
import { exportDataOperationCostPlanByProjectsUseCase } from '../../../application/use_cases/operationCostPlan/exportDataOperationCostPlanByProjectsUseCase'

export const searchOperationCostPlanByProjectsController = async (
  req: Request,
  res: Response,
  services: Pick<
    OperationCostPlanRepositoryPort,
    'searchOperationCostPlansByProject'
  >
): Promise<Response<OperationCostPlanProjectListResponse>> => {
  const {
    project_id,
    company_id,
    from,
    to,
    offset,
    limit,
  } = (req.query as unknown) as OperationCostPlanProjectListRequest

  const operationCostPlan = await searchOperationCostPlanByProjectsUseCase(
    limit,
    offset,
    from ?? '',
    to ?? '',
    project_id,
    company_id,
    services
  )

  return res.status(200).send(operationCostPlan)
}

export const operationCostPlanByProjectsExportDataController = async (
  req: Request,
  res: Response,
  services: Pick<
    OperationCostPlanRepositoryPort,
    'searchOperationCostPlansByProject'
  >
): Promise<Response<OperationCostPlanProjectListResponse>> => {
  const {
    project_id,
    company_id,
    from,
    to,
    offset,
    limit,
  } = (req.query as unknown) as OperationCostPlanProjectListRequest

  const operationCostPlan = await searchOperationCostPlanByProjectsUseCase(
    limit,
    offset,
    from ?? '',
    to ?? '',
    project_id,
    company_id,
    services
  )
  const downloadLink = await exportDataOperationCostPlanByProjectsUseCase(
    operationCostPlan
  )
  return res.status(200).send({ downloadLink })
}
