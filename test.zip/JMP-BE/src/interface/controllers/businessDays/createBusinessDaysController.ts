import { Request, Response } from 'express'
import { BusinessDaysRepositoryPort } from '../../../application/port/repositories/businessDays/BusinessDaysRepositoryPort'
import { createBusinessDaysUseCase } from '../../../application/use_cases/businessDays/createBusinessDaysUseCase'
import { BusinessDaysList } from '../../routes/businessDays/dto/businessDays.dto'

export const createBusinessDaysController = async (
  req: Request,
  res: Response,
  repository: Pick<BusinessDaysRepositoryPort, 'create' | 'findMany'>
): Promise<Response<BusinessDaysList>> => {
  const { name: nameOfUser } = res.locals.user
  const businessDays: BusinessDaysList = req.body
  const businessDaysResult = await createBusinessDaysUseCase(
    businessDays,
    nameOfUser,
    repository
  )
  return res.status(200).json(businessDaysResult)
}
