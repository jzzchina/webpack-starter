import { Request, Response } from 'express'
import { BusinessDaysRepositoryPort } from '../../../application/port/repositories/businessDays/BusinessDaysRepositoryPort'
import { findAllBusinessDaysUseCase } from '../../../application/use_cases/businessDays/findAllBusinessDaysUseCase'
import { BusinessListResponse } from '../../routes/businessDays/dto/businessDays.dto'

export const findAllBusinessDaysController = async (
  req: Request,
  res: Response,
  repository: Pick<BusinessDaysRepositoryPort, 'findAll'>
): Promise<Response<BusinessListResponse>> => {
  const { company_id } = req.query
  const companyID = parseInt(company_id as string)
  const listBusinessDays = await findAllBusinessDaysUseCase(
    companyID,
    repository
  )

  return res.status(200).json(listBusinessDays)
}
