import { Request, Response } from 'express'
import { BusinessDaysRepositoryPort } from '../../../application/port/repositories/businessDays/BusinessDaysRepositoryPort'
import { deleteBusinessDaysUseCase } from '../../../application/use_cases/businessDays/deleteBusinessDaysUseCase'

export const deleteBusinessDaysController = async (
  req: Request,
  res: Response,
  businessDaysService: Pick<BusinessDaysRepositoryPort, 'delete'>
): Promise<Response<void>> => {
  const { companyId, monthOfYearDate } = req.params
  await deleteBusinessDaysUseCase(
    Number(companyId),
    monthOfYearDate,
    businessDaysService
  )
  return res.status(200).json({ message: 'Records deleted successfully' })
}
