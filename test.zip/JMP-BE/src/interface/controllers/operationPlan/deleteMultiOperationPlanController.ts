import { deleteMultiOperationPlanUseCase } from '../../../application/use_cases/operationPlan/deleteMultiOperationPlanUseCase'
import { OperationPlan } from '../../../domain/models/OperationPlan'

import { Request, Response } from 'express'
import { OperationPlanRepositoryPort } from '../../../application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { OperationCostRepositoryPort } from '../../../application/port/repositories/operationCost/OperationCostRepositoryPort'

export const deleteMultiOperationPlanController = async (
  req: Request,
  res: Response,
  operationPlanRepository: OperationPlanRepositoryPort,
  operationRepository: Pick<
    OperationCostRepositoryPort,
    'findOperationBelongsToOperationPlan'
  >
): Promise<Response<void>> => {
  const deleteOperationPlanInput: Partial<OperationPlan>[] = req.body.map(
    (pk: any) => ({
      operation_plan_id: pk.operationPlanId,
      personnel_id: pk.personnelId,
      project_id: pk.projectId,
      month_of_year_date: pk.yearOfMonthDate,
    })
  )
  await deleteMultiOperationPlanUseCase(
    deleteOperationPlanInput,
    operationPlanRepository,
    operationRepository
  )
  return res.status(200).send({ message: 'Records deleted successfully' })
}
