import { Request, Response } from 'express'
import { createOperationPlanUseCase } from './../../../application/use_cases/operationPlan/createOperationPlanUseCase'
import { OperationPlanRepositoryPort } from '../../../application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import {
  CreateOperationPlanDto,
  CreateOperationPlanResponse,
} from '../../routes/operationPlan/dto/operationPlans.dto'

export const createOperationPlanController = async (
  req: Request,
  res: Response,
  servicesOpPlan: Pick<
    OperationPlanRepositoryPort,
    'create' | 'findMany' | 'findAllOperationPlansByPersonnelId'
  >
): Promise<Response<CreateOperationPlanResponse>> => {
  const userInformation: Record<string, unknown> = res.locals.user
  const arrayBody: CreateOperationPlanDto[] = req.body
  const result: CreateOperationPlanResponse[] = await createOperationPlanUseCase(
    arrayBody,
    servicesOpPlan,
    userInformation
  )
  return res.status(200).send(result)
}
