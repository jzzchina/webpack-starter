import { Request, Response } from 'express'
import { OperationPlanRepositoryPort } from '../../../application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { searchOperationPlanByPersonnelsUseCase } from '../../../application/use_cases/operationPlan/searchOperationPlanByPersonnelsUseCase'
import { SkillList } from '../../../domain/models/Personnel'
import { OperationPlanPersonnelResponse } from '../../../infrastructure/repositories/operationPlan/interface'
import { SearchOperationPlanQueryParams } from '../../../domain/types/operationPlan.types'
import { exportDataOperationPlanByPersonnelsUseCase } from '../../../application/use_cases/operationPlan/exportDataOperationPlanByPersonnelsUseCase'

export const searchOperationPlanByPersonnelsController = async (
  req: Request,
  res: Response,
  services: Pick<OperationPlanRepositoryPort, 'findOperationPlansByPersonnel'>
): Promise<Response<OperationPlanPersonnelResponse>> => {
  const {
    project_id,
    company_id,
    to,
    from,
    offset,
    limit,
  } = (req.query as unknown) as SearchOperationPlanQueryParams
  const skills: SkillList = req.body?.skills ?? {}
  const searchOperationPlans = await searchOperationPlanByPersonnelsUseCase(
    to,
    from,
    offset,
    limit,
    project_id,
    company_id,
    skills,
    services
  )
  return res.status(200).json(searchOperationPlans)
}

export const exportDataOperationPlanByPersonnelsController = async (
  req: Request,
  res: Response,
  services: Pick<OperationPlanRepositoryPort, 'findOperationPlansByPersonnel'>
): Promise<Response<OperationPlanPersonnelResponse>> => {
  const {
    project_id,
    company_id,
    to,
    from,
    offset,
    limit,
  } = (req.query as unknown) as SearchOperationPlanQueryParams
  const skills: SkillList = req.body?.skills ?? {}
  const searchOperationPlans = await searchOperationPlanByPersonnelsUseCase(
    to,
    from,
    offset,
    limit,
    project_id,
    company_id,
    skills,
    services
  )

  const downloadLink = await exportDataOperationPlanByPersonnelsUseCase(
    searchOperationPlans
  )
  return res.status(200).send({ downloadLink })
}
