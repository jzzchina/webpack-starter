import { Request, Response } from 'express'
import { OperationPlanRepositoryPort } from '../../../application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { searchOperationPlanByProjectsUseCase } from '../../../application/use_cases/operationPlan/searchOperationPlanByProjectsUseCase'
import { SkillList } from '../../../domain/models/Personnel'
import { OperationPlanProjectResponse } from './../../../infrastructure/repositories/operationPlan/interface'
import { SearchOperationPlanQueryParams } from '../../../domain/types/operationPlan.type'

export const searchOperationPlanByProjectsController = async (
  req: Request,
  res: Response,
  services: Pick<OperationPlanRepositoryPort, 'findOperationPlansByProject'>
): Promise<Response<OperationPlanProjectResponse>> => {
  const {
    project_id,
    company_id,
    to,
    from,
    offset,
    limit,
  } = (req.query as unknown) as SearchOperationPlanQueryParams
  const skills: SkillList = req.body?.skills ?? {}

  const operationPlans = await searchOperationPlanByProjectsUseCase(
    to,
    from,
    offset,
    limit,
    Number(project_id),
    Number(company_id),
    skills,
    services
  )
  return res.status(200).json(operationPlans)
}
