import { PersonnelRepositoryPort } from './../../../../application/port/repositories/personnel/PersonnelRepositoryPort'
import { deletePersonnelsUseCase } from '../../../../application/use_cases/options/personnel/deletePersonnelsUseCase'
import { Request, Response } from 'express'

export const deletePersonnelsController = async (
  req: Request,
  res: Response,
  services: Pick<
    PersonnelRepositoryPort,
    'deletePersonnels' | 'findPersonnelByAssignment'
  >
): Promise<void> => {
  const { personnel_id }: any = req.query
  await deletePersonnelsUseCase(personnel_id, services)

  return res.status(200).send({ message: 'Records deleted successfully' }).end()
}
