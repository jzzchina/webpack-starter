import { PersonnelRepositoryPort } from '../../../../application/port/repositories/personnel/PersonnelRepositoryPort'
import { searchExistenceOfOperationUseCase } from '../../../../application/use_cases/options/personnel/searchExistenceOfOperationUseCase'
import { SearchExistenceOfOperationResponse } from '../../../routes/options/personnel/dto/personnel.dto'
import { OperationPlanRepositoryPort } from '../../../../application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { OperationCostRepositoryPort } from '../../../../application/port/repositories/operationCost/OperationCostRepositoryPort'
import { Request, Response } from 'express'

export const searchExistenceOfOperationController = async (
  req: Request,
  res: Response,
  personnelRepository: Pick<PersonnelRepositoryPort, 'findOneById'>,
  operationPlanRepository: Pick<
    OperationPlanRepositoryPort,
    'findOperationPlansByPersonnelId'
  >,
  operationCostRepository: Pick<
    OperationCostRepositoryPort,
    'searchOperationCostsByPersonnelId'
  >
): Promise<Response<SearchExistenceOfOperationResponse>> => {
  const from = req.query.from as string
  const to = req.query.to as string
  const personnelId = Number(req.params.personnelId)

  const searchResponse = await searchExistenceOfOperationUseCase(
    from,
    to,
    personnelId,
    personnelRepository,
    operationPlanRepository,
    operationCostRepository
  )

  return res.status(200).json(searchResponse)
}
