import { Request, Response } from 'express'
import { PersonnelRepositoryPort } from '../../../../application/port/repositories/personnel/PersonnelRepositoryPort'
import { findAllPersonnelUseCase } from '../../../../application/use_cases/options/personnel/findAllPersonnelsUseCase'
import {
  PaginatedPersonnelList,
  PersonnelSearchCriteria,
  SkillList,
} from '../../../../domain/models/Personnel'

export const findAllPersonnelController = async (
  req: Request,
  res: Response,
  repository: Pick<PersonnelRepositoryPort, 'findAll'>
): Promise<Response<PaginatedPersonnelList>> => {
  const query = req.query
  const {
    limit,
    offset,
    personnel_id,
    name,
    name_jpn,
    project_id,
    company_id,
    search_name,
    include_status_closed,
  } = query

  const skills: SkillList = req.body?.skills ?? {}
  const searchCriteria: PersonnelSearchCriteria = {
    limit: Number(limit),
    offset: Number(offset),
    personnel_id: Number(personnel_id),
    name: String(name),
    name_jpn: String(name_jpn),
    project_id: Number(project_id),
    company_id: Number(company_id),
    search_name: String(search_name),
    skills,
    includeStatusClosed: Boolean(include_status_closed),
  }

  const findPersonnelResult = await findAllPersonnelUseCase(
    searchCriteria,
    repository
  )
  return res.status(200).json(findPersonnelResult)
}
