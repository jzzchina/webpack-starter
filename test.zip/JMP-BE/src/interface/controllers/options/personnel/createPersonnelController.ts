import { PersonnelRepositoryPort } from './../../../../application/port/repositories/personnel/PersonnelRepositoryPort'
import { createPersonnelUseCase } from '../../../../application/use_cases/options/personnel/createPersonnelUseCase'
import {
  Personnel,
  PersonnelCreateResponse,
} from '../../../routes/options/personnel/dto/personnel.dto'
import { Request, Response } from 'express'

export const createPersonnelController = async (
  req: Request,
  res: Response,
  services: Pick<PersonnelRepositoryPort, 'create' | 'findMany'>
): Promise<Response<PersonnelCreateResponse[]>> => {
  const userInformation: Record<string, unknown> = res.locals.user
  const personnelList: Personnel[] = req.body

  const result = await createPersonnelUseCase(
    personnelList,
    userInformation,
    services
  )

  return res.status(200).send(result)
}
