import { findAllProjectsUseCase } from '../../../../application/use_cases/options/project/findAllProjectsUseCase'
import { ProjectRepositoryPort } from '../../../../application/port/repositories/project/ProjectRepositoryPort'
import { ProjectSearchCriteria } from '../../../../domain/models/Project'
import { ProjectListResponse } from '../../../routes/options/project/dto/projects.dto'
import { OperationCostRepositoryPort } from '../../../../application/port/repositories/operationCost/OperationCostRepositoryPort'
import { Request, Response } from 'express'

export const findAllProjectsController = async (
  projectServices: Pick<ProjectRepositoryPort, 'findAll'>,
  operationCostServices: Pick<
    OperationCostRepositoryPort,
    'searchOperationCostsByProjectId'
  >,
  _req: Request,
  res: Response
): Promise<Partial<Response<ProjectListResponse>>> => {
  const {
    project_id,
    project_name,
    company_id,
    user_part,
    project_manager,
    status,
    limit,
    offset,
    project_start_date,
    project_end_date,
    include_status_closed,
  } = _req.query

  const searchCriteria: ProjectSearchCriteria = {
    project_id: Number(project_id),
    project_name: String(project_name || ''),
    company_id: Number(company_id),
    user_part: String(user_part || ''),
    project_manager: String(project_manager || ''),
    status: parseInt(status as string),
    limit: Number(limit),
    offset: Number(offset),
    project_start_date: String(project_start_date || ''),
    project_end_date: String(project_end_date || ''),
    include_status_closed: Boolean(include_status_closed),
  }
  const listProjects = await findAllProjectsUseCase(
    projectServices,
    operationCostServices,
    searchCriteria
  )
  return res.status(200).json(listProjects)
}
