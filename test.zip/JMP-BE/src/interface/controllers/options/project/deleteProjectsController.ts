import { Request, Response } from 'express'
import { ProjectRepositoryPort } from '../../../../application/port/repositories/project/ProjectRepositoryPort'
import { deleteProjectsUseCase } from '../../../../application/use_cases/options/project/deleteProjectsUseCase'

export const deleteProjectsController = async (
  req: Request,
  res: Response,
  repository: Pick<ProjectRepositoryPort, 'deleteProjects'>
): Promise<Response<void>> => {
  const idList: number[] = (req.query.project_id as string[]).map((el) =>
    Number(el)
  )
  await deleteProjectsUseCase(idList, repository)
  return res.status(200).send({ message: 'Records deleted successfully' })
}
