import { ProjectRepositoryPort } from '../../../../application/port/repositories/project/ProjectRepositoryPort'
import {
  CreateProjectDto,
  ProjectDtoResponse,
} from '../../../routes/options/project/dto/projects.dto'
import { createProjectsUseCase } from '../../../../application/use_cases/options/project/createProjectsUseCase'
import { Request, Response } from 'express'
import { WbsRepositoryPort } from '../../../../application/port/repositories/wbs/wbsRepositoryPort'

export const createProjectsController = async (
  req: Request,
  res: Response,
  service: Pick<ProjectRepositoryPort, 'createProjects'>,
  wbsRepository: Pick<WbsRepositoryPort, 'createWbs'>
): Promise<Response<ProjectDtoResponse[]>> => {
  const userName: string = res?.locals?.user?.name
  const dtoList: CreateProjectDto[] = req.body
  const result = await createProjectsUseCase(
    userName,
    dtoList,
    service,
    wbsRepository
  )
  return res.status(200).send(result)
}
