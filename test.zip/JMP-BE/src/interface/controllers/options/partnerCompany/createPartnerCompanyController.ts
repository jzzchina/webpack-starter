import { Request, Response } from 'express'
import { createPartnerCompanyUseCase } from './../../../../application/use_cases/options/partnerCompany/createPartnerCompanyUseCase'
import { PartnerCompanyRepositoryPort } from './../../../../application/port/repositories/partnerCompany/PartnerCompanyRepositoryPort'
import {
  PartnerCompanyCreateResponse,
  PartnerCompanyBodyRequest,
} from '../../../routes/options/partnerCompany/dto/partnerCompany.dto'
import { SalesManRepositoryPort } from '../../../../application/port/repositories/salesMan/SalesManRepositoryPort'

export const createPartnerCompanyController = async (
  req: Request,
  res: Response,
  repository: Pick<PartnerCompanyRepositoryPort, 'create' | 'findMany'>,
  salesManRepository: Pick<
    SalesManRepositoryPort,
    'createSalesMan' | 'findSalesManByIds'
  >
): Promise<Response<PartnerCompanyCreateResponse[]>> => {
  const userInformation: Record<string, unknown> = res.locals.user
  const companyListRequestInput: PartnerCompanyBodyRequest[] = req.body
  const result = await createPartnerCompanyUseCase(
    companyListRequestInput,
    userInformation,
    repository,
    salesManRepository
  )
  return res.status(200).send(result)
}
