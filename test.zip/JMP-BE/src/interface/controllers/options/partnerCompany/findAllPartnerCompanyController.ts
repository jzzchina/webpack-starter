import { Request, Response } from 'express'
import { PartnerCompanyRepositoryPort } from '../../../../application/port/repositories/partnerCompany/PartnerCompanyRepositoryPort'
import { findAllPartnerCompanyUseCase } from '../../../../application/use_cases/options/partnerCompany/findAllPartnerCompanyUseCase'
import { PartnerCompanyListResponse } from '../../../routes/options/partnerCompany/dto/partnerCompany.dto'
import { FindAllPartnerCompanyRequest } from '../../../../infrastructure/repositories/options/partnerCompany/interface'

export const findAllPartnerCompanyController = async (
  req: Request,
  res: Response,
  services: Pick<PartnerCompanyRepositoryPort, 'findAll'>
): Promise<Response<Partial<PartnerCompanyListResponse>>> => {
  const {
    company_id,
    company_name,
    contract_pattern_code,
    limit,
    offset,
  } = (req.query as unknown) as FindAllPartnerCompanyRequest

  const findAllPartnerCompany = await findAllPartnerCompanyUseCase(
    services,
    Number(company_id),
    String(company_name || ''),
    parseInt((contract_pattern_code as unknown) as string),
    Number(limit),
    Number(offset)
  )
  return res.status(200).json(findAllPartnerCompany)
}
