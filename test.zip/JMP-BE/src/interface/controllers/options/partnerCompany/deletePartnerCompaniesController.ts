import { deletePartnerCompaniesUseCase } from '../../../../application/use_cases/options/partnerCompany/deletePartnerCompaniesUseCase'
import { PartnerCompanyRepositoryPort } from '../../../../application/port/repositories/partnerCompany/PartnerCompanyRepositoryPort'
import { Request, Response } from 'express'

export const deletePartnerCompaniesController = async (
  req: Request,
  res: Response,
  repository: Pick<PartnerCompanyRepositoryPort, 'deletePartnerCompanies'>
): Promise<void> => {
  const { company_id } = req.query as any
  await deletePartnerCompaniesUseCase(company_id, repository)
  res.status(200).send({ message: 'Records deleted successfully' })
}
