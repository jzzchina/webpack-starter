import { PersonnelPriceRepositoryPort } from '../../../../application/port/repositories/personnelPriceRepositoryPort.ts/PersonnelPriceRepositoryPort'
import { createPersonnelPriceUseCase } from '../../../../application/use_cases/options/personnelPrice/createPersonnelPriceUseCase'
import { findByPersonnelIDUseCase } from '../../../../application/use_cases/options/personnelPrice/findByPersonnelIDUseCase'
import { deletePersonnelPriceUseCase } from '../../../../application/use_cases/options/personnelPrice/deletePersonnelPriceUseCase'
import { PersonnelList } from '../../../../domain/models/Personnel'
import { PersonnelPrice } from '../../../../domain/models/PersonnelPrice'
import { Request, Response } from 'express'
import { OperationCostRepositoryPort } from '../../../../application/port/repositories/operationCost/OperationCostRepositoryPort'

export const findByIdPersonnelController = async (
  req: Request,
  res: Response,
  personnelPriceRepository: Pick<
    PersonnelPriceRepositoryPort,
    'findByPersonnelID'
  >
): Promise<Response<PersonnelList>> => {
  const personnelId = parseInt(req.query.personnel_id as string)
  const foundPersonnelPricesResult = await findByPersonnelIDUseCase(
    personnelId,
    personnelPriceRepository
  )
  return res.status(200).json(foundPersonnelPricesResult)
}
export const createPersonnelPriceController = async (
  req: Request,
  res: Response,
  personnelPriceRepository: Pick<
    PersonnelPriceRepositoryPort,
    'createPersonnelPrice' | 'findMany'
  >,
  operationCostRepository: Pick<
    OperationCostRepositoryPort,
    'updateCostAmountByPersonnelAndDate'
  >
): Promise<Response<PersonnelPrice[]>> => {
  const userInformation: Record<string, unknown> = res.locals.user
  const personnelList: PersonnelPrice[] = req.body

  const result = await createPersonnelPriceUseCase(
    personnelList,
    userInformation,
    personnelPriceRepository,
    operationCostRepository
  )
  return res.status(200).send(result)
}

export const deletePersonnelPriceController = async (
  req: Request,
  res: Response,
  personnelPriceRepository: Pick<PersonnelPriceRepositoryPort, 'delete'>
): Promise<Response<void>> => {
  const { personnelId, priceStartDate } = req.params

  await deletePersonnelPriceUseCase(
    Number(personnelId),
    priceStartDate,
    personnelPriceRepository
  )
  return res.status(200).send({ message: 'Records deleted successfully' })
}
