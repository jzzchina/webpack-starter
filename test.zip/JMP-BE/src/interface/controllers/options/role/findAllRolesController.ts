import { RoleListResponse } from './../../../../infrastructure/repositories/options/role/interface'
import { RoleRepositoryPort } from '../../../../application/port/repositories/role/RoleRepositoryPort'
import { findAllRolesUseCase } from '../../../../application/use_cases/options/role/findAllRoleUseCase'
import { Request, Response } from 'express'

export const findAllRolesController = async (
  _req: Request,
  res: Response,
  repository: Pick<RoleRepositoryPort, 'findAll'>
): Promise<Response<RoleListResponse>> => {
  const allRoles = await findAllRolesUseCase(repository)
  return res.status(200).json(allRoles)
}
