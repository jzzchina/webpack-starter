# nodejs-backend-template

Standardized template for nodejs backend projects based on Clean Architecture.

## Directory structure

Based on [The Clean Architecture](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html).

```
📦src
 ┣ 📂application
 ┃ ┣ 📂errors
 ┃ ┃ ┣ 📜index.ts
 ┃ ┃ ┣ 📜MissingRequiredParameterError.ts
 ┃ ┃ ┣ 📜TaskIDAlreadyExistsError.ts
 ┃ ┃ ┗ 📜TaskIDDoesntExistError.ts
 ┃ ┣ 📂port
 ┃ ┃ ┣ 📂repositories
 ┃ ┃ ┃ ┗ 📂task
 ┃ ┃ ┃ ┃ ┗ 📜TaskRepositoryPort.ts
 ┃ ┃ ┗ 📜index.ts
 ┃ ┗ 📂use_cases
 ┃ ┃ ┗ 📂task
 ┃ ┃ ┃ ┣ 📜createTaskUseCase.ts
 ┃ ┃ ┃ ┣ 📜deleteTaskUseCase.ts
 ┃ ┃ ┃ ┣ 📜findAllTasksUseCase.ts
 ┃ ┃ ┃ ┣ 📜findTaskByIdUseCase.ts
 ┃ ┃ ┃ ┗ 📜updateTaskUseCase.ts
 ┣ 📂domain
 ┃ ┗ 📂models
 ┃ ┃ ┗ 📜Task.ts
 ┣ 📂infrastructure
 ┃ ┣ 📂env
 ┃ ┃ ┗ 📜index.ts
 ┃ ┣ 📂orm
 ┃ ┃ ┗ 📂typeorm
 ┃ ┃ ┃ ┣ 📂config
 ┃ ┃ ┃ ┃ ┗ 📜ormconfig.ts
 ┃ ┃ ┃ ┣ 📂connection
 ┃ ┃ ┃ ┃ ┗ 📜index.ts
 ┃ ┃ ┃ ┣ 📂entities
 ┃ ┃ ┃ ┃ ┣ 📜Dw_m_business_days.ts
 ┃ ┃ ┃ ┃ ┣ 📜Dw_m_partner_company.ts
 ┃ ┃ ┃ ┃ ┣ 📜Dw_m_personnel.ts
 ┃ ┃ ┃ ┃ ┣ 📜Dw_m_personnel_price.ts
 ┃ ┃ ┃ ┃ ┣ 📜Dw_m_project.ts
 ┃ ┃ ┃ ┃ ┣ 📜Dw_m_role.ts
 ┃ ┃ ┃ ┃ ┣ 📜Dw_t_operation.ts
 ┃ ┃ ┃ ┃ ┣ 📜Dw_t_operation_plan.ts
 ┃ ┃ ┃ ┃ ┗ 📜Task.ts
 ┃ ┃ ┃ ┗ 📂migrations
 ┃ ┃ ┃ ┃ ┗ 📜.gitkeep
 ┃ ┣ 📂repositories
 ┃ ┃ ┗ 📂task
 ┃ ┃ ┃ ┣ 📜taskRepositoryInMemory.ts
 ┃ ┃ ┃ ┗ 📜taskRepositoryMySQL.ts
 ┃ ┗ 📂webserver
 ┃ ┃ ┗ 📂express
 ┃ ┃ ┃ ┣ 📜apiDocs.ts
 ┃ ┃ ┃ ┣ 📜index.ts
 ┃ ┃ ┃ ┗ 📜routes.ts
 ┗ 📂interface
 ┃ ┣ 📂controllers
 ┃ ┃ ┗ 📂task
 ┃ ┃ ┃ ┣ 📜createTaskController.ts
 ┃ ┃ ┃ ┣ 📜deleteTaskController.ts
 ┃ ┃ ┃ ┣ 📜findAllTasksController.ts
 ┃ ┃ ┃ ┣ 📜findTaskByIdController.ts
 ┃ ┃ ┃ ┗ 📜updateTaskController.ts
 ┃ ┗ 📂routes
 ┃ ┃ ┣ 📂task
 ┃ ┃ ┃ ┣ 📜createTask.ts
 ┃ ┃ ┃ ┣ 📜deleteTask.ts
 ┃ ┃ ┃ ┣ 📜findAllTasks.ts
 ┃ ┃ ┃ ┣ 📜findTaskById.ts
 ┃ ┃ ┃ ┗ 📜updateTask.ts
 ┃ ┃ ┗ 📂utils
 ┃ ┃ ┃ ┗ 📜util.ts
```

## Packages

We need this section because we've been facing a problem caused by minor update of package such as parcel...

### How to add a package for runtime

```sh
# Install the package as exact version in dependencies.
$ pnpm add --save-exact PACKAGE_NAME
```

### How to add a package for development

```sh
# Install the package as exact version in devDependencies.
$ pnpm add --save-exact --save-dev PACKAGE_NAME
```

### How to add a package for the type definition (@types/PACKAGE_NAME)

```sh
# Install the package as exact version in devDependencies.
$ pnpm add --save-exact --save-dev PACKAGE_NAME
```

### How to update a package

```sh
$ pnpm add PACKAGE_NAME
```

## Development

1. Install node_modules locally.

   ```bash
   $ pnpm install
   ```

1. Start containers.

    You can choose one of:

    ```bash
    # Using existing containers.
    $ pnpm run container:start
    ```

    ```bash
    # Build containers before starting.
    $ pnpm run container:start --build
    ```

    ```sh
    # Remove images and containers and rebuild them before starting.
    $ pnpm run container:start:rebuild
    ```

    **Note**: If you get such an error, you can add "node_modules" to ".dockerignore".

    ```sh
    => ERROR [express 7/7] COPY --chown=node:node . /home/node/app/                                                                                                                                                              1.7s
    ------
    > [express 7/7] COPY --chown=node:node . /home/node/app/:
    ------
    failed to solve: cannot copy to non-directory: /var/lib/docker/overlay2/7dmwjq9uo4i2hzsl9e4b6rryk/merged/home/node/app/node_modules/@eslint/eslintrc
    ```

1. Add some new changes.

## Environment variables

Refer to `./docker/<SERVICE_NAME>.dev.env` if you need to modify the environment variables for local development. Those files are used in `./docker/docker-compose.yml` using **env_file** configuration option following [this official document](https://docs.docker.com/compose/environment-variables/#the-env_file-configuration-option).

## How to create and run a migration (TypeORM)

    Before executing the following scripts, change the value of environment variable `DB_HOST` to `localhost`.

    ```bash
    # Create a new migration
    $ pnpm run typeorm-cli migration:generate -n Task

    # Run migrations
    $ pnpm run typeorm-cli migration:run
    ```
## Test(jest)
    
```sh
# Usage: jest [--config=<pathToConfigFile>] [TestPathPattern]
$ pnpm run test-unit /Users/ryo.inoue/repository/JMP-BE/test/units/use_cases/options/project/findAllProjectsUsecase.test.ts
```

## Development tools

- [TypeScript](https://www.typescriptlang.org/)
- [Express](https://expressjs.com/)
- [Jest](https://jestjs.io/)
- [TypeORM](https://typeorm.io/)
- [ESLint](https://eslint.org/)
- [Prettier](https://prettier.io/)
- [husky](https://typicode.github.io/husky/#/)
- [lint-staged](https://github.com/okonet/lint-staged)
- [nodemon](https://nodemon.io/)
- [pnpm](https://pnpm.io)
