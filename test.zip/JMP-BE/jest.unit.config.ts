import type { Config } from 'jest'

// * Jest Config for Unit Testing

const config: Config = {
  verbose: true,
  testEnvironment: 'node',
  preset: 'ts-jest',
  transform: {
    '^.+\\.tsx?$': 'ts-jest',
  },
  testMatch: ['**/test/units/**/*.test.ts'],
  maxWorkers: 1,
  modulePathIgnorePatterns: [
    'build',
    'node_modules',
    'coverage',
    'docker',
    'api-docs',
    'migrations',
  ],
  testPathIgnorePatterns: [
    'build',
    'node_modules',
    'coverage',
    'src/application/errors',
    'docker',
    'api-docs',
    'migrations',
  ],
  collectCoverage: true,
  collectCoverageFrom: ['src/**/*.ts'],
  coverageReporters: [
    'clover',
    'lcov',
    'text-summary',
    'html',
    ['text', { skipFull: false }],
  ],
  coverageThreshold: {
    // todo: set desired coverage threshold for CI
    global: {
      branches: 30,
      functions: 30,
      lines: 30,
      statements: 30,
    },
  },
  setupFilesAfterEnv: ['./jest.setup.ts'],
}

export default config
