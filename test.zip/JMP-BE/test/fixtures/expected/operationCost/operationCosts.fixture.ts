export const projects = [
  {
    project_end_date: null,
    notes: 'JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
    updated_by: null,
    update_at: null,
    process_id: null,
    project_id: 1,
    project_name: 'JMP',
    project_contact: 'JMP@example.com',
    project_start_date: '2022-01-01',
    dw_t_operation_plan: [
      {
        updated_by: 'Gaith Hmaied',
        update_at: new Date(2022 - 11 - 22),
        process_id: null,
        month_of_year_date: '2022-01-01',
        man_month_number: '0.26',
        hours_number: '0.500',
        created_by: 'Gaith Hmaied',
        create_at: new Date(2022 - 11 - 22),
        process_at: new Date(2022 - 11 - 22),
        dw_m_personnel: {
          personnel_id: 1,
          dw_m_partner_company: {
            company_id: 1,
            company_name: 'Avaxia',
            contract_pattern_code: 2,
            dw_m_business_day: [
              {
                month_of_year_date: '2022-01-01',
                business_days_number: '20',
              },
              {
                month_of_year_date: '2022-02-01',
                business_days_number: '22',
              },
            ],
          },
          name: 'Phuong Le',
          name_jpn: 'Phuong Le',
          registered_date: new Date('2021-01-01'),
          unregistered_date: new Date('2022-12-31'),
          skill_list: {},
          dw_m_personnel_price: [
            {
              contract_pattern_code: 1,
              price_start_date: new Date('2022-11-27'),
              price_amount: 100,
              currency_type_code: 1,
            },
          ],
          dw_t_operation_plan: [
            {
              month_of_year_date: '2022-01-01',
              man_month_number: '0.26',
              hours_number: '0.500',
            },
          ],
          dw_t_operation: [
            {
              operation_id: 1,

              cost_amount: 0,
              hours_number: '0.300',
              month_of_year_date: '2022-01-01',
            },
          ],
        },
      },
    ],
    dw_t_operation: [
      {
        operation_id: 10,
        cost_amount: 0,
        hours_number: '0.300',
        month_of_year_date: '2022-01-01',
      },
      {
        operation_id: 2,
        cost_amount: 100,
        hours_number: '0.600',
        month_of_year_date: '2022-02-01',
      },
    ],
  },
]
export const projectsWithoutMonthOfYearDate = [
  {
    project_end_date: null,
    notes: 'JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
    updated_by: null,
    update_at: null,
    process_id: null,
    project_id: 1,
    project_name: 'JMP',
    project_contact: 'JMP@example.com',
    project_start_date: '2022-01-01',
    dw_t_operation_plan: [
      {
        updated_by: 'Gaith Hmaied',
        update_at: new Date(2022 - 11 - 22),
        process_id: null,
        month_of_year_date: '2022-01-01',
        man_month_number: '0.26',
        hours_number: '0.500',
        created_by: 'Gaith Hmaied',
        create_at: new Date(2022 - 11 - 22),
        process_at: new Date(2022 - 11 - 22),
        dw_m_personnel: {
          personnel_id: 1,
          dw_m_partner_company: {
            company_id: 1,
            company_name: 'JMP11',
            contract_pattern_code: 2,
            dw_m_business_day: [
              {
                month_of_year_date: '2022-02-02',
                business_days_number: '23',
              },
              {
                month_of_year_date: '2022-03-02',
                business_days_number: '24',
              },
            ],
          },

          name: 'Phuong Le',
          name_jpn: 'Phuong Le',
          registered_date: new Date('2021-01-01'),
          unregistered_date: new Date('2022-12-31'),
          skill_list: {},
          dw_m_personnel_price: [
            {
              contract_pattern_code: 1,
              price_start_date: new Date('2022-11-27'),
              price_amount: 100,
              currency_type_code: 1,
            },
          ],
          dw_t_operation_plan: [
            {
              man_month_number: '0.26',
              hours_number: '0.500',
            },
            {
              man_month_number: '0.26',
              hours_number: '0.500',
            },
          ],
          dw_t_operation: [
            {
              cost_amount: 0,
              hours_number: '0.300',
            },
            {
              cost_amount: 10,
              hours_number: '0.300',
            },
          ],
        },
      },
    ],
    dw_t_operation: [
      {
        cost_amount: 0,
        hours_number: '0.300',
      },
      {
        cost_amount: 100,
        hours_number: '0.600',
      },
    ],
  },
]

export const operationCostsCreate = [
  {
    dw_m_personnel: {
      personnel_id: 1,
    },
    dw_m_project: {
      project_id: 1,
    },
    month_of_year_date: new Date('2022-01-01'),
    cost_amount: 0.5,
    hours_number: 0.6,
  },
]

export const operationCostsUpdate = [
  {
    dw_m_personnel: {
      personnel_id: 1,
    },
    dw_m_project: {
      project_id: 2,
    },
    month_of_year_date: new Date('2022-03-01'),
    cost_amount: 0.07,
    hours_number: 0.3,
  },
]

export const operationCosts = [
  {
    dw_m_personnel: {
      personnel_id: 1,
    },
    dw_m_project: {
      project_id: 1,
    },
    month_of_year_date: '2022-01-01',
    hours_number: 5,
    cost_amount: 0.8,
    created_by: '正吾 今',
    create_at: '2022-12-12',
    updated_by: '正吾 今',
    update_at: '2022-12-12',
    process_at: '2022-12-12',
    process_id: '1',
  },
  {
    dw_m_personnel: {
      personnel_id: 2,
    },
    dw_m_project: {
      project_id: 1,
    },
    month_of_year_date: '2022-01-01',
    hours_number: 6,
    cost_amount: 0.9,
    created_by: '正吾 今',
    create_at: '2022-12-12',
    updated_by: '正吾 今',
    update_at: '2022-12-12',
    process_at: '2022-12-12',
    process_id: '1',
  },
]
export const buildCreateOperationCostResponseFixture = [
  {
    costAmount: 1000,
    createdAt: new Date('2024-04-17'),
    createdBy: 'test',
    hoursNumber: 160,
    operationId: 1,
    personnelId: undefined,
    processAt: new Date('2024-04-17'),
    processId: '1234',
    projectId: undefined,
    updateAt: new Date('2024-04-17'),
    updatedBy: 'user',
    yearOfMonthDate: '2024-04-01',
  },
]

export const OperationCreateQueryParamsObjectFixture = [
  {
    operation_id: 1,
    hours_number: 160.5,
    cost_amount: 0.1,
    dw_m_personnel: 5,
    dw_m_project: 5,
    month_of_year_date: '2022-01-01',
    created_by: 'SYS USER',
    updated_by: 'SYS USER',
  },
]

export const expectedResultGetUniqueListOfOperationCosts = [
  {
    create_at: new Date('2024-04-17'),
    created_by: 'User Test',
    deleted_at: null,
    dw_t_operation_plan: [
      {
        create_at: new Date('2024-04-17'),
        created_by: 'User Test',
        deleted_at: null,
        dw_m_personnel: {
          create_at: new Date('2024-04-17'),
          created_by: 'User Test',
          deleted_at: null,
          dw_m_partner_company: {
            company_id: 1,
            company_name: 'Company Test',
            contract_pattern_code: 1,
            create_at: new Date('2024-04-17'),
            created_by: 'unit test',
            deleted_at: null,
            dw_m_business_day: [
              {
                business_days_id: 1,
                business_days_number: 1,
                create_at: new Date('2022-02-01'),
                created_by: 'John Doe',
                deleted_at: null,
                month_of_year_date: '2025-04-01',
                process_at: new Date('2022-02-01'),
                process_id: '123',
                update_at: null,
                updated_by: 'Jane Smith',
              },
            ],
            process_at: new Date('2024-04-17'),
            process_id: null,
            update_at: null,
            updated_by: null,
          },
          dw_m_personnel_price: [],
          dw_t_operation: [
            {
              cost_amount: 1000,
              create_at: new Date('2024-04-17'),
              created_by: 'unit test',
              deleted_at: null,
              hours_number: 160,
              month_of_year_date: '2024-04-01',
              operation_id: 1,
              process_at: new Date('2024-04-17'),
              process_id: null,
              update_at: null,
              updated_by: null,
            },
          ],
          dw_t_operation_plan: [
            {
              create_at: new Date('2024-04-17'),
              created_by: 'unit test',
              deleted_at: null,
              dw_m_role: {
                create_at: new Date('2024-04-17'),
                created_by: 'unit test',
                process_at: new Date('2024-04-17'),
                process_id: null,
                role_id: 1,
                role_name: 'unit test',
                update_at: null,
                updated_by: null,
              },
              hours_number: 160,
              man_month_number: 1,
              month_of_year_date: '2025-04-01',
              operation_plan_id: 1,
              process_at: new Date('2024-04-17'),
              process_id: null,
              update_at: null,
              updated_by: null,
            },
          ],
          name: 'unit test',
          name_jpn: '見本　太郎',
          email: 'JhonDoe@Jera.com',
          personnel_id: 1,
          process_at: new Date('2024-04-17'),
          process_id: null,
          registered_date: new Date('2022-01-01'),
          skill_list: {
            'BackEnd,Node.js': { level: 3 },
            'FrontEnd,Web(React)': { level: 2 },
            LeadDev: { level: 1 },
          },
          unregistered_date: null,
          update_at: null,
          updated_by: null,
        },
        hours_number: 160,
        man_month_number: 1,
        month_of_year_date: '2024-04-01',
        operation_plan_id: 1,
        process_at: new Date('2024-04-17'),
        process_id: '123abc',
        update_at: null,
        updated_by: 'User Test',
      },
    ],
    dw_m_wbs: [
      {
        wbs_id: 1,
        wbs_code: 'WBS Code',
        wbs_title: 'WBS Title',
        subject: 'CAPEX',
        created_by: 'John Doe',
        create_at: new Date('2024-04-16'),
        updated_by: null,
        update_at: new Date('2024-04-16'),
        process_at: new Date('2024-04-16'),
        process_id: 'Process_1',
        deleted_at: null,
      },
    ],
    notes: 'Example notes',
    process_at: new Date('2024-04-17'),
    process_id: null,
    project_contact: 'contact@example.com',
    project_contact2: 'contact2@example.com',
    project_contact3: 'contact3@example.com',
    project_contact4: 'contact4@example.com',
    project_end_date: null,
    project_id: 1,
    project_manager: 'Test User',
    project_name: 'Sample Project',
    project_start_date: new Date('2024-04-17'),
    status: 1,
    update_at: null,
    updated_by: null,
    user_part: 'testing',
  },
]

export const buildOperationCostListResponseResultFixture = {
  from: '2020-04-01',
  items: [
    {
      note: 'Example notes',
      personnel: [
        {
          businessDays: { '2025-04-01': { businessDaysNumber: 1 } },
          companyId: 1,
          companyName: 'Company Test',
          contractPatternCode: 1,
          name: 'unit test',
          nameJpn: '見本　太郎',
          operationPlans: {
            '2025-04-01': { hoursNumber: 160, manMonthNumber: 1 },
          },
          operations: {
            '2024-04-01': {
              costAmount: 1000,
              hoursNumber: 160,
              operationId: 1,
            },
          },
          personnelId: 1,
          prices: [],
          registeredDate: new Date('2022-01-01'),
          unregisteredDate: null,
        },
      ],
      wbs: {
        wbsTitle: 'WBS Title',
        wbsCode: 'WBS Code',
      },
      projectContact: 'contact@example.com',
      projectContact2: 'contact2@example.com',
      projectContact3: 'contact3@example.com',
      projectContact4: 'contact4@example.com',
      projectEndDate: null,
      projectId: 1,
      projectName: 'Sample Project',
      projectStartDate: new Date('2024-04-17'),
    },
  ],
  length: 1,
  offset: 0,
  to: '2027-04-30',
  totalLength: 2,
}
