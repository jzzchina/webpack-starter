import { OperationPlanPersonnelResponse } from '../../../../src/infrastructure/repositories/operationPlan/interface'

import {
  OperationPlanProject,
  OperationPlanProjectResponse,
} from '../../../../src/infrastructure/repositories/operationPlan/interface'

type OperationPlanPersonnelFixture = {
  expectedOperationResponse: OperationPlanPersonnelResponse
  emptyOperationResponse: OperationPlanPersonnelResponse
}
export const operationPlansCreate = [
  {
    dw_m_personnel: {
      personnel_id: 1,
    },
    dw_m_project: {
      project_id: 1,
      dw_t_operation: [
        {
          cost_amount: 0,
        },
      ],
    },
    month_of_year_date: new Date('2022-01-01'),
    dw_m_role: {
      role_id: 1,
      role_name: 'Admin',
    },
    man_month_number: 1,
    hours_number: 2,
  },
  {
    dw_m_personnel: {
      personnel_id: 2,
    },
    dw_m_project: {
      project_id: 1,
    },
    month_of_year_date: new Date('2022-01-01'),
    dw_m_role: {
      role_id: 1,
      role_name: 'Admin',
    },
    man_month_number: 1,
    hours_number: 2,
  },
]

export const operationPlansUpdate = [
  {
    dw_m_personnel: {
      personnel_id: 1,
    },
    dw_m_project: {
      project_id: 2,
      dw_t_operation: [
        {
          cost_amount: 0,
        },
      ],
    },
    month_of_year_date: new Date('2022-01-01'),
    dw_m_role: {
      role_id: 1,
      role_name: 'Admin',
    },
    man_month_number: 1,
    hours_number: 3,
  },
]

export const operationPlans = [
  {
    personnel_id: 1,
    project_id: 1,
    month_of_year_date: '2022-01-01',
    role_id: 1,
    man_month_number: 1,
    hours_number: 5,
    created_by: 'Phuong Le',
    create_at: '2022-11-27',
    updated_by: 'Phuong Le',
    update_at: '2022-11-27',
    process_at: '2022-11-27',
    process_id: '1',
  },
]

export const operationPlanPersonnelResFixture: OperationPlanPersonnelFixture = {
  expectedOperationResponse: ({
    from: '2027-04-30',
    items: [
      {
        allProjectIds: [],
        businessDays: {},
        companyId: 1,
        companyName: 'test',
        contractPatternCode: 1,
        name: 'unit test',
        nameJpn: '見本　太郎',
        personnelId: 1,
        prices: [],
        projects: [],
        registeredDate: new Date('2022-01-01'),
        skillList: {
          'BackEnd,Node.js': { level: 3 },
          'FrontEnd,Web(React)': { level: 2 },
          LeadDev: { level: 1 },
        },
        totals: {
          operationPlans: {
            '2025-04-01': {
              manMonthNumber: 1,
              operationPlanId: 1,
            },
          },
        },
        unregisteredDate: null,
      },
    ],
    length: 1,
    offset: 0,
    to: '2020-04-01',
    totalLength: 2,
  } as unknown) as OperationPlanPersonnelResponse,
  emptyOperationResponse: {
    from: '2027-04-30',
    to: '2020-04-01',
    offset: 0,
    length: 0,
    totalLength: 0,
    items: [],
  },
}

type OperationPlanFixture = {
  expectedOperationResponse: OperationPlanProjectResponse
  expectedEmptyOperationResponse: OperationPlanProjectResponse
}

// Note: I am using as unknown as Date because some dates are returned as strings from the database
export const buildOperationPlanProjectExpect: OperationPlanFixture = {
  expectedOperationResponse: {
    from: '2027-04-30',
    to: '2020-04-01',
    offset: 0,
    length: 2,
    totalLength: 2,
    items: ([
      {
        projectId: 1,
        projectName: 'Sample Project',
        projectContact: 'contact1@example.com',
        projectContact2: 'contact1@example.com',
        projectContact3: 'contact2@example.com',
        projectContact4: 'contact3@example.com',
        projectStartDate: new Date('2024-04-17'),
        projectEndDate: null,
        note: 'Example notes',
        totals: {
          operationPlans: {
            '2024-04-01': {
              operationPlanId: 1,
              manMonthNumber: 2,
            },
          },
        },
        allPersonnelIds: [1],
        personnel: [
          {
            companyId: 1,
            contractPatternCode: 1,
            companyName: 'test',
            personnelId: 1,
            name: 'unit test',
            nameJpn: '見本　太郎',
            registeredDate: new Date('2022-01-01'),
            unregisteredDate: null,
            operation: false,
            skillList: {
              LeadDev: {
                level: 1,
              },
              'BackEnd,Node.js': {
                level: 3,
              },
              'FrontEnd,Web(React)': {
                level: 2,
              },
            },
            prices: [],
            businessDays: {
              '2025-04-01': {
                businessDaysNumber: 1,
              },
            },
            operationPlans: {
              '2025-04-01': {
                operationPlanId: 1,
                manMonthNumber: 3,
                roleId: 1,
                roleName: 'test',
              },
            },
          },
        ],
      },
      {
        projectId: 1,
        projectName: 'Sample Project',
        projectContact: 'contact1@example.com',
        projectContact2: 'contact1@example.com',
        projectContact3: 'contact2@example.com',
        projectContact4: 'contact3@example.com',
        projectStartDate: new Date('2024-04-17'),
        projectEndDate: null,
        note: 'Example notes',
        totals: {
          operationPlans: {},
        },
        allPersonnelIds: [],
        personnel: [],
      },
    ] as unknown) as OperationPlanProject[],
  },
  expectedEmptyOperationResponse: {
    from: '2027-04-30',
    to: '2020-04-01',
    offset: 0,
    length: 0,
    totalLength: 0,
    items: [],
  },
}
export const operationPlansFixture = {
  search: {
    findResult: {
      items: [
        {
          project_end_date: '2022-06-01',
          notes: null,
          updated_by: null,
          update_at: null,
          process_id: null,
          project_id: 1,
          project_name: 'project 1',
          project_contact: 'test',
          project_start_date: '2022-01-01',
          dw_t_operation_plan: [
            {
              updated_by: 'Unit Test',
              update_at: '2023-01-25T00:13:27.233Z',
              process_id: null,
              month_of_year_date: '2022-05-01',
              man_month_number: '0.55',
              hours_number: '0.500',
              created_by: 'Unit Test',
              create_at: '2023-01-25T00:13:27.233Z',
              process_at: '2023-01-25T00:13:27.233Z',
              dw_m_personnel: {
                name_jpn: 'テスト１',
                unregistered_date: '2022-05-01',
                updated_by: null,
                update_at: null,
                process_id: null,
                personnel_id: 1,
                name: 'test1',
                registered_date: '2022-01-01',
                skill_list: {
                  LeadDev: {
                    level: 1,
                  },
                  'BackEnd,Node.js': {
                    level: 3,
                  },
                  'FrontEnd,Web(React)': {
                    level: 2,
                  },
                },
                dw_t_operation_plan: [
                  {
                    updated_by: null,
                    update_at: null,
                    process_id: null,
                    month_of_year_date: '2022-05-01',
                    man_month_number: '0.55',
                    dw_m_role: {
                      updated_by: null,
                      update_at: null,
                      process_id: null,
                      role_id: 1,
                      role_name: 'Lead',
                    },
                  },
                ],
                dw_m_personnel_price: [
                  {
                    updated_by: null,
                    update_at: null,
                    process_id: null,
                    contract_pattern_code: 0,
                    price_start_date: '2022-01-01',
                    price_amount: '5625.00',
                    currency_type_code: 0,
                  },
                ],
                dw_m_partner_company: {
                  updated_by: null,
                  update_at: null,
                  process_id: null,
                  company_id: 1,
                  company_name: 'Company 1',
                  contract_pattern_code: 1,
                  dw_m_business_day: [
                    {
                      updated_by: 'test',
                      update_at: '2020-12-31T23:00:00.000Z',
                      process_id: 'test',
                      month_of_year_date: '2021-01-01',
                      business_days_number: 1,
                      created_by: 'test',
                      create_at: '2020-12-31T23:00:00.000Z',
                      process_at: '2020-12-31T23:00:00.000Z',
                    },
                  ],
                },
                dw_t_operation: [
                  {
                    updated_by: 'Unit Test',
                    update_at: '2023-01-25T00:13:27.233Z',
                    process_id: null,
                    month_of_year_date: '2022-05-01',
                  },
                ],
              },
            },
            {
              updated_by: 'Unit Test',
              update_at: '2023-01-25T00:13:27.233Z',
              process_id: null,
              month_of_year_date: '2022-05-01',
              man_month_number: '0.55',
              hours_number: '0.500',
              created_by: 'Unit Test',
              create_at: '2023-01-25T00:13:27.233Z',
              process_at: '2023-01-25T00:13:27.233Z',
              dw_m_personnel: {
                name_jpn: 'テスト１',
                unregistered_date: '2022-05-01',
                updated_by: null,
                update_at: null,
                process_id: null,
                personnel_id: 1,
                name: 'test1',
                registered_date: '2022-01-01',
                skill_list: {
                  LeadDev: {
                    level: 1,
                  },
                  'BackEnd,Node.js': {
                    level: 3,
                  },
                  'FrontEnd,Web(React)': {
                    level: 2,
                  },
                },
                dw_t_operation_plan: [
                  {
                    updated_by: null,
                    update_at: null,
                    process_id: null,
                    month_of_year_date: '2022-05-01',
                    man_month_number: '0.55',
                    dw_m_role: {
                      updated_by: null,
                      update_at: null,
                      process_id: null,
                      role_id: 1,
                      role_name: 'Lead',
                    },
                  },
                ],
                dw_m_personnel_price: [
                  {
                    updated_by: null,
                    update_at: null,
                    process_id: null,
                    contract_pattern_code: 0,
                    price_start_date: '2022-01-01',
                    price_amount: '5625.00',
                    currency_type_code: 0,
                  },
                ],
                dw_m_partner_company: {
                  updated_by: null,
                  update_at: null,
                  process_id: null,
                  company_id: 1,
                  company_name: 'Company 1',
                  contract_pattern_code: 1,
                  dw_m_business_day: [
                    {
                      updated_by: 'test',
                      update_at: '2020-12-31T23:00:00.000Z',
                      process_id: 'test',
                      month_of_year_date: '2021-01-01',
                      business_days_number: 1,
                      created_by: 'test',
                      create_at: '2020-12-31T23:00:00.000Z',
                      process_at: '2020-12-31T23:00:00.000Z',
                    },
                  ],
                },
              },
            },
            {
              updated_by: 'Unit Test',
              update_at: '2023-01-25T00:13:27.233Z',
              process_id: null,
              month_of_year_date: '2022-05-01',
              man_month_number: '0.55',
              hours_number: '0.500',
              created_by: 'Unit Test',
              create_at: '2023-01-25T00:13:27.233Z',
              process_at: '2023-01-25T00:13:27.233Z',
              dw_m_personnel: {
                name_jpn: 'テスト１',
                unregistered_date: '2022-05-01',
                updated_by: null,
                update_at: null,
                process_id: null,
                name: 'test1',
                registered_date: '2022-01-01',
                skill_list: {
                  LeadDev: {
                    level: 1,
                  },
                  'BackEnd,Node.js': {
                    level: 3,
                  },
                  'FrontEnd,Web(React)': {
                    level: 2,
                  },
                },
                dw_t_operation_plan: [
                  {
                    updated_by: null,
                    update_at: null,
                    process_id: null,
                    month_of_year_date: '2022-05-01',
                    man_month_number: '0.55',
                    dw_m_role: {
                      updated_by: null,
                      update_at: null,
                      process_id: null,
                      role_id: 1,
                      role_name: 'Lead',
                    },
                  },
                ],
                dw_m_personnel_price: [
                  {
                    updated_by: null,
                    update_at: null,
                    process_id: null,
                    contract_pattern_code: 0,
                    price_start_date: '2022-01-01',
                    price_amount: '5625.00',
                    currency_type_code: 0,
                  },
                ],
                dw_m_partner_company: {
                  updated_by: null,
                  update_at: null,
                  process_id: null,
                  company_id: 1,
                  company_name: 'Company 1',
                  contract_pattern_code: 1,
                  dw_m_business_day: [
                    {
                      updated_by: 'test',
                      update_at: '2020-12-31T23:00:00.000Z',
                      process_id: 'test',
                      month_of_year_date: '2021-01-01',
                      business_days_number: 1,
                      created_by: 'test',
                      create_at: '2020-12-31T23:00:00.000Z',
                      process_at: '2020-12-31T23:00:00.000Z',
                    },
                  ],
                },
              },
            },
          ],
        },

        {
          project_end_date: '2022-06-01',
          notes: null,
          updated_by: null,
          update_at: null,
          process_id: null,
          project_id: 1,
          project_name: 'project 1',
          project_contact: 'test',
          project_start_date: '2022-01-01',
          dw_t_operation_plan: [
            {
              updated_by: 'Unit Test',
              update_at: '2023-01-25T00:13:27.233Z',
              process_id: null,
              month_of_year_date: '2022-05-01',
              man_month_number: '0.55',
              hours_number: '0.500',
              created_by: 'Unit Test',
              create_at: '2023-01-25T00:13:27.233Z',
              process_at: '2023-01-25T00:13:27.233Z',
              dw_m_personnel: {
                name_jpn: 'テスト１',
                unregistered_date: '2022-05-01',
                updated_by: null,
                update_at: null,
                process_id: null,
                personnel_id: 1,
                name: 'test1',
                registered_date: '2022-01-01',
                skill_list: {
                  LeadDev: {
                    level: 1,
                  },
                  'BackEnd,Node.js': {
                    level: 3,
                  },
                  'FrontEnd,Web(React)': {
                    level: 2,
                  },
                },
                dw_t_operation_plan: [
                  {
                    updated_by: null,
                    update_at: null,
                    process_id: null,
                    month_of_year_date: '2022-05-01',
                    man_month_number: '0.55',
                    dw_m_role: {
                      updated_by: null,
                      update_at: null,
                      process_id: null,
                      role_id: 1,
                      role_name: 'Lead',
                    },
                  },
                ],
                dw_m_personnel_price: [
                  {
                    updated_by: null,
                    update_at: null,
                    process_id: null,
                    contract_pattern_code: 0,
                    price_start_date: '2022-01-01',
                    price_amount: '5625.00',
                    currency_type_code: 0,
                  },
                ],
                dw_m_partner_company: {
                  updated_by: null,
                  update_at: null,
                  process_id: null,
                  company_id: 1,
                  company_name: 'Company 1',
                  contract_pattern_code: 1,
                  dw_m_business_day: [
                    {
                      updated_by: 'test',
                      update_at: '2020-12-31T23:00:00.000Z',
                      process_id: 'test',
                      month_of_year_date: '2021-01-01',
                      business_days_number: 1,
                      created_by: 'test',
                      create_at: '2020-12-31T23:00:00.000Z',
                      process_at: '2020-12-31T23:00:00.000Z',
                    },
                  ],
                },
                dw_t_operation: [
                  {
                    updated_by: 'Unit Test',
                    update_at: '2023-01-25T00:13:27.233Z',
                    process_id: null,
                    month_of_year_date: '2022-05-01',
                  },
                ],
              },
            },
            {
              updated_by: 'Unit Test',
              update_at: '2023-01-25T00:13:27.233Z',
              process_id: null,
              month_of_year_date: '2022-05-01',
              man_month_number: '0.55',
              hours_number: '0.500',
              created_by: 'Unit Test',
              create_at: '2023-01-25T00:13:27.233Z',
              process_at: '2023-01-25T00:13:27.233Z',
              dw_m_personnel: {
                name_jpn: 'テスト１',
                unregistered_date: '2022-05-01',
                updated_by: null,
                update_at: null,
                process_id: null,
                personnel_id: 1,
                name: 'test1',
                registered_date: '2022-01-01',
                skill_list: {
                  LeadDev: {
                    level: 1,
                  },
                  'BackEnd,Node.js': {
                    level: 3,
                  },
                  'FrontEnd,Web(React)': {
                    level: 2,
                  },
                },
                dw_t_operation_plan: [
                  {
                    updated_by: null,
                    update_at: null,
                    process_id: null,
                    month_of_year_date: '2022-05-01',
                    man_month_number: '0.55',
                    dw_m_role: {
                      updated_by: null,
                      update_at: null,
                      process_id: null,
                      role_id: 1,
                      role_name: 'Lead',
                    },
                  },
                ],
                dw_m_personnel_price: [
                  {
                    updated_by: null,
                    update_at: null,
                    process_id: null,
                    contract_pattern_code: 0,
                    price_start_date: '2022-01-01',
                    price_amount: '5625.00',
                    currency_type_code: 0,
                  },
                ],
                dw_m_partner_company: {
                  updated_by: null,
                  update_at: null,
                  process_id: null,
                  company_id: 1,
                  company_name: 'Company 1',
                  contract_pattern_code: 1,
                  dw_m_business_day: [
                    {
                      updated_by: 'test',
                      update_at: '2020-12-31T23:00:00.000Z',
                      process_id: 'test',
                      month_of_year_date: '2021-01-01',
                      business_days_number: 1,
                      created_by: 'test',
                      create_at: '2020-12-31T23:00:00.000Z',
                      process_at: '2020-12-31T23:00:00.000Z',
                    },
                  ],
                },
              },
            },
            {
              updated_by: 'Unit Test',
              update_at: '2023-01-25T00:13:27.233Z',
              process_id: null,
              month_of_year_date: '2022-05-01',
              man_month_number: '0.55',
              hours_number: '0.500',
              created_by: 'Unit Test',
              create_at: '2023-01-25T00:13:27.233Z',
              process_at: '2023-01-25T00:13:27.233Z',
              dw_m_personnel: {
                name_jpn: 'テスト１',
                unregistered_date: '2022-05-01',
                updated_by: null,
                update_at: null,
                process_id: null,
                name: 'test1',
                registered_date: '2022-01-01',
                skill_list: {
                  LeadDev: {
                    level: 1,
                  },
                  'BackEnd,Node.js': {
                    level: 3,
                  },
                  'FrontEnd,Web(React)': {
                    level: 2,
                  },
                },
                dw_t_operation_plan: [
                  {
                    updated_by: null,
                    update_at: null,
                    process_id: null,
                    month_of_year_date: '2022-05-01',
                    man_month_number: '0.55',
                    dw_m_role: {
                      updated_by: null,
                      update_at: null,
                      process_id: null,
                      role_id: 1,
                      role_name: 'Lead',
                    },
                  },
                ],
                dw_m_personnel_price: [
                  {
                    updated_by: null,
                    update_at: null,
                    process_id: null,
                    contract_pattern_code: 0,
                    price_start_date: '2022-01-01',
                    price_amount: '5625.00',
                    currency_type_code: 0,
                  },
                ],
                dw_m_partner_company: {
                  updated_by: null,
                  update_at: null,
                  process_id: null,
                  company_id: 1,
                  company_name: 'Company 1',
                  contract_pattern_code: 1,
                  dw_m_business_day: [
                    {
                      updated_by: 'test',
                      update_at: '2020-12-31T23:00:00.000Z',
                      process_id: 'test',
                      month_of_year_date: '2021-01-01',
                      business_days_number: 1,
                      created_by: 'test',
                      create_at: '2020-12-31T23:00:00.000Z',
                      process_at: '2020-12-31T23:00:00.000Z',
                    },
                  ],
                },
              },
            },
          ],
        },
      ],
      totalItems: 1,
    },
  },
}
export const operationPlanRepositoryFixture = {
  connection: {
    getRepository: jest.fn().mockReturnValue({
      createQueryBuilder: jest.fn().mockReturnValue({
        delete: jest.fn().mockReturnThis(),
        from: jest.fn().mockReturnThis(),
        select: jest.fn().mockReturnThis(),
        where: jest.fn().mockReturnThis(),
        execute: jest.fn(), // To be mocked in each test
        getManyAndCount: jest.fn(), // To be mocked in each test
        leftJoinAndSelect: jest.fn().mockReturnThis(),
        leftJoin: jest.fn().mockReturnThis(),
        andWhere: jest.fn().mockReturnThis(),
        orderBy: jest.fn().mockReturnThis(),
        skip: jest.fn().mockReturnThis(),
        take: jest.fn().mockReturnThis(),
        innerJoinAndSelect: jest.fn().mockReturnThis(),
        setParameter: jest.fn().mockReturnThis(),
        softDelete: jest.fn().mockReturnThis(),
      }),
    }),
  },

  operationPlanDeleteSuccess: [
    {
      personnel_id: 1,
      project_id: 3,
      month_of_year_date: '2022-01-01',
      role_id: 12,
      man_month_number: 2,
      hours_number: 6,
      created_by: 'Phuong Le',
      create_at: '2022-01-01',
      updated_by: 'Phuong Le',
      update_at: '2022-01-01',
      process_at: '2022-01-01',
      process_id: 'A100',
    },
  ],
}
export const operationPlansFindAllFixture = [
  {
    Dw_t_operation_plan: {
      updated_by: 'Ghaith Hmaied',
      update_at: new Date('2024-04-19'),
      process_id: null,
      deleted_at: null,
      operation_plan_id: 1,
      month_of_year_date: new Date('2022-01-01'),
      man_month_number: 0.25,
      hours_number: 0.5,
      created_by: 'Ghaith Hmaied',
      create_at: new Date('2024-04-19'),
      process_at: new Date('2024-04-19'),
    },
  },
]
export const buildCreateOperationPlanResponseFixture = [
  {
    costAmount: 0,
    createdAt: new Date('2024-04-17'),
    createdBy: 'test',
    hoursNumber: 160,
    manMonthNumber: 1,
    operationPlanId: 1,
    personnelId: undefined,
    processAt: new Date('2024-04-17'),
    processId: null,
    projectId: undefined,
    roleId: 1,
    roleName: 'test',
    updateAt: null,
    updatedBy: null,
    yearOfMonthDate: '2025-04-01',
  },
]

export const buildOperationPlanCreateQueryParamsFixture = [
  {
    created_by: 'SYS USER',
    dw_m_personnel: 1234,
    dw_m_project: 1234,
    dw_m_role: 1234,
    hours_number: 0.5,
    man_month_number: 0.25,
    month_of_year_date: '2022-01-01',
    operation_plan_id: undefined,
    updated_by: 'SYS USER',
  },
]
