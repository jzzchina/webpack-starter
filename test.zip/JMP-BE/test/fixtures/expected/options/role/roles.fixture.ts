import { Dw_m_role } from '../../../../../src/infrastructure/orm/typeorm/entities/Dw_m_role'

export const roles: Dw_m_role[] = [
  {
    role_id: 1,
    role_name: 'Dev',
    created_by: 'Phuong Le',
    create_at: new Date('2022-11-01'),
    updated_by: null,
    update_at: null,
    process_at: new Date('2022-11-01'),
    process_id: null,
  },
  {
    role_id: 2,
    role_name: 'Admin',
    created_by: 'Phuong Le',
    create_at: new Date('2022-11-02'),
    updated_by: null,
    update_at: null,
    process_at: new Date('2022-11-02'),
    process_id: null,
  },
]
