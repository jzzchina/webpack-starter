import { SkillList } from '../../../../src/domain/models/Personnel'

export const personnelsWithOperationPlans = [
  {
    personnel_id: 1,
    dw_m_partner_company: {
      company_id: 1,
      company_name: 'JMP',
      contract_pattern_code: 2,
      dw_m_business_day: [
        {
          month_of_year_date: '2022-01-01',
          business_days_number: 20,
        },
        {
          month_of_year_date: '2022-02-01',
          business_days_number: 22,
        },
      ],
    },
    name: 'Phuong Le',
    name_jpn: 'Phuong Le',
    registered_date: new Date('2010-01-01'),
    unregistered_date: new Date('2023-01-01'),
    skill_list: { Dev: { level: 1 }, Lead: { level: 2 } },
    dw_m_personnel_price: [
      {
        contract_pattern_code: 1,
        price_start_date: new Date('2022-11-27'),
        price_amount: 100,
        currency_type_code: 1,
      },
    ],
    dw_t_operation_plan: [
      {
        month_of_year_date: new Date('2022-01-01'),
        man_month_number: 5,
        hours_number: 2,
        dw_m_project: {
          project_id: 2,
          project_name: 'JMP',
          project_contact: 'JMP@gmail.com',
          project_start_date: new Date('2021-01-01'),
          project_end_date: null,
          notes: null,
        },
        dw_m_role: {
          role_id: 1,
          role_name: 'Admin',
        },
      },
      {
        month_of_year_date: new Date('2022-02-01'),
        man_month_number: 5,
        hours_number: 2,
        dw_m_project: {
          project_id: 2,
          project_name: 'JMP',
          project_contact: 'JMP@gmail.com',
          project_start_date: new Date('2021-01-01'),
          project_end_date: null,
          notes: null,
        },
        dw_m_role: {
          role_id: 1,
          role_name: 'Admin',
        },
      },
      {
        month_of_year_date: new Date('2022-02-01'),
        man_month_number: 6,
        hours_number: 1,
        dw_m_project: {
          project_id: 1,
          project_name: 'JMP',
          project_contact: 'JMP@gmail.com',
          project_start_date: new Date('2021-01-01'),
          project_end_date: null,
          notes: null,
        },
        dw_m_role: {
          role_id: 1,
          role_name: 'Admin',
        },
      },
      {
        month_of_year_date: new Date('2021-12-01'),
        man_month_number: 2,
        hours_number: 1,
        dw_m_project: {
          project_id: 1,
          project_name: 'JMP',
          project_contact: 'JMP@gmail.com',
          project_start_date: new Date('2021-01-01'),
          project_end_date: null,
          notes: null,
        },
        dw_m_role: {
          role_id: 1,
          role_name: 'Admin',
        },
      },
    ],
  },
  {
    personnel_id: 2,
    dw_m_partner_company: {
      company_id: 2,
      company_name: 'JMP',
      contract_pattern_code: 2,
      dw_m_business_day: undefined,
    },
    name: 'Le Phuong',
    name_jpn: 'Le Phuong',
    registered_date: new Date('2010-01-01'),
    unregistered_date: new Date('2023-01-01'),
    skill_list: { Dev: { level: 1 } },
    dw_m_personnel_price: [
      {
        contract_pattern_code: 1,
        price_start_date: new Date('2022-11-27'),
        price_amount: 100,
        currency_type_code: 1,
      },
    ],
  },
]

export const insertPersonnelResult = {
  identifiers: [{ personnel_id: 1 }],
  generatedMaps: [
    {
      personnel_id: 1,
      name_jpn: '見本　太郎',
      unregistered_date: null,
      create_at: '2022-11-30T17:23:52.214Z',
      updated_by: '',
      update_at: '2022-11-30T17:23:52.214Z',
      process_at: '2022-11-30T17:23:52.214Z',
    },
  ],
  raw: {
    fieldCount: 0,
    affectedRows: 1,
    insertId: 0,
    info: '',
    serverStatus: 3,
    warningStatus: 12,
  },
}

export const findManyPersonnel = [
  {
    name_jpn: '見本　太郎',
    unregistered_date: new Date('2022-01-02'),
    updated_by: null,
    update_at: null,
    process_id: null,
    personnel_id: 1,
    name: 'Test User',
    registered_date: new Date('2022-01-01'),
    skill_list: {
      LeadDev: { level: 1 },
      'BackEnd,Node.js': { level: 3 },
      'FrontEnd,Web(React)': { level: 2 },
    },
    dw_m_partner_company: {
      updated_by: null,
      update_at: null,
      process_id: null,
      company_id: 1234,
      company_name: 'Avanade',
      contract_pattern_code: 0,
    },
    dw_m_personnel_price: [],
  },
]
export const findManyUpdatedPersonnel = [
  {
    name_jpn: '見本　太郎',
    unregistered_date: new Date('2022-05-02'),
    updated_by: null,
    update_at: null,
    process_id: null,
    personnel_id: 1,
    name: 'Test User',
    registered_date: new Date('2022-01-01'),
    skill_list: {
      LeadDev: { level: 1 },
      'BackEnd,Node.js': { level: 3 },
      'FrontEnd,Web(React)': { level: 2 },
    },
    dw_m_partner_company: {
      updated_by: null,
      update_at: null,
      process_id: null,
      company_id: 1234,
      company_name: 'Avanade',
      contract_pattern_code: 0,
    },
    dw_m_personnel_price: [],
  },
]

export const updatedPersonnelResponse = [
  {
    personnelId: 1,
    name: 'Test User',
    nameJpn: '見本　太郎',
    registeredDate: new Date('2022-01-01'),
    unregisteredDate: new Date('2022-05-02'),
    companyId: 1234,
    contractPatternCode: 0,
    companyName: 'Avanade',
    createAt: undefined,
    createdBy: undefined,
    skillList: {
      LeadDev: {
        level: 1,
      },
      'FrontEnd,Web(React)': {
        level: 2,
      },
      'BackEnd,Node.js': {
        level: 3,
      },
    } as SkillList,
    prices: [],
  },
]
export const personnelResponse = [
  {
    personnelId: 1,
    name: 'Test User',
    nameJpn: '見本　太郎',
    registeredDate: new Date('2022-01-01'),
    unregisteredDate: new Date('2022-01-02'),
    companyId: 1234,
    contractPatternCode: 0,
    companyName: 'Avanade',
    createAt: undefined,
    createdBy: undefined,
    skillList: {
      LeadDev: {
        level: 1,
      },
      'FrontEnd,Web(React)': {
        level: 2,
      },
      'BackEnd,Node.js': {
        level: 3,
      },
    } as SkillList,
    prices: [],
  },
]
