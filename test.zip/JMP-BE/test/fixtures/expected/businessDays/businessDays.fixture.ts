import { BusinessDaysObject } from '../../../../src/interface/routes/businessDays/dto/businessDays.dto'

type BusinessDaysFixture = {
  expectedBusinessDaysObject: BusinessDaysObject
  expectedEmptyBusinessDaysObject: BusinessDaysObject
}

const businessDaysFixture: BusinessDaysFixture = {
  expectedBusinessDaysObject: {
    '2022-02-02': { businessDaysNumber: 20 },
    '2022-02-03': { businessDaysNumber: 30 },
  },
  expectedEmptyBusinessDaysObject: {},
}
export const buildBusinessDaysListResponseResultFixture = [
  {
    businessDaysNumber: 1,
    companyId: 1,
    monthOfYearDate: '2021-01-01',
  },
]
export default businessDaysFixture
