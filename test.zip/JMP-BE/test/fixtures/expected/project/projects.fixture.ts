const projectsWithOperationPlans = [
  {
    project_id: 1,
    project_name: 'JMP',
    project_contact: 'JMP@gmail.com',
    project_start_date: new Date('2010-01-01'),
    project_end_date: new Date('2023-01-01'),
    notes: null,
    dw_t_operation_plan: [
      {
        month_of_year_date: new Date('2022-01-01'),
        man_month_number: 5,
        hours_number: 2,
        dw_m_role: {
          role_id: 1,
          role_name: 'Dev',
        },
        dw_m_personnel: {
          personnel_id: 1,
          dw_m_partner_company: {
            company_id: 1,
            company_name: 'JMP',
            contract_pattern_code: 2,
          },
          name: 'Phuong Le',
          name_jpn: 'Phuong Le',
          registered_date: new Date('2021-01-01'),
          unregistered_date: new Date('2022-12-31'),
          skill_list: {},
          dw_m_personnel_price: [
            {
              contract_pattern_code: 1,
              price_start_date: new Date('2022-11-27'),
              price_amount: 100,
              currency_type_code: 1,
            },
          ],
          dw_t_operation_plan: [
            {
              month_of_year_date: new Date('2022-01-01'),
              man_month_number: 5,
              hours_number: 2,
              dw_m_project: {
                project_id: 1,
              },
            },
            {
              month_of_year_date: new Date('2022-02-01'),
              man_month_number: 5,
              hours_number: 2,
              dw_m_project: {
                project_id: 1,
              },
            },
            {
              month_of_year_date: new Date('2022-02-01'),
              man_month_number: 6,
              hours_number: 1,
              dw_m_project: {
                project_id: 2,
              },
            },
            {
              month_of_year_date: new Date('2021-12-01'),
              man_month_number: 2,
              hours_number: 1,
              dw_m_project: {
                project_id: 2,
              },
            },
          ],
        },
      },
      {
        month_of_year_date: new Date('2022-02-01'),
        man_month_number: 5,
        hours_number: 2,
        dw_m_role: {
          role_id: 1,
          role_name: 'Dev',
        },
        dw_m_personnel: {
          personnel_id: 1,
          dw_m_partner_company: {
            company_id: 1,
            company_name: 'JMP',
            contract_pattern_code: 2,
          },
          name: 'Phuong Le',
          name_jpn: 'Phuong Le',
          registered_date: new Date('2021-01-01'),
          unregistered_date: new Date('2022-12-31'),
          skill_list: {},
          dw_m_personnel_price: [
            {
              contract_pattern_code: 1,
              price_start_date: new Date('2022-11-27'),
              price_amount: 100,
              currency_type_code: 1,
            },
          ],
          dw_t_operation_plan: [
            {
              month_of_year_date: new Date('2022-01-01'),
              man_month_number: 5,
              hours_number: 2,
              dw_m_project: {
                project_id: 1,
              },
            },
            {
              month_of_year_date: new Date('2022-02-01'),
              man_month_number: 5,
              hours_number: 2,
              dw_m_project: {
                project_id: 1,
              },
            },
            {
              month_of_year_date: new Date('2022-02-01'),
              man_month_number: 6,
              hours_number: 1,
              dw_m_project: {
                project_id: 2,
              },
            },
            {
              month_of_year_date: new Date('2021-12-01'),
              man_month_number: 2,
              hours_number: 1,
              dw_m_project: {
                project_id: 2,
              },
            },
          ],
        },
      },
    ],
  },
  {
    project_id: 2,
    project_name: 'Medicare',
    project_contact: 'Medicare@gmail.com',
    project_start_date: new Date('2020-01-01'),
    project_end_date: null,
    notes: null,
  },
]

export { projectsWithOperationPlans }
