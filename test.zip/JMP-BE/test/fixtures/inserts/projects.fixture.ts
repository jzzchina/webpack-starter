const projectsParams = [
  {
    projectId: 1,
    projectName: 'JMP',
    projectContact: 'user@example.com',
    projectStartDate: '2022-01-01',
    projectEndDate: '2022-12-01',
    note: 'JDPP Project',
  },
  {
    projectId: 2,
    projectName: 'RSOC',
    projectContact: 'user@rsoc.com',
    projectStartDate: '2022-01-01',
    projectEndDate: '2023-12-01',
    note: 'JDPP Project',
  },
]
const projectParams = [
  {
    projectId: 1,
    projectName: 'RSOC',
    projectContact: 'user@example.com',
    projectStartDate: '2022-01-01',
    projectEndDate: '2022-12-01',
    note: 'JDPP Project',
  },
]
export { projectsParams, projectParams }

export const patchProjectCorrectArray = [
  {
    projectId: 1234,
    projectName: 'JMP',
    projectContact: 'user@example.com',
    projectStartDate: '2022-01-01',
    projectEndDate: null,
    note: 'JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
  },
  {
    projectId: 5678,
    projectName: 'JMP-5678',
    projectContact: 'user@example.com',
    projectStartDate: '2022-01-01',
    projectEndDate: null,
    note: '5678 JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
  },
]
export const patchProjectIncorrectArray_multipleValuesForSameProject = [
  {
    projectId: 1234,
    projectName: 'JMP',
    projectContact: 'user@example.com',
    projectStartDate: '2022-01-01',
    projectEndDate: null,
    note: 'JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
  },
  {
    projectId: 1234,
    projectName: 'JMP_2',
    projectContact: 'user@example_2.com',
    projectStartDate: '2022-01-01',
    projectEndDate: null,
    note: '2_JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
  },
]

export const patchProjectIncorrectArray_wrongId = [
  {
    projectId: 'abc',
    projectName: 'JMP',
    projectContact: 'user@example.com',
    projectStartDate: '2022-01-01',
    projectEndDate: null,
    note: 'JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
  },
]
export const patchProjectIncorrectArray_noName = [
  {
    projectId: '1234',
    projectName: '',
    projectContact: 'user@example.com',
    projectStartDate: '2022-01-01',
    projectEndDate: null,
    note: 'JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
  },
]
export const patchProjectIncorrectArray_noContact = [
  {
    projectId: '1234',
    projectName: 'JMP',
    projectContact: '',
    projectStartDate: '2022-01-01',
    projectEndDate: null,
    note: 'JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
  },
]

export const preDeleteProjectsArray = [
  {
    projectId: '2222',
    projectName: 'project to delete 2222',
    projectContact: 'user@example.com',
    projectStartDate: '2022-01-01',
    projectEndDate: null,
    note: 'JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
  },
  {
    projectId: '3333',
    projectName: 'project to delete 3333',
    projectContact: 'user@example.com',
    projectStartDate: '2022-01-01',
    projectEndDate: null,
    note: 'JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
  },
]
export const deleteProjectsIdsArray = [2222, 3333]
