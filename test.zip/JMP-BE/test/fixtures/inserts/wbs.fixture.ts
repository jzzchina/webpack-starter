const searchWbsCostsParams = {
  offset: 0,
  limit: 5,
  from: '',
  to: '',
  companyId: 12345,
}

const wbsCostRepositoryFixture = {
  connection: {
    getRepository: jest.fn().mockReturnValue({
      createQueryBuilder: jest.fn().mockReturnValue({
        delete: jest.fn().mockReturnThis(),
        from: jest.fn().mockReturnThis(),
        select: jest.fn().mockReturnThis(),
        where: jest.fn().mockReturnThis(),
        execute: jest.fn(), // To be mocked in each test
        getManyAndCount: jest.fn(), // To be mocked in each test
        leftJoinAndSelect: jest.fn().mockReturnThis(),
        leftJoin: jest.fn().mockReturnThis(),
        andWhere: jest.fn().mockReturnThis(),
        orderBy: jest.fn().mockReturnThis(),
        skip: jest.fn().mockReturnThis(),
        take: jest.fn().mockReturnThis(),
        innerJoinAndSelect: jest.fn().mockReturnThis(),
        setParameter: jest.fn().mockReturnThis(),
        softDelete: jest.fn().mockReturnThis(),
      }),
    }),
  },
}

export { searchWbsCostsParams, wbsCostRepositoryFixture }
