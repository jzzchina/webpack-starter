import { Dw_m_business_days } from '../../../src/infrastructure/orm/typeorm/entities/Dw_m_business_days'
import { ObjectLiteral } from 'typeorm'

type BusinessDaysFixture = {
  databaseBusinessDays: Dw_m_business_days[]
  emptyDatabaseBusinessDays: Dw_m_business_days[]
}

const businessDaysFixture: BusinessDaysFixture = {
  databaseBusinessDays: [
    {
      business_days_id: 1,
      month_of_year_date: ('2022-02-02' as unknown) as Date, // The value is returned as a string from the database
      business_days_number: 20,
      created_by: 'John Doe',
      create_at: new Date(),
      process_at: new Date(),
      process_id: '123',
      update_at: new Date(),
      updated_by: 'Jane Smith',
      deleted_at: null,
    },
    {
      business_days_id: 2,
      month_of_year_date: ('2022-02-03' as unknown) as Date,
      business_days_number: 30,
      created_by: 'John Doe',
      create_at: new Date(),
      process_at: new Date(),
      process_id: '123',
      update_at: null,
      updated_by: 'Jane Smith',
      deleted_at: null,
    },
  ],
  emptyDatabaseBusinessDays: [],
}
export const creationResult = {
  identifiers: [
    {
      month_of_year_date: '2022-01-01T00:00:00.000Z',
      dw_m_partner_company: 1,
    },
  ],
  generatedMaps: [{}],
  raw: {
    fieldCount: 0,
    affectedRows: 1,
    insertId: 0,
    info: '',
    serverStatus: 2,
    warningStatus: 1,
  },
}
export const businessDaysCreatePayload = [
  {
    dw_m_partner_company: 1,
    month_of_year_date: new Date('2021-01-01'),
    business_days_number: 0,
    created_by: 'Unit Test',
    updated_by: 'Unit Test',
  },
]
export const deleteBusinessDaysPayload = {
  input: {
    successfulDeletion: {
      companyId: 1,
      date: '2021-01-01',
    },
    failedDeletion: {
      companyId: 999,
      date: '1998-01-01',
    },
  },
  response: {
    success: {
      affectedRows: 1,
      rawResponse: {
        fieldCount: 0,
        insertId: 0,
        info: '',
        serverStatus: 2,
        warningStatus: 1,
      },
    },
    error: {
      generatedMaps: [],
      raw: [],
      affected: 0,
    },
  },
}
export const businessDaysInputFixture = {
  result: {
    foundBusinessDays: [
      {
        updated_by: null,
        update_at: null,
        process_id: null,
        month_of_year_date: '2021-01-01',
        business_days_number: 1,
        dw_m_partner_company: {
          updated_by: null,
          update_at: '2022-10-07T22:04:52.254Z',
          process_id: null,
          company_id: 1,
          company_name: 'Test Company',
          contract_pattern_code: 1,
          created_by: 'Unit Test',
          create_at: '2022-10-07T22:04:52.254Z',
          process_at: '2022-10-07T22:04:52.254Z',
        },
      },
    ],
  },
  input: {
    validInput: {
      companyID: 1,
    },
  },
}
export const buildBusinessDaysListDTOResult = [
  {
    business_days_id: 1,
    business_days_number: 1,
    created_by: 'UnitTest User',
    dw_m_partner_company: 1,
    month_of_year_date: '2021-01-01',
    updated_by: 'UnitTest User',
  },
]
export const businessDaysList = [
  {
    businessDaysId: 1,
    companyId: 1,
    monthOfYearDate: '2021-01-01',
    businessDaysNumber: 1,
    createdBy: 'UnitTest User',
    createdAt: '2022-10-07T22:04:52.254Z',
    updatedBy: 'UnitTest User',
    updateAt: '2022-10-07T22:04:52.254Z',
    processAt: '2022-10-07T22:04:52.254Z',
  },
]
export const findAllBusinessDaysPayload = {
  result: {
    foundBusinessDays: [
      {
        updated_by: null,
        update_at: null,
        process_id: null,
        month_of_year_date: '2021-01-01',
        business_days_number: 1,
        dw_m_partner_company: {
          updated_by: null,
          update_at: '2022-10-07T22:04:52.254Z',
          process_id: null,
          company_id: 1,
          company_name: 'Test Company',
          contract_pattern_code: 1,
          created_by: 'Unit Test',
          create_at: '2022-10-07T22:04:52.254Z',
          process_at: '2022-10-07T22:04:52.254Z',
        },
      },
    ],
  },
}
export const businessDayRepositoryConnection = {
  getRepository: jest.fn().mockReturnValue({
    createQueryBuilder: jest.fn().mockReturnValue({
      from: jest.fn().mockReturnThis(),
      select: jest.fn().mockReturnThis(),
      where: jest.fn().mockReturnThis(),
      insert: jest.fn().mockReturnThis(),
      into: jest.fn().mockReturnThis(),
      values: jest.fn().mockReturnThis(),
      orUpdate: jest.fn().mockReturnThis(),
      catch: jest.fn().mockReturnThis(),
      execute: jest.fn(), // To be mocked in each test
      getManyAndCount: jest.fn(), // To be mocked in each test
      leftJoinAndSelect: jest.fn().mockReturnThis(),
      leftJoin: jest.fn().mockReturnThis(),
      andWhere: jest.fn().mockReturnThis(),
      orderBy: jest.fn().mockReturnThis(),
      skip: jest.fn().mockReturnThis(),
      take: jest.fn().mockReturnThis(),
      innerJoinAndSelect: jest.fn().mockReturnThis(),
      setParameter: jest.fn().mockReturnThis(),
      softDelete: jest.fn().mockReturnThis(),
    }),
    save: jest.fn(),
  }),
}
export const businessDaysToInsert = [
  {
    dw_m_partner_company: {
      company_id: 1,
      company_name: '',
      contract_pattern_code: 5,
      created_by: '',
      create_at: new Date('2020-01-01'),
      updated_by: '',
      update_at: null,
      process_at: new Date('2020-01-01'),
      process_id: null,
      deleted_at: null,
    },
    month_of_year_date: new Date('2020-01-01'),
  },
]
export const businessDaysKey = {
  companyId: 1,
  monthOfYearDate: '2020-01-01',
}
export const businessDayDeleteResult = {
  generatedMaps: [],
  raw: {
    fieldCount: 0,
    affectedRows: 1,
    insertId: 0,
    info: 'Rows matched: 1  Changed: 1  Warnings: 0',
    serverStatus: 2,
    warningStatus: 0,
    changedRows: 1,
  },
}
export const businessDayDeleteResultFailed = {
  generatedMaps: [],
  raw: {
    fieldCount: 0,
    affectedRows: 0,
    insertId: 0,
    info: '',
    serverStatus: 2,
    warningStatus: 0,
    changedRows: 1,
  },
}
export const allBusinessDays = [
  {
    company_id: 1,
    month_of_year_date: '2022-01-01',
    business_days_number: 20,
  },
  {
    company_id: 1,
    month_of_year_date: '2022-02-01',
    business_days_number: 22,
  },
]
export const businessDaysKeys = [
    { business_days_id: 1 },
    { business_days_id: 2 },
  ] as ObjectLiteral[],
  nonBusinessDaysKeys = [
    { business_days_id: 999 },
    { business_days_id: 0 },
  ] as ObjectLiteral[]
export const manyBusinessDays = [
  {
    company_id: 1,
    month_of_year_date: '2022-01-01',
    business_days_number: 20,
  },
  {
    company_id: 1,
    month_of_year_date: '2022-02-01',
    business_days_number: 22,
  },
  {
    company_id: 2,
    month_of_year_date: '2022-02-01',
    business_days_number: 22,
  },
]

export default businessDaysFixture
