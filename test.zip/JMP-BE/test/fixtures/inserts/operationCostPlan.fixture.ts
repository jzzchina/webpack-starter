const searchOperationCostPlanParams = {
  offset: 0,
  limit: 10,
  from: '',
  to: '',
  projectId: null,
  companyId: null,
}
const searchOperationCostPlanWithDateAndFiltersParams = {
  offset: 0,
  limit: 10,
  from: '2024-01-01',
  to: '2024-05-01',
  projectId: 1,
  companyId: 1,
}
const invalidSearchOperationCostPlanParams = {
  offset: 0,
  limit: 0,
  from: '',
  to: '',
  projectId: null,
  companyId: null,
}
const operationCostPlanRepositoryFixture = {
  connection: {
    getRepository: jest.fn().mockReturnValue({
      createQueryBuilder: jest.fn().mockReturnValue({
        delete: jest.fn().mockReturnThis(),
        from: jest.fn().mockReturnThis(),
        select: jest.fn().mockReturnThis(),
        where: jest.fn().mockReturnThis(),
        execute: jest.fn(), // To be mocked in each test
        getManyAndCount: jest.fn(), // To be mocked in each test
        leftJoinAndSelect: jest.fn().mockReturnThis(),
        leftJoin: jest.fn().mockReturnThis(),
        andWhere: jest.fn().mockReturnThis(),
        orderBy: jest.fn().mockReturnThis(),
        skip: jest.fn().mockReturnThis(),
        take: jest.fn().mockReturnThis(),
        innerJoinAndSelect: jest.fn().mockReturnThis(),
        setParameter: jest.fn().mockReturnThis(),
        softDelete: jest.fn().mockReturnThis(),
      }),
    }),
  },
}
export {
  searchOperationCostPlanParams,
  invalidSearchOperationCostPlanParams,
  searchOperationCostPlanWithDateAndFiltersParams,
  operationCostPlanRepositoryFixture,
}
