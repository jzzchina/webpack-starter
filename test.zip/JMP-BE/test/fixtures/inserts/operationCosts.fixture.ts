import { InsertResult } from 'typeorm'
import { Dw_t_operation } from '../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation'
import { JwtPayload } from 'jsonwebtoken'
import { CreateOperationCostDto } from '../../../src/interface/routes/operationCost/dto/operationCost.dto'
import { Dw_m_project } from '../../../src/infrastructure/orm/typeorm/entities/Dw_m_project'

const prerequisitePayloads = {
  partnerCompany: [
    {
      company_id: 1234,
      contract_pattern_code: 2,
      company_name: 'Avanade',
      created_by: 1234,
      create_at: '2022-02-02',
      updated_by: 1234,
      update_at: '2022-02-02',
    },
  ],
  project: [
    {
      projectId: 1234,
      projectName: 'JMP',
      projectContact: 'user@example.com',
      projectStartDate: '2022-01-01',
      projectEndDate: null,
      note: 'JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
    },
  ],
  personnel: [
    {
      personnel_id: 1234,
      name: 'Example Taro',
      name_jpn: '見本　太郎',
      registered_date: '2022-01-01',
      unregistered_date: null,

      skill_list: {
        LeadDev: {
          level: 1,
        },
        'FrontEnd,Web(React)': {
          level: 2,
        },
        'BackEnd,Node.js': {
          level: 3,
        },
      },
      created_by: 1234,
      create_at: '2022-02-02',
      updated_by: 1234,
      update_at: '2022-02-02',

      process_at: '2022-02-02',
      process_id: 1,

      dw_m_partner_company: 1234,
    },
  ],
}

const createOperationCostsParams = [
  {
    hoursNumber: 160.5,
    personnelId: 1234,
    projectId: 1234,
    yearOfMonthDate: '2022-01-01',
    costAmount: 0.06,
  },
  // {
  //   personnelId: 2,
  //   projectId: 1,
  //   costAmount: 0.07,
  //   yearOfMonthDate: '2022-01-01',
  //   hoursNumber: 0.04,
  // },
]

const createOperationCosts_InvalidParams_noPersonnel = [
  {
    personnelId: 878787,
    projectId: 1,
    costAmount: 0.06,
    yearOfMonthDate: '2022-01-01',
    hoursNumber: 0.02,
  },
]

const createOperationCosts_InvalidParams_sameResources = [
  {
    personnelId: 1,
    projectId: 1,
    costAmount: 0.06,
    yearOfMonthDate: '2022-01-01',
    hoursNumber: 0.02,
  },
  {
    personnelId: 1,
    projectId: 1,
    costAmount: 0.07,
    yearOfMonthDate: '2022-01-01',
    hoursNumber: 0.04,
  },
]

const updateOperationCostsParams = [
  {
    personnelId: 1,
    projectId: 2,
    costAmount: 0.07,
    yearOfMonthDate: '2022-02-01',
    hoursNumber: 0.08,
  },
  {
    personnelId: 1,
    projectId: 2,
    costAmount: 0,
    yearOfMonthDate: '2022-02-01',
    hoursNumber: 0.08,
  },
]

const deleteOperationCostsParams = [
  {
    personnelId: 1,
    projectId: 1,
    yearOfMonthDate: ('2022-01-01' as unknown) as Date,
  },
  {
    personnelId: 2,
    projectId: 1,
    yearOfMonthDate: ('2022-01-01' as unknown) as Date,
  },
]

const builtOperationCostParams = {
  PersonnelIds: [1, 2],
  ProjectIds: [1, 1],
  YearOfMonths: ['2022-01-01', '2022-01-01'],
}
const insertResult: InsertResult = {
  identifiers: [
    {
      month_of_year_date: '2022-01-01',
      dw_m_personnel: 1,
      dw_m_project: 1,
    },
  ],
  generatedMaps: [],
  raw: [],
}
const updateInsertResult: InsertResult = {
  identifiers: [
    {
      month_of_year_date: '2022-01-01',
      dw_m_personnel: 1,
      dw_m_project: 2,
    },
  ],
  generatedMaps: [],
  raw: [],
}

const userInformation = {
  name: 'Wael Ben Miloud',
  roles: 'Dev',
}

const searchOperationCostsParams = {
  offset: 0,
  limit: 100,
  from: '',
  to: '',
  projectId: null,
  companyId: null,
}

const invalidSearchOperationCostsParams = {
  offset: 0,
  limit: 0,
  from: '',
  to: '',
  projectId: null,
  companyId: null,
}

const CreateOperationCostResponseInputFixture: Partial<Dw_t_operation>[] = [
  {
    operation_id: 1,
    month_of_year_date: ('2024-04-01' as unknown) as Date,
    hours_number: 160,
    cost_amount: 1000,
    created_by: 'test',
    create_at: new Date('2024-04-17'),
    process_at: new Date('2024-04-17'),
    updated_by: 'user',
    update_at: new Date('2024-04-17'),
    process_id: '1234',
  },
]
const inputArrayBody: CreateOperationCostDto[] = [
  {
    hoursNumber: 160.5,
    operationId: 1,
    personnelId: 5,
    projectId: 5,
    yearOfMonthDate: '2022-01-01',
    costAmount: 0.1,
  },
]

const projectsFixture: Dw_m_project[] = [
  {
    project_end_date: null,
    notes: 'Example notes',
    updated_by: null,
    update_at: null,
    created_by: 'User Test',
    create_at: new Date('2024-04-17'),
    process_at: new Date('2024-04-17'),
    project_manager: 'Test User',
    status: 1,
    user_part: 'testing',
    process_id: null,
    deleted_at: null,
    project_id: 1,
    project_name: 'Sample Project',
    project_start_date: new Date('2024-04-17'),
    project_contact: 'contact@example.com',
    project_contact2: 'contact2@example.com',
    project_contact3: 'contact3@example.com',
    project_contact4: 'contact4@example.com',
    dw_t_operation_plan: [
      {
        updated_by: 'User Test',
        update_at: null,
        process_id: '123abc',
        deleted_at: null,
        operation_plan_id: 1,
        month_of_year_date: ('2024-04-01' as unknown) as Date,
        man_month_number: 1,
        hours_number: 160,
        created_by: 'User Test',
        create_at: new Date('2024-04-17'),
        process_at: new Date('2024-04-17'),
        dw_m_personnel: {
          name_jpn: '見本　太郎',
          unregistered_date: null,
          email: 'JhonDoe@Jera.com',
          updated_by: null,
          update_at: null,
          process_id: null,
          deleted_at: null,
          created_by: 'User Test',
          create_at: new Date('2024-04-17'),
          process_at: new Date('2024-04-17'),
          personnel_id: 1,
          name: 'unit test',
          registered_date: new Date('2022-01-01'),
          skill_list: {
            LeadDev: { level: 1 },
            'BackEnd,Node.js': { level: 3 },
            'FrontEnd,Web(React)': { level: 2 },
          },
          dw_t_operation_plan: [
            {
              updated_by: null,
              update_at: null,
              process_id: null,
              process_at: new Date('2024-04-17'),
              deleted_at: null,
              operation_plan_id: 1,
              month_of_year_date: ('2025-04-01' as unknown) as Date,
              man_month_number: 1,
              hours_number: 160,
              created_by: 'unit test',
              create_at: new Date('2024-04-17'),
              dw_m_role: {
                updated_by: null,
                update_at: null,
                process_id: null,
                created_by: 'unit test',
                create_at: new Date('2024-04-17'),
                process_at: new Date('2024-04-17'),
                role_id: 1,
                role_name: 'unit test',
              },
            },
          ],
          dw_t_operation: [
            {
              operation_id: 1,
              month_of_year_date: ('2024-04-01' as unknown) as Date,
              hours_number: 160,
              cost_amount: 1000,
              created_by: 'unit test',
              create_at: new Date('2024-04-17'),
              process_at: new Date('2024-04-17'),
              updated_by: null,
              update_at: null,
              process_id: null,
              deleted_at: null,
            },
          ],
          dw_m_personnel_price: [],
          dw_m_partner_company: {
            updated_by: null,
            update_at: null,
            process_id: null,
            deleted_at: null,
            created_by: 'unit test',
            create_at: new Date('2024-04-17'),
            process_at: new Date('2024-04-17'),
            company_id: 1,
            company_name: 'Company Test',
            contract_pattern_code: 1,
            dw_m_business_day: [
              {
                updated_by: 'Jane Smith',
                update_at: null,
                process_id: '123',
                deleted_at: null,
                business_days_id: 1,
                month_of_year_date: ('2025-04-01' as unknown) as Date,
                business_days_number: 1,
                created_by: 'John Doe',
                create_at: new Date('2022-02-01'),
                process_at: new Date('2022-02-01'),
              },
            ],
          },
        },
      },
    ],
    dw_m_wbs: [
      {
        wbs_id: 1,
        wbs_code: 'WBS Code',
        wbs_title: 'WBS Title',
        subject: 'CAPEX',
        created_by: 'John Doe',
        create_at: new Date('2024-04-16'),
        updated_by: null,
        update_at: new Date('2024-04-16'),
        process_at: new Date('2024-04-16'),
        process_id: 'Process_1',
        deleted_at: null,
      },
    ],
  },
]
const commonFields = {
  totalItems: 2,
  from: '2020-04-01',
  to: '2027-04-30',
  offset: 0,
  limit: 1,
}

const jwtPayload: JwtPayload = {
  aud: 'bdae2666-6b38-4e2a-8c61-da607f4c01df',
  iss:
    'https://login.microsoftonline.com/f700b98b-78fb-4312-8d98-298d62e115c8/v2.0',
  iat: 1673367415,
  nbf: 1673367415,
  exp: 1767979315,
  idp: 'https://sts.windows.net/7ecf1dcb-eca3-4727-8201-49cf4c94b669/',
  name: 'SYS USER',
  nonce: '530bc23c-d122-4c0f-b94e-250e4c6a456d',
  oid: '69bd80c1-e5f9-4826-878b-be30ce00cdee',
  preferred_username: 'sys.user@test.com',
  rh: '0.AVYAi7kA9_t4EkONmCmNYuEVyGYmrr04aypOjGHaYH9MAd9WAJk.',
  roles: ['jmp_admin'],
  sub: 'JNBWwc40oyTGH0LpDN4q-MbnKgyEekuQcBD38ZVr4wM',
  tid: 'f700b98b-78fb-4312-8d98-298d62e115c8',
  uti: 'YNI1fA3miE2fQI7omlYkAA',
  ver: '2.0',
}
export {
  prerequisitePayloads,
  createOperationCostsParams,
  createOperationCosts_InvalidParams_sameResources,
  createOperationCosts_InvalidParams_noPersonnel,
  updateOperationCostsParams,
  deleteOperationCostsParams,
  builtOperationCostParams,
  insertResult,
  updateInsertResult,
  userInformation,
  searchOperationCostsParams,
  invalidSearchOperationCostsParams,
  CreateOperationCostResponseInputFixture,
  jwtPayload,
  inputArrayBody,
  projectsFixture,
  commonFields,
}
