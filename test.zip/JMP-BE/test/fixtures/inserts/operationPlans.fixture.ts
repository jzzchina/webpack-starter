import { InsertResult } from 'typeorm'
import { CreateOperationPlanDto } from '../../../src/interface/routes/operationPlan/dto/operationPlans.dto'
import { Dw_m_personnel } from '../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { Dw_m_project } from '../../../src/infrastructure/orm/typeorm/entities/Dw_m_project'
import { SkillList } from '../../../src/domain/models/Personnel'
import { Dw_t_operation_plan } from '../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import { JwtPayload } from 'jsonwebtoken'

type OperationPlanPersonnelFixture = {
  foundTotalItems: number
  notFoundTotalItems: number
  from: string
  to: string
  offset: number
  databasePersonnel: Dw_m_personnel[]
  emptyPersonnel: Dw_m_personnel[]
}

const createOperationPlansParams = [
  {
    manMonthNumber: 1,
    personnelId: 1,
    projectId: 1,
    roleId: 1,
    yearOfMonthDate: '2022-01-01',
    hoursNumber: 2,
  },
  {
    manMonthNumber: 1,
    personnelId: 2,
    projectId: 1,
    roleId: 1,
    yearOfMonthDate: '2022-01-01',
    hoursNumber: 2,
  },
]

const updateOperationPlansParams = [
  {
    manMonthNumber: 1,
    personnelId: 1,
    projectId: 2,
    roleId: 1,
    yearOfMonthDate: '2022-01-01',
    hoursNumber: 3,
  },
]

const deleteParams = [
  {
    manMonthNumber: 1,
    personnelId: 1,
    projectId: 2,
    roleId: 0,
    yearOfMonthDate: '2022-01-01',
    hoursNumber: 2,
  },
]

const insertResult: InsertResult = {
  identifiers: [
    {
      month_of_year_date: '2022-01-01',
      dw_m_personnel: 1,
      dw_m_project: 1,
    },
    {
      month_of_year_date: '2022-01-01',
      dw_m_personnel: 2,
      dw_m_project: 1,
    },
  ],
  generatedMaps: [],
  raw: [],
}

const userInformation = {
  name: 'Phuong Le',
  roles: 'Dev',
}

const searchOperationPlansParams = {
  offset: 0,
  limit: 10,
  from: '2000-10-10',
  to: '2030-12-12',
  projectId: null,
  companyId: null,
}

const invalidSearchOperationPlansParams = {
  offset: 0,
  limit: 0,
  from: '',
  to: '',
  projectId: null,
  companyId: null,
}

const deleteOperationPlansParams = [
  {
    personnel_id: 1,
    project_id: 1,
    month_of_year_date: '2022-01-01',
  },
]

const skillList = { Dev: { level: 1 } }

const operationPlanPersonnelInputFixture: OperationPlanPersonnelFixture = {
  foundTotalItems: 2,
  notFoundTotalItems: 0,
  from: '2020-04-01',
  to: '2027-04-30',
  offset: 0,
  databasePersonnel: [
    {
      name_jpn: '見本　太郎',
      unregistered_date: null,
      registered_date: new Date('2022-01-01'),
      email: 'JhonDoe@Jera.com',
      updated_by: null,
      update_at: null,
      process_id: null,
      deleted_at: null,
      created_by: 'test',
      create_at: new Date('2024-04-17'),
      process_at: new Date('2024-04-17'),
      personnel_id: 1,
      name: 'unit test',
      skill_list: {
        LeadDev: { level: 1 },
        'BackEnd,Node.js': { level: 3 },
        'FrontEnd,Web(React)': { level: 2 },
      },
      dw_m_partner_company: {
        company_id: 1,
        company_name: 'test',
        contract_pattern_code: 1,
        created_by: 'test',
        create_at: new Date('2024-04-17'),
        process_at: new Date('2024-04-17'),
        updated_by: null,
        update_at: null,
        process_id: null,
        deleted_at: null,
      },
      dw_t_operation: [
        {
          operation_id: 1,
          month_of_year_date: ('2024-04-01' as unknown) as Date,
          hours_number: 160,
          cost_amount: 1000,
          created_by: 'test',
          create_at: new Date('2024-04-17'),
          process_at: new Date('2024-04-17'),
          updated_by: null,
          update_at: null,
          process_id: null,
          deleted_at: null,
        },
      ],
      dw_t_operation_plan: [
        {
          updated_by: null,
          update_at: null,
          process_id: null,
          process_at: new Date('2024-04-17'),
          deleted_at: null,
          operation_plan_id: 1,
          month_of_year_date: ('2025-04-01' as unknown) as Date,
          man_month_number: 1,
          hours_number: 160,
          created_by: 'test',
          create_at: new Date('2024-04-17'),
          dw_m_role: {
            updated_by: null,
            update_at: null,
            process_id: null,
            created_by: 'test',
            create_at: new Date('2024-04-17'),
            process_at: new Date('2024-04-17'),
            role_id: 1,
            role_name: 'test',
          },
        },
      ],
      dw_m_personnel_price: [],
    },
  ],
  emptyPersonnel: [],
}

class OperationPlanMock {
  public static create(): CreateOperationPlanDto[] {
    return [
      {
        manMonthNumber: 0.25,
        personnelId: 1234,
        projectId: 1234,
        roleId: 1234,
        yearOfMonthDate: '2022-01-01',
        hoursNumber: 0.5,
      } as CreateOperationPlanDto,
    ]
  }

  public static getOne() {
    return {
      costAmount: '0.060',
      manMonthNumber: '0.25',
      hoursNumber: '0.500',
      personnelId: 1234,
      projectId: 1234,
      yearOfMonthDate: '2022-01-01',
      roleId: 1234,
      roleName: 'LeadDev',
      createdBy: 'test',
      createdAt: '2022-12-28T17:39:31.342Z',
      updatedBy: 'test',
      updateAt: '2022-12-28T17:39:31.342Z',
      processAt: '2022-12-28T17:39:31.342Z',
      processId: null,
    }
  }

  public static skillList() {
    return {
      skills: {
        LeadDev: {
          level: 1,
        },
        'FrontEnd,Web(React)': {
          level: 2,
        },
        'BackEnd,Node.js': {
          level: 3,
        },
      },
    }
  }

  public static query() {
    return {
      limit: 100,
      offset: 0,
      project_id: 1234,
      company_id: 1234,
    }
  }

  public static getPersonnelResponse() {
    return {
      offset: 0,
      length: 1,
      totalLength: 1,
      items: [
        {
          companyId: 1234,
          contractPatternCode: 2,
          companyName: 'Avanade',
          personnelId: 1234,
          name: 'Example Taro',
          nameJpn: '見本　太郎',
          registeredDate: '2022-01-01',
          unregisteredDate: null,
          skillList: {
            LeadDev: {
              level: 1,
            },
            'BackEnd,Node.js': {
              level: 3,
            },
            'FrontEnd,Web(React)': {
              level: 2,
            },
          },
          prices: [],
          totals: {
            operationPlans: {
              '2022-01-01': {
                manMonthNumber: 0.25,
              },
            },
          },
          allProjectIds: [1234],
          projects: [
            {
              projectId: 1234,
              projectName: 'JMP',
              projectContact: 'user@example.com',
              projectStartDate: '2022-01-01',
              projectEndDate: null,
              note:
                'JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
              roleId: 1234,
              roleName: 'LeadDev',
              operationPlans: {
                '2022-01-01': {
                  manMonthNumber: 0.25,
                  roleId: 1234,
                  roleName: 'LeadDev',
                },
              },
            },
          ],
        },
      ],
    }
  }

  public static getProjectResponse() {
    return {
      offset: 0,
      length: 1,
      totalLength: 1,
      items: [
        {
          projectId: 1234,
          projectName: 'JMP',
          projectContact: 'user@example.com',
          projectStartDate: '2022-01-01',
          projectEndDate: null,
          note:
            'JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
          totals: {
            operationPlans: {
              '2022-01-01': {
                manMonthNumber: 0.25,
              },
            },
          },
          allPersonnelIds: [1234],
          personnel: [
            {
              companyId: 1234,
              contractPatternCode: 2,
              companyName: 'Avanade',
              personnelId: 1234,
              name: 'Example Taro',
              nameJpn: '見本　太郎',
              registeredDate: '2022-01-01',
              unregisteredDate: null,
              skillList: {
                LeadDev: {
                  level: 1,
                },
                'BackEnd,Node.js': {
                  level: 3,
                },
                'FrontEnd,Web(React)': {
                  level: 2,
                },
              },
              prices: [],
              operationPlans: {
                '2022-01-01': {
                  manMonthNumber: 0.25,
                  roleId: 1234,
                  roleName: 'LeadDev',
                },
              },
            },
          ],
        },
      ],
    }
  }
}

type OperationPlanFixture = {
  foundTotalItems: number
  notFoundTotalItems: number
  from: string
  to: string
  offset: number
  databaseProjects: Dw_m_project[]
  emptyProject: Dw_m_project[]
}

// Note: I am using as unknown as Date because some dates are returned as strings from the database
const buildOperationPlanProjectPayload: OperationPlanFixture = {
  foundTotalItems: 2,
  notFoundTotalItems: 0,
  from: '2020-04-01',
  to: '2027-04-30',
  offset: 0,
  databaseProjects: [
    {
      project_end_date: null,
      notes: 'Example notes',
      updated_by: null,
      update_at: null,
      created_by: 'test',
      create_at: new Date('2024-04-17'),
      process_at: new Date('2024-04-17'),
      project_manager: 'test',
      status: 1,
      user_part: 'test',
      process_id: null,
      deleted_at: null,
      project_id: 1,
      project_name: 'Sample Project',
      project_start_date: new Date('2024-04-17'),
      project_contact: 'contact1@example.com',
      project_contact2: 'contact1@example.com',
      project_contact3: 'contact2@example.com',
      project_contact4: 'contact3@example.com',
      dw_t_operation_plan: [
        {
          updated_by: 'test',
          update_at: null,
          process_id: '123abc',
          deleted_at: null,
          operation_plan_id: 1,
          month_of_year_date: ('2024-04-01' as unknown) as Date,
          man_month_number: 1,
          hours_number: 160,
          created_by: 'test',
          create_at: new Date('2024-04-17'),
          process_at: new Date('2024-04-17'),
          dw_m_personnel: {
            name_jpn: '見本　太郎',
            unregistered_date: null,
            email: 'JhonDoe@Jera.com',
            updated_by: null,
            update_at: null,
            process_id: null,
            deleted_at: null,
            created_by: 'test',
            create_at: new Date('2024-04-17'),
            process_at: new Date('2024-04-17'),
            personnel_id: 1,
            name: 'unit test',
            registered_date: new Date('2022-01-01'),
            skill_list: {
              LeadDev: { level: 1 },
              'BackEnd,Node.js': { level: 3 },
              'FrontEnd,Web(React)': { level: 2 },
            },
            dw_t_operation_plan: [
              {
                updated_by: null,
                update_at: null,
                process_id: null,
                process_at: new Date('2024-04-17'),
                deleted_at: null,
                operation_plan_id: 1,
                month_of_year_date: ('2025-04-01' as unknown) as Date,
                man_month_number: 1,
                hours_number: 160,
                created_by: 'test',
                create_at: new Date('2024-04-17'),
                dw_m_role: {
                  updated_by: null,
                  update_at: null,
                  process_id: null,
                  created_by: 'test',
                  create_at: new Date('2024-04-17'),
                  process_at: new Date('2024-04-17'),
                  role_id: 1,
                  role_name: 'test',
                },
              },

              {
                updated_by: null,
                update_at: null,
                process_id: null,
                process_at: new Date('2024-04-17'),
                deleted_at: null,
                operation_plan_id: 2,
                month_of_year_date: ('2025-04-01' as unknown) as Date,
                man_month_number: 2,
                hours_number: 160,
                created_by: 'test',
                create_at: new Date('2024-04-17'),
                dw_m_role: {
                  updated_by: null,
                  update_at: null,
                  process_id: null,
                  created_by: 'test',
                  create_at: new Date('2024-04-17'),
                  process_at: new Date('2024-04-17'),
                  role_id: 1,
                  role_name: 'test',
                },
              },
            ],
            dw_t_operation: [
              {
                operation_id: 1,
                month_of_year_date: ('2024-04-01' as unknown) as Date,
                hours_number: 160,
                cost_amount: 1000,
                created_by: 'test',
                create_at: new Date('2024-04-17'),
                process_at: new Date('2024-04-17'),
                updated_by: null,
                update_at: null,
                process_id: null,
                deleted_at: null,
              },
            ],
            dw_m_personnel_price: [],
            dw_m_partner_company: {
              updated_by: null,
              update_at: null,
              process_id: null,
              deleted_at: null,
              created_by: 'test',
              create_at: new Date('2024-04-17'),
              process_at: new Date('2024-04-17'),
              company_id: 1,
              company_name: 'test',
              contract_pattern_code: 1,
              dw_m_business_day: [
                {
                  updated_by: 'Jane Smith',
                  update_at: null,
                  process_id: '123',
                  deleted_at: null,
                  business_days_id: 1,
                  month_of_year_date: ('2025-04-01' as unknown) as Date,
                  business_days_number: 1,
                  created_by: 'John Doe',
                  create_at: new Date('2022-02-01'),
                  process_at: new Date('2022-02-01'),
                },
              ],
            },
          },
        },
        {
          updated_by: 'test',
          update_at: null,
          process_id: '123abc',
          deleted_at: null,
          operation_plan_id: 1,
          month_of_year_date: ('2024-04-01' as unknown) as Date,
          man_month_number: 1,
          hours_number: 160,
          created_by: 'test',
          create_at: new Date('2024-04-17'),
          process_at: new Date('2024-04-17'),
          dw_m_personnel: {
            name_jpn: '見本　太郎',
            unregistered_date: null,
            email: 'JhonDoe@Jera.com',
            updated_by: null,
            update_at: null,
            process_id: null,
            deleted_at: null,
            created_by: 'test',
            create_at: new Date('2024-04-17'),
            process_at: new Date('2024-04-17'),
            personnel_id: 1,
            name: 'unit test',
            registered_date: new Date('2022-01-01'),
            skill_list: {
              LeadDev: { level: 1 },
              'BackEnd,Node.js': { level: 3 },
              'FrontEnd,Web(React)': { level: 2 },
            },
            dw_t_operation_plan: [
              {
                updated_by: null,
                update_at: null,
                process_id: null,
                process_at: new Date('2024-04-17'),
                deleted_at: null,
                operation_plan_id: 1,
                month_of_year_date: ('2025-04-01' as unknown) as Date,
                man_month_number: 1,
                hours_number: 160,
                created_by: 'test',
                create_at: new Date('2024-04-17'),
                dw_m_role: {
                  updated_by: null,
                  update_at: null,
                  process_id: null,
                  created_by: 'test',
                  create_at: new Date('2024-04-17'),
                  process_at: new Date('2024-04-17'),
                  role_id: 1,
                  role_name: 'test',
                },
              },

              {
                updated_by: null,
                update_at: null,
                process_id: null,
                process_at: new Date('2024-04-17'),
                deleted_at: null,
                operation_plan_id: 2,
                month_of_year_date: ('2025-04-01' as unknown) as Date,
                man_month_number: 2,
                hours_number: 160,
                created_by: 'test',
                create_at: new Date('2024-04-17'),
                dw_m_role: {
                  updated_by: null,
                  update_at: null,
                  process_id: null,
                  created_by: 'test',
                  create_at: new Date('2024-04-17'),
                  process_at: new Date('2024-04-17'),
                  role_id: 1,
                  role_name: 'test',
                },
              },
            ],
            dw_t_operation: [
              {
                operation_id: 1,
                month_of_year_date: ('2024-04-01' as unknown) as Date,
                hours_number: 160,
                cost_amount: 1000,
                created_by: 'test',
                create_at: new Date('2024-04-17'),
                process_at: new Date('2024-04-17'),
                updated_by: null,
                update_at: null,
                process_id: null,
                deleted_at: null,
              },
            ],
            dw_m_personnel_price: [],
            dw_m_partner_company: {
              updated_by: null,
              update_at: null,
              process_id: null,
              deleted_at: null,
              created_by: 'test',
              create_at: new Date('2024-04-17'),
              process_at: new Date('2024-04-17'),
              company_id: 1,
              company_name: 'test',
              contract_pattern_code: 1,
              dw_m_business_day: [
                {
                  updated_by: 'Jane Smith',
                  update_at: null,
                  process_id: '123',
                  deleted_at: null,
                  business_days_id: 1,
                  month_of_year_date: ('2025-04-01' as unknown) as Date,
                  business_days_number: 1,
                  created_by: 'John Doe',
                  create_at: new Date('2022-02-01'),
                  process_at: new Date('2022-02-01'),
                },
              ],
            },
          },
        },
      ],
    },
    {
      project_end_date: null,
      notes: 'Example notes',
      updated_by: null,
      update_at: null,
      created_by: 'test',
      create_at: new Date('2024-04-17'),
      process_at: new Date('2024-04-17'),
      project_manager: 'test',
      status: 1,
      user_part: 'test',
      process_id: null,
      deleted_at: null,
      project_id: 1,
      project_name: 'Sample Project',
      project_start_date: new Date('2024-04-17'),
      project_contact: 'contact1@example.com',
      project_contact2: 'contact1@example.com',
      project_contact3: 'contact2@example.com',
      project_contact4: 'contact3@example.com',
      dw_t_operation_plan: [],
    },
  ],
  emptyProject: [],
}
const deleteResult = {
  generatedMaps: [],
  raw: {
    fieldCount: 0,
    affectedRows: 1,
    insertId: 0,
    info: 'Rows matched: 1  Changed: 1  Warnings: 0',
    serverStatus: 2,
    warningStatus: 0,
    changedRows: 1,
  },
}
const operationPlanNotExist = [
  {
    personnel_id: 3,
    project_id: 5,
    month_of_year_date: '2022-01-01',
    role_id: 12,
    man_month_number: 2,
    hours_number: 6,
    created_by: 'Phuong Le',
    create_at: '2022-01-01',
    updated_by: 'Phuong Le',
    update_at: '2022-01-01',
    process_at: '2022-01-01',
    process_id: 'A100',
  },
]
const notMatchedDeleteResult = {
  generatedMaps: [],
  raw: {
    fieldCount: 0,
    affectedRows: 0,
    insertId: 0,
    info: 'Rows matched: 0 Changed: 0  Warnings: 0',
    serverStatus: 2,
    warningStatus: 0,
    changedRows: 1,
  },
}
const personnel = [
  {
    personnel_id: 1,
    dw_m_partner_company: {
      company_id: 1,
      company_name: 'JMP',
      contract_pattern_code: 2,
      dw_m_business_day: [
        {
          month_of_year_date: '2022-01-01',
          business_days_number: 20,
        },
        {
          month_of_year_date: '2022-02-01',
          business_days_number: 22,
        },
      ],
    },
    name: 'Phuong Le',
    name_jpn: 'Phuong Le',
    registered_date: new Date('2010-01-01'),
    unregistered_date: new Date('2023-01-01'),
    skill_list: { Dev: { level: 1 }, Lead: { level: 2 } },
    dw_m_personnel_price: [
      {
        contract_pattern_code: 1,
        price_start_date: new Date('2022-11-27'),
        price_amount: 100,
        currency_type_code: 1,
      },
    ],
    dw_t_operation_plan: [
      {
        month_of_year_date: new Date('2022-01-01'),
        man_month_number: 5,
        hours_number: 2,
        dw_m_project: {
          project_id: 2,
          project_name: 'JMP',
          project_contact: 'JMP@gmail.com',
          project_start_date: new Date('2021-01-01'),
          project_end_date: null,
          notes: null,
        },
        dw_m_role: {
          role_id: 1,
          role_name: 'Admin',
        },
      },
      {
        month_of_year_date: new Date('2022-02-01'),
        man_month_number: 5,
        hours_number: 2,
        dw_m_project: {
          project_id: 2,
          project_name: 'JMP',
          project_contact: 'JMP@gmail.com',
          project_start_date: new Date('2021-01-01'),
          project_end_date: null,
          notes: null,
        },
        dw_m_role: {
          role_id: 1,
          role_name: 'Admin',
        },
      },
      {
        month_of_year_date: new Date('2022-02-01'),
        man_month_number: 6,
        hours_number: 1,
        dw_m_project: {
          project_id: 1,
          project_name: 'JMP',
          project_contact: 'JMP@gmail.com',
          project_start_date: new Date('2021-01-01'),
          project_end_date: null,
          notes: null,
        },
        dw_m_role: {
          role_id: 1,
          role_name: 'Admin',
        },
      },
      {
        month_of_year_date: new Date('2021-12-01'),
        man_month_number: 2,
        hours_number: 1,
        dw_m_project: {
          project_id: 1,
          project_name: 'JMP',
          project_contact: 'JMP@gmail.com',
          project_start_date: new Date('2021-01-01'),
          project_end_date: null,
          notes: null,
        },
        dw_m_role: {
          role_id: 1,
          role_name: 'Admin',
        },
      },
    ],
  },
  {
    personnel_id: 2,
    dw_m_partner_company: {
      company_id: 2,
      company_name: 'JMP',
      contract_pattern_code: 2,
      dw_m_business_day: [
        {
          month_of_year_date: '2022-01-01',
          business_days_number: 20,
        },
        {
          month_of_year_date: '2022-02-01',
          business_days_number: 22,
        },
      ],
    },
    name: 'Le Phuong',
    name_jpn: 'Le Phuong',
    registered_date: new Date('2010-01-01'),
    unregistered_date: new Date('2023-01-01'),
    skill_list: { Dev: { level: 1 } },
    dw_m_personnel_price: [
      {
        contract_pattern_code: 1,
        price_start_date: new Date('2022-11-27'),
        price_amount: 100,
        currency_type_code: 1,
      },
    ],
  },
]
const personnelWithFilter = [
  {
    personnel_id: 1,
    dw_m_partner_company: {
      company_id: 1,
      company_name: 'JMP',
      contract_pattern_code: 2,
      dw_m_business_day: [
        {
          month_of_year_date: '2022-01-01',
          business_days_number: 20,
        },
        {
          month_of_year_date: '2022-02-01',
          business_days_number: 22,
        },
      ],
    },
    name: 'Phuong Le',
    name_jpn: 'Phuong Le',
    registered_date: new Date('2010-01-01'),
    unregistered_date: new Date('2023-01-01'),
    skill_list: { Dev: { level: 1 }, Lead: { level: 2 } },
    dw_m_personnel_price: [
      {
        contract_pattern_code: 1,
        price_start_date: new Date('2022-11-27'),
        price_amount: 100,
        currency_type_code: 1,
      },
    ],
    dw_t_operation_plan: [
      {
        month_of_year_date: new Date('2022-01-01'),
        man_month_number: 5,
        hours_number: 2,
        dw_m_project: {
          project_id: 2,
          project_name: 'JMP',
          project_contact: 'JMP@gmail.com',
          project_start_date: new Date('2021-01-01'),
          project_end_date: null,
          notes: null,
        },
        dw_m_role: {
          role_id: 1,
          role_name: 'Admin',
        },
      },
      {
        month_of_year_date: new Date('2022-02-01'),
        man_month_number: 5,
        hours_number: 2,
        dw_m_project: {
          project_id: 2,
          project_name: 'JMP',
          project_contact: 'JMP@gmail.com',
          project_start_date: new Date('2021-01-01'),
          project_end_date: null,
          notes: null,
        },
        dw_m_role: {
          role_id: 1,
          role_name: 'Admin',
        },
      },
      {
        month_of_year_date: new Date('2022-02-01'),
        man_month_number: 6,
        hours_number: 1,
        dw_m_project: {
          project_id: 1,
          project_name: 'JMP',
          project_contact: 'JMP@gmail.com',
          project_start_date: new Date('2021-01-01'),
          project_end_date: null,
          notes: null,
        },
        dw_m_role: {
          role_id: 1,
          role_name: 'Admin',
        },
      },
      {
        month_of_year_date: new Date('2021-12-01'),
        man_month_number: 2,
        hours_number: 1,
        dw_m_project: {
          project_id: 1,
          project_name: 'JMP',
          project_contact: 'JMP@gmail.com',
          project_start_date: new Date('2021-01-01'),
          project_end_date: null,
          notes: null,
        },
        dw_m_role: {
          role_id: 1,
          role_name: 'Admin',
        },
      },
    ],
  },
]

const from = '2010-01-01'
const to = '2023-01-01'
const undefinedSkillList = (undefined as unknown) as SkillList
const skillListWithoutLevel = ({
  LeadDev: {
    level: undefined,
  },
} as unknown) as SkillList

const dwOperationPlanFixture: Partial<Dw_t_operation_plan>[] = [
  {
    updated_by: null,
    update_at: null,
    process_id: null,
    process_at: new Date('2024-04-17'),
    deleted_at: null,
    operation_plan_id: 1,
    month_of_year_date: ('2025-04-01' as unknown) as Date,
    man_month_number: 1,
    hours_number: 160,
    created_by: 'test',
    create_at: new Date('2024-04-17'),
    dw_m_role: {
      updated_by: null,
      update_at: null,
      process_id: null,
      created_by: 'test',
      create_at: new Date('2024-04-17'),
      process_at: new Date('2024-04-17'),
      role_id: 1,
      role_name: 'test',
    },
  },
]

const arrayBodyOperationPlanDto = [
  {
    manMonthNumber: 0.25,
    personnelId: 1234,
    projectId: 1234,
    roleId: 1234,
    yearOfMonthDate: '2022-01-01',
    hoursNumber: 0.5,
  } as CreateOperationPlanDto,
]

const jwtPayload: JwtPayload = {
  aud: 'bdae2666-6b38-4e2a-8c61-da607f4c01df',
  iss:
    'https://login.microsoftonline.com/f700b98b-78fb-4312-8d98-298d62e115c8/v2.0',
  iat: 1673367415,
  nbf: 1673367415,
  exp: 1767979315,
  idp: 'https://sts.windows.net/7ecf1dcb-eca3-4727-8201-49cf4c94b669/',
  name: 'SYS USER',
  nonce: '530bc23c-d122-4c0f-b94e-250e4c6a456d',
  oid: '69bd80c1-e5f9-4826-878b-be30ce00cdee',
  preferred_username: 'sys.user@test.com',
  rh: '0.AVYAi7kA9_t4EkONmCmNYuEVyGYmrr04aypOjGHaYH9MAd9WAJk.',
  roles: ['jmp_admin'],
  sub: 'JNBWwc40oyTGH0LpDN4q-MbnKgyEekuQcBD38ZVr4wM',
  tid: 'f700b98b-78fb-4312-8d98-298d62e115c8',
  uti: 'YNI1fA3miE2fQI7omlYkAA',
  ver: '2.0',
}

export {
  personnel,
  personnelWithFilter,
  from,
  to,
  undefinedSkillList,
  skillListWithoutLevel,
  notMatchedDeleteResult,
  deleteResult,
  operationPlanNotExist,
  deleteOperationPlansParams,
  searchOperationPlansParams,
  invalidSearchOperationPlansParams,
  skillList,
  createOperationPlansParams,
  updateOperationPlansParams,
  deleteParams,
  insertResult,
  userInformation,
  operationPlanPersonnelInputFixture,
  OperationPlanMock,
  buildOperationPlanProjectPayload,
  dwOperationPlanFixture,
  arrayBodyOperationPlanDto,
  jwtPayload,
}
