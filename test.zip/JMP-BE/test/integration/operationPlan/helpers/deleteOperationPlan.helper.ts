import { OperationPlanRepositories } from './prepareRepositories.helper'

export interface DeleteOperationPlan {
  personnelId: number
  projectId: number
  yearOfMonthDate: string
}

// * A helper function to delete the created operation plan
const deleteOperationPlan = async (
  repositories: OperationPlanRepositories,
  createdOperationPlan: DeleteOperationPlan
): Promise<void> => {
  await repositories.operationPlanDBRepo
    .createQueryBuilder('dw_t_operation_plan')
    .delete()
    .where('personnel_id=:personnel_id', {
      personnel_id: createdOperationPlan.personnelId,
    })
    .andWhere('project_id=:project_id', {
      project_id: createdOperationPlan.projectId,
    })
    .andWhere('month_of_year_date=:month_of_year_date', {
      month_of_year_date: createdOperationPlan.yearOfMonthDate,
    })
    .execute()
}

export default deleteOperationPlan
