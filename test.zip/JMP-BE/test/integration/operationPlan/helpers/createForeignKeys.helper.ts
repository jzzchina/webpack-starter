import { Dw_m_personnel } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel'
import fixture from '../operationPlan.fixture'
import { OperationPlanRepositories } from './prepareRepositories.helper'

export interface OperationPlanForeignKeys {
  companyId: number
  personnelId: number
  projectId: number
  roleId: number
}

// A Helper function that creates all the foreign keys for the operationPlan and returns the ids
const createForeignKeys = async (
  repositories: OperationPlanRepositories,
  personnelObject: any
): Promise<OperationPlanForeignKeys> => {
  // * We need to create a partnerCompany, so we can create a personnel
  const partnerCompanyFixture = fixture.create.partnerCompany
  const partnerCompany = await repositories.partnerCompanyRepo.save(
    partnerCompanyFixture
  )
  const companyId = partnerCompany.company_id

  // * Create a personnel
  let personnelFixture = fixture.create.personnel
  personnelFixture.dw_m_partner_company = companyId // * Set the partnerCompanyID
  if (personnelObject) {
    delete personnelFixture.personnel_id
    personnelFixture = Object.assign(personnelFixture, personnelObject)
  }
  const castedPersonnelFixture = (personnelFixture as unknown) as Dw_m_personnel
  const personnel = await repositories.personnelRepo.save(
    castedPersonnelFixture
  )
  const personnelId = personnel.personnel_id

  // * Create a project
  const projectFixture = fixture.create.project
  const project = await repositories.projectRepo.save(projectFixture)
  const projectId = project.project_id

  // * Create a role
  const roleFixture = fixture.create.role
  const role = await repositories.roleRepo.save(roleFixture)
  const roleId = role.role_id

  return { companyId, personnelId, projectId, roleId }
}

export default createForeignKeys
