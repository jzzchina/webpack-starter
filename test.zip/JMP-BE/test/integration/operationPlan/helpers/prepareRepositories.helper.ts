import { Connection, Repository } from 'typeorm'
import { OperationPlanRepositoryPort } from '../../../../src/application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { Dw_m_business_days } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_business_days'
import { Dw_m_partner_company } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_partner_company'
import { Dw_m_personnel } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { Dw_m_project } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_project'
import { Dw_m_role } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_role'
import { Dw_t_operation_plan } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import { operationPlanRepositoryMySQL } from '../../../../src/infrastructure/repositories/operationPlan/operationPlanRepositoryMySQL'
import { OperationCostRepositoryPort } from '../../../../src/application/port/repositories/operationCost/OperationCostRepositoryPort'
import { operationCostRepositoryMySQL } from '../../../../src/infrastructure/repositories/operationCost/operationCostRepositoryMySQL'

export interface OperationPlanRepositories {
  operationPlanRepository: OperationPlanRepositoryPort
  operationPlanDBRepo: Repository<Dw_t_operation_plan>
  personnelRepo: Repository<Dw_m_personnel>
  projectRepo: Repository<Dw_m_project>
  roleRepo: Repository<Dw_m_role>
  businessDaysDBRepo: Repository<Dw_m_business_days>
  partnerCompanyRepo: Repository<Dw_m_partner_company>
  operationCostRepository: OperationCostRepositoryPort
}

// * A function that prepares the repositories for the tests
const prepareRepositories = async (
  connection: Connection
): Promise<OperationPlanRepositories> => {
  const operationPlanRepository: OperationPlanRepositoryPort = await operationPlanRepositoryMySQL(
    connection
  )
  const operationPlanDBRepo: Repository<Dw_t_operation_plan> = await connection.getRepository(
    Dw_t_operation_plan
  )
  const businessDaysDBRepo: Repository<Dw_m_business_days> = await connection.getRepository(
    Dw_m_business_days
  )
  const personnelRepo: Repository<Dw_m_personnel> = await connection.getRepository(
    Dw_m_personnel
  )
  const projectRepo: Repository<Dw_m_project> = await connection.getRepository(
    Dw_m_project
  )
  const roleRepo: Repository<Dw_m_role> = await connection.getRepository(
    Dw_m_role
  )
  const partnerCompanyRepo: Repository<Dw_m_partner_company> = connection.getRepository(
    Dw_m_partner_company
  )
  const operationCostRepository: OperationCostRepositoryPort = await operationCostRepositoryMySQL(
    connection
  )

  const repositories = {
    operationPlanRepository,
    operationPlanDBRepo,
    personnelRepo,
    projectRepo,
    roleRepo,
    partnerCompanyRepo,
    businessDaysDBRepo,
    operationCostRepository,
  }

  return repositories
}

export default prepareRepositories
