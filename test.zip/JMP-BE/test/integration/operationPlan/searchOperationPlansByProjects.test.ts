import { Connection } from 'typeorm'
import express from 'express'
import { authGenerator } from '../common/authGenerator'
import { createApp } from '../../../src/infrastructure/webserver/express/app'
import { createConnection } from '../../../src/infrastructure/orm/typeorm/connection'
import { createRouter } from '../../../src/infrastructure/webserver/express/routes'
import request from 'supertest'
import prepareRepositories, {
  OperationPlanRepositories,
} from './helpers/prepareRepositories.helper'
import createForeignKeys, {
  OperationPlanForeignKeys,
} from './helpers/createForeignKeys.helper'
import fixture from './operationPlan.fixture'
import { Dw_t_operation_plan } from '../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import deleteOperationPlan, {
  DeleteOperationPlan,
} from './helpers/deleteOperationPlan.helper'
import { HeaderAuth } from '../../../src/domain/types/common.type'
import { requestQueryOperationByProject } from '../../../src/domain/types/operationPlan.type'
import { SkillList } from '../../../src/domain/models/Personnel'
import { Repositories } from '../../../src/application/port'
import {
  OperationPlanPersonnel,
  OperationPlanProject,
} from '../../../src/infrastructure/repositories/operationPlan/interface'

describe('TEST - Search operation plan by projects API', () => {
  let repositories: OperationPlanRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(() => {
    connection.close()
  })

  let requestQuery: requestQueryOperationByProject
  let WrongRequestQuery: requestQueryOperationByProject
  let requestBody: SkillList
  let foreignKeys: OperationPlanForeignKeys
  let insertedOperationPlan: Dw_t_operation_plan

  beforeEach(async () => {
    const personnelObject = fixture.create.personnel
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories, personnelObject)
    const { companyId, personnelId, projectId, roleId } = foreignKeys

    // * Prepare the item to be searched
    const operationPlanFixture = fixture.delete.operationPlan
    operationPlanFixture.dw_m_personnel = personnelId
    operationPlanFixture.dw_m_project = projectId
    operationPlanFixture.dw_m_role = roleId

    // * Insert the item
    insertedOperationPlan = await repositories.operationPlanDBRepo.save(
      (operationPlanFixture as unknown) as Dw_t_operation_plan
    )

    // * Prepare the request query
    const requestQueryFixture = fixture.searchBy.query
    const wrongRequestQueryFixture = fixture.searchBy.wrongQuery
    requestQueryFixture.project_id = projectId
    requestQueryFixture.company_id = companyId

    requestQuery = requestQueryFixture
    requestBody = (fixture.searchBy.skillList as unknown) as SkillList
    WrongRequestQuery = wrongRequestQueryFixture as requestQueryOperationByProject
  })

  afterEach(async () => {
    // * Delete the created operation plan
    const createdOperationPlan: DeleteOperationPlan = {
      personnelId: (insertedOperationPlan.dw_m_personnel as unknown) as number,
      projectId: (insertedOperationPlan.dw_m_project as unknown) as number,
      yearOfMonthDate: insertedOperationPlan.month_of_year_date.toString(),
    }
    await deleteOperationPlan(repositories, createdOperationPlan)
    // * Remove foreign keyss
    await removeForeignKeys(repositories, foreignKeys)
  })

  it('POST: /operation-plans/projects 200', async () => {
    const response = await request(app)
      .post('/operation-plans/projects')
      .query(requestQuery)
      .send(requestBody)
      .set(auth)
    const responseBody = response.body

    const expectedStatusCode = 200
    const expectedResponseFields = [
      'from',
      'to',
      'offset',
      'length',
      'totalLength',
      'items',
    ]

    const expectedItemsFields = [
      'projectId',
      'projectName',
      'projectContact',
      'projectContact2',
      'projectContact3',
      'projectContact4',
      'projectStartDate',
      'projectEndDate',
      'note',
      'totals',
      'allPersonnelIds',
      'personnel',
    ]

    const expectedPersonnelFields = [
      'companyId',
      'contractPatternCode',
      'companyName',
      'personnelId',
      'name',
      'nameJpn',
      'registeredDate',
      'unregisteredDate',
      'operation',
      'skillList',
      'prices',
      'businessDays',
      'operationPlans',
    ]

    // * Checking the Status Code
    expect(response.status).toBe(expectedStatusCode)
    // * Checking the response fields
    expect(Object.keys(responseBody)).toEqual(expectedResponseFields)
    // * Checking the items fields
    responseBody.items.forEach((item: OperationPlanProject) => {
      expect(Object.keys(item)).toEqual(expectedItemsFields)
    })
    // * Checking the personnel fields
    responseBody.items.forEach((item: OperationPlanProject) => {
      if (item.personnel) {
        item.personnel.forEach((personnel: OperationPlanPersonnel) => {
          expect(Object.keys(personnel)).toEqual(expectedPersonnelFields)
        })
      }
    })
  })
  it('POST: /operation-plans/projects 422 Invalid Inputs', async () => {
    const response = await request(app)
      .post('/operation-plans/projects')
      .query(WrongRequestQuery)
      .send(requestBody)
      .set(auth)
    const responseBody = response.body

    const expectedStatusCode = 422

    expect(response.status).toBe(expectedStatusCode)
    expect(responseBody.res).toEqual('Validation error')
  })

  it('POST: /operation-plans/projects 404 Invalid Route', async () => {
    const response = await request(app)
      .post('/operation-plans/projects/test')
      .query(requestQuery)
      .send(requestBody)
      .set(auth)
    const expectedStatusCode = 404
    expect(response.statusCode).toEqual(expectedStatusCode)
  })

  it('POST /operation-plans/projects: fail authentication', async () => {
    const response = await request(app)
      .post('/operation-plans/projects')
      .query(requestQuery)
      .send(fixture.searchBy.skillList)

    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = { message: 'Forbidden' }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })
})
