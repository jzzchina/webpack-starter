import express from 'express'
import request from 'supertest'
import { Connection } from 'typeorm'
import { OperationPlan } from '../../../src/domain/models/OperationPlan'
import { createConnection } from '../../../src/infrastructure/orm/typeorm/connection'
import { createApp } from '../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../src/infrastructure/webserver/express/routes'
import { authGenerator } from '../common/authGenerator'
import createForeignKeys, {
  OperationPlanForeignKeys,
} from './helpers/createForeignKeys.helper'
import fixture from './operationPlan.fixture'
import prepareRepositories, {
  OperationPlanRepositories,
} from './helpers/prepareRepositories.helper'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import deleteOperationPlan from './helpers/deleteOperationPlan.helper'
import { createOperationRequestBody } from '../../../src/domain/types/operationPlan.type'
import { HeaderAuth } from '../../../src/domain/types/common.type'
import { Repositories } from '../../../src/application/port'

describe('TEST - Create operation plan API', () => {
  let repositories: OperationPlanRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let requestBody: createOperationRequestBody[]
  let wrongRequestBody: Partial<createOperationRequestBody>[]
  let methodNotAllowedOperationPlanBody: Partial<createOperationRequestBody>[]
  let foreignKeys: OperationPlanForeignKeys

  beforeEach(async () => {
    const personnelObject = fixture.create.personnel
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories, personnelObject) // * Create foreign keys
    const { personnelId, projectId, roleId } = foreignKeys

    // * prepare the request body
    const operationPlanFixture = fixture.create.operationPlan
    const wrongOperationPlanFixture = fixture.create.wrongOperationPlan
    const methodNotAllowedOperationPlanFixture = {
      ...fixture.create.operationPlan,
      personnelId: 10,
    }
    operationPlanFixture.personnelId = personnelId
    operationPlanFixture.projectId = projectId
    operationPlanFixture.roleId = roleId
    requestBody = [operationPlanFixture]
    wrongRequestBody = [wrongOperationPlanFixture]
    methodNotAllowedOperationPlanBody = [methodNotAllowedOperationPlanFixture]
  })

  afterEach(async () => {
    // * Delete the created operation plan
    await removeForeignKeys(repositories, foreignKeys)
  })

  it('PATCH: /operation-plans 200', async () => {
    const response = await request(app)
      .patch('/operation-plans')
      .send(requestBody)
      .set(auth)
    const responseBody = response.body

    const expectedStatusCode = 200
    const expectedFields = [
      'costAmount',
      'manMonthNumber',
      'hoursNumber',
      'personnelId',
      'projectId',
      'yearOfMonthDate',
      'roleId',
      'roleName',
      'createdBy',
      'createdAt',
      'updatedBy',
      'updateAt',
      'processId',
      'processAt',
    ]

    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    responseBody.forEach((item: OperationPlan) => {
      expectedFields.forEach((field: string) => {
        expect(item).toHaveProperty(field)
      })
    })

    // * Delete the created operation plan
    if (responseBody.length > 0) {
      const createdOperationPlan = responseBody[0]
      await deleteOperationPlan(repositories, createdOperationPlan)
    }
  })

  it('PATCH: /operation-plans 422 Invalid Inputs', async () => {
    const response = await request(app)
      .patch('/operation-plans')
      .send(wrongRequestBody)
      .set(auth)
    const responseBody = response.body
    const expectedStatusCode = 422

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody.res).toEqual('Validation error')

    // * Delete the created operation plan
    if (responseBody.length > 0) {
      const createdOperationPlan = responseBody[0]
      await deleteOperationPlan(repositories, createdOperationPlan)
    }
  })

  it('PATCH: /operation-plans 405 Method Not Allowed', async () => {
    const response = await request(app)
      .patch('/operation-plans')
      .send(methodNotAllowedOperationPlanBody)
      .set(auth)
    const responseBody = response.body
    const expectedStatusCode = 405

    expect(response.statusCode).toEqual(expectedStatusCode)

    if (responseBody.length > 0) {
      const createdOperationPlan = responseBody[0]
      await deleteOperationPlan(repositories, createdOperationPlan)
    }
  })

  it('PATCH: /operation-plans 404 Invalid Route', async () => {
    const response = await request(app)
      .patch('/operation-plans/test')
      .send(wrongRequestBody)
      .set(auth)
    const responseBody = response.body
    const expectedStatusCode = 404
    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Delete the created operation plan
    if (responseBody.length > 0) {
      const createdOperationPlan = responseBody[0]
      await deleteOperationPlan(repositories, createdOperationPlan)
    }
  })

  it('PATCH /operation-plans: fail authentication', async () => {
    const response = await request(app)
      .patch('/operation-plans')
      .send(requestBody)
    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = { message: 'Forbidden' }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })
})
