import { Connection } from 'typeorm'
import express from 'express'
import { authGenerator } from '../common/authGenerator'
import { createApp } from '../../../src/infrastructure/webserver/express/app'
import { createConnection } from '../../../src/infrastructure/orm/typeorm/connection'
import { createRouter } from '../../../src/infrastructure/webserver/express/routes'
import request from 'supertest'
import prepareRepositories, {
  OperationPlanRepositories,
} from './helpers/prepareRepositories.helper'
import fixture from './operationPlan.fixture'
import createForeignKeys, {
  OperationPlanForeignKeys,
} from './helpers/createForeignKeys.helper'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import { Dw_t_operation_plan } from '../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import deleteOperationPlan, {
  DeleteOperationPlan,
} from './helpers/deleteOperationPlan.helper'
import { HeaderAuth } from '../../../src/domain/types/common.type'
import { Repositories } from '../../../src/application/port'
import { deleteOperationPlanRequestBody } from '../../../src/domain/types/operationPlan.type'

describe('TEST- Delete operation plan API', () => {
  let repositories: OperationPlanRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(() => {
    connection.close()
  })

  let requestBody: deleteOperationPlanRequestBody[]
  let foreignKeys: OperationPlanForeignKeys

  beforeEach(async () => {
    const personnelObject = fixture.create.personnel
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories, personnelObject) // * Create foreign keys
    const { personnelId, projectId, roleId } = foreignKeys

    // * Prepare the item to be removed
    const operationPlanFixture = fixture.delete.operationPlan
    operationPlanFixture.dw_m_personnel = personnelId
    operationPlanFixture.dw_m_project = projectId
    operationPlanFixture.dw_m_role = roleId

    // * Insert the item
    const operationPlanToBeRemoved = await repositories.operationPlanDBRepo.save(
      (operationPlanFixture as unknown) as Dw_t_operation_plan
    )

    // * Prepare the request body
    const requestBodyFixture = fixture.delete.requestBody

    requestBodyFixture.personnelId = (operationPlanToBeRemoved.dw_m_personnel as unknown) as number
    requestBodyFixture.projectId = (operationPlanToBeRemoved.dw_m_project as unknown) as number
    requestBodyFixture.yearOfMonthDate = (operationPlanToBeRemoved.month_of_year_date as unknown) as string
    requestBodyFixture.operationPlanId = (operationPlanToBeRemoved.operation_plan_id as unknown) as number
    requestBody = [requestBodyFixture]
  })

  afterEach(async () => {
    // * Delete the created operation plan
    await removeForeignKeys(repositories, foreignKeys)
  })

  it('POST: /operation-plans 200', async () => {
    const response = await request(app)
      .post('/operation-plans')
      .send(requestBody)
      .set(auth)
    const responseBody = response.body
    const expectedStatusCode = 200
    const expectedBody = {
      message: 'Records deleted successfully',
    }

    expect(response.status).toBe(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })

  it('POST /operation-plans: fail authentication', async () => {
    const response = await request(app)
      .post('/operation-plans')
      .send(requestBody)
    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = { message: 'Forbidden' }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)

    // * Delete the created operation plan
    const createdOperationPlan: DeleteOperationPlan = {
      personnelId: requestBody[0].personnelId,
      projectId: requestBody[0].projectId,
      yearOfMonthDate: requestBody[0].yearOfMonthDate,
    }
    await deleteOperationPlan(repositories, createdOperationPlan)
  })
  it('POST /operation-plans: Wrong Endpoint or Method', async () => {
    const response = await request(app)
      .post('/operation-plan')
      .send(requestBody)
    const responseBody = response.body

    const expectedStatusCode = 404
    const expectedBody = {}

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })
})
