import { Connection } from 'typeorm'
import express from 'express'
import { authGenerator } from '../common/authGenerator'
import { createApp } from '../../../src/infrastructure/webserver/express/app'
import { createConnection } from '../../../src/infrastructure/orm/typeorm/connection'
import { createRouter } from '../../../src/infrastructure/webserver/express/routes'
import request from 'supertest'
import prepareRepositories, {
  OperationPlanRepositories,
} from './helpers/prepareRepositories.helper'
import createForeignKeys, {
  OperationPlanForeignKeys,
} from './helpers/createForeignKeys.helper'
import fixture from './operationPlan.fixture'
import { Dw_t_operation_plan } from '../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import deleteOperationPlan, {
  DeleteOperationPlan,
} from './helpers/deleteOperationPlan.helper'
import { HeaderAuth } from '../../../src/domain/types/common.type'
import { Repositories } from '../../../src/application/port'
import { SearchOperationPlanQueryParams } from '../../../src/domain/types/operationPlan.type'
import { OperationPlanPersonnel } from '../../../src/infrastructure/repositories/operationPlan/interface'
import { Personnel } from '../../../src/domain/models/Personnel'

describe('TEST - Search operation plan personnel API', () => {
  let repositories: OperationPlanRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(() => {
    connection.close()
  })

  let requestQuery: SearchOperationPlanQueryParams
  let foreignKeys: OperationPlanForeignKeys
  let insertedOperationPlan: Dw_t_operation_plan

  beforeEach(async () => beforeEachHandler(repositories))

  afterEach(async () => {
    // * Delete the created operation plan
    const createdOperationPlan: DeleteOperationPlan = {
      personnelId: (insertedOperationPlan.dw_m_personnel as unknown) as number,
      projectId: (insertedOperationPlan.dw_m_project as unknown) as number,
      yearOfMonthDate: insertedOperationPlan.month_of_year_date.toString(),
    }
    await deleteOperationPlan(repositories, createdOperationPlan)
    // * Remove foreign keyss
    await removeForeignKeys(
      repositories,
      foreignKeys,
      insertedOperationPlan.month_of_year_date.toString()
    )
  })

  it('POST: /operation-plans/personnel 200', async () => {
    const response = await request(app)
      .post('/operation-plans/personnel')
      .query(requestQuery)
      .send(fixture.searchBy.skillList)
      .set(auth)
    const responseBody = response.body

    const expectedStatusCode = 200
    const expectedResponseFields = [
      'from',
      'to',
      'offset',
      'length',
      'totalLength',
      'items',
    ]
    const expectedItemsFields = [
      'companyId',
      'contractPatternCode',
      'companyName',
      'personnelId',
      'name',
      'nameJpn',
      'registeredDate',
      'unregisteredDate',
      'skillList',
      'prices',
      'businessDays',
      'totals',
      'allProjectIds',
      'projects',
    ]

    // * Checking the Status Code
    expect(response.status).toBe(expectedStatusCode)
    // * Checking the response fields
    expect(Object.keys(responseBody)).toEqual(expectedResponseFields)
    // * Checking the items fields
    responseBody.items.forEach((item: OperationPlanPersonnel) => {
      expect(Object.keys(item)).toEqual(expectedItemsFields)
    })
  })

  it('POST: /operation-plans/personnel 200 - filter by date', async () => {
    const registeredDate = new Date('2022-01-01')
    const unregisteredDate = null
    await beforeEachHandler(repositories, {
      registeredDate,
      unregisteredDate,
    })

    requestQuery.from = '2023-01-01'
    requestQuery.to = '2023-03-01'
    delete requestQuery.project_id
    delete requestQuery.company_id

    const response = await request(app)
      .post('/operation-plans/personnel')
      .query(requestQuery)
      .send(fixture.searchBy.skillList)
      .set(auth)
    const responseBody = response.body

    const expectedStatusCode = 200
    const expectedItemsFields = [
      'companyId',
      'contractPatternCode',
      'companyName',
      'personnelId',
      'name',
      'nameJpn',
      'registeredDate',
      'unregisteredDate',
      'skillList',
      'prices',
      'businessDays',
      'totals',
      'allProjectIds',
      'projects',
    ]

    // * Checking the Status Code
    expect(response.status).toBe(expectedStatusCode)
    // * Checking the response fields
    expect(responseBody.items).toHaveLength(2)
    expect(responseBody.items[0].registeredDate).toEqual(registeredDate)
    expect(responseBody.items[0].unregisteredDate).toEqual(unregisteredDate)

    // * Checking the items fields
    responseBody.items.forEach((item: OperationPlanPersonnel) => {
      expect(Object.keys(item)).toEqual(expectedItemsFields)
    })
  })

  it('POST: /operation-plans/personnel 422 - "to" is missed', async () => {
    requestQuery.from = '2020-01-01'
    requestQuery.to = ''

    const response = await request(app)
      .post('/operation-plans/personnel')
      .query(requestQuery)
      .send(fixture.searchBy.skillList)
      .set(auth)
    const responseBody = response.body

    const expectedStatusCode = 422

    // * Checking the Status Code
    expect(response.status).toBe(expectedStatusCode)
    // * Checking the response fields
    expect(responseBody.res).toEqual('Validation error')
    expect(responseBody.message).toEqual('"to" must be in YYYY-MM-DD format')
  })

  it('POST /operation-plans/personnel: fail authentication', async () => {
    const response = await request(app)
      .post('/operation-plans/personnel')
      .query(requestQuery)
      .send(fixture.searchBy.skillList)

    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = { message: 'Forbidden' }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })

  async function beforeEachHandler(
    repositories: OperationPlanRepositories,
    personnelObject?: Pick<Personnel, 'registeredDate' | 'unregisteredDate'>
  ) {
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories, personnelObject)
    const { companyId, personnelId, projectId, roleId } = foreignKeys

    // * Prepare the item to be searched
    const operationPlanFixture = fixture.delete.operationPlan
    operationPlanFixture.dw_m_personnel = personnelId
    operationPlanFixture.dw_m_project = projectId
    operationPlanFixture.dw_m_role = roleId

    // * Insert the item
    insertedOperationPlan = await repositories.operationPlanDBRepo.save(
      (operationPlanFixture as unknown) as Dw_t_operation_plan
    )
    //* insert business days
    const businessDaysFixture = fixture.create.dw_m_business_day
    businessDaysFixture.dw_m_partner_company.company_id = companyId
    businessDaysFixture.month_of_year_date = insertedOperationPlan.month_of_year_date.toString()
    await repositories.businessDaysDBRepo.save(businessDaysFixture)

    // * Prepare the request query
    const requestQueryFixture = fixture.searchBy.query
    requestQueryFixture.project_id = projectId
    requestQueryFixture.company_id = companyId

    requestQuery = requestQueryFixture
  }
})
