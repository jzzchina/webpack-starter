import express from 'express'
import request from 'supertest'
import { Connection } from 'typeorm'

import { createConnection } from '../../../src/infrastructure/orm/typeorm/connection'
import { Dw_m_business_days } from '../../../src/infrastructure/orm/typeorm/entities/Dw_m_business_days'
import { createApp } from '../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../src/infrastructure/webserver/express/routes'
import { authGenerator } from '../common/authGenerator'
import fixture from './businessDays.fixture'
import createForeignKeys, {
  BusinessDaysForeignKeys,
} from './helpers/createForeignKeys.helper'
import prepareRepositories, {
  BusinessDaysRepositories,
} from './helpers/prepareRepositories.helper'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import { HeaderAuth } from '../../../src/domain/types/common.type'
import { Repositories } from '../../../src/application/port'
import { deleteCreatedBusinessDays, mapFixture } from './helpers/common'

describe('TEST - Create Business Days API', () => {
  let repositories: BusinessDaysRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let foreignKeys: BusinessDaysForeignKeys
  let businessDaysFixtureArray: Partial<Dw_m_business_days>[]
  let wrongBusinessDaysFixtureArray: Partial<Dw_m_business_days>[]
  let manyBusinessDaysFixtureArray: Partial<Dw_m_business_days>[]
  let manyBusinessDaysForUpdateFixtureArray: Partial<Dw_m_business_days>[]

  beforeEach(async () => {
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories)
    const { companyId } = foreignKeys
    businessDaysFixtureArray = mapFixture(
      fixture.create.businessDays,
      companyId
    )
    manyBusinessDaysFixtureArray = mapFixture(
      fixture.create.manyBusinessDays,
      companyId
    )
    manyBusinessDaysForUpdateFixtureArray = mapFixture(
      fixture.create.manyBusinessDays,
      companyId
    )
    const wrongRequestBody = fixture.create.wrongBusinessDays
    wrongBusinessDaysFixtureArray = wrongRequestBody as Partial<Dw_m_business_days>[]
  })

  afterEach(async () => {
    // * Delete the created foreign keys
    await removeForeignKeys(repositories, foreignKeys)
  })

  it('PATCH: insert single business day ', async () => {
    const response = await request(app)
      .patch('/business-days')
      .send(businessDaysFixtureArray)

      .set(auth)
    expect(response.statusCode).toEqual(200)
    expect(response.body).toEqual(businessDaysFixtureArray)

    // * Delete the created business days
    await deleteCreatedBusinessDays(
      response.body,
      repositories,
      foreignKeys.companyId
    )
  })

  it('PATCH: insert single business day with zero day number ', async () => {
    const response = await request(app)
      .patch('/business-days')
      .send(businessDaysFixtureArray)

      .set(auth)
    expect(response.statusCode).toEqual(200)
    expect(response.body).toEqual(businessDaysFixtureArray)

    // * Delete the created business days
    await deleteCreatedBusinessDays(
      response.body,
      repositories,
      foreignKeys.companyId
    )
  })

  it('PATCH: insert many business day ', async () => {
    const response = await request(app)
      .patch('/business-days')
      .send(manyBusinessDaysFixtureArray)
      .set(auth)
    expect(response.statusCode).toEqual(200)
    expect(response.body.length).toEqual(2)
    expect(response.body).toEqual(manyBusinessDaysFixtureArray)

    // * Delete the created business days
    await deleteCreatedBusinessDays(
      response.body,
      repositories,
      foreignKeys.companyId
    )
  })

  it('PATCH: insert  business day with no exist companyId ', async () => {
    const response = await request(app)
      .patch('/business-days')
      .send(fixture.create.businessDaysWithWrongCompanyId)
      .set(auth)
    expect(response.statusCode).toEqual(400)
    expect(response.body).toEqual({
      message: ' the requested company_id not found',
    })
  })

  it('PATCH: update  business days ', async () => {
    const newBusinessDays = await request(app)
      .patch('/business-days')
      .send([manyBusinessDaysForUpdateFixtureArray[0]])
      .set(auth)
    expect(newBusinessDays.statusCode).toEqual(200)
    expect(newBusinessDays.body).toEqual([
      manyBusinessDaysForUpdateFixtureArray[0],
    ])
    const response = await request(app)
      .patch('/business-days')
      .send([manyBusinessDaysForUpdateFixtureArray[1]])
      .set(auth)
    expect(response.statusCode).toEqual(200)
    expect(response.body.length).toEqual(1)
    expect(response.body[0]).toEqual(manyBusinessDaysForUpdateFixtureArray[1])

    // * Delete the created business days
    await deleteCreatedBusinessDays(
      response.body,
      repositories,
      foreignKeys.companyId
    )
  })

  it('PATCH: /business-days wrong route should return 404 ', async () => {
    const response = await request(app)
      .patch('/business-days/test')
      .send(fixture.create.businessDaysWithWrongCompanyId)
      .set(auth)
    expect(response.statusCode).toEqual(404)
  })

  it('PATCH: /business-days/ 422 Invalid Inputs', async () => {
    const response = await request(app)
      .patch('/business-days/')
      .send(wrongBusinessDaysFixtureArray)
      .set(auth)
    const responseBody = response.body
    const expectedStatusCode = 422
    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody.res).toEqual('Validation error')
  })
})
