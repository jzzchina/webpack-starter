import { Dw_m_business_days } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_business_days'
import deleteBusinessDays from './deleteBusinessDays.helper'
import { BusinessDaysRepositories } from './prepareRepositories.helper'

export const deleteCreatedBusinessDays = async (
  businessDays: Dw_m_business_days[],
  repositories: BusinessDaysRepositories,
  companyId: number
): Promise<void> => {
  for (const item of businessDays) {
    await deleteBusinessDays(repositories, companyId, item.month_of_year_date)
  }
}

export const mapFixture = (
  fixtureData: any[],
  companyId: number
): Dw_m_business_days[] => {
  return fixtureData.map((item) => ({ ...item, companyId }))
}
