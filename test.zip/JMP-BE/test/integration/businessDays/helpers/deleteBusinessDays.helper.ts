import { Dw_m_business_days } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_business_days'
import { BusinessDaysRepositories } from './prepareRepositories.helper'

// * A helper function to delete the personnel
const deleteBusinessDays = async (
  repositories: BusinessDaysRepositories,
  company_id: number,
  monthOfYearDate: Date
): Promise<void> => {
  await repositories.businessDaysDBRepo
    .createQueryBuilder()
    .delete()
    .from(Dw_m_business_days)
    .where('company_id = :company_id', { company_id })
    .andWhere('month_of_year_date = :month_of_year_date', {
      month_of_year_date: monthOfYearDate,
    })
    .execute()
    .catch((err: any) => {
      throw new Error(err)
    })
}

export default deleteBusinessDays
