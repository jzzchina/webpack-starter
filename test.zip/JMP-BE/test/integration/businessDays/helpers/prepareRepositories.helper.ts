import { Connection, Repository } from 'typeorm'
import { BusinessDaysRepositoryPort } from '../../../../src/application/port/repositories/businessDays/BusinessDaysRepositoryPort'
import { Dw_m_business_days } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_business_days'
import { Dw_m_partner_company } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_partner_company'
import { businessDaysRepositoryMySQL } from '../../../../src/infrastructure/repositories/businessDays/businessDaysRepositoryMySQL'

export interface BusinessDaysRepositories {
  businessDaysRepository: BusinessDaysRepositoryPort
  businessDaysDBRepo: Repository<Dw_m_business_days>
  partnerCompanyDBRepo: Repository<Dw_m_partner_company>
}

// * A function that prepares the repositories for the tests
const prepareRepositories = async (
  connection: Connection
): Promise<BusinessDaysRepositories> => {
  const businessDaysRepository = await businessDaysRepositoryMySQL(connection)
  const businessDaysDBRepo = await connection.getRepository(Dw_m_business_days)
  const partnerCompanyDBRepo = connection.getRepository(Dw_m_partner_company)

  const repositories = {
    businessDaysRepository,
    businessDaysDBRepo,
    partnerCompanyDBRepo,
  }

  return repositories
}

export default prepareRepositories
