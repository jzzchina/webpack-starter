import { BusinessDaysForeignKeys } from './createForeignKeys.helper'
import { BusinessDaysRepositories } from './prepareRepositories.helper'

// * A Helper function that removes all the foreign keys after running the tests
const removeForeignKeys = async (
  repositories: BusinessDaysRepositories,
  foreignKeys: BusinessDaysForeignKeys
): Promise<void> => {
  const { companyId } = foreignKeys
  // * Delete the created partnerCompany
  await repositories.partnerCompanyDBRepo.delete({ company_id: companyId })
}

export default removeForeignKeys
