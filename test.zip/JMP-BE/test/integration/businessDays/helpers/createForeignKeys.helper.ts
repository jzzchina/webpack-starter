import fixture from '../businessDays.fixture'
import { BusinessDaysRepositories } from './prepareRepositories.helper'

export interface BusinessDaysForeignKeys {
  companyId: number
}

// A Helper function that creates all the foreign keys for the BusinessDays and returns the ids
const createForeignKeys = async (
  repositories: BusinessDaysRepositories
): Promise<BusinessDaysForeignKeys> => {
  const partnerCompanyFixture = fixture.getAll.partnerCompany
  const partnerCompany = await repositories.partnerCompanyDBRepo.save(
    partnerCompanyFixture
  )
  const companyId = partnerCompany.company_id

  return { companyId }
}

export default createForeignKeys
