import express from 'express'
import request from 'supertest'
import { Connection } from 'typeorm'
import { createConnection } from '../../../src/infrastructure/orm/typeorm/connection'
import { Dw_m_business_days } from '../../../src/infrastructure/orm/typeorm/entities/Dw_m_business_days'
import { createApp } from '../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../src/infrastructure/webserver/express/routes'
import { authGenerator } from '../common/authGenerator'
import fixture from './businessDays.fixture'
import createForeignKeys, {
  BusinessDaysForeignKeys,
} from './helpers/createForeignKeys.helper'
import deleteBusinessDays from './helpers/deleteBusinessDays.helper'
import prepareRepositories, {
  BusinessDaysRepositories,
} from './helpers/prepareRepositories.helper'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import { HeaderAuth } from '../../../src/domain/types/common.type'
import { Repositories } from '../../../src/application/port'
import { BusinessDays } from '../../../src/interface/routes/businessDays/dto/businessDays.dto'

describe('TEST - GetAll Business Days API', () => {
  let repositories: BusinessDaysRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let foreignKeys: BusinessDaysForeignKeys
  let createdBusinessDays: Dw_m_business_days

  beforeEach(async () => {
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories)
    const { companyId } = foreignKeys

    // * prepare the fixture
    const businessDaysFixture = fixture.getAll.businessDays
    businessDaysFixture.dw_m_partner_company = companyId

    // * Insert the BusinessDays so it can be retrieved
    createdBusinessDays = await repositories.businessDaysDBRepo.save(
      (businessDaysFixture as unknown) as Dw_m_business_days
    )
  })

  afterEach(async () => {
    // * Delete the created foreign keys
    await removeForeignKeys(repositories, foreignKeys)
  })

  it('GET: /business-days 200', async () => {
    const response = await request(app)
      .get('/business-days')
      .query({
        company_id: foreignKeys.companyId,
      })
      .set(auth)
    const responseBody = response.body

    const expectedStatusCode = 200
    const expectedItems = ['companyId', 'monthOfYearDate', 'businessDaysNumber']

    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    responseBody.items.forEach((item: BusinessDays) => {
      expectedItems.forEach((expectedItem: string) => {
        expect(item).toHaveProperty(expectedItem)
      })
    })
    // * Delete the created business days
    await deleteBusinessDays(
      repositories,
      foreignKeys.companyId,
      createdBusinessDays.month_of_year_date
    )
  })

  it('GET: /business-days - expect to return 403', async () => {
    const response = await request(app)
      .get('/business-days')
      // .set(auth); // * No auth token
      .query({ company_id: foreignKeys.companyId })

    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = {
      message: 'Forbidden',
    }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
    // * Delete the created business days
    await deleteBusinessDays(
      repositories,
      foreignKeys.companyId,
      createdBusinessDays.month_of_year_date
    )
  })
  it('GET: /business-days : try to call wrong endpoint expect to return 404', async () => {
    const response = await request(app)
      .get('/business-day')
      .set(auth)
      .query({ company_id: foreignKeys.companyId })

    const responseBody = response.body

    const expectedStatusCode = 404
    const expectedBody = {}

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })

  it('GET: /business-days - try to call with wrong company id format ', async () => {
    const response = await request(app)
      .get('/business-days')
      .set(auth)
      .query({ company_id: false })

    const responseBody = response.body

    const expectedStatusCode = 422
    const expectedBody = {
      message: '"company_id" must be a number',
      res: 'Validation error',
      type: 'number.base',
    }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
    // * Delete the created business days
    await deleteBusinessDays(
      repositories,
      foreignKeys.companyId,
      createdBusinessDays.month_of_year_date
    )
  })
})
