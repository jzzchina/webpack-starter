import express from 'express'
import request from 'supertest'
import { Connection } from 'typeorm'

import { createConnection } from '../../../src/infrastructure/orm/typeorm/connection'
import { createApp } from '../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../src/infrastructure/webserver/express/routes'
import { authGenerator } from '../common/authGenerator'
import createForeignKeys, {
  BusinessDaysForeignKeys,
} from './helpers/createForeignKeys.helper'
import prepareRepositories, {
  BusinessDaysRepositories,
} from './helpers/prepareRepositories.helper'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import fixture from './businessDays.fixture'
import { HeaderAuth } from '../../../src/domain/types/common.type'
import { Repositories } from '../../../src/application/port'

describe('TEST - Delete Business Days API', () => {
  let repositories: BusinessDaysRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let foreignKeys: BusinessDaysForeignKeys
  let createdCompanyId: number

  beforeEach(async () => {
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories)
    const { companyId } = foreignKeys
    createdCompanyId = companyId

    // * Prepare the businessDays fixture
    const businessDaysFixture = fixture.delete.toBeInserted
    businessDaysFixture.dw_m_partner_company.company_id = companyId
    // * Insert the businessDays fixture so It can be deleted in the tests
    await repositories.businessDaysDBRepo.save(businessDaysFixture)
  })

  afterEach(async () => {
    // * Delete the created foreign keys
    await removeForeignKeys(repositories, foreignKeys)
  })

  it('DELETE: delete single business day ', async () => {
    // * Arrange
    const url = '/business-days/' + createdCompanyId + '/' + '2020-01-01'

    // * Act
    const response = await request(app).delete(url).set(auth)
    const { statusCode, body } = response

    // * Assert
    const expectedStatusCode = 200
    const expectedBody = {
      message: 'Records deleted successfully',
    }
    expect(statusCode).toEqual(expectedStatusCode)
    expect(body).toEqual(expectedBody)
  })

  it('DELETE: delete single business day with wrong id', async () => {
    // * Arrange
    const invalidID = createdCompanyId + 1
    const url = '/business-days/' + invalidID + '/' + '2020-01-01'

    // * Act
    const response = await request(app).delete(url).set(auth)
    const { statusCode, body } = response

    // * Assert
    const expectedStatusCode = 404
    const expectedBody = {
      message: " Records doesn't exist!",
    }
    expect(statusCode).toEqual(expectedStatusCode)
    expect(body).toEqual(expectedBody)
  })
  it('DELETE: Try to delete single business day without Auth', async () => {
    // * Arrange
    const url = '/business-days/' + createdCompanyId + '/' + '2020-01-01'

    // * Act
    const response = await request(app).delete(url)
    const { statusCode, body } = response

    // * Assert
    const expectedStatusCode = 403
    const expectedBody = {
      message: 'Forbidden',
    }
    expect(statusCode).toEqual(expectedStatusCode)
    expect(body).toEqual(expectedBody)
  })
  it('DELETE: Try to wrong endpoint', async () => {
    // * Arrange
    const url = '/business-day/' + createdCompanyId + '/' + '2020-01-01'

    // * Act
    const response = await request(app).delete(url).set(auth)
    const { statusCode, body } = response

    // * Assert
    const expectedStatusCode = 404
    const expectedBody = {}
    expect(statusCode).toEqual(expectedStatusCode)
    expect(body).toEqual(expectedBody)
  })
  it('DELETE: Try to delete single business day with wrong id format', async () => {
    // * Arrange
    const wrongFormatCompanyId = false
    const url = '/business-days/' + wrongFormatCompanyId + '/' + '2020-01-01'

    // * Act
    const response = await request(app).delete(url).set(auth)
    const { statusCode, body } = response

    // * Assert
    const expectedStatusCode = 422
    const expectedBody = {
      message: '"companyId" must be a number',
      res: 'Validation error',
      type: 'number.base',
    }
    expect(statusCode).toEqual(expectedStatusCode)
    expect(body).toEqual(expectedBody)
  })
})
