const businessDaysFixture = {
  getAll: {
    businessDays: {
      dw_m_partner_company: -1, // To be replaced by the id of the company created in the test
      month_of_year_date: '2022-01-01',
      business_days_number: 1,
      created_by: 'Integration Test',
      updated_by: 'Integration Test',
    },
    partnerCompany: {
      contract_pattern_code: 3,
      company_name: 'This is a test company',
      created_by: 'Integration Test',
      updated_by: 'Integration Test',
    },
  },
  create: {
    businessDays: [
      {
        companyId: 1234,
        monthOfYearDate: '2022-01-01',
        businessDaysNumber: 0,
      },
    ],
    wrongBusinessDays: [
      {
        companyId: 1234,
        monthOfYearDate: '2022-01-01',
      },
    ],
    manyBusinessDays: [
      {
        companyId: 1234,
        monthOfYearDate: '2022-01-01',
        businessDaysNumber: 20,
      },
      {
        companyId: 1234,
        monthOfYearDate: '2022-02-01',
        businessDaysNumber: 22,
      },
    ],
    businessDaysWithWrongCompanyId: [
      {
        companyId: 12345,
        monthOfYearDate: '2022-01-01',
        businessDaysNumber: 20,
      },
    ],
  },
  update: {
    businessDays: [
      {
        companyId: 12,
        monthOfYearDate: '2022-01-01',
        businessDaysNumber: 20,
      },
      {
        companyId: 12,
        monthOfYearDate: '2022-02-02',
        businessDaysNumber: 30,
      },
    ],
  },
  delete: {
    toBeInserted: {
      month_of_year_date: '2020-01-01',
      business_days_number: 8,
      dw_m_partner_company: {
        company_id: -1, // To be replaced by the id of the company created in the test
      },
      created_by: 'test',
      updated_by: 'test',
    },
  },
}

export default businessDaysFixture
