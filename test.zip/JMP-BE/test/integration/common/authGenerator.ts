import jwt from 'jsonwebtoken'
import { HeaderAuth } from '../../../src/domain/types/common.type'

export const authGenerator = (): HeaderAuth => {
  const [name, roles] = ['test', ['test']]
  const payloadXAdToken = {
    name,
    roles,
  }
  const exp = Math.floor(Date.now() / 1000) + 1800
  const payloadWso2Token = { exp }

  const xAdToken = jwt.sign(payloadXAdToken, 'test')
  const wso2Token = jwt.sign(payloadWso2Token, 'test')

  return {
    authorization: `Bearer ${wso2Token}`,
    'x-ad-token': xAdToken,
  }
}
