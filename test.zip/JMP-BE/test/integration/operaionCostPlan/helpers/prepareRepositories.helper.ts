import { Connection, Repository } from 'typeorm'
import { Dw_m_partner_company } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_partner_company'
import { Dw_m_personnel } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { Dw_m_project } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_project'
import { Dw_m_role } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_role'
import { Dw_m_personnel_price } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel_price'
import { Dw_m_business_days } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_business_days'
import { Dw_t_operation_plan } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import { OperationCostPlanRepositoryPort } from '../../../../src/application/port/repositories/operationCostPlan/OperationCostPlanRepositoryPort'
import { operationCostPlanRepositoryMySQL } from '../../../../src/infrastructure/repositories/operationCostPlan/operationCostPlanRepositoryMySQL'

export interface OperationCostPlanRepositories {
  operationCostPlanRepository: OperationCostPlanRepositoryPort
  operationPlanDBRepository: Repository<Dw_t_operation_plan>
  personnelRepo: Repository<Dw_m_personnel>
  projectRepo: Repository<Dw_m_project>
  roleRepo: Repository<Dw_m_role>
  personnelPriceRepo: Repository<Dw_m_personnel_price>
  businessDaysRepo: Repository<Dw_m_business_days>
  partnerCompanyRepo: Repository<Dw_m_partner_company>
}

// * A function that prepares the repositories for the tests
const prepareRepositories = async (
  connection: Connection
): Promise<OperationCostPlanRepositories> => {
  const operationCostPlanRepository: OperationCostPlanRepositoryPort = await operationCostPlanRepositoryMySQL(
    connection
  )
  const roleRepo: Repository<Dw_m_role> = connection.getRepository(Dw_m_role)
  const personnelRepo: Repository<Dw_m_personnel> = connection.getRepository(
      Dw_m_personnel
    ),
    personnelPriceRepo: Repository<Dw_m_personnel_price> = connection.getRepository(
      Dw_m_personnel_price
    ),
    businessDaysRepo: Repository<Dw_m_business_days> = connection.getRepository(
      Dw_m_business_days
    )
  const projectRepo: Repository<Dw_m_project> = connection.getRepository(
    Dw_m_project
  )
  const partnerCompanyRepo: Repository<Dw_m_partner_company> = connection.getRepository(
    Dw_m_partner_company
  )
  const operationPlanDBRepository: Repository<Dw_t_operation_plan> = connection.getRepository(
    Dw_t_operation_plan
  )

  const repositories = {
    operationCostPlanRepository,
    roleRepo,
    personnelRepo,
    projectRepo,
    partnerCompanyRepo,
    personnelPriceRepo,
    businessDaysRepo,
    operationPlanDBRepository,
  }

  return repositories
}

export default prepareRepositories
