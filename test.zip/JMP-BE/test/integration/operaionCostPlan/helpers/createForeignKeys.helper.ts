import { Dw_m_personnel } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel'
import fixture from '../operationPlanfixture'
import { OperationCostPlanRepositories } from './prepareRepositories.helper'

export interface OperationCostPlanForeignKeys {
  companyId: number
  personnelId: number
  projectId: number
  monthOfYearDate: string
  priceStartDate: string
  roleId: number
}
// A Helper function that creates all the foreign keys for the operationCost and returns the ids
const createForeignKeys = async (
  repositories: OperationCostPlanRepositories
): Promise<OperationCostPlanForeignKeys> => {
  // * We need to create a partnerCompany, so we can create a personnel
  const partnerCompanyFixture = fixture.create.partnerCompany
  const partnerCompany = await repositories.partnerCompanyRepo.save(
    partnerCompanyFixture
  )
  const companyId = partnerCompany.company_id

  // * Create a personnel
  const personnelFixture = fixture.create.personnel
  personnelFixture.dw_m_partner_company = companyId // * Set the partnerCompanyID
  const castedPersonnelFixture = (personnelFixture as unknown) as Dw_m_personnel
  const personnel = await repositories.personnelRepo.save(
    castedPersonnelFixture
  )
  const personnelId = personnel.personnel_id

  // * Create a project
  const projectFixture = fixture.create.project
  const project = await repositories.projectRepo.save(projectFixture)
  const projectId = project.project_id
  // * create personnel price
  const personnelPriceFixture = fixture.create.personnelPrice
  personnelPriceFixture.dw_m_personnel.personnel_id = personnelId
  const personnelPrice = await repositories.personnelPriceRepo.save(
    personnelPriceFixture
  )
  const priceStartDate = personnelPrice.price_start_date
  // * create role
  const roleFixture = fixture.create.role
  const role = await repositories.roleRepo.save(roleFixture)
  const roleId = role.role_id
  // create business days
  const businessDaysFixture = fixture.create.businessDays
  businessDaysFixture.dw_m_partner_company.company_id = companyId
  const businessDays = await repositories.businessDaysRepo.save(
    businessDaysFixture
  )
  const monthOfYearDate = businessDays.month_of_year_date

  return {
    companyId,
    personnelId,
    projectId,
    monthOfYearDate,
    priceStartDate,
    roleId,
  }
}

export default createForeignKeys
