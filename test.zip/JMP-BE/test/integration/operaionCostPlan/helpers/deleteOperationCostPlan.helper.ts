import { OperationCostPlanRepositories } from './prepareRepositories.helper'

export interface DeleteOperationCostPlan {
  personnelId: number
  projectId: number
  yearOfMonthDate: string
}

// * A helper function to delete the created operation cost
const deleteOperationPlan = async (
  repositories: OperationCostPlanRepositories,
  createdOperationCost: DeleteOperationCostPlan
): Promise<void> => {
  await repositories.operationPlanDBRepository.delete({
    month_of_year_date: createdOperationCost.yearOfMonthDate,
  })
}

export default deleteOperationPlan
