import { OperationCostPlanForeignKeys } from './createForeignKeys.helper'
import { OperationCostPlanRepositories } from './prepareRepositories.helper'

// * A Helper function that removes all the foreign keys after running the tests
const removeForeignKeys = async (
  repositories: OperationCostPlanRepositories,
  foreignKeys: OperationCostPlanForeignKeys
): Promise<void> => {
  const {
    companyId,
    personnelId,
    projectId,
    monthOfYearDate,
    priceStartDate,
    roleId,
  } = foreignKeys

  // * Delete the created project
  await repositories.projectRepo.delete({ project_id: projectId })

  // * Delete the created personnel
  await repositories.personnelRepo.delete({ personnel_id: personnelId })

  // * Delete the created partnerCompany
  await repositories.partnerCompanyRepo.delete({ company_id: companyId })
  // * Delete the created personnelPrice
  await repositories.personnelPriceRepo.delete({
    price_start_date: priceStartDate,
  })
  // * Delete the created role
  await repositories.roleRepo.delete({ role_id: roleId })
  // * Delete the created businessDays
  await repositories.businessDaysRepo.delete({
    month_of_year_date: monthOfYearDate,
  })
}

export default removeForeignKeys
