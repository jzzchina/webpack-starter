import { Connection } from 'typeorm'
import express from 'express'
import { authGenerator } from '../common/authGenerator'
import { createApp } from '../../../src/infrastructure/webserver/express/app'
import { createConnection } from '../../../src/infrastructure/orm/typeorm/connection'
import { createRouter } from '../../../src/infrastructure/webserver/express/routes'
import fixture from './operationPlanfixture'
import request from 'supertest'
import prepareRepositories, {
  OperationCostPlanRepositories,
} from './helpers/prepareRepositories.helper'
import createForeignKeys, {
  OperationCostPlanForeignKeys,
} from './helpers/createForeignKeys.helper'
import { Dw_t_operation_plan } from '../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import { DeleteOperationPlan } from '../operationPlan/helpers/deleteOperationPlan.helper'
import deleteOperationPlan from './helpers/deleteOperationCostPlan.helper'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import { HeaderAuth } from '../../../src/domain/types/common.type'
import { Repositories } from '../../../src/application/port'
import {
  OperationPlanPersonnel,
  OperationPlanProject,
} from '../../../src/infrastructure/repositories/operationPlan/interface'
import { SearchOperationPlanQueryParams } from '../../../src/domain/types/operationPlan.type'

describe('TEST - Search operation cost API', () => {
  let repositories: OperationCostPlanRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(() => {
    connection.close()
  })

  let requestQuery: SearchOperationPlanQueryParams
  let foreignKeys: OperationCostPlanForeignKeys
  let insertedOperationPlan: Dw_t_operation_plan

  beforeEach(async () => {
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories)
    const {
      companyId,
      personnelId,
      projectId,
      monthOfYearDate,
      roleId,
    } = foreignKeys

    // * Prepare the item to be searched
    const operationPlanFixture = fixture.create.operationPlan
    operationPlanFixture[0].dw_m_personnel.personnel_id = personnelId
    operationPlanFixture[0].dw_m_project.project_id = projectId
    operationPlanFixture[0].month_of_year_date = monthOfYearDate
    operationPlanFixture[0].dw_m_role.role_id = roleId
    operationPlanFixture[1].dw_m_personnel.personnel_id = personnelId
    operationPlanFixture[1].dw_m_project.project_id = projectId

    operationPlanFixture[1].dw_m_role.role_id = roleId

    // * Insert the item
    insertedOperationPlan = await repositories.operationPlanDBRepository.save(
      (operationPlanFixture as unknown) as Dw_t_operation_plan
    )
    // * Prepare the request query
    const requestQueryFixture = fixture.searchBy.query
    requestQueryFixture.project_id = projectId
    requestQueryFixture.company_id = companyId

    requestQuery = requestQueryFixture
  })

  afterEach(async () => {
    // * Delete the created operation cost
    const createdOperationPlan: DeleteOperationPlan = {
      personnelId: (insertedOperationPlan.dw_m_personnel as unknown) as number,
      projectId: (insertedOperationPlan.dw_m_project as unknown) as number,
      yearOfMonthDate: insertedOperationPlan.month_of_year_date?.toString(),
    }
    await deleteOperationPlan(repositories, createdOperationPlan)
    // * Remove foreign keys
    await removeForeignKeys(repositories, foreignKeys)
  })

  it('GET: /operation-cost-plans/projects 200', async () => {
    const response = await request(app)
      .get('/operation-cost-plans/projects')
      .query(requestQuery)
      .set(auth)
    const responseBody = response.body
    const expectedStatusCode = 200
    const expectedResponseFields = [
      'from',
      'to',
      'offset',
      'length',
      'totalLength',
      'items',
    ]
    const expectedItemsFields = [
      'projectId',
      'projectName',
      'projectContact',
      'projectStartDate',
      'projectEndDate',
      'note',
      'personnel',
    ]
    const expectedPersonnelFields = [
      'companyId',
      'contractPatternCode',
      'companyName',
      'personnelId',
      'name',
      'nameJpn',
      'registeredDate',
      'unregisteredDate',
      'skillList',
      'prices',
      'businessDays',
      'operationCostPlans',
    ]

    // * Checking the Status Code
    expect(response.status).toBe(expectedStatusCode)
    // * Checking the response fields
    expect(Object.keys(responseBody)).toEqual(expectedResponseFields)
    // * Checking the total items fields
    responseBody.items.forEach((item: OperationPlanProject) => {
      expect(Object.keys(item)).toEqual(expectedItemsFields)
      if (item.personnel) {
        item.personnel.forEach((personnel: OperationPlanPersonnel) => {
          expect(Object.keys(personnel)).toEqual(expectedPersonnelFields)
        })
      }
    })
  })

  it('GET /operation-cost-plans/projects: fail authentication', async () => {
    const response = await request(app)
      .get('/operation-cost-plans/projects')
      .query(requestQuery)

    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = { message: 'Forbidden' }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })
})
