import { Connection } from 'typeorm'
import express from 'express'
import { authGenerator } from '../common/authGenerator'
import { createApp } from '../../../src/infrastructure/webserver/express/app'
import { createConnection } from '../../../src/infrastructure/orm/typeorm/connection'
import { createRouter } from '../../../src/infrastructure/webserver/express/routes'
import request from 'supertest'
import prepareRepositories, {
  OperationCostRepositories,
} from './helpers/prepareRepositories.helper'
import createForeignKeys, {
  OperationCostForeignKeys,
} from './helpers/createForeignKeys.helper'
import fixture from './operationCost.fixture'
import { Dw_t_operation } from '../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import deleteOperationCost, {
  DeleteOperationCost,
} from './helpers/deleteOperationCost.helper'
import { HeaderAuth } from '../../../src/domain/types/common.type'
import { Repositories } from '../../../src/application/port'
import {
  OperationCostListRequest,
  OperationCostListResponse,
  PersonnelOperationCost,
  ProjectOperationCost,
} from '../../../src/interface/routes/operationCost/dto/operationCost.dto'

describe('TEST - Search operation cost API', () => {
  let repositories: OperationCostRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(() => {
    connection.close()
  })

  let requestQuery: OperationCostListRequest
  let foreignKeys: OperationCostForeignKeys
  let insertedOperationCost: Dw_t_operation

  beforeEach(async () => {
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories)
    const { companyId, personnelId, projectId } = foreignKeys

    // * Prepare the item to be searched
    const operationCostFixture = fixture.delete.operationCost
    operationCostFixture.dw_m_personnel = personnelId
    operationCostFixture.dw_m_project = projectId

    // * Insert the item
    insertedOperationCost = await repositories.operationCostDBRepo.save(
      (operationCostFixture as unknown) as Dw_t_operation
    )

    // * Prepare the request query
    const requestQueryFixture = fixture.searchBy.query
    requestQueryFixture.project_id = projectId
    requestQueryFixture.company_id = companyId

    requestQuery = requestQueryFixture
  })

  afterEach(async () => {
    // * Delete the created operation cost
    const createdOperationCost: DeleteOperationCost = {
      personnelId: (insertedOperationCost.dw_m_personnel as unknown) as number,
      projectId: (insertedOperationCost.dw_m_project as unknown) as number,
      yearOfMonthDate: insertedOperationCost.month_of_year_date.toString(),
    }
    await deleteOperationCost(repositories, createdOperationCost)
    // * Remove foreign keyss
    await removeForeignKeys(repositories, foreignKeys)
  })

  it('GET: /operation-costs 200', async () => {
    const response = await request(app)
      .get('/operation-costs')
      .query(requestQuery)
      .set(auth)

    const responseBody: OperationCostListResponse = response.body

    const expectedStatusCode = 200
    const expectedResponseFields = [
      'from',
      'to',
      'offset',
      'length',
      'totalLength',
      'items',
    ]
    const expectedItemsFields = [
      'projectId',
      'projectName',
      'projectContact',
      'projectStartDate',
      'projectEndDate',
      'note',
      'personnel',
    ]

    const expectedPersonnelFields = [
      'companyId',
      'contractPatternCode',
      'companyName',
      'personnelId',
      'name',
      'nameJpn',
      'registeredDate',
      'unregisteredDate',
      'prices',
      'businessDays',
      'operationPlans',
      'operations',
    ]

    // * Checking the Status Code
    expect(response.status).toBe(expectedStatusCode)
    // * Checking the response fields
    expect(Object.keys(responseBody)).toEqual(expectedResponseFields)
    // * Checking the items fields
    responseBody.items.forEach((item: ProjectOperationCost) => {
      expect(Object.keys(item)).toEqual(expectedItemsFields)
    })
    // * Checking the personnel fields
    responseBody.items.forEach((item: ProjectOperationCost) => {
      item.personnel.forEach((personnel: PersonnelOperationCost) => {
        expect(Object.keys(personnel)).toEqual(expectedPersonnelFields)
      })
    })
  })

  it('GET /operation-costs: fail authentication', async () => {
    const response = await request(app)
      .get('/operation-costs')
      .query(requestQuery)

    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = { message: 'Forbidden' }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })
})
