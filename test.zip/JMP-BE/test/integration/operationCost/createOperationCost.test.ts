import express from 'express'
import request from 'supertest'
import { Connection } from 'typeorm'
import { createConnection } from '../../../src/infrastructure/orm/typeorm/connection'
import { createApp } from '../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../src/infrastructure/webserver/express/routes'
import { authGenerator } from '../common/authGenerator'
import createForeignKeys, {
  OperationCostForeignKeys,
} from './helpers/createForeignKeys.helper'
import { Operation } from './../../../src/domain/models/Operation'
import fixture from './operationCost.fixture'
import prepareRepositories, {
  OperationCostRepositories,
} from './helpers/prepareRepositories.helper'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import deleteOperationCost from './helpers/deleteOperationCost.helper'
import { HeaderAuth } from '../../../src/domain/types/common.type'
import { Repositories } from '../../../src/application/port'
import { CreateOperationCostDto } from '../../../src/interface/routes/operationCost/dto/operationCost.dto'

describe('TEST - Create operation cost API', () => {
  let repositories: OperationCostRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let requestBody: Partial<CreateOperationCostDto>[]
  let foreignKeys: OperationCostForeignKeys

  beforeEach(async () => {
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories) // * Create foreign keys
    const { personnelId, projectId } = foreignKeys

    // * prepare the request body
    const operationCostFixture = fixture.create.operationCost
    operationCostFixture.personnelId = personnelId
    operationCostFixture.projectId = projectId
    requestBody = [operationCostFixture]
  })

  afterEach(async () => {
    // * Delete the created operation cost
    await removeForeignKeys(repositories, foreignKeys)
  })

  it('PATCH: /operation-costs 200', async () => {
    const response = await request(app)
      .patch('/operation-costs')
      .send(requestBody)
      .set(auth)
    const responseBody = response.body

    const expectedStatusCode = 200
    const expectedFields = [
      'hoursNumber',
      'personnelId',
      'projectId',
      'yearOfMonthDate',
      'createdBy',
      'createdAt',
      'updatedBy',
      'updateAt',
      'processId',
      'processAt',
    ]

    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    responseBody.forEach((item: Operation) => {
      expectedFields.forEach((field: string) => {
        expect(item).toHaveProperty(field)
      })
    })

    // * Delete the created operation cost
    if (responseBody.length > 0) {
      const createdOperationCost = responseBody[0]
      await deleteOperationCost(repositories, createdOperationCost)
    }
  })

  it('PATCH /operation-costs: fail authentication', async () => {
    const response = await request(app)
      .patch('/operation-costs')
      .send(requestBody)
    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = { message: 'Forbidden' }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })
})
