import { Connection } from 'typeorm'
import express from 'express'
import { authGenerator } from '../common/authGenerator'
import { createApp } from '../../../src/infrastructure/webserver/express/app'
import { createConnection } from '../../../src/infrastructure/orm/typeorm/connection'
import { createRouter } from '../../../src/infrastructure/webserver/express/routes'
import request from 'supertest'
import prepareRepositories, {
  OperationCostRepositories,
} from './helpers/prepareRepositories.helper'
import fixture from './operationCost.fixture'
import createForeignKeys, {
  OperationCostForeignKeys,
} from './helpers/createForeignKeys.helper'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import { Dw_t_operation } from '../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation'
import deleteOperationCost, {
  DeleteOperationCost,
} from './helpers/deleteOperationCost.helper'
import { HeaderAuth } from '../../../src/domain/types/common.type'
import { Repositories } from '../../../src/application/port'
import { DeleteOperationCostDto } from '../../../src/interface/routes/operationCost/dto/operationCost.dto'

describe('TEST- Delete operation cost API', () => {
  let repositories: OperationCostRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(() => {
    connection.close()
  })

  let requestBody: DeleteOperationCostDto[]
  let foreignKeys: OperationCostForeignKeys

  beforeEach(async () => {
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories) // * Create foreign keys
    const { personnelId, projectId } = foreignKeys

    // * Prepare the item to be removed
    const operationCostFixture = fixture.delete.operationCost
    operationCostFixture.dw_m_personnel = personnelId
    operationCostFixture.dw_m_project = projectId

    // * Insert the item
    const operationCostToBeRemoved = await repositories.operationCostDBRepo.save(
      (operationCostFixture as unknown) as Dw_t_operation
    )
    // * Prepare the request body
    const requestBodyFixture = fixture.delete.requestBody
    requestBodyFixture.personnelId = (operationCostToBeRemoved.dw_m_personnel as unknown) as number
    requestBodyFixture.projectId = (operationCostToBeRemoved.dw_m_project as unknown) as number
    requestBodyFixture.yearOfMonthDate = (operationCostToBeRemoved.month_of_year_date as unknown) as Date

    requestBody = [requestBodyFixture]
  })

  afterEach(async () => {
    // * Delete the created operation cost
    await removeForeignKeys(repositories, foreignKeys)
  })

  it('Delete operation cost successfully', async () => {
    const response = await request(app)
      .delete('/operation-costs')
      .send(requestBody)
      .set(auth)
    const responseBody = response.body

    const expectedStatusCode = 200
    const expectedBody = {
      message: 'Records deleted successfully',
    }

    expect(response.status).toBe(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })

  it('try to delete operation cost without permissions', async () => {
    const response = await request(app)
      .delete('/operation-costs')
      .send(requestBody)
    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = { message: 'Forbidden' }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)

    // * Delete the created operation cost
    const createdOperationCost: DeleteOperationCost = {
      personnelId: requestBody[0].personnelId,
      projectId: requestBody[0].projectId,
      yearOfMonthDate: requestBody[0].yearOfMonthDate.toString(),
    }
    await deleteOperationCost(repositories, createdOperationCost)
  })
})
