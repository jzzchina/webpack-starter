const operationCostFixture = {
  create: {
    operationCost: {
      hoursNumber: 0.25,
      personnelId: -1, // To be replaced by the id of the personnel created in the test
      projectId: -1, // To be replaced by the id of the project created in the test
      yearOfMonthDate: '2022-01-01',
      costAmount: 0.5,
    },
    partnerCompany: {
      contract_pattern_code: 3,
      company_name: 'This is a test company',
      created_by: 'Integration Test',
      updated_by: 'Integration Test',
    },
    personnel: {
      personnel_id: undefined,
      name: 'Example Taro (Create a new personnel (id is auto generated))',
      name_jpn: '見本　太郎',
      registered_date: '2022-01-01',
      unregistered_date: null,
      skill_list: {
        LeadDev: { level: 1 },
        'FrontEnd,Web(React)': { level: 2 },
        'BackEnd,Node.js': { level: 3 },
      },
      dw_m_partner_company: -1, // To be replaced by the id of the partnerCompany created in the test
      created_by: 'Dhia Djobbi',
      updated_by: 'Dhia Djobbi',
    },
    project: {
      project_name: 'test project',
      project_contact: 'test@test.com',
      project_start_date: '2022-01-01',
      project_end_date: null,
      notes: 'This is a test project',
      created_by: 'Integration Test',
      updated_by: 'Integration Test',
      status: 0,
    },
  },
  delete: {
    operationCost: {
      dw_m_personnel: -1, // To be replaced by the id of the personnel created in the test
      dw_m_project: -1, // To be replaced by the id of the project created in the test
      cost_amount: 0.5,
      month_of_year_date: '2022-01-01',
      hours_number: 0.5,
      created_by: 'Integration Test',
      updated_by: 'Integration Test',
    },
    requestBody: {
      personnelId: -1, // To be replaced by the id of the personnel created in the test
      projectId: -1, // To be replaced by the id of the project created in the test
      yearOfMonthDate: new Date(''), // To be replaced by the year of the month of the operation cost to be deleted
    },
  },
  searchBy: {
    query: {
      limit: 100,
      offset: 0,
      project_id: -1, // To be replaced by the id of the project created in the test
      company_id: -1, // To be replaced by the id of the partnerCompany created in the test
      from: '2020-01-01',
      to: '2030-01-01',
    },
  },
}

export default operationCostFixture
