import { OperationCostRepositories } from './prepareRepositories.helper'

export interface DeleteOperationCost {
  personnelId: number
  projectId: number
  yearOfMonthDate: string
}

// * A helper function to delete the created operation cost
const deleteOperationCost = async (
  repositories: OperationCostRepositories,
  createdOperationCost: DeleteOperationCost
): Promise<void> => {
  await repositories.operationCostDBRepo
    .createQueryBuilder('dw_t_operation')
    .delete()
    .where('personnel_id=:personnel_id', {
      personnel_id: createdOperationCost.personnelId,
    })
    .andWhere('project_id=:project_id', {
      project_id: createdOperationCost.projectId,
    })
    .andWhere('month_of_year_date=:month_of_year_date', {
      month_of_year_date: createdOperationCost.yearOfMonthDate,
    })
    .execute()
}

export default deleteOperationCost
