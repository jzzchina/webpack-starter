import { Dw_m_personnel } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel'
import fixture from '../operationCost.fixture'
import { OperationCostRepositories } from './prepareRepositories.helper'

export interface OperationCostForeignKeys {
  companyId: number
  personnelId: number
  projectId: number
}

// A Helper function that creates all the foreign keys for the operationCost and returns the ids
const createForeignKeys = async (
  repositories: OperationCostRepositories
): Promise<OperationCostForeignKeys> => {
  // * We need to create a partnerCompany, so we can create a personnel
  const partnerCompanyFixture = fixture.create.partnerCompany
  const partnerCompany = await repositories.partnerCompanyRepo.save(
    partnerCompanyFixture
  )
  const companyId = partnerCompany.company_id

  // * Create a personnel
  const personnelFixture = fixture.create.personnel
  personnelFixture.dw_m_partner_company = companyId // * Set the partnerCompanyID
  const castedPersonnelFixture = (personnelFixture as unknown) as Dw_m_personnel
  const personnel = await repositories.personnelRepo.save(
    castedPersonnelFixture
  )
  const personnelId = personnel.personnel_id

  // * Create a project
  const projectFixture = fixture.create.project
  const project = await repositories.projectRepo.save(projectFixture)
  const projectId = project.project_id

  return { companyId, personnelId, projectId }
}

export default createForeignKeys
