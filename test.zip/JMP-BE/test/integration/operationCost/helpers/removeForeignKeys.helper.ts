import { OperationCostForeignKeys } from './createForeignKeys.helper'
import { OperationCostRepositories } from './prepareRepositories.helper'

// * A Helper function that removes all the foreign keys after running the tests
const removeForeignKeys = async (
  repositories: OperationCostRepositories,
  foreignKeys: OperationCostForeignKeys
): Promise<void> => {
  const { companyId, personnelId, projectId } = foreignKeys

  // * Delete the created project
  await repositories.projectRepo.delete({ project_id: projectId })

  // * Delete the created personnel
  await repositories.personnelRepo.delete({ personnel_id: personnelId })

  // * Delete the created partnerCompany
  await repositories.partnerCompanyRepo.delete({ company_id: companyId })
}

export default removeForeignKeys
