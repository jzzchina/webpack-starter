import { operationCostRepositoryMySQL } from '../../../../src/infrastructure/repositories/operationCost/operationCostRepositoryMySQL'
import { OperationCostRepositoryPort } from '../../../../src/application/port/repositories/operationCost/OperationCostRepositoryPort'
import { Connection, Repository } from 'typeorm'
import { Dw_m_partner_company } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_partner_company'
import { Dw_m_personnel } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { Dw_m_project } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_project'
import { Dw_t_operation } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation'

export interface OperationCostRepositories {
  operationCostRepository: OperationCostRepositoryPort
  operationCostDBRepo: Repository<Dw_t_operation>
  personnelRepo: Repository<Dw_m_personnel>
  projectRepo: Repository<Dw_m_project>
  // roleRepo: Repository<Dw_m_role>;
  partnerCompanyRepo: Repository<Dw_m_partner_company>
}

// * A function that prepares the repositories for the tests
const prepareRepositories = async (
  connection: Connection
): Promise<OperationCostRepositories> => {
  const operationCostRepository: OperationCostRepositoryPort = await operationCostRepositoryMySQL(
    connection
  )
  const operationCostDBRepo: Repository<Dw_t_operation> = await connection.getRepository(
    Dw_t_operation
  )
  const personnelRepo: Repository<Dw_m_personnel> = await connection.getRepository(
    Dw_m_personnel
  )
  const projectRepo: Repository<Dw_m_project> = await connection.getRepository(
    Dw_m_project
  )
  const partnerCompanyRepo: Repository<Dw_m_partner_company> = connection.getRepository(
    Dw_m_partner_company
  )

  const repositories = {
    operationCostRepository,
    operationCostDBRepo,
    personnelRepo,
    projectRepo,
    partnerCompanyRepo,
  }

  return repositories
}

export default prepareRepositories
