import request from 'supertest'
import express from 'express'
import { Connection } from 'typeorm'

import { createApp } from '../../src/infrastructure/webserver/express/app'
import { createConnection } from '../../src/infrastructure/orm/typeorm/connection'
import { createRouter } from '../../src/infrastructure/webserver/express/routes'
import { personnelRepositoryMySQL } from '../../src/infrastructure/repositories/options/personnel/personnelRepositoryMySQL'
import { authGenerator } from './common/authGenerator'
import { HeaderAuth } from '../../src/domain/types/common.type'
import { Repositories } from '../../src/application/port'

describe('Guide Testing', () => {
  const repositories = {} as Repositories
  let connection: Connection
  let auth: HeaderAuth

  let app: express.Express
  beforeAll(async () => {
    auth = authGenerator()
    app = createApp()
    connection = await createConnection()
    repositories.personnelRepository = await personnelRepositoryMySQL(
      connection
    )
    app.use('/', createRouter(repositories))
  })

  afterAll(() => {
    connection.close()
  })

  test('Should get all personnel with no filters ', async () => {
    const res = await request(app).post('/personnel').set(auth)
    expect(res.statusCode).toBe(200)
  })
})
