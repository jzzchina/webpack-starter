import request from 'supertest'
import express from 'express'
import { Connection } from 'typeorm'

import { createConnection } from '../../../../src/infrastructure/orm/typeorm/connection'
import { authGenerator } from '../../common/authGenerator'
import { createApp } from '../../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../../src/infrastructure/webserver/express/routes'
import prepareRepositories, {
  PartnerCompanyRepositories,
} from './helpers/prepareRepositories.helper'
import fixture from './partnerCompany.fixture'
import deletePartnerCompany from './helpers/deletePartnerCompany.helper'
import { Dw_m_partner_company } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_partner_company'
import { HeaderAuth } from '../../../../src/domain/types/common.type'
import { Repositories } from '../../../../src/application/port'
import {
  PartnerCompany,
  PartnerCompanyListResponse,
} from '../../../../src/interface/routes/options/partnerCompany/dto/partnerCompany.dto'

describe('TEST - FindAll partnerCompany API', () => {
  let repositories: PartnerCompanyRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let createdCompanyID: number
  let createdCompaniesIds: number[] = []

  const partnerCompanyFixture = fixture.getAll.partnerCompany
  const limit = 10
  const offset = 0
  const contract_pattern_code = partnerCompanyFixture[0].contract_pattern_code
  const company_name = partnerCompanyFixture[0].company_name
  const query = {
    limit,
    offset,
    contract_pattern_code,
    company_name,
    company_id: -1,
  }

  beforeEach(async () => {
    // * Insert the partner company so it can be retrieved
    const partnerCompany = await repositories.partnerCompanyDBRepo.save(
      partnerCompanyFixture
    )
    createdCompanyID = partnerCompany[0].company_id
    createdCompaniesIds = partnerCompany.map((company) => company.company_id)

    const personnelFixture = fixture.create.personnel
    personnelFixture.dw_m_partner_company.company_id = createdCompanyID
    await repositories.personnelDBRepo.save(
      (personnelFixture as unknown) as Dw_m_partner_company
    )
  })

  afterEach(async () => {
    // * Delete the created partner company
    await deletePartnerCompany(repositories, createdCompaniesIds)
  })

  it('GET: /partner-companies 200', async () => {
    query.company_id = createdCompanyID

    const response = await request(app)
      .get('/partner-companies')
      .set(auth)
      .query(query)

    const responseBody = response.body

    const expectedStatusCode = 200
    const expectedBodyFields = ['offset', 'length', 'totalLength', 'items']
    const expectedItems = [
      'companyId',
      'contractPatternCode',
      'companyName',
      'numberOfPersonnel',
    ]

    // * Check if the response status code is the expected
    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    expectedBodyFields.forEach((expectedBodyField: string) => {
      expect(responseBody).toHaveProperty(expectedBodyField)
    })

    // * Check if the response body has the expected Items
    responseBody.items.forEach((item: PartnerCompany) => {
      expectedItems.forEach((expectedItem: string) => {
        expect(item).toHaveProperty(expectedItem)
      })
    })
    expect(responseBody.items[0].companyName).toEqual('AVAXIA')

    // * Check if the search result is correct
    responseBody.items.forEach((item: PartnerCompany) => {
      expect(item.companyId).toEqual(createdCompanyID)
      expect(item.contractPatternCode).toEqual(contract_pattern_code)
      expect(item.companyName).toEqual(company_name)
      expect(item.numberOfPersonnel).toEqual(1)
    })
  })
  it('GET ALL: /partner-companies 200', async () => {
    query.company_id = createdCompanyID

    const response = await request(app).get('/partner-companies').set(auth)

    const responseBody: PartnerCompanyListResponse = response.body

    const expectedStatusCode = 200
    const expectedBodyFields = ['offset', 'length', 'totalLength', 'items']
    const expectedItems = [
      'companyId',
      'contractPatternCode',
      'companyName',
      'numberOfPersonnel',
    ]

    // * Check if the response status code is the expected
    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    expectedBodyFields.forEach((expectedBodyField: string) => {
      expect(responseBody).toHaveProperty(expectedBodyField)
    })
    expect(responseBody.items[0].companyName).toEqual('AVAXIA')
    expect(responseBody.items[1].companyName).toEqual('JERA')
    // * Check if the response body has the expected Items
    responseBody.items.forEach((item: PartnerCompany) => {
      expectedItems.forEach((expectedItem: string) => {
        expect(item).toHaveProperty(expectedItem)
      })
    })
  })

  it('GET: /partner-companies - expect to return 403', async () => {
    const response = await request(app).get('/partner-companies').query(query)
    query.company_id = createdCompanyID

    // .set(auth); // * No auth token

    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = {
      message: 'Forbidden',
    }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })
})
