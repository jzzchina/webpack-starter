import { Connection, Repository } from 'typeorm'
import { Dw_m_partner_company } from './../../../../../src/infrastructure/orm/typeorm/entities/Dw_m_partner_company'
import { PartnerCompanyRepositoryPort } from './../../../../../src/application/port/repositories/partnerCompany/PartnerCompanyRepositoryPort'
import { partnerCompanyRepositoryMySQL } from './../../../../../src/infrastructure/repositories/options/partnerCompany/partnerCompanyRepositoryMySQL'
import { Dw_m_personnel } from '../../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel'

export interface PartnerCompanyRepositories {
  partnerCompanyRepository: PartnerCompanyRepositoryPort
  partnerCompanyDBRepo: Repository<Dw_m_partner_company>
  personnelDBRepo: Repository<Dw_m_personnel>
}

// * A function that prepares the repositories for the tests
const prepareRepositories = async (
  connection: Connection
): Promise<PartnerCompanyRepositories> => {
  const partnerCompanyRepository: PartnerCompanyRepositoryPort = await partnerCompanyRepositoryMySQL(
    connection
  )
  const partnerCompanyDBRepo: Repository<Dw_m_partner_company> = await connection.getRepository(
    Dw_m_partner_company
  )
  const personnelDBRepo: Repository<Dw_m_personnel> = await connection.getRepository(
    Dw_m_personnel
  )

  const repositories = {
    partnerCompanyRepository,
    partnerCompanyDBRepo,
    personnelDBRepo,
  }

  return repositories
}

export default prepareRepositories
