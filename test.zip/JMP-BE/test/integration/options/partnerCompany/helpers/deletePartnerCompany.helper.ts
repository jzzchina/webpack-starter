import { PartnerCompanyRepositories } from './prepareRepositories.helper'

// * A helper function to delete the created partner company
const deletePartnerCompanies = async (
  repositories: PartnerCompanyRepositories,
  companyIds: number[]
): Promise<void> => {
  await repositories.partnerCompanyDBRepo.delete(companyIds)
}

export default deletePartnerCompanies
