import express from 'express'
import request from 'supertest'
import { Connection } from 'typeorm'
import { createConnection } from './../../../../src/infrastructure/orm/typeorm/connection/index'
import { createApp } from './../../../../src/infrastructure/webserver/express/app'
import { createRouter } from './../../../../src/infrastructure/webserver/express/routes'
import { authGenerator } from './../../common/authGenerator'
import fixture from './partnerCompany.fixture'
import prepareRepositories, {
  PartnerCompanyRepositories,
} from './helpers/prepareRepositories.helper'
import deletePartnerCompany from './helpers/deletePartnerCompany.helper'
import {
  PartnerCompany,
  PartnerCompanyCreateResponse,
} from '../../../../src/interface/routes/options/partnerCompany/dto/partnerCompany.dto'
import { HeaderAuth } from '../../../../src/domain/types/common.type'
import { Repositories } from '../../../../src/application/port'

describe('TEST - Create partner company API', () => {
  let repositories: PartnerCompanyRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let requestBody: Partial<PartnerCompany>[]

  beforeEach(async () => {
    // * prepare the request body
    const partnerCompanyFixture = fixture.create.partnerCompany
    requestBody = [partnerCompanyFixture]
  })

  it('PATCH: /partner-companies 200', async () => {
    const response = await request(app)
      .patch('/partner-companies')
      .send(requestBody)
      .set(auth)
    const responseBody = response.body

    const expectedStatusCode = 200
    const expectedFields = [
      'companyId',
      'contractPatternCode',
      'companyName',
      'createdBy',
      'createAt',
      'updatedBy',
      'updateAt',
      'processAt',
      'processId',
    ]

    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    responseBody.forEach((item: PartnerCompanyCreateResponse) => {
      expectedFields.forEach((field: string) => {
        expect(item).toHaveProperty(field)
      })
    })

    // * Delete the created partner company
    if (responseBody.length > 0) {
      const createdPartnerCompany = responseBody[0]
      await deletePartnerCompany(repositories, createdPartnerCompany.companyId)
    }
  })

  it('PATCH /partner-companies: fail authentication', async () => {
    const response = await request(app)
      .patch('/partner-companies')
      .send(requestBody)
    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = { message: 'Forbidden' }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })
})
