const partnerCompanyFixture = {
  create: {
    partnerCompany: {
      contractPatternCode: 3,
      companyName: 'Test Company',
    },

    personnel: {
      name: 'Example Taro (Create a new personnel (id is auto generated))',
      name_jpn: '見本　太郎',
      registered_date: '2022-01-01',
      unregistered_date: null,
      skill_list: {
        LeadDev: {
          level: 1,
        },
        'FrontEnd,Web(React)': {
          level: 2,
        },
        'BackEnd,Node.js': {
          level: 3,
        },
      },
      dw_m_partner_company: { company_id: -1 }, // To be replaced by the id of the company created in the test
      created_by: 'Integration Test',
      updated_by: 'Integration Test',
    },
  },

  getAll: {
    partnerCompany: [
      {
        contract_pattern_code: 2,
        company_name: 'AVAXIA',
        created_by: 'Integration Test',
        updated_by: 'Integration Test',
      },
      {
        contract_pattern_code: 2,
        company_name: 'JERA',
        created_by: 'Integration Test',
        updated_by: 'Integration Test',
      },
    ],
  },
}

export default partnerCompanyFixture
