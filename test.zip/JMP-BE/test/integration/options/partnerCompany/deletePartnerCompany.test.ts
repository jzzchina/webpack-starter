import express from 'express'
import request from 'supertest'
import { Connection } from 'typeorm'
import { createConnection } from './../../../../src/infrastructure/orm/typeorm/connection/index'
import { createApp } from './../../../../src/infrastructure/webserver/express/app'
import { createRouter } from './../../../../src/infrastructure/webserver/express/routes'
import { authGenerator } from './../../common/authGenerator'
import fixture from './partnerCompany.fixture'
import prepareRepositories, {
  PartnerCompanyRepositories,
} from './helpers/prepareRepositories.helper'
import deletePartnerCompanies from './helpers/deletePartnerCompany.helper'
import { HeaderAuth } from '../../../../src/domain/types/common.type'
import { Repositories } from '../../../../src/application/port'

describe('TEST - Delete partner company API', () => {
  let repositories: PartnerCompanyRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let createdPartnerCompanyIDs: number[]

  beforeEach(async () => {
    // * prepare the request body
    const partnerCompanyFixture = fixture.getAll.partnerCompany
    // * Insert the partner company so it can be retrieved
    const partnerCompany = await repositories.partnerCompanyDBRepo.save(
      partnerCompanyFixture
    )
    createdPartnerCompanyIDs = partnerCompany.map(
      (partnerCompany) => partnerCompany.company_id
    )
  })

  afterEach(async () => {
    // * Delete the created partner companies

    await deletePartnerCompanies(repositories, createdPartnerCompanyIDs)
  })

  it('DELETE: /partner-companies 404', async () => {
    const response = await request(app)
      .delete('/partner-companies')
      .query({ company_id: createdPartnerCompanyIDs[0] + 100 })
      .set(auth)
    const responseBody = response.body
    const expectedStatusCode = 404
    const expectedBody = { message: " Records doesn't exist!" }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })

  it('DELETE: /partner-companies 200', async () => {
    const response = await request(app)
      .delete('/partner-companies')
      .query({ company_id: createdPartnerCompanyIDs })
      .set(auth)

    const expectedStatusCode = 200
    const expectedBody = { message: 'Records deleted successfully' }
    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body
    expect(response.body).toEqual(expectedBody)
  })

  it('DELETE /partner-companies: fail authentication', async () => {
    const response = await request(app)
      .delete('/partner-companies')
      .query({ company_id: createdPartnerCompanyIDs })

    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = { message: 'Forbidden' }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })
})
