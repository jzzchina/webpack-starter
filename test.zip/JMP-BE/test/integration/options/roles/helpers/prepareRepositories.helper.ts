import { Connection, Repository } from 'typeorm'
import { RoleRepositoryPort } from '../../../../../src/application/port/repositories/role/RoleRepositoryPort'
import { Dw_m_role } from '../../../../../src/infrastructure/orm/typeorm/entities/Dw_m_role'
import { roleRepositoryMySQL } from '../../../../../src/infrastructure/repositories/options/role/roleRepositoryMySQL'

export interface RoleRepositories {
  roleRepository: RoleRepositoryPort
  roleDBRepo: Repository<Dw_m_role>
}

// * A function that prepares the repositories for the tests
const prepareRepositories = async (
  connection: Connection
): Promise<RoleRepositories> => {
  const roleRepository: RoleRepositoryPort = await roleRepositoryMySQL(
    connection
  )
  const roleDBRepo: Repository<Dw_m_role> = await connection.getRepository(
    Dw_m_role
  )

  const repositories = {
    roleRepository,
    roleDBRepo,
  }

  return repositories
}

export default prepareRepositories
