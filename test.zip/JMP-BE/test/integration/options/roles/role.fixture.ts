const roleFixture = {
  getAll: {
    role: {
      role_name: 'Test_role',
      created_by: 'Integration Test',
      updated_by: 'Integration Test',
    },
  },
}

export default roleFixture
