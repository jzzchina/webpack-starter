import request from 'supertest'
import express from 'express'
import { Connection } from 'typeorm'

import { createConnection } from '../../../../src/infrastructure/orm/typeorm/connection'
import { authGenerator } from '../../common/authGenerator'
import { createApp } from '../../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../../src/infrastructure/webserver/express/routes'
import prepareRepositories, {
  RoleRepositories,
} from './helpers/prepareRepositories.helper'
import fixture from './role.fixture'
import { HeaderAuth } from '../../../../src/domain/types/common.type'
import { Repositories } from '../../../../src/application/port'
import { RoleListResponse } from '../../../../src/infrastructure/repositories/options/role/interface'

describe('TEST - FindAll Roles API', () => {
  let repositories: RoleRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let createdRoleID: number

  beforeEach(async () => {
    // * prepare the request body
    const roleFixture = fixture.getAll.role

    // * Insert the role so it can be retrieved
    const role = await repositories.roleDBRepo.save(roleFixture)
    createdRoleID = role.role_id
  })

  afterEach(async () => {
    // * Delete the created role
    await repositories.roleDBRepo.delete(createdRoleID)
  })

  it('GET: /roles 200', async () => {
    const response = await request(app).get('/roles').set(auth)
    const responseBody: RoleListResponse = response.body

    const expectedStatusCode = 200
    const expectedItems = ['roleId', 'roleName']

    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    responseBody.items?.forEach((item) => {
      expectedItems.forEach((expectedItem: string) => {
        expect(item).toHaveProperty(expectedItem)
      })
    })
  })

  it('GET: /roles - expect to return 403', async () => {
    const response = await request(app).get('/roles')
    // .set(auth); // * No auth token
    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = {
      message: 'Forbidden',
    }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })
})
