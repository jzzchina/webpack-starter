import request from 'supertest'
import express from 'express'
import { Connection } from 'typeorm'

import { createConnection } from '../../../../src/infrastructure/orm/typeorm/connection'
import { authGenerator } from '../../common/authGenerator'
import { createApp } from '../../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../../src/infrastructure/webserver/express/routes'
import prepareRepositories, {
  PersonnelPriceRepositories,
} from './helpers/prepareRepositories.helper'
import createForeignKeys, {
  PersonnelPriceForeignKeys,
} from './helpers/createForeignKeys.helper'
import fixture from './personnelPrice.fixture'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import deletePersonnelPrice from './helpers/deletePersonnelPrice.helper'
import { PersonnelPrice } from '../../../../src/domain/models/PersonnelPrice'
import { HeaderAuth } from '../../../../src/domain/types/common.type'
import { Repositories } from '../../../../src/application/port'

describe('TEST - Create personnelPrices API', () => {
  let repositories: PersonnelPriceRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let foreignKeys: PersonnelPriceForeignKeys
  let requestBody: PersonnelPrice[]

  beforeEach(async () => {
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories)
    const { personnelId } = foreignKeys

    // * Prepare request body
    const personnelPriceFixture = fixture.create
      .personnelPrice as PersonnelPrice
    personnelPriceFixture.personnelId = personnelId
    requestBody = [personnelPriceFixture as PersonnelPrice]
  })

  afterEach(async () => {
    // * Delete the created foreign keys
    await removeForeignKeys(repositories, foreignKeys)
  })

  it('PATCH: /personnel-prices 200', async () => {
    const response = await request(app)
      .patch('/personnel-prices')
      .set(auth)
      .send(requestBody)

    const responseBody: PersonnelPrice[] = response.body

    const expectedStatusCode = 200
    const expectedItems = [
      'personnelId',
      'priceStartDate',
      'priceAmount',
      'currencyTypeCode',
      'contractPatternCode',
    ]

    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    responseBody.forEach((item) => {
      expectedItems.forEach((expectedItem: string) => {
        expect(item).toHaveProperty(expectedItem)
      })
    })
    // * Delete the created personnelPrice
    const createdPersonnelPrice: PersonnelPrice = responseBody[0]
    await deletePersonnelPrice(
      repositories,
      createdPersonnelPrice.personnelId as number,
      createdPersonnelPrice.priceStartDate
    )
  })

  it('PATCH: /personnel-prices - create with price equal to 0', async () => {
    requestBody[0].priceAmount =
      fixture.create.personnelPriceZeroPrice.priceAmount

    const response = await request(app)
      .patch('/personnel-prices')
      .set(auth)
      .send(requestBody)

    const responseBody: PersonnelPrice[] = response.body

    const expectedStatusCode = 200
    const expectedItems = [
      'personnelId',
      'priceStartDate',
      'priceAmount',
      'currencyTypeCode',
      'contractPatternCode',
    ]

    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    responseBody.forEach((item) => {
      expectedItems.forEach((expectedItem: string) => {
        expect(item).toHaveProperty(expectedItem)
      })
    })
    // * Delete the created personnelPrice
    const createdPersonnelPrice: PersonnelPrice = responseBody[0]
    await deletePersonnelPrice(
      repositories,
      createdPersonnelPrice.personnelId as number,
      createdPersonnelPrice.priceStartDate
    )
  })

  it('PATCH: /personnel-prices - expect to return 403', async () => {
    const response = await request(app)
      .patch('/personnel-prices')
      // .set(auth); // * No auth token
      .send(requestBody)
    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = {
      message: 'Forbidden',
    }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })
})
