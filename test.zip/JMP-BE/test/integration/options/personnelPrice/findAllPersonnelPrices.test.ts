import request from 'supertest'
import express from 'express'
import { Connection } from 'typeorm'

import { createConnection } from '../../../../src/infrastructure/orm/typeorm/connection'
import { authGenerator } from '../../common/authGenerator'
import { createApp } from '../../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../../src/infrastructure/webserver/express/routes'
import prepareRepositories, {
  PersonnelPriceRepositories,
} from './helpers/prepareRepositories.helper'
import createForeignKeys, {
  PersonnelPriceForeignKeys,
} from './helpers/createForeignKeys.helper'
import fixture from './personnelPrice.fixture'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import { Dw_m_personnel_price } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel_price'
import deletePersonnelPrice from './helpers/deletePersonnelPrice.helper'
import { Dw_m_personnel } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { HeaderAuth } from '../../../../src/domain/types/common.type'
import { Repositories } from '../../../../src/application/port'
import { PersonnelPriceList } from '../../../../src/interface/routes/options/personnelPrice/dto/personnelPrice.dto'

describe('TEST - FindAll personnelPrices API', () => {
  let repositories: PersonnelPriceRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let foreignKeys: PersonnelPriceForeignKeys
  let createdPersonnelPrice: Dw_m_personnel_price

  beforeEach(async () => {
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories)
    const { personnelId } = foreignKeys
    // * Prepare personnelPrice fixture
    const personnelPriceFixture = fixture.getAll.personnelPrice
    personnelPriceFixture.dw_m_personnel = personnelId
    const castedPersonnelPriceFixture = (personnelPriceFixture as unknown) as Dw_m_personnel_price

    // * Insert the personnelPrice so it can be retrieved
    createdPersonnelPrice = await repositories.personnelPriceDBRepo.save(
      castedPersonnelPriceFixture
    )
  })

  afterEach(async () => {
    // * Delete the created foreign keys
    await removeForeignKeys(repositories, foreignKeys)
  })

  it('GET: /personnel-prices 200', async () => {
    const response = await request(app)
      .get('/personnel-prices')
      .set(auth)
      .query({ personnel_id: createdPersonnelPrice.dw_m_personnel })

    const responseBody: PersonnelPriceList = response.body

    const expectedStatusCode = 200
    const expectedItems = [
      'personnelId',
      'priceStartDate',
      'priceAmount',
      'currencyTypeCode',
      'contractPatternCode',
    ]

    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    responseBody.items.forEach((item) => {
      expectedItems.forEach((expectedItem: string) => {
        expect(item).toHaveProperty(expectedItem)
      })
    })
    // * Delete the created personnelPrice
    const idPersonnel = createdPersonnelPrice.dw_m_personnel as Dw_m_personnel
    await deletePersonnelPrice(
      repositories,
      (idPersonnel as unknown) as number,
      createdPersonnelPrice.price_start_date
    )
  })

  it('GET: /personnel-prices - expect to return 403', async () => {
    const response = await request(app)
      .get('/personnel-prices')
      // .set(auth); // * No auth token
      .query({ personnel_id: createdPersonnelPrice.dw_m_personnel })
    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = {
      message: 'Forbidden',
    }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
    // * Delete the created personnelPrice
    const idPersonnel = createdPersonnelPrice.dw_m_personnel as Dw_m_personnel
    await deletePersonnelPrice(
      repositories,
      (idPersonnel as unknown) as number,
      createdPersonnelPrice.price_start_date
    )
  })
})
