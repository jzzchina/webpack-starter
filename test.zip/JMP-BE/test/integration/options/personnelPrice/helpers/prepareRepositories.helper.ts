import { Connection, Repository } from 'typeorm'
import { PersonnelPriceRepositoryPort } from '../../../../../src/application/port/repositories/personnelPriceRepositoryPort.ts/PersonnelPriceRepositoryPort'
import { Dw_m_partner_company } from '../../../../../src/infrastructure/orm/typeorm/entities/Dw_m_partner_company'
import { Dw_m_personnel } from '../../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { Dw_m_personnel_price } from '../../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel_price'
import { personnelPriceRepositoryMySQL } from '../../../../../src/infrastructure/repositories/options/personnelPrice/personnelPriceRepositoryMySQL'

export interface PersonnelPriceRepositories {
  // * The repository that will be used in the tests
  personnelPriceRepository: PersonnelPriceRepositoryPort
  // * Repositories that will be used to prepare the database for the tests
  personnelPriceDBRepo: Repository<Dw_m_personnel_price>
  partnerCompanyDBRepo: Repository<Dw_m_partner_company>
  personnelDBRepo: Repository<Dw_m_personnel>
}

// * A function that prepares the repositories for the tests
const prepareRepositories = async (
  connection: Connection
): Promise<PersonnelPriceRepositories> => {
  const personnelPriceDBRepo: Repository<Dw_m_personnel_price> = connection.getRepository(
    Dw_m_personnel_price
  )
  const personnelPriceRepository: PersonnelPriceRepositoryPort = await personnelPriceRepositoryMySQL(
    connection
  )
  const partnerCompanyDBRepo: Repository<Dw_m_partner_company> = connection.getRepository(
    Dw_m_partner_company
  )
  const personnelDBRepo: Repository<Dw_m_personnel> = await connection.getRepository(
    Dw_m_personnel
  )

  const repositories = {
    personnelPriceDBRepo,
    personnelPriceRepository,
    partnerCompanyDBRepo,
    personnelDBRepo,
  }

  return repositories
}

export default prepareRepositories
