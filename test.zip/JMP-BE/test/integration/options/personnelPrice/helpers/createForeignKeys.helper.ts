import { Dw_m_personnel } from '../../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { PersonnelPriceRepositories } from './prepareRepositories.helper'
import fixture from '../personnelPrice.fixture'

export interface PersonnelPriceForeignKeys {
  companyId: number
  personnelId: number
}

// A Helper function that creates all the foreign keys for the PersonnelPrice and returns the ids
const createForeignKeys = async (
  repositories: PersonnelPriceRepositories
): Promise<PersonnelPriceForeignKeys> => {
  // * We need to create a partnerCompany, so we can create a personnel
  const partnerCompanyFixture = fixture.getAll.partnerCompany
  const partnerCompany = await repositories.partnerCompanyDBRepo.save(
    partnerCompanyFixture
  )
  const companyId = partnerCompany.company_id

  // * Create a personnel
  const personnelFixture = fixture.getAll.personnel
  personnelFixture.dw_m_partner_company = companyId // * Set the partnerCompanyID
  const castedPersonnelFixture = (personnelFixture as unknown) as Dw_m_personnel
  const personnel = await repositories.personnelDBRepo.save(
    castedPersonnelFixture
  )
  const personnelId = personnel.personnel_id

  return { companyId, personnelId }
}

export default createForeignKeys
