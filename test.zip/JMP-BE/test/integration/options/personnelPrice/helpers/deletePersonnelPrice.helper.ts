import { PersonnelPriceRepositories } from './prepareRepositories.helper'

// * A helper function to delete the personnelPrice
const deletePersonnelPrice = async (
  repositories: PersonnelPriceRepositories,
  personnel_id: number,
  price_start_date: Date
): Promise<void> => {
  // * Delete by personnel_id and price_start_date
  await repositories.personnelPriceDBRepo
    .createQueryBuilder('dw_t_personnel_price')
    .delete()
    .where('dw_m_personnel = :personnel_id', { personnel_id })
    .andWhere('price_start_date = :price_start_date', { price_start_date })
    .execute()
}

export default deletePersonnelPrice
