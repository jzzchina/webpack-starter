import { PersonnelPriceForeignKeys } from './createForeignKeys.helper'
import { PersonnelPriceRepositories } from './prepareRepositories.helper'

// * A Helper function that removes all the foreign keys after running the tests
const removeForeignKeys = async (
  repositories: PersonnelPriceRepositories,
  foreignKeys: PersonnelPriceForeignKeys
): Promise<void> => {
  const { personnelId, companyId } = foreignKeys
  // * Delete the created personnel
  await repositories.personnelDBRepo.delete({ personnel_id: personnelId })

  // * Delete the created partnerCompany
  await repositories.partnerCompanyDBRepo.delete({ company_id: companyId })
}

export default removeForeignKeys
