const personnelPriceFixture = {
  getAll: {
    partnerCompany: {
      contract_pattern_code: 3,
      company_name: 'This is a test company',
      created_by: 'Integration Test',
      updated_by: 'Integration Test',
    },
    personnel: {
      name: 'Test Personnel',
      name_jpn: '見本太郎',
      registered_date: '2022-01-01',
      unregistered_date: null,
      skill_list: {
        LeadDev: [Object],
        'FrontEnd,Web(React)': [Object],
        'BackEnd,Node.js': [Object],
      },
      dw_m_partner_company: 1,
      created_by: 'Integration Test',
      updated_by: 'Integration Test',
    },
    personnelPrice: {
      dw_m_personnel: -1, // * This will be replaced with the personnelId
      contract_pattern_code: 3,
      price_start_date: '2022-01-01',
      price_amount: 100,
      currency_type_code: 1,
      created_by: 'Integration Test',
      updated_by: 'Integration Test',
      create_at: '2021-01-01',
      update_at: '2021-01-01',
      process_at: '2021-01-01',
      process_id: null,
    },
  },
  create: {
    personnelPrice: {
      personnelId: -1, // * This will be replaced with the personnelId
      priceStartDate: new Date('2022-01-01'),
      priceAmount: 5625,
      currencyTypeCode: 0,
      contractPatternCode: 0,
    },
    personnelPriceZeroPrice: {
      personnelId: -1, // * This will be replaced with the personnelId
      priceStartDate: new Date('2022-01-01'),
      priceAmount: 0,
      currencyTypeCode: 0,
      contractPatternCode: 0,
    },
  },
}

export default personnelPriceFixture
