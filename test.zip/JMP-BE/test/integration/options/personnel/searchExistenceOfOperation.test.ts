import request from 'supertest'
import express from 'express'
import { Connection } from 'typeorm'

import { createConnection } from '../../../../src/infrastructure/orm/typeorm/connection'
import { authGenerator } from '../../common/authGenerator'
import { createApp } from '../../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../../src/infrastructure/webserver/express/routes'
import prepareRepositories, {
  PersonnelRepositories,
} from './helpers/prepareRepositories.helper'
import createForeignKeys, {
  PersonelForeignKeys,
} from '../../options/personnel/helpers/createForeignKeys.helper'
import removeForeignKeys from '../../options/personnel/helpers/removeForeignKeys.helper'
import { HeaderAuth } from '../../../../src/domain/types/common.type'
import { Repositories } from '../../../../src/application/port'

describe('Search Existence Of Operation for Personnel', () => {
  let personnelrepositories: PersonnelRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    personnelrepositories = await prepareRepositories(connection)
    app.use(
      '/',
      createRouter((personnelrepositories as unknown) as Repositories)
    ) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let foreignKeys: PersonelForeignKeys

  beforeEach(async () => {
    // * Create foreign keys
    foreignKeys = await createForeignKeys(personnelrepositories)
  })

  afterEach(async () => {
    // * Delete the created foreign keys
    await removeForeignKeys(personnelrepositories, foreignKeys)
  })

  it('GET: /personnel/:personnelId/search-existence-of-operation - 200', async () => {
    const response = await request(app)
      .get(
        `/personnel/${foreignKeys.personnelId}/search-existence-of-operation`
      )
      .query({ from: '2000-01-01' })
      .set(auth)
    const responseBody = response.body
    expect(responseBody).toHaveProperty('operationPlan')
    expect(responseBody).toHaveProperty('operation')
    expect(responseBody.operation).toEqual(true)
    expect(responseBody.operationPlan).toEqual(true)
    const expectedStatusCode = 200
    expect(response.statusCode).toEqual(expectedStatusCode)
  })

  it('GET: /personnel/:personnelId/search-existence-of-operation - 200, no records', async () => {
    const response = await request(app)
      .get(
        `/personnel/${foreignKeys.personnelId}/search-existence-of-operation`
      )
      .query({ from: '2060-01-01' })
      .set(auth)
    const responseBody = response.body
    expect(responseBody).toHaveProperty('operationPlan')
    expect(responseBody).toHaveProperty('operation')
    expect(responseBody.operation).toEqual(false)
    expect(responseBody.operationPlan).toEqual(false)
    const expectedStatusCode = 200
    expect(response.statusCode).toEqual(expectedStatusCode)
  })

  it('GET: /personnel/:personnelId/search-existence-of-operation - 200, no operation cost', async () => {
    const response = await request(app)
      .get(
        `/personnel/${foreignKeys.personnelId}/search-existence-of-operation`
      )
      .query({ from: '2000-01-01', to: '2021-01-01' })
      .set(auth)
    const responseBody = response.body
    expect(responseBody).toHaveProperty('operationPlan')
    expect(responseBody).toHaveProperty('operation')
    expect(responseBody.operation).toEqual(false)
    expect(responseBody.operationPlan).toEqual(true)
    const expectedStatusCode = 200
    expect(response.statusCode).toEqual(expectedStatusCode)
  })

  it('GET: /personnel/:personnelId/search-existence-of-operation - 422, validation error', async () => {
    const response = await request(app)
      .get(
        `/personnel/${foreignKeys.personnelId}/search-existence-of-operation`
      )
      .query({ frm: '2000-01-01' })
      .set(auth)
    const responseBody = response.body
    const expectedStatusCode = 422

    expect(responseBody).toEqual({
      res: 'Validation error',
      message: '"from" is required',
      type: 'any.required',
    })
    expect(response.statusCode).toEqual(expectedStatusCode)
  })
})
