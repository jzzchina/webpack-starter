const personnelFixture = {
  create: {
    personnel: {
      personnelId: 1,
      name: 'Example Taro (Create a new personnel (id is auto generated))',
      nameJpn: '見本　太郎',
      registeredDate: '2022-01-01',
      unregisteredDate: null,
      skillList: {
        LeadDev: {
          level: 1,
        },
        'FrontEnd,Web(React)': {
          level: 2,
        },
        'BackEnd,Node.js': {
          level: 3,
        },
      },
      companyId: -1, // To be replaced by the id of the company created in the test
    },
    personnelDB: {
      name: 'Perso1',
      name_jpn: '見本　太郎',
      registered_date: '2022-01-01',
      unregistered_date: null,
      skill_list: {
        LeadDev: {
          level: 1,
        },
        'FrontEnd,Web(React)': {
          level: 2,
        },

        'BackEnd,Node.js': {
          level: 3,
        },
      },
      dw_m_partner_company: {
        company_id: -1, // To be replaced by the id of the company created in the test
      },
      created_by: 'Integration Test',
      updated_by: 'Integration Test',
    },
    partnerCompany: {
      contract_pattern_code: 3,
      company_name: 'This is a test company',
      created_by: 'Integration Test',
      updated_by: 'Integration Test',
    },
    requiredFieldsOnly: {
      personnelId: 1,
      name: 'Example Taro (Create a new personnel (id is auto generated))',
      registeredDate: '2022-01-01',
      skillList: {
        LeadDev: {
          level: 1,
        },
        'FrontEnd,Web(React)': {
          level: 2,
        },
        'BackEnd,Node.js': {
          level: 3,
        },
      },
      companyId: -1, // To be replaced by the id of the company created in the test
    },
  },
  getAll: {
    personnel: [
      {
        name: 'B2TEST',
        name_jpn: '見本　太郎',
        registered_date: '2022-01-01',
        unregistered_date: null,
        skill_list: {
          LeadDev: {
            level: 1,
          },
          'FrontEnd,Web(React)': {
            level: 2,
          },

          'BackEnd,Node.js': {
            level: 3,
          },
        },
        dw_m_partner_company: -1, // To be replaced by the id of the company created in the test
        created_by: 'Integration Test',
        updated_by: 'Integration Test',
      },
      {
        name: 'C3TEST',
        name_jpn: '見本　太郎',
        registered_date: '2022-01-01',
        unregistered_date: null,
        skill_list: {
          LeadDev: {
            level: 1,
          },
          'FrontEnd,Web(React)': {
            level: 2,
          },

          'BackEnd,Node.js': {
            level: 3,
          },
        },
        dw_m_partner_company: -1, // To be replaced by the id of the company created in the test
        created_by: 'Integration Test',
        updated_by: 'Integration Test',
      },
    ],
    personnel_2: {
      name: 'Test Personnel Name 2',
      name_jpn: '見本　太郎 2',
      registered_date: '2022-01-01',
      unregistered_date: null,
      skill_list: {
        LeadDev: {
          level: 1,
        },
        'FrontEnd,Web(React) 2': {
          level: 2,
        },

        'BackEnd,Node.js': {
          level: 3,
        },
      },
      dw_m_partner_company: -1, // To be replaced by the id of the company created in the test
      created_by: 'Integration Test',
      updated_by: 'Integration Test',
    },
  },

  project: {
    project_id: 10,
    project_name: 'test project',
    project_start_date: '2022-01-01',
    status: 0,
    created_by: 'Integration Test',
    updated_by: 'Integration Test',
  },
  role: {
    role_id: 1,
    role_name: 'test role',
    created_by: 'Integration Test',
    updated_by: 'Integration Test',
  },
  operationPlan: {
    month_of_year_date: '2020-01-01',
    dw_m_personnel: {
      personnel_id: -1, // To be replaced by the id of the personnel created in the test
    },
    dw_m_project: {
      project_id: -1, // To be replaced by the id of the project created in the test,
    },
    dw_m_role: {
      role_id: -1, // To be replaced by the id of the role created in the test,
    },
    man_month_number: 1,
    hours_number: 0.1,
    created_by: 'Integration Test',
    updated_by: 'Integration Test',
  },

  operation: {
    month_of_year_date: '2022-01-01',
    hours_number: 0.1,
    cost_amount: 0.1,
    created_by: 'Integration Test',
    create_at: new Date(),
    updated_by: 'Integration Test',
    update_at: new Date(),
    dw_m_personnel: {
      personnel_id: -1, // To be replaced by the id of the personnel created in the test
    },
    dw_m_project: {
      project_id: -1, // To be replaced by the id of the project created in the test,
    },
  },
}
export default personnelFixture
