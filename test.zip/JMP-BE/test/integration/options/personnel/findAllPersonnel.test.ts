import request from 'supertest'
import express from 'express'
import { Connection } from 'typeorm'

import { createConnection } from '../../../../src/infrastructure/orm/typeorm/connection'
import { authGenerator } from '../../common/authGenerator'
import { createApp } from '../../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../../src/infrastructure/webserver/express/routes'
import prepareRepositories, {
  PersonnelRepositories,
} from './helpers/prepareRepositories.helper'
import createForeignKeys, {
  PersonelForeignKeys,
} from './helpers/createForeignKeys.helper'
import fixture from './personnel.fixture'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import deletePersonnel from './helpers/deletePersonnel.helper'
import { Dw_m_personnel } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { HeaderAuth } from '../../../../src/domain/types/common.type'
import { Repositories } from '../../../../src/application/port'
import { PaginatedPersonnelList } from '../../../../src/domain/models/Personnel'

describe('TEST - FindAll personnel API', () => {
  let repositories: PersonnelRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    // * Delete the created personnel
    await deletePersonnel(repositories, createdPersonelId)
    for (const personnelId of createdPersonelIds) {
      await deletePersonnel(repositories, personnelId)
    }
    await connection.close()
  })

  const requestBody = fixture.getAll.personnel[0].skill_list
  let foreignKeys: PersonelForeignKeys
  let createdPersonelIds: number[]
  let createdPersonelId: number
  beforeEach(async () => {
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories)
    const { companyId } = foreignKeys

    // * prepare the request body
    const personnelFixture = fixture.getAll.personnel
    personnelFixture[0].dw_m_partner_company = companyId
    personnelFixture[1].dw_m_partner_company = companyId

    const personnelFixture_2 = fixture.getAll.personnel_2
    personnelFixture_2.dw_m_partner_company = companyId

    // * Insert the personnel so it can be retrieved
    await insertManyPersonnel(personnelFixture, foreignKeys)
    await insertPersonnel(personnelFixture_2, foreignKeys)
  })

  async function insertPersonnel(
    personnelFixture: unknown,
    foreignKeys: PersonelForeignKeys
  ) {
    const { projectId, roleId } = foreignKeys

    const personnel = await repositories.personnelDBRepo.save(
      (personnelFixture as unknown) as Dw_m_personnel
    )
    createdPersonelId = personnel.personnel_id
    const operationPlanFixture = fixture.operationPlan
    operationPlanFixture.dw_m_personnel.personnel_id = createdPersonelId
    operationPlanFixture.dw_m_project.project_id = projectId
    operationPlanFixture.dw_m_role.role_id = roleId
    await repositories.operationPlanRepo.save(operationPlanFixture)
  }
  async function insertManyPersonnel(
    personnelFixture: unknown,
    foreignKeys: PersonelForeignKeys
  ) {
    const { projectId, roleId } = foreignKeys

    const personnel = ((await repositories.personnelDBRepo.save(
      (personnelFixture as unknown) as Dw_m_personnel
    )) as unknown) as Dw_m_personnel[]
    createdPersonelIds = personnel.map((p) => p.personnel_id)
    const operationPlanFixture = fixture.operationPlan
    operationPlanFixture.dw_m_personnel.personnel_id = personnel[0].personnel_id
    operationPlanFixture.dw_m_project.project_id = projectId
    operationPlanFixture.dw_m_role.role_id = roleId
    await repositories.operationPlanRepo.save(operationPlanFixture)
  }
  afterEach(async () => {
    // * Delete the created foreign keys
    await removeForeignKeys(repositories, foreignKeys)
  })

  it('POST: /personnel 200 find one', async () => {
    const response = await request(app)
      .post('/personnel')
      .query({
        // personnel_id: createdPersonelId,
        name: 'Test Personnel Name',
        company_id: foreignKeys.companyId,
      })
      .set(auth)
      .send(requestBody)

    const responseBody: PaginatedPersonnelList = response.body

    const expectedStatusCode = 200
    const expectedBodyFields = ['offset', 'length', 'totalLength', 'items']
    const expectedItems = [
      'personnelId',
      'name',
      'nameJpn',
      'registeredDate',
      'unregisteredDate',
      'companyId',
      'contractPatternCode',
      'companyName',
      'skillList',
      'prices',
      'allAssignedProjects',
    ]

    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    expectedBodyFields.forEach((expectedBodyField: string) => {
      expect(responseBody).toHaveProperty(expectedBodyField)
    })

    expect(responseBody.items.length).toEqual(1)

    // * Check if the response body items has the expected fields
    responseBody.items.forEach((item) => {
      expectedItems.forEach((expectedItem: string) => {
        expect(item).toHaveProperty(expectedItem)
        expect(item.allAssignedProjects).toBeInstanceOf(Array)
      })
    })
    expect(responseBody.items[0].allAssignedProjects).toEqual(['test project'])
    // * Delete the created personnel
  })

  it('POST: /personnel - get with pagination an sorted ', async () => {
    const response = await request(app)
      .post('/personnel')
      .query({
        limit: 100,
        offset: 0,
        // personnel_id: createdPersonelId,
        // name: 'Test Personnel Name',
      })
      .set(auth)
      .send(requestBody)

    const responseBody: PaginatedPersonnelList = response.body

    const expectedStatusCode = 200
    const expectedBodyFields = ['offset', 'length', 'totalLength', 'items']
    const expectedItems = [
      'personnelId',
      'name',
      'nameJpn',
      'registeredDate',
      'unregisteredDate',
      'companyId',
      'contractPatternCode',
      'companyName',
      'skillList',
      'prices',
      'allAssignedProjects',
    ]

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody.items.length).toEqual(4)
    expect(responseBody.items[0].name).toEqual('B2TEST')
    expect(responseBody.items[1].name).toEqual('C3TEST')
    expect(responseBody.items[2].name).toEqual('Perso1')

    // * Check if the response body has the expected fields
    expectedBodyFields.forEach((expectedBodyField: string) => {
      expect(responseBody).toHaveProperty(expectedBodyField)
    })
    // * Check if the response body items has the expected fields
    responseBody.items.forEach((item) => {
      expectedItems.forEach((expectedItem: string) => {
        expect(item).toHaveProperty(expectedItem)
        expect(item.allAssignedProjects).toBeInstanceOf(Array)
      })
    })
    // * Delete the created personnel
    if (responseBody.length > 0) {
      await deletePersonnel(repositories, createdPersonelId)
    }
  })

  it('POST: /personnel - find particular person', async () => {
    const response = await request(app)
      .post('/personnel')
      .query({
        personnel_id: createdPersonelId,
        name: 'Test Personnel Name 2',
        company_id: foreignKeys.companyId,
      })
      .set(auth)
      .send(requestBody)

    const responseBody: PaginatedPersonnelList = response.body

    const expectedStatusCode = 200
    const expectedBodyFields = ['offset', 'length', 'totalLength', 'items']
    const expectedItems = [
      'personnelId',
      'name',
      'nameJpn',
      'registeredDate',
      'unregisteredDate',
      'companyId',
      'contractPatternCode',
      'companyName',
      'skillList',
      'prices',
      'allAssignedProjects',
    ]

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody.items.length).toEqual(1)

    // * Check if the response body has the expected fields
    expectedBodyFields.forEach((expectedBodyField: string) => {
      expect(responseBody).toHaveProperty(expectedBodyField)
    })
    // * Check if the response body items has the expected fields
    responseBody.items.forEach((item) => {
      expectedItems.forEach((expectedItem: string) => {
        expect(item).toHaveProperty(expectedItem)
        expect(item.allAssignedProjects).toBeInstanceOf(Array)
      })
    })
    expect(responseBody.items[0].allAssignedProjects).toEqual(['test project'])
    // * Delete the created personnel
    if (responseBody.length > 0) {
      await deletePersonnel(repositories, createdPersonelId)
    }
  })

  it('POST: /personnel - expect to return 403', async () => {
    const response = await request(app)
      .post('/personnel')
      // .set(auth); // * No auth token
      .send(requestBody)
    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = {
      message: 'Forbidden',
    }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })
})
