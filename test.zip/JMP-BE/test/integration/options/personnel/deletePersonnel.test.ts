import request from 'supertest'
import express from 'express'
import { Connection } from 'typeorm'

import { createConnection } from '../../../../src/infrastructure/orm/typeorm/connection'
import { authGenerator } from '../../common/authGenerator'
import { createApp } from '../../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../../src/infrastructure/webserver/express/routes'
import prepareRepositories, {
  PersonnelRepositories,
} from './helpers/prepareRepositories.helper'
import createForeignKeys, {
  PersonelForeignKeys,
} from './helpers/createForeignKeys.helper'
import fixture from './personnel.fixture'
import removeForeignKeys from './helpers/removeForeignKeys.helper'
import deletePersonnel from './helpers/deletePersonnel.helper'
import { Dw_m_personnel } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { HeaderAuth } from '../../../../src/domain/types/common.type'
import { Repositories } from '../../../../src/application/port'

describe('TEST - Delete personnel API', () => {
  let repositories: PersonnelRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let foreignKeys: PersonelForeignKeys
  let createdPersonelId: number

  beforeEach(async () => {
    // * Create foreign keys
    foreignKeys = await createForeignKeys(repositories)
    const { companyId } = foreignKeys

    // * prepare the request body
    const personnelFixture = fixture.getAll.personnel_2
    personnelFixture.dw_m_partner_company = companyId

    // * Insert the personnel that is going to be deleted
    const personnel = await repositories.personnelDBRepo.save(
      (personnelFixture as unknown) as Dw_m_personnel
    )
    createdPersonelId = personnel.personnel_id
  })

  afterEach(async () => {
    // * Delete the created foreign keys
    await removeForeignKeys(repositories, foreignKeys)
  })

  it('DELETE: /personnel 200', async () => {
    const response = await request(app)
      .delete('/personnel')
      .query({ personnel_id: createdPersonelId })
      .set(auth)

    const expectedStatusCode = 200
    const expectedBody = { message: 'Records deleted successfully' }
    const responseBody = response.body
    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })

  it('DELETE: /personnel 404', async () => {
    const response = await request(app)
      .delete('/personnel')
      .query({ personnel_id: createdPersonelId + 1 })
      .set(auth)

    const responseBody = response.body

    const expectedStatusCode = 404
    const expectedBody = {
      message: " Records doesn't exist!",
    }
    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })

  it('GET: /DELETE - expect to return 403', async () => {
    const response = await request(app).delete('/personnel')
    // .set(auth); // * No auth token

    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = {
      message: 'Forbidden',
    }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
    // * Delete the created personnel
    if (responseBody.length > 0) {
      await deletePersonnel(repositories, createdPersonelId)
    }
  })
})
