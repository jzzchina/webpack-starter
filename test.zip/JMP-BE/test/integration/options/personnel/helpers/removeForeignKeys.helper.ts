import { PersonelForeignKeys } from './createForeignKeys.helper'
import { PersonnelRepositories } from './prepareRepositories.helper'
import fixture from '../personnel.fixture'

// * A Helper function that removes all the foreign keys after running the tests
const removeForeignKeys = async (
  repositories: PersonnelRepositories,
  foreignKeys: PersonelForeignKeys
): Promise<void> => {

  const { companyId, projectId, roleId } = foreignKeys
  // * Delete the created partnerCompany
  await repositories.operationPlanRepo.delete({
    man_month_number: fixture.operationPlan.man_month_number,
  })
  await repositories.operationRepo.delete({
    month_of_year_date: fixture.operation.month_of_year_date,
  })
  await repositories.partnerCompanyRepo.delete({ company_id: companyId })
  await repositories.projectRepo.delete({ project_id: projectId })
  await repositories.roleRepo.delete({ role_id: roleId })
}

export default removeForeignKeys
