import { PersonnelRepositories } from './prepareRepositories.helper';

// * A helper function to delete the personnel
const deletePersonnel = async (
  repositories: PersonnelRepositories,
  id: number
): Promise<void> => {
  await repositories.personnelDBRepo.delete({ personnel_id: id });
};

export default deletePersonnel;
