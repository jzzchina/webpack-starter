import { Dw_m_personnel } from '../../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel'
import { Dw_t_operation } from '../../../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation'
import { Dw_t_operation_plan } from '../../../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import fixture from '../personnel.fixture'
import { PersonnelRepositories } from './prepareRepositories.helper'

export interface PersonelForeignKeys {
  companyId: number
  projectId: number
  roleId: number
  personnelId: number
}

// A Helper function that creates all the foreign keys for the operationPlan and returns the ids
const createForeignKeys = async (
  repositories: PersonnelRepositories
): Promise<PersonelForeignKeys> => {
  const partnerCompanyFixture = fixture.create.partnerCompany
  const projectFixture = fixture.project
  const roleFixture = fixture.role
  const partnerCompany = await repositories.partnerCompanyRepo.save(
    partnerCompanyFixture
  )
  const project = await repositories.projectRepo.save(projectFixture)
  const role = await repositories.roleRepo.save(roleFixture)

  const companyId = partnerCompany.company_id
  const projectId = project.project_id
  const roleId = role.role_id
  const personnelDBFixture = fixture.create.personnelDB
  personnelDBFixture.dw_m_partner_company.company_id = companyId
  const personnel = await repositories.personnelDBRepo.save(
    (personnelDBFixture as unknown) as Dw_m_personnel
  )
  const personnelId = personnel.personnel_id
  const operationPlanFixture = fixture.operationPlan
  operationPlanFixture.dw_m_project.project_id = projectId
  operationPlanFixture.dw_m_role.role_id = roleId
  operationPlanFixture.dw_m_personnel.personnel_id = personnelId
  const operationFixture = fixture.operation
  operationFixture.dw_m_project.project_id = projectId
  operationFixture.dw_m_personnel.personnel_id = personnelId
  // *   Create OperationPlan
  await repositories.operationPlanRepo.save(
    (operationPlanFixture as unknown) as Dw_t_operation_plan
  )

  await repositories.operationRepo.save(
    (operationFixture as unknown) as Dw_t_operation
  )

  return { companyId, projectId, roleId, personnelId }
}

export default createForeignKeys
