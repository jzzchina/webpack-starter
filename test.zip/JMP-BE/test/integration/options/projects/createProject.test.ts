import request from 'supertest'
import express from 'express'
import { Connection } from 'typeorm'

import { createConnection } from '../../../../src/infrastructure/orm/typeorm/connection'
import { authGenerator } from '../../common/authGenerator'
import { createApp } from '../../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../../src/infrastructure/webserver/express/routes'
import prepareRepositories, {
  ProjectRepositories,
} from './helpers/prepareRepositories.helper'
import fixture from './project.fixture'
import { HeaderAuth } from '../../../../src/domain/types/common.type'
import { Repositories } from '../../../../src/application/port'
import { ProjectDtoResponse } from '../../../../src/interface/routes/options/project/dto/projects.dto'

describe('TEST - PATCH Projects API', () => {
  let repositories: ProjectRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  it('PATCH: /projects 200', async () => {
    const response = await request(app)
      .patch('/projects')
      .set(auth)
      .send([fixture.createAPI.project])

    const responseBody: ProjectDtoResponse[] = response.body

    const expectedStatusCode = 200
    const expectedFields = [
      'projectId',
      'projectName',
      'projectContact',
      'projectStartDate',
      'projectEndDate',
      'note',
      'createdBy',
      'createdAt',
      'updatedBy',
      'updateAt',
      'processAt',
      'processId',
    ]
    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    responseBody.forEach((item) => {
      expectedFields.forEach((expectedItem: string) => {
        expect(item).toHaveProperty(expectedItem)
      })
    })

    // * Delete the created project
    if (responseBody.length > 0) {
      const createdPartnerCompany = responseBody[0]
      await repositories.projectDBRepo.delete(
        Number(createdPartnerCompany.projectId)
      )
    }
  })
  it('should create project with required fields only ', async () => {
    const response = await request(app)
      .patch('/projects')
      .set(auth)
      .send([fixture.createAPI.project])
    const responseBody: ProjectDtoResponse[] = response.body
    const expectedStatusCode = 200
    const expectedFields = [
      'projectId',
      'projectName',
      'projectContact',
      'projectStartDate',
      'projectEndDate',
      'note',
      'createdBy',
      'createdAt',
      'updatedBy',
      'updateAt',
      'processAt',
      'processId',
    ]
    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    responseBody.forEach((item) => {
      expectedFields.forEach((expectedItem: string) => {
        expect(item).toHaveProperty(expectedItem)
      })
    })

    // * Delete the created project
    if (responseBody.length > 0) {
      const createdPartnerCompany = responseBody[0]
      await repositories.projectDBRepo.delete(
        Number(createdPartnerCompany.projectId)
      )
    }
  })
  it('PATCH: /projects - expect to return 403', async () => {
    const response = await request(app)
      .patch('/projects')
      // .set(auth); // * No auth token
      .send([fixture.createAPI.project])

    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = {
      message: 'Forbidden',
    }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })

  it('PATCH: /projects - email validation - Success', async () => {
    const dataToSend = fixture.createAPI.projectWithValidEmail
    const response = await request(app)
      .patch('/projects')
      .set(auth)
      .send([dataToSend])

    const responseBody = response.body

    const expectedStatusCode = 200

    expect(response.statusCode).toEqual(expectedStatusCode)

    // * Delete the created project
    if (responseBody.length > 0) {
      const createdPartnerCompany = responseBody[0]
      await repositories.projectDBRepo.delete(createdPartnerCompany.projectId)
    }
  })

  it('PATCH: /projects - email validation - Failed', async () => {
    const emailToLong = fixture.createAPI.projectWithTooLongEmail
    const emailWithUnicodeShort = fixture.createAPI.projectWithUnicodeShortEmail
    const emailWithUnicodeDouble =
      fixture.createAPI.projectWithUnicodeDoubleEmail

    const promisesArray = [
      request(app).patch('/projects').set(auth).send([emailToLong]),
      request(app).patch('/projects').set(auth).send([emailWithUnicodeShort]),
      request(app).patch('/projects').set(auth).send([emailWithUnicodeDouble]),
    ]

    const reposnses = await Promise.allSettled(promisesArray)
    const results = reposnses.map((item: any) => item.value.body)
    const [tooLong, unicodeShort, unicodeDouble] = results

    expect(tooLong.message).toEqual('"projectContact" must be a valid email')
    expect(unicodeShort.message).toEqual(
      '"projectContact" must be a valid email'
    )
    expect(unicodeDouble.message).toEqual(
      '"projectContact" must be a valid email'
    )
  })
})
