import request from 'supertest'
import { Express } from 'express'
import { Connection } from 'typeorm'

import { createConnection } from '../../../../src/infrastructure/orm/typeorm/connection'
import { authGenerator } from '../../common/authGenerator'
import { createApp } from '../../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../../src/infrastructure/webserver/express/routes'
import prepareRepositories, {
  ProjectRepositories,
} from './helpers/prepareRepositories.helper'
import fixture from './project.fixture'
import { HeaderAuth } from '../../../../src/domain/types/common.type'
import { Repositories } from '../../../../src/application/port'

describe('TEST - DELETE Projects API', () => {
  let repositories: ProjectRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let createdProjectId: number

  beforeEach(async () => {
    const projectFixture = fixture.getAll.project
    const createdProject = await repositories.projectDBRepo.save(projectFixture)
    createdProjectId = createdProject.project_id
  })

  afterEach(async () => {
    await repositories.projectDBRepo.delete(createdProjectId)
  })

  it('DELETE: /projects 200', async () => {
    const response = await request(app)
      .delete('/projects')
      .query({ project_id: createdProjectId })
      .set(auth)

    const responseBody = response.body

    const expectedStatusCode = 200
    const expectedBody = {
      message: 'Records deleted successfully',
    }
    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body
    expect(responseBody).toEqual(expectedBody)
  })

  it('DELETE: /projects - expect to return 403', async () => {
    const response = await request(app)
      .delete('/projects')
      .query({ project_id: createdProjectId })
    // .set(auth); // * No auth token

    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = {
      message: 'Forbidden',
    }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })

  it('DELETE: /projects - expect to return 404', async () => {
    await repositories.projectDBRepo.delete(createdProjectId)

    const response = await request(app)
      .delete('/projects')
      .query({ project_id: createdProjectId + 1 })
      .set(auth)

    const responseBody = response.body

    const expectedStatusCode = 404
    const expectedBody = {
      message: " Records doesn't exist!",
    }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })
})
