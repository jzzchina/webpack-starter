import request from 'supertest'
import express from 'express'
import { Connection } from 'typeorm'

import { createConnection } from '../../../../src/infrastructure/orm/typeorm/connection'
import { authGenerator } from '../../common/authGenerator'
import { createApp } from '../../../../src/infrastructure/webserver/express/app'
import { createRouter } from '../../../../src/infrastructure/webserver/express/routes'
import prepareRepositories, {
  ProjectRepositories,
} from './helpers/prepareRepositories.helper'
import fixture from './project.fixture'
import { Dw_m_project } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_project'
import { HeaderAuth } from '../../../../src/domain/types/common.type'
import { Repositories } from '../../../../src/application/port'
import { ProjectListResponse } from '../../../../src/interface/routes/options/project/dto/projects.dto'

describe('TEST - GET Projects API', () => {
  let repositories: ProjectRepositories
  let connection: Connection
  let auth: HeaderAuth
  let app: express.Express

  beforeAll(async () => {
    auth = authGenerator() // * Generate auth token
    app = createApp()
    connection = await createConnection() // * Create connection to database

    // * Prepare repositories
    repositories = await prepareRepositories(connection)

    app.use('/', createRouter((repositories as unknown) as Repositories)) // * Create router
  })

  afterAll(async () => {
    await connection.close()
  })

  let createdProjectId: number

  beforeEach(async () => {
    const projectFixture = fixture.create.project
    const createdProject = await repositories.projectDBRepo.save(
      (projectFixture as unknown) as Dw_m_project
    )
    createdProjectId = createdProject.project_id
  })

  afterEach(async () => {
    await repositories.projectDBRepo.delete(createdProjectId)
  })

  // * 200
  test('GET: /projects 200', async () => {
    const limit = 50
    const offset = 0
    const query = { limit, offset }

    const response = await request(app).get('/projects').set(auth).query(query)

    const responseBody: ProjectListResponse = response.body

    const expectedStatusCode = 200
    const expectedBodyFields = ['offset', 'length', 'totalLength', 'items']
    const expectedItems = [
      'projectId',
      'projectName',
      'status',
      'projectStartDate',
      'projectEndDate',
      'projectManager',
      'projectContact',
      'userPart',
      'note',
    ]

    // * Check if the response status code is the expected
    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    expectedBodyFields.forEach((expectedBodyField: string) => {
      expect(responseBody).toHaveProperty(expectedBodyField)
    })
    // * Check if the response body has the expected fields
    responseBody.items?.forEach((item) => {
      expectedItems.forEach((expectedItem: string) => {
        expect(item).toHaveProperty(expectedItem)
      })
    })
  })
  test('GET: /projects with include statue closed 200', async () => {
    const limit = 50
    const offset = 0
    const include_status_closed = true
    const query = { limit, offset, include_status_closed }

    const response = await request(app).get('/projects').set(auth).query(query)

    const responseBody: ProjectListResponse = response.body
    expect(responseBody).toHaveProperty('items')
    if (responseBody.items) expect(responseBody.items[0].status).toEqual(5)
    const expectedStatusCode = 200
    const expectedBodyFields = ['offset', 'length', 'totalLength', 'items']
    const expectedItems = [
      'projectId',
      'projectName',
      'status',
      'projectStartDate',
      'projectEndDate',
      'projectManager',
      'projectContact',
      'userPart',
      'note',
    ]

    // * Check if the response status code is the expected
    expect(response.statusCode).toEqual(expectedStatusCode)
    // * Check if the response body has the expected fields
    expectedBodyFields.forEach((expectedBodyField: string) => {
      expect(responseBody).toHaveProperty(expectedBodyField)
    })
    // * Check if the response body has the expected fields
    responseBody.items?.forEach((item) => {
      expectedItems.forEach((expectedItem: string) => {
        expect(item).toHaveProperty(expectedItem)
      })
    })
  })
  // * 403 Forbidden
  test('GET: /projects - expect to return 403', async () => {
    const query = { project_id: createdProjectId } // * // * project create API Columns add Uncomment after handling.
    const response = await request(app).get('/projects').query(query)
    // .set(auth); // * No auth token

    const responseBody = response.body

    const expectedStatusCode = 403
    const expectedBody = {
      message: 'Forbidden',
    }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody).toEqual(expectedBody)
  })

  // * 422 Validation Error
  test('GET: /projects - expect to return 422', async () => {
    const query = { status: 8 }
    const response = await request(app).get('/projects').set(auth).query(query)

    const responseBody = response.body

    const expectedStatusCode = 422
    const expectedBody = {
      res: 'Validation error',
    }

    expect(response.statusCode).toEqual(expectedStatusCode)
    expect(responseBody.res).toEqual(expectedBody.res)
  })
})
