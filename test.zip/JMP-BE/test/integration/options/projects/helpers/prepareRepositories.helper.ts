import { Connection, Repository } from 'typeorm'
import { ProjectRepositoryPort } from '../../../../../src/application/port/repositories/project/ProjectRepositoryPort'
import { Dw_m_project } from '../../../../../src/infrastructure/orm/typeorm/entities/Dw_m_project'
import { projectRepositoryMySQL } from '../../../../../src/infrastructure/repositories/options/project/projectRepositoryMySQL'

export interface ProjectRepositories {
  projectRepository: ProjectRepositoryPort
  projectDBRepo: Repository<Dw_m_project>
}

// * A function that prepares the repositories for the tests
const prepareRepositories = async (
  connection: Connection
): Promise<ProjectRepositories> => {
  const projectRepository: ProjectRepositoryPort = await projectRepositoryMySQL(
    connection
  )
  const projectDBRepo: Repository<Dw_m_project> = await connection.getRepository(
    Dw_m_project
  )

  const repositories = {
    projectRepository,
    projectDBRepo,
  }

  return repositories
}

export default prepareRepositories
