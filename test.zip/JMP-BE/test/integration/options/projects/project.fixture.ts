const projectFixture = {
  create: {
    project: {
      project_name: 'Integration Test Project',
      status: 5,
      project_start_date: '2022-01-01',
      project_end_date: '2023-12-01',
      notes: 'this is a note',
      project_manager: 'test',
      project_contact: 'user@example.com',
      user_part: 'SOE',
      created_by: 'Integration Test',
      updated_by: 'Integration Test',
    },
  },
  getAll: {
    project: {
      project_id: 1,
      project_name: 'Test Project 1',
      status: 0,
      project_start_date: '2022-01-01',
      project_end_date: '2023-12-01',
      project_manager: 'test',
      project_contact: 'user@example.com',
      user_part: 'SOE',
      notes: 'JDPPのリソース管理用エクセルシートをシステム化するプロジェクト',
      created_by: 'Unit Test',
      create_at: '2023-02-10T19:05:00.404Z',
      updated_by: 'Unit Test',
      update_at: '2023-02-10T19:05:00.404Z',
      process_id: null,
      process_at: '2023-02-10T19:05:00.404Z',
    },
  },
  createAPI: {
    project: {
      projectId: 18,
      projectName: 'Integration Test Project',
      status: 0,
      projectStartDate: '2022-01-01',
    },
    projectWithValidEmail: {
      projectId: 18,
      projectName: 'Integration Test Project',
      status: 0,
      projectStartDate: '2022-01-01',
      projectContact: 'valid.one@email.com',
    },

    projectWithTooLongEmail: {
      projectId: 18,
      projectName: 'Integration Test Project',
      status: 0,
      projectStartDate: '2022-01-01',
      projectContact:
        'tooLong_9_12_15_18_21_24_27_30_33_36_39_42_45_48_51_60_63_66_69_72@emal.com',
    },
    projectWithUnicodeShortEmail: {
      projectId: 18,
      projectName: 'Integration Test Project',
      status: 0,
      projectStartDate: '2022-01-01',
      projectContact: 'имейл@emal.com',
    },
    projectWithUnicodeDoubleEmail: {
      projectId: 18,
      projectName: 'Integration Test Project',
      status: 0,
      projectStartDate: '2022-01-01',
      projectContact: '絡先メールアドレス@emal.com',
    },

    projectWithRequiredFieldsOnly: {
      projectName: 'Integration Test Project 2',
      status: 0,
      projectStartDate: '2022-01-01',
    },
  },
}

export default projectFixture
