import { Connection } from 'typeorm'

import { operationCostPlanRepositoryMySQL } from '../../../../src/infrastructure/repositories/operationCostPlan/operationCostPlanRepositoryMySQL'
import { projects } from '../../../fixtures/expected/operationCostPlan/operationCostPlan.fixture'
import {
  operationCostPlanRepositoryFixture,
  searchOperationCostPlanParams,
  searchOperationCostPlanWithDateAndFiltersParams,
} from '../../../fixtures/inserts/operationCostPlan.fixture'
import CustomError from '../../../../src/application/errors/CustomError'
import messages from '../../../../src/application/errors/messages'

describe('TEST - operationCostPlanRepositoryMySQL ', () => {
  const connection = (operationCostPlanRepositoryFixture.connection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })
  test('should search operation cost Plan successfully', async () => {
    // Arrange
    const operationCost = await operationCostPlanRepositoryMySQL(connection)

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_project').createQueryBuilder(),
      'getManyAndCount'
    )

    executeSpy.mockResolvedValueOnce([projects, 1])

    // Act
    const {
      limit,
      offset,
      from,
      to,
      projectId,
      companyId,
    } = searchOperationCostPlanWithDateAndFiltersParams
    const result = await operationCost.searchOperationCostPlansByProject(
      limit,
      offset,
      from,
      to,
      projectId,
      companyId
    )

    // Assert
    expect(executeSpy).toHaveBeenCalledTimes(1)
    expect(result.totalItems).toEqual(1)
  })
  test('should return empty array of operation cost plan', async () => {
    // Arrange
    const operationCost = await operationCostPlanRepositoryMySQL(connection)

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_project').createQueryBuilder(),
      'getManyAndCount'
    )

    executeSpy.mockResolvedValueOnce([undefined, 0] as [never, number])

    // Act
    const {
      limit,
      offset,
      from,
      to,
      projectId,
      companyId,
    } = searchOperationCostPlanParams
    const result = await operationCost.searchOperationCostPlansByProject(
      limit,
      offset,
      from,
      to,
      projectId,
      companyId
    )

    // Assert
    expect(executeSpy).toHaveBeenCalledTimes(1)
    expect(result.totalItems).toEqual(0)
  })

  test('should throw a error', async () => {
    // Arrange
    const operationCost = await operationCostPlanRepositoryMySQL(connection)

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_project').createQueryBuilder(),
      'getManyAndCount'
    )

    executeSpy.mockRejectedValue([undefined, 0])
    const expectedError = new CustomError(
      messages.unexpectedError,
      'Internal Server Error'
    )
    try {
      await operationCost.searchOperationCostPlansByProject(
        0,
        0,
        '1',
        '2',
        0,
        0
      )
    } catch (err) {
      expect(err).toEqual(expectedError)
    }
  })
})
