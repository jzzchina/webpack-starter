const personnelPriceFixture = {
  personnelPricesKey: {
    personnel_id: 2,
    price_start_date: new Date('2022-01-01'),
  },
  connection: {
    getRepository: jest.fn().mockReturnValue({
      createQueryBuilder: jest.fn().mockReturnValue({
        softDelete: jest.fn().mockReturnThis(),
        from: jest.fn().mockReturnThis(),
        where: jest.fn().mockReturnThis(),
        andWhere: jest.fn().mockReturnThis(),
        execute: jest.fn(), // To be mocked in each test
      }),
    }),
  },

  deleteResult: {
    affected: 1,
    raw: {
      fieldCount: 0,
      affectedRows: 1,
      insertId: 0,
      info: 'Rows matched: 1  Changed: 1  Warnings: 0',
      serverStatus: 2,
      warningStatus: 0,
      changedRows: 1,
    },
  },
  deleteResultWithNoAffectedRows: {
    affected: 0,
    raw: {
      fieldCount: 0,
      affectedRows: 0,
      insertId: 0,
      info: 'Rows matched: 0  Changed: 0  Warnings: 0',
      serverStatus: 2,
      warningStatus: 0,
      changedRows: 1,
    },
  },
  deleteResultFailed: {
    _tag: 'IDDoesntExistError',
    message: `Records doesn't exist!`,
    status: 404,
  },
}

export default personnelPriceFixture
