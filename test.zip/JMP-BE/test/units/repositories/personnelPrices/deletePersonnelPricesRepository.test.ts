import { Connection } from 'typeorm'

import { personnelPriceRepositoryMySQL } from '../../../../src/infrastructure/repositories/options/personnelPrice/personnelPriceRepositoryMySQL'
import fixture from './personnelPrice.fixture'
import CustomError from '../../../../src/application/errors/CustomError'
import messages from '../../../../src/application/errors/messages'

describe('TEST - personnelPriceRepositoryMySQL delete method', () => {
  const connection = (fixture.connection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })

  test('should delete personnelPrice and return affected row', async () => {
    // Arrange
    const personnelPriceRepository = await personnelPriceRepositoryMySQL(
      connection
    )
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_personnel_price').createQueryBuilder(),
      'execute'
    )
    executeSpy.mockResolvedValueOnce(fixture.deleteResult)

    // Act
    const result = await personnelPriceRepository.delete(
      fixture.personnelPricesKey
    )

    // Assert
    expect(executeSpy).toHaveBeenCalledTimes(1)
    expect(result).toEqual(fixture.deleteResult)
  })

  test('should throw idDoesntExistError when the personnelPrice is not found', async () => {
    // Arrange
    const personnelPriceRepository = await personnelPriceRepositoryMySQL(
      connection
    )
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_personnel_price').createQueryBuilder(),
      'execute'
    )
    executeSpy.mockResolvedValueOnce(fixture.deleteResultWithNoAffectedRows)

    try {
      // Act
      await personnelPriceRepository.delete(fixture.personnelPricesKey)
    } catch (err) {
      // Assert
      expect(err).toEqual(
        new CustomError(messages.personnelPriceNotFound, 'Not Found')
      )
    }
  })
  test('should throw a unexpected error', async () => {
    // Arrange
    const personnelPriceRepository = await personnelPriceRepositoryMySQL(
      connection
    )

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_personnel_price').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockRejectedValueOnce(new Error('unexpected error'))

    // Act
    try {
      await personnelPriceRepository.delete(fixture.personnelPricesKey)
    } catch (err) {
      // Assert
      const error = err as Error
      expect(error).toBeInstanceOf(Error)
      expect(error.message).toEqual('unexpected error')
    }
  })
})
