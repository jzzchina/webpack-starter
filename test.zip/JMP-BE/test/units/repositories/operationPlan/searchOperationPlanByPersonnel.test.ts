import { Connection } from 'typeorm'
import { operationPlanRepositoryMySQL } from '../../../../src/infrastructure/repositories/operationPlan/operationPlanRepositoryMySQL'

import { operationPlanRepositoryFixture } from '../../../fixtures/expected/operationPlan/operationPlans.fixture'
import {
  personnel,
  to,
  from,
  personnelWithFilter,
  skillList,
  undefinedSkillList,
  skillListWithoutLevel,
} from '../../../fixtures/inserts/operationPlans.fixture'

describe('TEST - operationPlanRepositoryMySQL findByPersonnel method', () => {
  const connection = (operationPlanRepositoryFixture.connection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })

  test('should get all operationPlans without filters', async () => {
    // Arrange
    const partnerCompanyRepository = await operationPlanRepositoryMySQL(
      connection
    )
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_t_operation_plan').createQueryBuilder(),
      'getManyAndCount'
    )

    executeSpy.mockResolvedValueOnce([personnel, 2])

    // Act
    const result = await partnerCompanyRepository.findOperationPlansByPersonnel(
      '',
      '',
      0,
      10,
      NaN,
      NaN,
      undefinedSkillList
    )

    // Assert
    expect(executeSpy).toHaveBeenCalledTimes(1)
    expect(result.totalItems).toEqual(2)
    result.items.forEach((item) => {
      expect(item).toHaveProperty('personnel_id')
      expect(item).toHaveProperty('dw_m_partner_company')
      expect(item).toHaveProperty('dw_m_partner_company')
      expect(item).toHaveProperty('name'),
        expect(item).toHaveProperty('name_jpn'),
        expect(item).toHaveProperty('registered_date'),
        expect(item).toHaveProperty('unregistered_date'),
        expect(item).toHaveProperty('skill_list'),
        expect(item).toHaveProperty('dw_m_personnel_price')
    })
  })
  test('should get operationPlans with filters', async () => {
    // Arrange
    const partnerCompanyRepository = await operationPlanRepositoryMySQL(
      connection
    )
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_t_operation_plan').createQueryBuilder(),
      'getManyAndCount'
    )

    executeSpy.mockResolvedValueOnce([personnelWithFilter, 1])

    // Act
    const result = await partnerCompanyRepository.findOperationPlansByPersonnel(
      to,
      from,
      0,
      10,
      1,
      1,
      skillList
    )

    // Assert
    expect(executeSpy).toHaveBeenCalledTimes(1)
    expect(result.totalItems).toEqual(1)
    result.items.forEach((item) => {
      expect(item).toHaveProperty('personnel_id', 1)
      expect(item).toHaveProperty('dw_m_partner_company')
      expect(item.dw_m_partner_company).toHaveProperty('company_id', 1)
      expect(item).toHaveProperty('dw_m_partner_company')
      expect(item).toHaveProperty('name'),
        expect(item).toHaveProperty('name_jpn'),
        expect(item).toHaveProperty('registered_date', new Date(from)),
        expect(item).toHaveProperty('unregistered_date', new Date(to)),
        expect(item).toHaveProperty('skill_list', personnel[0].skill_list),
        expect(item).toHaveProperty('dw_m_personnel_price')
    })
  })

  test('should get operationPlans with null skills level', async () => {
    // Arrange
    const partnerCompanyRepository = await operationPlanRepositoryMySQL(
      connection
    )
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_t_operation_plan').createQueryBuilder(),
      'getManyAndCount'
    )

    executeSpy.mockResolvedValueOnce([personnelWithFilter, 1])

    // Act
    const result = await partnerCompanyRepository.findOperationPlansByPersonnel(
      to,
      from,
      0,
      10,
      1,
      1,
      skillListWithoutLevel
    )

    // Assert
    expect(executeSpy).toHaveBeenCalledTimes(1)
    expect(result.totalItems).toEqual(1)
    result.items.forEach((item) => {
      expect(item).toHaveProperty('personnel_id', 1)
      expect(item).toHaveProperty('dw_m_partner_company')
      expect(item.dw_m_partner_company).toHaveProperty('company_id', 1)
      expect(item).toHaveProperty('dw_m_partner_company')
      expect(item).toHaveProperty('name'),
        expect(item).toHaveProperty('name_jpn'),
        expect(item).toHaveProperty('registered_date', new Date(from)),
        expect(item).toHaveProperty('unregistered_date', new Date(to)),
        expect(item).toHaveProperty('skill_list', personnel[0].skill_list),
        expect(item).toHaveProperty('dw_m_personnel_price')
    })
  })

  test('should not find any operationPlans', async () => {
    // Arrange
    const partnerCompanyRepository = await operationPlanRepositoryMySQL(
      connection
    )
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_t_operation_plan').createQueryBuilder(),
      'getManyAndCount'
    )

    executeSpy.mockResolvedValueOnce([undefined, 0] as [never, number])

    // Act
    const result = await partnerCompanyRepository.findOperationPlansByPersonnel(
      to,
      from,
      0,
      10,
      1,
      1,
      {}
    )

    // Assert
    expect(executeSpy).toHaveBeenCalledTimes(1)
    expect(result.totalItems).toEqual(0)
  })

  test('should throw a error', async () => {
    // Arrange
    const partnerCompanyRepository = await operationPlanRepositoryMySQL(
      connection
    )
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_t_operation_plan').createQueryBuilder(),
      'getManyAndCount'
    )

    executeSpy.mockRejectedValueOnce(new Error('unexpected error'))
    // Act
    try {
      await partnerCompanyRepository.findOperationPlansByPersonnel(
        to,
        from,
        0,
        10,
        1,
        1,
        {}
      )
    } catch (err) {
      const error = err as Error
      expect(error).toBeInstanceOf(Error)
      expect(error.message).toEqual('unexpected error')
    }

    // Assert
    expect(executeSpy).toHaveBeenCalledTimes(1)
  })
})
