import { Connection } from 'typeorm'
import { operationPlanRepositoryMySQL } from '../../../../src/infrastructure/repositories/operationPlan/operationPlanRepositoryMySQL'

import { operationPlanRepositoryFixture } from '../../../fixtures/expected/operationPlan/operationPlans.fixture'
import {
  deleteResult,
  notMatchedDeleteResult,
  operationPlanNotExist,
} from '../../../fixtures/inserts/operationPlans.fixture'
import CustomError from '../../../../src/application/errors/CustomError'
import messages from '../../../../src/application/errors/messages'

describe('TEST - operationPlanRepositoryMySQL Delete method', () => {
  const connection = (operationPlanRepositoryFixture.connection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })

  test('should delete operation plan successfully', async () => {
    // Arrange
    const operationPlan = await operationPlanRepositoryMySQL(connection)

    const executeSpy = jest.spyOn(
      connection.getRepository('dw_t_operation_plan').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockResolvedValueOnce(deleteResult)

    // Act
    const result = await operationPlan.deleteOperationPlans(
      operationPlanNotExist
    )

    // Assert
    expect(result).toEqual(undefined)
    expect(executeSpy).toHaveBeenCalledTimes(1)
  })

  test('should throw a error when operation plan doesn`t exist', async () => {
    // Arrange
    const operationPlan = await operationPlanRepositoryMySQL(connection)
    const executeSpy = jest.spyOn(
      connection.getRepository('dw_t_operation_plan').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockResolvedValueOnce(notMatchedDeleteResult)
    try {
      // Act
      await operationPlan.deleteOperationPlans(operationPlanNotExist)
    } catch (err: unknown) {
      // Assert
      const expectedError = new CustomError(
        messages.recordsDoesNotExist,
        'Not Found'
      )
      expect(err).toEqual(expectedError)
    }
  })
  test('should throw a error', async () => {
    // Arrange
    const operationPlan = await operationPlanRepositoryMySQL(connection)

    const executeSpy = jest.spyOn(
      connection.getRepository('dw_t_operation_plan').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockRejectedValueOnce(new Error('unexpected error'))

    // Act
    try {
      await operationPlan.deleteOperationPlans(operationPlanNotExist)
    } catch (err) {
      // Assert
      const error = err as Error
      expect(error).toBeInstanceOf(Error)
      expect(error.message).toEqual('unexpected error')
    }
  })
})
