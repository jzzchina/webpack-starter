import { Connection } from 'typeorm'

import {
  searchWbsCostsParams,
  wbsCostRepositoryFixture,
} from '../../../fixtures/inserts/wbs.fixture'
import { wbsRepositoryMySQL } from '../../../../src/infrastructure/repositories/wbs/wbsRepositoryMySQL'
import { wbsCosts } from '../../../fixtures/expected/wbs/wbsCost.fixture'

describe('TEST - wbsRepositoryMySQL ', () => {
  const connection = (wbsCostRepositoryFixture.connection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })
  test('should search wbs cost successfully', async () => {
    // Arrange
    const wbsCost = await wbsRepositoryMySQL(connection)

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_personnel').createQueryBuilder(),
      'getManyAndCount'
    )

    executeSpy.mockResolvedValueOnce([wbsCosts, 1])

    // Act
    const { limit, offset, from, to, companyId } = searchWbsCostsParams
    const result = await wbsCost.searchWbsCosts(
      limit,
      offset,
      from,
      to,
      companyId
    )

    // Assert
    expect(executeSpy).toHaveBeenCalledTimes(1)
    expect(result.totalItems).toEqual(1)
  })

  test('should return empty array of wbs cost', async () => {
    // Arrange
    const wbsCost = await wbsRepositoryMySQL(connection)

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_personnel').createQueryBuilder(),
      'getManyAndCount'
    )

    executeSpy.mockResolvedValueOnce([undefined, 0] as [never, number])

    // Act
    const { limit, offset, from, to, companyId } = searchWbsCostsParams
    const result = await wbsCost.searchWbsCosts(
      limit,
      offset,
      from,
      to,
      companyId
    )

    // Assert
    expect(executeSpy).toHaveBeenCalledTimes(1)
    expect(result.totalItems).toEqual(0)
  })
})
