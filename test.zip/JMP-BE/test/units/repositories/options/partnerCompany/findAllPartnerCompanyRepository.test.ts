import { Connection } from 'typeorm'
import { partnerCompanyRepositoryMySQL } from '../../../../../src/infrastructure/repositories/options/partnerCompany/partnerCompanyRepositoryMySQL'

import fixture from './partnerCompany.fixture'

describe('TEST - partnerCompanyRepositoryMySQL findAll method', () => {
  const connection = (fixture.connection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })

  test('should select partnerCompanies with pagination and search', async () => {
    // Arrange
    const partnerCompanyRepository = await partnerCompanyRepositoryMySQL(
      connection
    )
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_partner_company').createQueryBuilder(),
      'getManyAndCount'
    )

    executeSpy.mockResolvedValueOnce([fixture.singlePartnerCompany, 1])

    // Act
    const result = await partnerCompanyRepository.findAll(107, 'JERA', 1, 10, 0)

    // Assert
    expect(executeSpy).toHaveBeenCalledTimes(1)
    expect(result.count).toEqual(1)
    expect(result.result[0].company_name).toEqual('JERA')
    expect(result.result[0].contract_pattern_code).toEqual(1)
    expect(result.result[0].company_id).toEqual(107)
  })

  test('should get All partner companies without pagination and search  ordered by company name', async () => {
    // Arrange
    const partnerCompanyRepository = await partnerCompanyRepositoryMySQL(
      connection
    )
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_partner_company').createQueryBuilder(),
      'getManyAndCount'
    )

    executeSpy.mockResolvedValueOnce([fixture.partnerCompanies, 2])

    // Act
    const result = await partnerCompanyRepository.findAll(
      NaN,
      '',
      NaN,
      NaN,
      NaN
    )

    // Assert
    expect(executeSpy).toHaveBeenCalledTimes(1)
    expect(result.count).toEqual(2)
    expect(result.result[0].company_name).toEqual('AVAXIA')
    expect(result.result[0].contract_pattern_code).toEqual(1)
    expect(result.result[0].company_id).toEqual(108)
    expect(result.result[1].company_name).toEqual('JERA')
    expect(result.result[1].contract_pattern_code).toEqual(1)
    expect(result.result[1].company_id).toEqual(107)
  })
})
