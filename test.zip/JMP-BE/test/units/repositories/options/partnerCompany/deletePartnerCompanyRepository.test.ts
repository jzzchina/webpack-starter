import { Connection } from 'typeorm'
import { partnerCompanyRepositoryMySQL } from '../../../../../src/infrastructure/repositories/options/partnerCompany/partnerCompanyRepositoryMySQL'

import fixture from './partnerCompany.fixture'
import CustomError from '../../../../../src/application/errors/CustomError'
import messages from '../../../../../src/application/errors/messages'

describe('TEST - partnerCompanyRepositoryMySQL Delete method', () => {
  const connection = (fixture.connection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })

  test('should delete partnerCompanies successfully', async () => {
    // Arrange
    const partnerCompanyRepository = await partnerCompanyRepositoryMySQL(
      connection
    )

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_partner_company').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockResolvedValueOnce(fixture.deleteResult)

    // Act
    const result = await partnerCompanyRepository.deletePartnerCompanies([108])

    // Assert
    expect(result).toEqual(undefined)
    expect(executeSpy).toHaveBeenCalledTimes(1)
  })

  test('should throw a error when partner company doesn`t exist', async () => {
    // Arrange
    const partnerCompanyRepository = await partnerCompanyRepositoryMySQL(
      connection
    )
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_partner_company').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockResolvedValueOnce(fixture.notMatchedDeleteResult)
    try {
      // Act
      await partnerCompanyRepository.deletePartnerCompanies([200])
    } catch (err) {
      // Assert
      expect(err).toEqual(
        new CustomError(messages.recordsDoesNotExist, 'Not Found')
      )
    }
  })
  test('should throw a error', async () => {
    // Arrange
    const partnerCompanyRepository = await partnerCompanyRepositoryMySQL(
      connection
    )

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_partner_company').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockRejectedValueOnce(new Error('unexpected error'))

    // Act
    try {
      await partnerCompanyRepository.deletePartnerCompanies([108])
    } catch (err) {
      // Assert
      const error = err as Error
      expect(error).toBeInstanceOf(Error)
      expect(error.message).toEqual('unexpected error')
    }
  })
})
