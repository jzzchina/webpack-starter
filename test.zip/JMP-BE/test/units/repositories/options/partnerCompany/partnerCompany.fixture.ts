const partnerCompanyFixture = {
  connection: {
    getRepository: jest.fn().mockReturnValue({
      createQueryBuilder: jest.fn().mockReturnValue({
        delete: jest.fn().mockReturnThis(),
        softDelete: jest.fn().mockReturnThis(),
        from: jest.fn().mockReturnThis(),
        select: jest.fn().mockReturnThis(),
        where: jest.fn().mockReturnThis(),
        execute: jest.fn(), // To be mocked in each test
        getManyAndCount: jest.fn(), // To be mocked in each test
        leftJoinAndSelect: jest.fn().mockReturnThis(),
        leftJoin: jest.fn().mockReturnThis(),
        andWhere: jest.fn().mockReturnThis(),
        orderBy: jest.fn().mockReturnThis(),
        skip: jest.fn().mockReturnThis(),
        take: jest.fn().mockReturnThis(),
      }),
    }),
  },
  partnerCompanies: [
    {
      company_id: 108,
      contract_pattern_code: 1,
      company_name: 'AVAXIA',
      dw_m_personnel: [
        {
          personnel_id: 1,
        },
        {
          personnel_id: 1,
        },
      ],
    },
    {
      company_id: 107,
      contract_pattern_code: 1,
      company_name: 'JERA',
      dw_m_personnel: [
        {
          personnel_id: 1,
          name: 'Test Name',
        },
        {
          personnel_id: 1,
        },
      ],
      created_by: 'system',
      create_at: new Date(),
      updated_by: 'system',
      update_at: new Date(),
      process_at: new Date(),
      process_id: null,
    },
  ],
  singlePartnerCompany: [
    {
      company_id: 107,
      contract_pattern_code: 1,
      company_name: 'JERA',
      dw_m_personnel: [
        {
          personnel_id: 1,
          name: 'Test Name',
        },
        {
          personnel_id: 1,
        },
      ],
      created_by: 'system',
      create_at: new Date(),
      updated_by: 'system',
      update_at: new Date(),
      process_at: new Date(),
      process_id: null,
    },
  ],
  deleteResult: {
    generatedMaps: [],
    raw: {
      fieldCount: 0,
      affectedRows: 1,
      insertId: 0,
      info: 'Rows matched: 1  Changed: 1  Warnings: 0',
      serverStatus: 2,
      warningStatus: 0,
      changedRows: 1,
    },
  },
  notMatchedDeleteResult: {
    generatedMaps: [],
    raw: {
      fieldCount: 0,
      affectedRows: 0,
      insertId: 0,
      info: 'Rows matched: 0 Changed: 0  Warnings: 0',
      serverStatus: 2,
      warningStatus: 0,
      changedRows: 1,
    },
  },
}

export default partnerCompanyFixture
