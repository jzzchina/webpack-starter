import { Connection } from 'typeorm'
import { PersonnelSearchCriteria } from '../../../../../src/domain/models/Personnel'
import { personnelRepositoryMySQL } from '../../../../../src/infrastructure/repositories/options/personnel/personnelRepositoryMySQL'
import fixture from './personnel.fixture'

describe('TEST - PersonnelRepository findAll method', () => {
  const connection = (fixture.connection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })

  test('should find all personnel with searchCriteria', async () => {
    // Arrange
    const businessDaysRepository = await personnelRepositoryMySQL(connection)
    const getManyAndCountSpy = jest.spyOn(
      connection.getRepository('Dw_m_personnel').createQueryBuilder(),
      'getManyAndCount'
    )
    getManyAndCountSpy.mockResolvedValueOnce([
      fixture.getManyAndCount.result,
      fixture.getManyAndCount.count,
    ])

    // Act
    const result = await businessDaysRepository.findAll(
      (fixture.searchCriteria as unknown) as PersonnelSearchCriteria
    )

    // Assert
    expect(getManyAndCountSpy).toHaveBeenCalledTimes(1)
    expect(getManyAndCountSpy).toHaveBeenCalledWith()
    expect(result).toEqual({
      count: fixture.getManyAndCount.count,
      result: fixture.getManyAndCount.result,
    })
  })

  test('should find all personnel without searchCriteria', async () => {
    // Arrange
    const businessDaysRepository = await personnelRepositoryMySQL(connection)
    const getManyAndCountSpy = jest.spyOn(
      connection.getRepository('Dw_m_personnel').createQueryBuilder(),
      'getManyAndCount'
    )
    getManyAndCountSpy.mockResolvedValueOnce([
      fixture.getManyAndCount.result,
      fixture.getManyAndCount.count,
    ])

    // Act
    const result = await businessDaysRepository.findAll(
      (fixture.emptySearchCriteria as unknown) as PersonnelSearchCriteria
    )

    // Assert
    expect(getManyAndCountSpy).toHaveBeenCalledTimes(1)
    expect(getManyAndCountSpy).toHaveBeenCalledWith()
    expect(result).toEqual({
      count: fixture.getManyAndCount.count,
      result: fixture.getManyAndCount.result,
    })
  })

  test('should throw error when getManyAndCount throws error', async () => {
    // Arrange
    const businessDaysRepository = await personnelRepositoryMySQL(connection)
    const getManyAndCountSpy = jest.spyOn(
      connection.getRepository('Dw_m_personnel').createQueryBuilder(),
      'getManyAndCount'
    )
    getManyAndCountSpy.mockRejectedValueOnce(new Error('Error'))

    try {
      // Act
      await businessDaysRepository.findAll(
        (fixture.searchCriteria as unknown) as PersonnelSearchCriteria
      )
    } catch (error) {
      // Assert
      expect(error).toBeInstanceOf(Error)
    }

    expect(getManyAndCountSpy).toHaveBeenCalledTimes(1)
    expect(getManyAndCountSpy).toHaveBeenCalledWith()
  })
})
