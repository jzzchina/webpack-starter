const personnelFixture = {
  connection: {
    getRepository: jest.fn().mockReturnValue({
      createQueryBuilder: jest.fn().mockReturnValue({
        select: jest.fn().mockReturnThis(),
        softDelete: jest.fn().mockReturnThis(),
        from: jest.fn().mockReturnThis(),
        leftJoin: jest.fn().mockReturnThis(),
        orderBy: jest.fn().mockReturnThis(),
        take: jest.fn().mockReturnThis(),
        skip: jest.fn().mockReturnThis(),
        where: jest.fn().mockReturnThis(),
        andWhere: jest.fn().mockReturnThis(),
        setParameter: jest.fn().mockReturnThis(),
        getManyAndCount: jest.fn(), // To be mocked in each test
        execute: jest.fn(), // To be mocked in each test
      }),
    }),
  },
  getManyAndCount: {
    result: [
      {
        name_jpn: '単体テスト',
        unregistered_date: null,
        updated_by: null,
        update_at: null,
        process_id: null,
        personnel_id: 100,
        name: 'Unit Test name',
        registered_date: '2022-01-01',
        skill_list: {
          LeadDev: {
            level: 1,
          },
          'BackEnd,Node.js': {
            level: 3,
          },
          'FrontEnd,Web(React)': {
            level: 2,
          },
        },
        dw_m_partner_company: {
          updated_by: null,
          update_at: null,
          process_id: null,
          company_id: 1,
          company_name: 'Unit Test Company Name',
          contract_pattern_code: 1,
        },
        dw_m_personnel_price: [],
      },
    ],
    count: 1,
  },
  searchCriteria: {
    limit: 100,
    offset: 0,
    personnel_id: 2,
    name: '3',
    name_jpn: 'テスト',
    project_id: 112,
    company_id: 1,
    search_name: 'test41 テスト８',
    skills: {
      LeadDev: { level: 1 },
      'FrontEnd,Web(React)': { level: undefined },
      'BackEnd,Node.js': { level: 3 },
    },
  },
  emptySearchCriteria: {
    limit: NaN,
    offset: NaN,
    personnel_id: NaN,
    name: 'undefined',
    name_jpn: 'undefined',
    project_id: NaN,
    company_id: NaN,
    search_name: 'undefined',
  },
  deleteResult: {
    generatedMaps: [],
    raw: {
      fieldCount: 0,
      affectedRows: 1,
      insertId: 0,
      info: 'Rows matched: 1  Changed: 1  Warnings: 0',
      serverStatus: 2,
      warningStatus: 0,
      changedRows: 1,
    },
  },
  notMatchedDeleteResult: {
    generatedMaps: [],
    raw: {
      fieldCount: 0,
      affectedRows: 0,
      insertId: 0,
      info: 'Rows matched: 0 Changed: 0  Warnings: 0',
      serverStatus: 2,
      warningStatus: 0,
      changedRows: 1,
    },
  },
}

export default personnelFixture
