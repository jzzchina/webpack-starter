import { Connection } from 'typeorm'
import { personnelRepositoryMySQL } from '../../../../../src/infrastructure/repositories/options/personnel/personnelRepositoryMySQL'

import fixture from './personnel.fixture'
import CustomError from '../../../../../src/application/errors/CustomError'
import messages from '../../../../../src/application/errors/messages'

describe('TEST - personnelRepositoryMySQL Delete method', () => {
  const connection = (fixture.connection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })

  test('should delete personnel successfully', async () => {
    // Arrange
    const personnelRepository = await personnelRepositoryMySQL(connection)

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_personnel').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockResolvedValueOnce(fixture.deleteResult)

    // Act
    const result = await personnelRepository.deletePersonnels([100])

    // Assert
    expect(result).toEqual(undefined)
    expect(executeSpy).toHaveBeenCalledTimes(1)
  })

  test('should throw a error when personnel doesn`t exist', async () => {
    // Arrange
    const personnelRepository = await personnelRepositoryMySQL(connection)
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_personnel').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockResolvedValueOnce(fixture.notMatchedDeleteResult)
    try {
      // Act
      await personnelRepository.deletePersonnels([200])
    } catch (err) {
      // Assert
      expect(err).toEqual(
        new CustomError(messages.personnelDoesNotExist, 'Not Found')
      )
    }
  })
  test('should throw a error', async () => {
    // Arrange
    const personnelRepository = await personnelRepositoryMySQL(connection)

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_personnel').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockRejectedValueOnce(new Error('unexpected error'))

    // Act
    try {
      await personnelRepository.deletePersonnels([100])
    } catch (err) {
      // Assert
      const error = err as Error
      expect(error).toBeInstanceOf(Error)
      expect(error.message).toEqual('unexpected error')
    }
  })
})
