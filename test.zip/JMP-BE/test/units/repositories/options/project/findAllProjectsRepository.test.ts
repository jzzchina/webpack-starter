import { Connection } from 'typeorm'
import { ProjectSearchCriteria } from '../../../../../src/domain/models/Project'
import { projectRepositoryMySQL } from '../../../../../src/infrastructure/repositories/options/project/projectRepositoryMySQL'
import fixture from './project.fixture'

describe('TEST - ProjectRepository findAll method', () => {
  const connection = (fixture.connection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })

  test('should find all project with searchCriteria', async () => {
    // Arrange
    const projectRepository = await projectRepositoryMySQL(connection)
    const getManyAndCountSpy = jest.spyOn(
      connection.getRepository('Dw_m_project').createQueryBuilder(),
      'getManyAndCount'
    )
    getManyAndCountSpy.mockResolvedValueOnce([
      fixture.getManyAndCount.result,
      fixture.getManyAndCount.count,
    ])

    // Act
    const result = await projectRepository.findAll(
      (fixture.searchCriteria as unknown) as ProjectSearchCriteria
    )

    // Assert
    expect(getManyAndCountSpy).toHaveBeenCalledTimes(1)
    expect(getManyAndCountSpy).toHaveBeenCalledWith()
    expect(result).toEqual({
      count: fixture.getManyAndCount.count,
      result: fixture.getManyAndCount.result,
    })
  })

  test('should find all project without searchCriteria', async () => {
    // Arrange
    const projectRepository = await projectRepositoryMySQL(connection)
    const getManyAndCountSpy = jest.spyOn(
      connection.getRepository('Dw_m_project').createQueryBuilder(),
      'getManyAndCount'
    )
    getManyAndCountSpy.mockResolvedValueOnce([
      fixture.getManyAndCount.result,
      fixture.getManyAndCount.count,
    ])

    // Act
    const result = await projectRepository.findAll(
      (fixture.emptySearchCriteria as unknown) as ProjectSearchCriteria
    )

    // Assert
    expect(getManyAndCountSpy).toHaveBeenCalledTimes(1)
    expect(getManyAndCountSpy).toHaveBeenCalledWith()
    expect(result).toEqual({
      count: fixture.getManyAndCount.count,
      result: fixture.getManyAndCount.result,
    })
  })

  test('should throw error when getManyAndCount throws error', async () => {
    // Arrange
    const projectRepository = await projectRepositoryMySQL(connection)
    const getManyAndCountSpy = jest.spyOn(
      connection.getRepository('Dw_m_project').createQueryBuilder(),
      'getManyAndCount'
    )
    getManyAndCountSpy.mockRejectedValueOnce(new Error('Unexpected error'))

    try {
      // Act
      await projectRepository.findAll(
        (fixture.searchCriteria as unknown) as ProjectSearchCriteria
      )
    } catch (error) {
      // Assert
      const err = error as Error
      expect(err).toBeInstanceOf(Error)
      expect(err.message).toEqual('Unexpected error')
    }

    expect(getManyAndCountSpy).toHaveBeenCalledTimes(1)
    expect(getManyAndCountSpy).toHaveBeenCalledWith()
  })
})
