import { Connection } from 'typeorm'
import { projectRepositoryMySQL } from '../../../../../src/infrastructure/repositories/options/project/projectRepositoryMySQL'
import fixture from './project.fixture'
import CustomError from '../../../../../src/application/errors/CustomError'

describe('TEST - ProjectRepository create method', () => {
  const connection = (fixture.connection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })
  const projectsToBeInserted = fixture.projectsToBeInserted

  test('should create new projects', async () => {
    // * Arrange
    const projectRepository = await projectRepositoryMySQL(connection)

    const createdProjects = fixture.createdProject

    const saveSpy = jest.spyOn(connection.getRepository('Dw_m_project'), 'save')
    saveSpy.mockResolvedValueOnce(createdProjects)

    // * Act
    const result = await projectRepository.createProjects(projectsToBeInserted)

    // * Assert
    expect(saveSpy).toHaveBeenCalledTimes(1)
    expect(result).toEqual(createdProjects)
  })

  test('should throw error - methodNotAllowedError', async () => {
    // * Arrange
    const projectRepository = await projectRepositoryMySQL(connection)
    const saveSpy = jest.spyOn(connection.getRepository('Dw_m_project'), 'save')
    const methodNotAllowedErr = {
      errno: 1452,
      code: 'ER_NO_REFERENCED_ROW_2',
    }

    saveSpy.mockRejectedValueOnce(methodNotAllowedErr)

    try {
      // * Act
      await projectRepository.createProjects(projectsToBeInserted)
    } catch (error) {
      const err = error as CustomError
      // * Assert
      expect(err.message).toEqual('Foreign key constraint error')
    }

    expect(saveSpy).toHaveBeenCalledTimes(1)
  })

  test('should throw error - Error', async () => {
    // * Arrange
    const projectRepository = await projectRepositoryMySQL(connection)

    const saveSpy = jest.spyOn(connection.getRepository('Dw_m_project'), 'save')
    const error = new Error('Error')
    saveSpy.mockRejectedValueOnce(error)

    try {
      // * Act
      await projectRepository.createProjects(projectsToBeInserted)
    } catch (error) {
      // * Assert
      expect(error).toBeInstanceOf(Error)
      expect(error).toHaveProperty('message')
    }

    expect(saveSpy).toHaveBeenCalledTimes(1)
  })
})
