import { Connection } from 'typeorm'
import { projectRepositoryMySQL } from '../../../../../src/infrastructure/repositories/options/project/projectRepositoryMySQL'

import fixture from './project.fixture'
import CustomError from '../../../../../src/application/errors/CustomError'
import messages from '../../../../../src/application/errors/messages'

describe('TEST - projectRepositoryMySQL Delete method', () => {
  const connection = (fixture.connection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })

  test('should delete projects successfully', async () => {
    // Arrange
    const projectRepository = await projectRepositoryMySQL(connection)

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_project').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockResolvedValueOnce(fixture.deleteResult)

    // Act
    const result = await projectRepository.deleteProjects([108])

    // Assert
    expect(result).toEqual(undefined)
    expect(executeSpy).toHaveBeenCalledTimes(1)
  })

  test('should throw a error when projects doesn`t exist', async () => {
    // Arrange
    const projectRepository = await projectRepositoryMySQL(connection)
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_project').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockResolvedValueOnce(fixture.notMatchedDeleteResult)
    try {
      // Act
      await projectRepository.deleteProjects([200])
    } catch (err) {
      // Assert
      expect(err).toEqual(
        new CustomError(messages.projectNotFound, 'Not Found')
      )
    }
  })
  test('should throw a error', async () => {
    // Arrange
    const projectRepository = await projectRepositoryMySQL(connection)

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_project').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockRejectedValueOnce(new Error('unexpected error'))

    // Act
    try {
      await projectRepository.deleteProjects([108])
    } catch (err) {
      // Assert
      const error = err as Error
      expect(error).toBeInstanceOf(Error)
      expect(error.message).toEqual('unexpected error')
    }
  })
})
