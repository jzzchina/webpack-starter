import { UpdateResult } from 'typeorm'

const operationCostFixture = {
  connection: {
    getRepository: jest.fn().mockReturnValue({
      createQueryBuilder: jest.fn().mockReturnValue({
        delete: jest.fn().mockReturnThis(),
        from: jest.fn().mockReturnThis(),
        select: jest.fn().mockReturnThis(),
        where: jest.fn().mockReturnThis(),
        execute: jest.fn(), // To be mocked in each test
        getManyAndCount: jest.fn(), // To be mocked in each test
        leftJoinAndSelect: jest.fn().mockReturnThis(),
        leftJoin: jest.fn().mockReturnThis(),
        andWhere: jest.fn().mockReturnThis(),
        orderBy: jest.fn().mockReturnThis(),
        skip: jest.fn().mockReturnThis(),
        take: jest.fn().mockReturnThis(),
        innerJoinAndSelect: jest.fn().mockReturnThis(),
        setParameter: jest.fn().mockReturnThis(),
        softDelete: jest.fn().mockReturnThis(),
      }),
    }),
  },
  operationCostDeleteSuccess: [
    {
      personnel_id: 1,
      project_id: 3,
      month_of_year_date: '2022-01-01',
      role_id: 12,
      man_month_number: 2,
      hours_number: 6,
      created_by: 'Phuong Le',
      create_at: '2022-01-01',
      updated_by: 'Phuong Le',
      update_at: '2022-01-01',
      process_at: '2022-01-01',
      process_id: 'A100',
    },
  ],
  operationCostNotExist: {
    ProjectIds: [3, 4, 5],
    PersonnelIds: [5, 2, 1],
    YearOfMonths: ['2022-01-01', '2022-01-02'],
  },

  deleteResult: {
    generatedMaps: [],
    raw: {
      fieldCount: 0,
      affected: 1,
      insertId: 0,
      info: 'Rows matched: 1  Changed: 1  Warnings: 0',
      serverStatus: 2,
      warningStatus: 0,
      changedRows: 1,
    },
  },
  notMatchedDeleteResult: {
    generatedMaps: [],
    raw: {
      fieldCount: 0,
      affected: 0,
      insertId: 0,
      info: 'Rows matched: 0 Changed: 0  Warnings: 0',
      serverStatus: 2,
      warningStatus: 0,
      changedRows: 1,
    },
  } as UpdateResult,
}

export default operationCostFixture
