import { Connection } from 'typeorm'
import { operationCostRepositoryMySQL } from '../../../../src/infrastructure/repositories/operationCost/operationCostRepositoryMySQL'

import fixture from './operationCost.fixture'
import CustomError from '../../../../src/application/errors/CustomError'
import messages from '../../../../src/application/errors/messages'

describe('TEST - operationCostRepositoryMySQL Delete method', () => {
  const connection = (fixture.connection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })

  test('should delete operation plan successfully', async () => {
    // Arrange
    const operationCost = await operationCostRepositoryMySQL(connection)

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_t_operation').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockResolvedValueOnce(fixture.deleteResult)

    // Act
    const result = await operationCost.deleteOperationCosts(
      fixture.operationCostNotExist
    )

    // Assert
    expect(result).toEqual(undefined)
    expect(executeSpy).toHaveBeenCalledTimes(1)
  })

  test('should throw a error when operation plan doesn`t exist', async () => {
    // Arrange
    const operationCost = await operationCostRepositoryMySQL(connection)
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_t_operation').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockResolvedValueOnce(fixture.notMatchedDeleteResult)
    try {
      await operationCost.deleteOperationCosts(fixture.operationCostNotExist)
    } catch (err: unknown) {
      const expectedError = new CustomError(
        messages.targetOperationCostNotFound,
        'Not Found'
      )
      expect(err).toEqual(expectedError)
    }
  })
  test('should throw a error', async () => {
    // Arrange
    const operationCost = await operationCostRepositoryMySQL(connection)

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_t_operation').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockRejectedValueOnce(new Error('unexpected error'))

    // Act
    try {
      await operationCost.deleteOperationCosts(fixture.operationCostNotExist)
    } catch (err) {
      // Assert
      const error = err as Error
      expect(error).toBeInstanceOf(Error)
      expect(error.message).toEqual('unexpected error')
    }
  })
})
