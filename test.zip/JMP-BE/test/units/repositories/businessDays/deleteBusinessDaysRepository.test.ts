import { Connection } from 'typeorm'
import { businessDaysRepositoryMySQL } from '../../../../src/infrastructure/repositories/businessDays/businessDaysRepositoryMySQL'
import CustomError from '../../../../src/application/errors/CustomError'
import {
  businessDayDeleteResult,
  businessDayDeleteResultFailed,
  businessDayRepositoryConnection,
  businessDaysKey,
} from '../../../fixtures/inserts/businessDays.fixture'
import messages from '../../../../src/application/errors/messages'

describe('TEST - businessDaysRepositoryMySQL delete method', () => {
  const connection = (businessDayRepositoryConnection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })

  test('should delete businessDays and return affected row', async () => {
    // Arrange
    const businessDaysRepository = await businessDaysRepositoryMySQL(connection)
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_business_days').createQueryBuilder(),
      'execute'
    )
    executeSpy.mockResolvedValueOnce(businessDayDeleteResult)

    // Act
    const result = await businessDaysRepository.delete(
      businessDaysKey.companyId,
      businessDaysKey.monthOfYearDate
    )

    // Assert
    expect(result).toEqual(businessDayDeleteResult)
    expect(executeSpy).toHaveBeenCalledTimes(1)
  })

  test('should throw idDoesntExistError when the businessDays is not found', async () => {
    // Arrange
    const businessDaysRepository = await businessDaysRepositoryMySQL(connection)
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_business_days').createQueryBuilder(),
      'execute'
    )
    executeSpy.mockResolvedValueOnce(businessDayDeleteResultFailed)

    try {
      // Act
      await businessDaysRepository.delete(
        businessDaysKey.companyId,
        businessDaysKey.monthOfYearDate
      )
    } catch (err: unknown) {
      // Assert
      const expectedError = new CustomError(
        messages.recordsDoesNotExist,
        'Not Found'
      )
      expect(err).toEqual(expectedError)
    }
  })
  test('should throw a error', async () => {
    // Arrange
    const businessDaysRepository = await businessDaysRepositoryMySQL(connection)

    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_business_days').createQueryBuilder(),
      'execute'
    )

    executeSpy.mockRejectedValueOnce(new Error('unexpected error'))

    // Act
    try {
      await businessDaysRepository.delete(
        businessDaysKey.companyId,
        businessDaysKey.monthOfYearDate
      )
    } catch (err) {
      // Assert
      const error = err as Error
      expect(error).toBeInstanceOf(Error)
      expect(error.message).toEqual('unexpected error')
    }
  })
})
