import { Connection, Repository, SelectQueryBuilder } from 'typeorm'
import { businessDaysRepositoryMySQL } from '../../../../src/infrastructure/repositories/businessDays/businessDaysRepositoryMySQL'
// import { methodBadRequestError } from '../../../../src/application/errors/MethodBadRequestError'
import {
  businessDayRepositoryConnection,
  businessDaysKeys,
  manyBusinessDays,
} from '../../../fixtures/inserts/businessDays.fixture'
import { Dw_m_business_days } from '../../../../src/infrastructure/orm/typeorm/entities/Dw_m_business_days'

describe('TEST - businessDaysRepositoryMySQL findMany method', () => {
  const connection = (businessDayRepositoryConnection as unknown) as Connection
  let mockQueryBuilder: SelectQueryBuilder<Dw_m_business_days>
  beforeEach(() => {
    mockQueryBuilder = ({
      select: jest.fn().mockReturnThis(),
      leftJoinAndSelect: jest.fn().mockReturnThis(),
      whereInIds: jest.fn().mockReturnThis(),
      orderBy: jest.fn().mockReturnThis(),
      addOrderBy: jest.fn().mockReturnThis(),
      getMany: jest.fn().mockResolvedValue(manyBusinessDays),
      catch: jest.fn(),
    } as unknown) as SelectQueryBuilder<Dw_m_business_days>

    // Mock getRepository and createQueryBuilder methods
    jest.spyOn(connection, 'getRepository').mockReturnValue(({
      createQueryBuilder: jest.fn().mockReturnValue(mockQueryBuilder),
    } as unknown) as Repository<any>)
  })
  afterEach(() => {
    jest.clearAllMocks()
  })

  test('should list Many business Days', async () => {
    const businessDaysRepository = await businessDaysRepositoryMySQL(connection)

    const result = await businessDaysRepository.findMany(businessDaysKeys)

    expect(mockQueryBuilder.select).toHaveBeenCalledWith([
      'businessDays.company_id',
      'businessDays.month_of_year_date',
      'businessDays.business_days_number',
    ])
    expect(mockQueryBuilder.leftJoinAndSelect).toHaveBeenCalledWith(
      'businessDays.dw_m_partner_company',
      'dw_m_partner_company'
    )
    expect(mockQueryBuilder.getMany).toHaveBeenCalled()
    expect(result.length).toEqual(3)
  })

  test('should throw an error if query fails', async () => {
    const businessDaysRepository = await businessDaysRepositoryMySQL(connection)
    ;(mockQueryBuilder.getMany as jest.Mock).mockRejectedValueOnce(new Error())
    try {
      await businessDaysRepository.findMany([])
    } catch (error) {
      expect(error).toBeInstanceOf(Error)
    }
  })
})
