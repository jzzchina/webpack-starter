import { Connection, Repository, SelectQueryBuilder } from 'typeorm'
import { businessDaysRepositoryMySQL } from '../../../../src/infrastructure/repositories/businessDays/businessDaysRepositoryMySQL'
import {
  allBusinessDays,
  businessDayRepositoryConnection,
} from '../../../fixtures/inserts/businessDays.fixture'
import { BusinessDays } from '../../../../src/interface/routes/businessDays/dto/businessDays.dto'

describe('TEST - businessDaysRepositoryMySQL findAll method', () => {
  const connection = (businessDayRepositoryConnection as unknown) as Connection
  let mockQueryBuilder: SelectQueryBuilder<BusinessDays>
  beforeEach(() => {
    mockQueryBuilder = ({
      select: jest.fn().mockReturnThis(),
      leftJoinAndSelect: jest.fn().mockReturnThis(),
      where: jest.fn().mockReturnThis(),
      orderBy: jest.fn().mockReturnThis(),
      addOrderBy: jest.fn().mockReturnThis(),
      getMany: jest.fn().mockResolvedValue(allBusinessDays),
      catch: jest.fn(),
    } as Partial<
      SelectQueryBuilder<BusinessDays>
    >) as SelectQueryBuilder<BusinessDays>

    // Mock getRepository and createQueryBuilder methods
    jest.spyOn(connection, 'getRepository').mockReturnValue(({
      createQueryBuilder: jest.fn().mockReturnValue(mockQueryBuilder),
    } as unknown) as Repository<any>)
  })
  afterEach(() => {
    jest.clearAllMocks()
  })

  test('should list all business Days', async () => {
    const businessDaysRepository = await businessDaysRepositoryMySQL(connection)
    const companyID = 1

    const result = await businessDaysRepository.findAll(companyID)

    expect(mockQueryBuilder.select).toHaveBeenCalledWith([
      'business_days.business_days_id',
      'business_days.company_id',
      'business_days.month_of_year_date',
      'business_days.business_days_number',
    ])
    expect(mockQueryBuilder.leftJoinAndSelect).toHaveBeenCalledWith(
      'business_days.dw_m_partner_company',
      'Dw_m_partner_company'
    )
    expect(mockQueryBuilder.where).toHaveBeenCalledWith(
      'business_days.company_id = :companyId',
      {
        companyId: 1,
      }
    )
    expect(mockQueryBuilder.getMany).toHaveBeenCalled()
    expect(result.length).toEqual(2)
  })
  test('should throw an error if query fails', async () => {
    const businessDaysRepository = await businessDaysRepositoryMySQL(connection)
    const companyID = 1
    ;(mockQueryBuilder.getMany as jest.Mock).mockRejectedValueOnce(new Error())
    try {
      await businessDaysRepository.findAll(companyID)
    } catch (error) {
      expect(error).toBeInstanceOf(Error)
    }
  })
})
