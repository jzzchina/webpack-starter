import { Connection } from 'typeorm'
import { businessDaysRepositoryMySQL } from '../../../../src/infrastructure/repositories/businessDays/businessDaysRepositoryMySQL'
import CustomError from '../../../../src/application/errors/CustomError'
import {
  businessDayRepositoryConnection,
  businessDaysToInsert,
} from '../../../fixtures/inserts/businessDays.fixture'
import messages from '../../../../src/application/errors/messages'

describe('TEST - businessDaysRepositoryMySQL Create method', () => {
  const connection = (businessDayRepositoryConnection as unknown) as Connection

  afterEach(() => {
    jest.clearAllMocks()
  })

  test('should create businessDays', async () => {
    // Arrange
    const businessDaysRepository = await businessDaysRepositoryMySQL(connection)
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_business_days').createQueryBuilder(),
      'execute'
    )
    executeSpy.mockResolvedValueOnce(businessDaysToInsert)

    // Act
    const result = await businessDaysRepository.create(businessDaysToInsert)
    // Assert
    expect(executeSpy).toHaveBeenCalledTimes(1)
    expect(result).toEqual(businessDaysToInsert)
  })

  test('should throw error - methodBadRequestError', async () => {
    // * Arrange
    const businessDaysRepository = await businessDaysRepositoryMySQL(connection)
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_business_days').createQueryBuilder(),
      'execute'
    )
    const methodBadRequestErr = {
      errno: 1452,
    }

    executeSpy.mockRejectedValueOnce(methodBadRequestErr)
    try {
      // * Act
      await businessDaysRepository.create(businessDaysToInsert)
    } catch (error) {
      // * Assert
      const expectedError = new CustomError(
        messages.requestedCompanyIdNotFound,
        'Bad Request'
      )
      expect(error).toEqual(expectedError)
    }

    expect(executeSpy).toHaveBeenCalledTimes(1)
  })

  test('should throw error - Error', async () => {
    // * Arrange
    const businessDaysRepository = await businessDaysRepositoryMySQL(connection)
    const executeSpy = jest.spyOn(
      connection.getRepository('Dw_m_business_days').createQueryBuilder(),
      'execute'
    )
    const error = new Error('Error')
    executeSpy.mockRejectedValueOnce(error)

    try {
      // * Act
      await businessDaysRepository.create(businessDaysToInsert)
    } catch (error) {
      // * Assert
      expect(error).toBeInstanceOf(Error)
      expect(error).toHaveProperty('message')
    }

    expect(executeSpy).toHaveBeenCalledTimes(1)
  })
})
