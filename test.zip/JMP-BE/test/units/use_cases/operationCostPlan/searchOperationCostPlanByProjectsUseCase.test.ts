import { OperationCostPlanRepositoryPort } from '../../../../src/application/port/repositories/operationCostPlan/OperationCostPlanRepositoryPort'
import { searchOperationCostPlanByProjectsUseCase } from '../../../../src/application/use_cases/operationCostPlan/searchOperationCostPlanByProjectUseCase'
import { projects } from '../../../fixtures/expected/operationCostPlan/operationCostPlan.fixture'
import {
  searchOperationCostPlanParams,
  invalidSearchOperationCostPlanParams,
} from '../../../fixtures/inserts/operationCostPlan.fixture'

describe('searchOperationCostPlanByProjectsUseCase', () => {
  const repository = ({
    searchOperationCostPlansByProject: () => jest.fn(),
  } as unknown) as OperationCostPlanRepositoryPort
  let findManySpy: jest.SpyInstance
  beforeEach(() => {
    findManySpy = jest.spyOn(repository, 'searchOperationCostPlansByProject')
  })

  afterAll(() => {
    jest.resetAllMocks()
  })

  test('should return project list when param data is valid', async () => {
    findManySpy.mockImplementation(() =>
      Promise.resolve({ totalItems: 2, projects: projects })
    )

    const result = await searchOperationCostPlanByProjectsUseCase(
      searchOperationCostPlanParams.limit,
      searchOperationCostPlanParams.offset,
      searchOperationCostPlanParams.from,
      searchOperationCostPlanParams.to,
      searchOperationCostPlanParams.projectId,
      searchOperationCostPlanParams.companyId,
      repository
    )

    expect(repository.searchOperationCostPlansByProject).toHaveBeenCalledTimes(
      1
    )

    expect(result.items).toHaveLength(1)
    expect(result.totalLength).toBeLessThanOrEqual(
      searchOperationCostPlanParams.limit
    )
    result.items.forEach((item) => {
      expect(item).toHaveProperty('projectId')
      expect(item).toHaveProperty('projectName')
      expect(item).toHaveProperty('projectContact')
      expect(item).toHaveProperty('projectStartDate')
      expect(item).toHaveProperty('projectEndDate')
      expect(item).toHaveProperty('note')
      expect(item).toHaveProperty('personnel')

      item.personnel?.forEach((personnel) => {
        expect(personnel).toHaveProperty('companyId')
        expect(personnel).toHaveProperty('contractPatternCode')
        expect(personnel).toHaveProperty('companyName')
        expect(personnel).toHaveProperty('personnelId')
        expect(personnel).toHaveProperty('name')
        expect(personnel).toHaveProperty('nameJpn')
        expect(personnel).toHaveProperty('businessDays', {
          '2022-01-01': {
            businessDaysNumber: '20',
          },
          '2022-02-01': {
            businessDaysNumber: '22',
          },
        })
        expect(personnel).toHaveProperty('registeredDate')
        expect(personnel).toHaveProperty('unregisteredDate')
        expect(personnel).toHaveProperty('skillList')
        expect(personnel).toHaveProperty('prices')
        personnel.prices
          ? personnel.prices.map((personnelPrice) => {
              expect(personnelPrice).toHaveProperty('contractPatternCode')
              expect(personnelPrice).toHaveProperty('priceStartDate')
              expect(personnelPrice).toHaveProperty('priceAmount')
              expect(personnelPrice).toHaveProperty('currencyTypeCode')
            })
          : []
        expect(personnel).toHaveProperty('operationCostPlans')
        expect(personnel.operationCostPlans).toHaveProperty('2022-01-01', {
          manMonthNumber: 0.26,
          hoursNumber: 0.5,
        })
      })
    })
  })

  test('should throw an error when any param validation fails', async () => {
    findManySpy.mockImplementation(() => Promise.reject('Error'))

    try {
      await searchOperationCostPlanByProjectsUseCase(
        invalidSearchOperationCostPlanParams.limit,
        invalidSearchOperationCostPlanParams.offset,
        invalidSearchOperationCostPlanParams.from,
        invalidSearchOperationCostPlanParams.to,
        invalidSearchOperationCostPlanParams.projectId,
        invalidSearchOperationCostPlanParams.companyId,
        repository
      )
    } catch (error) {
      expect(error).toBeTruthy()
    }
  })

  test('should return empty list when operationPlan are not found', async () => {
    findManySpy.mockImplementation(() =>
      Promise.resolve({ projects: [], totalItems: 0 })
    )

    const result = await searchOperationCostPlanByProjectsUseCase(
      searchOperationCostPlanParams.limit,
      searchOperationCostPlanParams.offset,
      searchOperationCostPlanParams.from,
      searchOperationCostPlanParams.to,
      searchOperationCostPlanParams.projectId,
      searchOperationCostPlanParams.companyId,
      repository
    )
    expect(repository.searchOperationCostPlansByProject).toHaveBeenCalled()
    expect(result.items).toHaveLength(0)
  })

  test('should throw an error when searchOperationCostPlansByProject throw error', async () => {
    findManySpy.mockImplementation(() => Promise.reject('Error'))

    try {
      await searchOperationCostPlanByProjectsUseCase(
        searchOperationCostPlanParams.limit,
        searchOperationCostPlanParams.offset,
        searchOperationCostPlanParams.from,
        searchOperationCostPlanParams.to,
        searchOperationCostPlanParams.projectId,
        searchOperationCostPlanParams.companyId,
        repository
      )
    } catch (error) {
      expect(error).toBeTruthy()
    }
  })
})
