import { WbsRepositoryPort } from '../../../../src/application/port/repositories/wbs/wbsRepositoryPort'
import { searchWbsCostsUseCase } from '../../../../src/application/use_cases/wbs/searchWbsCostsUseCase'
import { wbsCosts } from '../../../fixtures/expected/wbs/wbsCost.fixture'
import { searchWbsCostsParams } from '../../../fixtures/inserts/wbs.fixture'

describe('searchWbsCostsUseCase.test', () => {
  const repository = ({
    searchWbsCosts: () => jest.fn(),
  } as unknown) as WbsRepositoryPort
  let findManySpy: jest.SpyInstance
  beforeEach(() => {
    findManySpy = jest.spyOn(repository, 'searchWbsCosts')
  })

  afterAll(() => {
    jest.resetAllMocks()
  })

  test('should return project list when param data is valid', async () => {
    findManySpy.mockImplementation(() =>
      Promise.resolve({ totalItems: 11, personnel: wbsCosts })
    )

    const result = await searchWbsCostsUseCase(
      searchWbsCostsParams.limit,
      searchWbsCostsParams.offset,
      searchWbsCostsParams.from,
      searchWbsCostsParams.to,
      searchWbsCostsParams.companyId,
      repository
    )

    expect(repository.searchWbsCosts).toHaveBeenCalledTimes(1)

    expect(result.items).toHaveLength(5)
    expect(result.totalLength).toBeLessThanOrEqual(searchWbsCostsParams.limit)
    result.items.forEach((item) => {
      expect(item).toHaveProperty('month')
      expect(item).toHaveProperty('total')
      expect(item).toHaveProperty('wbs')

      item.wbs.forEach((w) => {
        expect(w).toHaveProperty('wbsCode')
        expect(w).toHaveProperty('wbsTitle')
        expect(w).toHaveProperty('subject')
        expect(w).toHaveProperty('projectName')
        expect(w).toHaveProperty('amount')
      })
    })
  })

  test('should throw an error when any param validation fails', async () => {
    findManySpy.mockImplementation(() => Promise.reject('Error'))

    try {
      await searchWbsCostsUseCase(
        searchWbsCostsParams.limit,
        searchWbsCostsParams.offset,
        searchWbsCostsParams.from,
        searchWbsCostsParams.to,
        searchWbsCostsParams.companyId,
        repository
      )
    } catch (error) {
      expect(error).toBeTruthy()
    }
  })

  test('should return empty list when operationPlan are not found', async () => {
    findManySpy.mockImplementation(() =>
      Promise.resolve({ totalItems: 0, personnel: [] })
    )

    const result = await searchWbsCostsUseCase(
      searchWbsCostsParams.limit,
      searchWbsCostsParams.offset,
      searchWbsCostsParams.from,
      searchWbsCostsParams.to,
      searchWbsCostsParams.companyId,
      repository
    )
    expect(repository.searchWbsCosts).toHaveBeenCalled()
    expect(result.items).toHaveLength(0)
  })
})
