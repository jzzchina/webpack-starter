import CustomError from '../../../../src/application/errors/CustomError'
import { BusinessDaysRepositoryPort } from '../../../../src/application/port/repositories/businessDays/BusinessDaysRepositoryPort'
import { deleteBusinessDaysUseCase } from '../../../../src/application/use_cases/businessDays/deleteBusinessDaysUseCase'
import { deleteBusinessDaysPayload } from '../../../fixtures/inserts/businessDays.fixture'

describe('TEST deleteBusinessDays UseCase', () => {
  const repository = ({
    delete: () => jest.fn(),
  } as unknown) as BusinessDaysRepositoryPort

  let deleteSpy: jest.SpyInstance

  beforeEach(() => {
    deleteSpy = jest.spyOn(repository, 'delete')
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  test('should delete business days', async () => {
    const companyId =
      deleteBusinessDaysPayload.input.successfulDeletion.companyId
    const date = deleteBusinessDaysPayload.input.successfulDeletion.date
    // * Arrange
    deleteSpy.mockImplementation(() =>
      Promise.resolve(deleteBusinessDaysPayload.response.success)
    )

    // * Act
    const result = await deleteBusinessDaysUseCase(companyId, date, repository)

    // * Assert

    expect(deleteSpy).toHaveBeenCalledTimes(1)

    expect(result).toBeUndefined()
  })

  test('should return 404 error', async () => {
    // * Arrange
    deleteSpy.mockImplementation(() =>
      Promise.resolve(deleteBusinessDaysPayload.response.error)
    )
    const companyId = deleteBusinessDaysPayload.input.failedDeletion.companyId
    const date = deleteBusinessDaysPayload.input.failedDeletion.date
    // * Act
    try {
      await deleteBusinessDaysUseCase(companyId, date, repository)
    } catch (error) {
      const err = error as CustomError
      expect(deleteSpy).toHaveBeenCalledTimes(1)
      expect(err.statusCode).toBe(404)
    }
  })
})
