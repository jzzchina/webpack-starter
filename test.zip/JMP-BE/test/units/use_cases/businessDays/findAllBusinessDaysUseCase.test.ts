import { BusinessDaysRepositoryPort } from '../../../../src/application/port/repositories/businessDays/BusinessDaysRepositoryPort'
import { findAllBusinessDaysUseCase } from '../../../../src/application/use_cases/businessDays/findAllBusinessDaysUseCase'
import { businessDaysInputFixture } from '../../../fixtures/inserts/businessDays.fixture'

describe('TEST findAllBusinessDays UseCase', () => {
  const repository = {
    findAll: () => jest.fn(),
  }
  let findAllSpy: jest.SpyInstance

  beforeEach(() => {
    findAllSpy = jest.spyOn(repository, 'findAll')
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  const foundBusinessDays = businessDaysInputFixture.result.foundBusinessDays
  const businessDaysRepo = (repository as unknown) as BusinessDaysRepositoryPort

  test('should return list of business days', async () => {
    // * Arrange
    findAllSpy.mockImplementation(() => Promise.resolve(foundBusinessDays))
    const companyId = businessDaysInputFixture.input.validInput.companyID
    // * Act
    const result = await findAllBusinessDaysUseCase(companyId, businessDaysRepo)

    // * Assert
    const expectedItems = ['companyId', 'monthOfYearDate', 'businessDaysNumber']

    expect(findAllSpy).toHaveBeenCalledTimes(1)
    expect(result).toHaveProperty('items')
    result.items.forEach((item) => {
      expectedItems.forEach((field) => {
        expect(item).toHaveProperty(field)
      })
    })
  })
})
