import { BusinessDaysRepositoryPort } from '../../../../src/application/port/repositories/businessDays/BusinessDaysRepositoryPort'
import { createBusinessDaysUseCase } from '../../../../src/application/use_cases/businessDays/createBusinessDaysUseCase'
import { BusinessDaysList } from '../../../../src/interface/routes/businessDays/dto/businessDays.dto'
import {
  businessDaysCreatePayload,
  creationResult,
} from '../../../fixtures/inserts/businessDays.fixture'

describe('TEST createBusinessDays UseCase', () => {
  const repository = {
    create: () => jest.fn(),
    findMany: () => jest.fn(),
  }

  let createSpy: jest.SpyInstance
  let findManySpy: jest.SpyInstance

  beforeEach(() => {
    createSpy = jest.spyOn(repository, 'create')
    findManySpy = jest.spyOn(repository, 'findMany')
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  const businessDays = businessDaysCreatePayload as BusinessDaysList

  const nameOfUser = 'Unit Test'
  const businessDaysRepo = (repository as unknown) as BusinessDaysRepositoryPort

  test('should create business days', async () => {
    // * Arrange
    createSpy.mockImplementation(() => Promise.resolve(creationResult))
    findManySpy.mockImplementation(() => Promise.resolve(businessDays))

    // * Act
    const result = await createBusinessDaysUseCase(
      businessDays,
      nameOfUser,
      businessDaysRepo
    )

    // * Assert
    const expectedItems = ['companyId', 'monthOfYearDate', 'businessDaysNumber']

    expect(createSpy).toHaveBeenCalledTimes(1)
    expect(findManySpy).toHaveBeenCalledTimes(1)

    result.forEach((item) => {
      expectedItems.forEach((field) => {
        expect(item).toHaveProperty(field)
      })
    })
  })
  test('should create business days with e businessDaysNumber equal to zero ', async () => {
    // * Arrange
    createSpy.mockImplementation(() => Promise.resolve(creationResult))
    findManySpy.mockImplementation(() => Promise.resolve(businessDays))

    // * Act
    const result = await createBusinessDaysUseCase(
      businessDays,
      nameOfUser,
      businessDaysRepo
    )

    // * Assert
    const expectedItems = ['companyId', 'monthOfYearDate', 'businessDaysNumber']

    expect(createSpy).toHaveBeenCalledTimes(1)
    expect(findManySpy).toHaveBeenCalledTimes(1)
    expect(result[0].businessDaysNumber).toBe(0)
    result.forEach((item) => {
      expectedItems.forEach((field) => {
        expect(item).toHaveProperty(field)
      })
    })
  })
})
