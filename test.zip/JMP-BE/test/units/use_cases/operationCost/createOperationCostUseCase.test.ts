import { OperationCostRepositoryPort } from '../../../../src/application/port/repositories/operationCost/OperationCostRepositoryPort'
import { createOperationCostUseCase } from '../../../../src/application/use_cases/operationCost/createOperationCostUseCase'
import { CreateOperationCostDto } from '../../../../src/interface/routes/operationCost/dto/operationCost.dto'
import {
  operationCostsCreate,
  operationCostsUpdate,
} from '../../../fixtures/expected/operationCost/operationCosts.fixture'
import {
  createOperationCostsParams,
  updateInsertResult,
  updateOperationCostsParams,
  userInformation,
} from '../../../fixtures/inserts/operationCosts.fixture'

describe('UNIT TEST:CreateOperationCostsUseCase', () => {
  const repository = ({
    create: () => jest.fn(),
  } as unknown) as Pick<OperationCostRepositoryPort, 'create'>
  let createSpy: jest.SpyInstance
  beforeEach(() => {
    createSpy = jest.spyOn(repository, 'create')
  })

  afterAll(() => {
    jest.resetAllMocks()
  })

  test('should create methods NOT be triggered by default', () => {
    expect(repository.create).not.toHaveBeenCalled()
  })

  describe('createOperationCostUseCase is called', () => {
    test('should create new operation cost', async () => {
      createSpy.mockImplementation(() => Promise.resolve(operationCostsCreate))

      const result = await createOperationCostUseCase(
        createOperationCostsParams as CreateOperationCostDto[],
        userInformation,
        repository
      )
      expect(repository.create).toHaveBeenCalled()
      expect(result).toHaveLength(1)
      expect(result[0]).toHaveProperty('personnelId', 1)
      expect(result[0]).toHaveProperty('projectId', 1)
      expect(result[0]).toHaveProperty('costAmount', 0.5)
      expect(result[0]).toHaveProperty('hoursNumber', 0.6)
      expect(result[0]).toHaveProperty(
        'yearOfMonthDate',
        new Date('2022-01-01')
      )
    })

    test('should update an operation cost successfully', async () => {
      jest
      createSpy.mockImplementation(() => Promise.resolve(operationCostsUpdate))

      const result = await createOperationCostUseCase(
        updateOperationCostsParams as CreateOperationCostDto[],
        userInformation,
        repository
      )
      expect(repository.create).toHaveBeenCalled()
      expect(result).toHaveLength(1)
      expect(result[0].projectId).toEqual(
        updateInsertResult.identifiers[0].dw_m_project
      )
      expect(result[0]).toHaveProperty('personnelId', 1)
      expect(result[0]).toHaveProperty('projectId', 2)
      expect(result[0]).toHaveProperty('costAmount', 0.07)
      expect(result[0]).toHaveProperty('hoursNumber', 0.3)
      expect(result[0]).toHaveProperty(
        'yearOfMonthDate',
        new Date('2022-03-01')
      )
    })

    test('should throw error when param is empty', async () => {
      jest
      createSpy.mockImplementation(() => Promise.resolve({}))

      try {
        await createOperationCostUseCase([], userInformation, repository)
      } catch (error) {
        expect(error).toBeTruthy
      }
    })

    test('should throw an error when create throw an error', async () => {
      jest
      createSpy.mockImplementation(() => Promise.reject('Error'))
      try {
        await createOperationCostUseCase([], userInformation, repository)
      } catch (error) {
        expect(error).toBeTruthy()
      }
    })
  })
})
