import { OperationCostRepositoryPort } from '../../../../src/application/port/repositories/operationCost/OperationCostRepositoryPort'
import { searchOperationCostsUseCase } from '../../../../src/application/use_cases/operationCost/searchOperationCostsUseCase'
import {
  projects,
  projectsWithoutMonthOfYearDate,
} from '../../../fixtures/expected/operationCost/operationCosts.fixture'
import {
  invalidSearchOperationCostsParams,
  searchOperationCostsParams,
} from '../../../fixtures/inserts/operationCosts.fixture'

describe('searchOperationCostsUseCase', () => {
  const repository = ({
    searchOperationCosts: () => jest.fn(),
  } as unknown) as Pick<OperationCostRepositoryPort, 'searchOperationCosts'>
  let searchOperationCostsSpy: jest.SpyInstance
  beforeEach(() => {
    searchOperationCostsSpy = jest.spyOn(repository, 'searchOperationCosts')
  })

  afterAll(() => {
    jest.resetAllMocks()
  })

  test('should searchOperationCosts methods NOT be triggered by default', () => {
    expect(repository.searchOperationCosts).not.toHaveBeenCalled()
  })

  describe('searchOperationCostsUseCase is called', () => {
    test('should return project list when param data is valid', async () => {
      searchOperationCostsSpy.mockImplementation(() =>
        Promise.resolve({ totalItems: 2, projects: projects })
      )

      const result = await searchOperationCostsUseCase(
        searchOperationCostsParams.limit,
        searchOperationCostsParams.offset,
        searchOperationCostsParams.from,
        searchOperationCostsParams.to,
        searchOperationCostsParams.projectId,
        searchOperationCostsParams.companyId,
        repository
      )
      expect(repository.searchOperationCosts).toHaveBeenCalled()
      expect(result.items).toHaveLength(1)
      expect(result.totalLength).toBeLessThanOrEqual(
        searchOperationCostsParams.limit
      )
      result.items.forEach((item) => {
        expect(item).toHaveProperty('projectId')
        expect(item).toHaveProperty('projectName')
        expect(item).toHaveProperty('projectContact')
        expect(item).toHaveProperty('projectStartDate')
        expect(item).toHaveProperty('projectEndDate')
        expect(item).toHaveProperty('note')
        expect(item).toHaveProperty('personnel')
        item.personnel.forEach((personnel) => {
          expect(personnel).toHaveProperty('companyId')
          expect(personnel).toHaveProperty('contractPatternCode')
          expect(personnel).toHaveProperty('companyName')
          expect(personnel).toHaveProperty('personnelId')
          expect(personnel).toHaveProperty('businessDays')
          expect(personnel).toHaveProperty('name')
          expect(personnel).toHaveProperty('nameJpn')
          expect(personnel).toHaveProperty('registeredDate')
          expect(personnel).toHaveProperty('unregisteredDate')
          expect(personnel).toHaveProperty('prices')
          personnel.prices
            ? personnel.prices.map((personnelPrice) => {
                expect(personnelPrice).toHaveProperty('contractPatternCode')
                expect(personnelPrice).toHaveProperty('priceStartDate')
                expect(personnelPrice).toHaveProperty('priceAmount')
                expect(personnelPrice).toHaveProperty('currencyTypeCode')
              })
            : []
          expect(personnel).toHaveProperty('operations')
          expect(personnel.operationPlans).toHaveProperty('2022-01-01', {
            manMonthNumber: 0.26,
            hoursNumber: 0.5,
          })
          expect(personnel.operations).toHaveProperty('2022-01-01', {
            costAmount: 0,
            hoursNumber: 0.3,
            operationId: 1,
          })
        })
      })
    })
    test('should return empty operation and operation plans when month_of_year_date are not exist', async () => {
      searchOperationCostsSpy.mockImplementation(() =>
        Promise.resolve({
          totalItems: 2,
          projects: projectsWithoutMonthOfYearDate,
        })
      )

      const result = await searchOperationCostsUseCase(
        searchOperationCostsParams.limit,
        searchOperationCostsParams.offset,
        searchOperationCostsParams.from,
        searchOperationCostsParams.to,
        searchOperationCostsParams.projectId,
        searchOperationCostsParams.companyId,
        repository
      )
      expect(repository.searchOperationCosts).toHaveBeenCalled()
      expect(result.items).toHaveLength(1)
      expect(result.totalLength).toBeLessThanOrEqual(
        searchOperationCostsParams.limit
      )
      result.items.forEach((item) => {
        expect(item).toHaveProperty('projectId')
        expect(item).toHaveProperty('projectName')
        expect(item).toHaveProperty('projectContact')
        expect(item).toHaveProperty('projectStartDate')
        expect(item).toHaveProperty('projectEndDate')
        expect(item).toHaveProperty('note')
        expect(item).toHaveProperty('personnel')
        item.personnel.forEach((personnel) => {
          expect(personnel).toHaveProperty('companyId')
          expect(personnel).toHaveProperty('contractPatternCode')
          expect(personnel).toHaveProperty('companyName')
          expect(personnel).toHaveProperty('businessDays')
          expect(personnel).toHaveProperty('personnelId')
          expect(personnel).toHaveProperty('name')
          expect(personnel).toHaveProperty('nameJpn')
          expect(personnel).toHaveProperty('registeredDate')
          expect(personnel).toHaveProperty('unregisteredDate')
          expect(personnel).toHaveProperty('prices')
          personnel.prices
            ? personnel.prices.map((personnelPrice) => {
                expect(personnelPrice).toHaveProperty('contractPatternCode')
                expect(personnelPrice).toHaveProperty('priceStartDate')
                expect(personnelPrice).toHaveProperty('priceAmount')
                expect(personnelPrice).toHaveProperty('currencyTypeCode')
              })
            : []
          expect(personnel).toHaveProperty('operations')
          expect(personnel.operationPlans).toEqual({})
          expect(personnel.operations).toEqual({})
        })
      })
    })
    test('should throw an error when any param validation fails', async () => {
      searchOperationCostsSpy.mockImplementation(() => Promise.reject('Error'))

      try {
        await searchOperationCostsUseCase(
          invalidSearchOperationCostsParams.limit,
          invalidSearchOperationCostsParams.offset,
          invalidSearchOperationCostsParams.from,
          invalidSearchOperationCostsParams.to,
          invalidSearchOperationCostsParams.projectId,
          invalidSearchOperationCostsParams.companyId,
          repository
        )
      } catch (error) {
        expect(error).toBeTruthy()
      }
    })

    test('should return empty list when data are not found', async () => {
      searchOperationCostsSpy.mockImplementation(() =>
        Promise.resolve({ projects: [], totalItems: 0 })
      )

      const result = await searchOperationCostsUseCase(
        searchOperationCostsParams.limit,
        searchOperationCostsParams.offset,
        searchOperationCostsParams.from,
        searchOperationCostsParams.to,
        searchOperationCostsParams.projectId,
        searchOperationCostsParams.companyId,
        repository
      )
      expect(repository.searchOperationCosts).toHaveBeenCalled()
      expect(result.items).toHaveLength(0)
    })

    test('should throw an error when searchOperationCosts throw error', async () => {
      searchOperationCostsSpy.mockImplementation(() => Promise.reject('Error'))

      try {
        await searchOperationCostsUseCase(
          searchOperationCostsParams.limit,
          searchOperationCostsParams.offset,
          searchOperationCostsParams.from,
          searchOperationCostsParams.to,
          searchOperationCostsParams.projectId,
          searchOperationCostsParams.companyId,
          repository
        )
      } catch (error) {
        expect(error).toBeTruthy()
      }
    })
  })
})
