import CustomError from '../../../../src/application/errors/CustomError'
import messages from '../../../../src/application/errors/messages'
import { OperationCostRepositoryPort } from '../../../../src/application/port/repositories/operationCost/OperationCostRepositoryPort'
import { deleteOperationCostsUseCase } from '../../../../src/application/use_cases/operationCost/deleteOperationCostsUseCase'
import { operationCosts } from '../../../fixtures/expected/operationCost/operationCosts.fixture'
import {
  builtOperationCostParams,
  deleteOperationCostsParams,
} from '../../../fixtures/inserts/operationCosts.fixture'

describe('deleteOperationCostsUseCase', () => {
  const repository = ({
    findMany: () => jest.fn(),
    deleteOperationCosts: () => jest.fn(),
  } as unknown) as Pick<
    OperationCostRepositoryPort,
    'findMany' | 'deleteOperationCosts'
  >
  let deleteSpy: jest.SpyInstance
  let findManySpy: jest.SpyInstance
  beforeEach(() => {
    findManySpy = jest.spyOn(repository, 'findMany').mockImplementation()
    deleteSpy = jest
      .spyOn(repository, 'deleteOperationCosts')
      .mockImplementation()
  })

  afterAll(() => {
    jest.resetAllMocks()
  })

  test('should deleteOperationsCost methods NOT triggered by default', () => {
    expect(repository.findMany).not.toHaveBeenCalled()
    expect(repository.deleteOperationCosts).not.toHaveBeenCalled()
  })

  describe('deleteOperationCostsUseCase is called', () => {
    test('should delete operation Cost if data is valid', async () => {
      findManySpy.mockImplementation(() => Promise.resolve(operationCosts))
      deleteSpy.mockImplementation(() => Promise.resolve([]))

      await deleteOperationCostsUseCase(deleteOperationCostsParams, repository)

      expect(repository.deleteOperationCosts).toHaveBeenCalled()
      expect(repository.deleteOperationCosts).toHaveBeenCalledWith(
        builtOperationCostParams
      )
    })

    test('should return error when params is empty', async () => {
      // When composite key are empty findMany return empty data
      jest
      findManySpy.mockImplementation(() => Promise.resolve([]))

      try {
        // the composite keys is not provided
        await deleteOperationCostsUseCase([], repository)
      } catch (error) {
        expect(error).toBeTruthy()
      }
    })

    test('should return error when composite keys not found in database', async () => {
      // id not found when findMany return empty data
      jest
      findManySpy.mockRejectedValue(
        () => new CustomError(messages.noForeignKeyMatched, 'Not Found')
      )

      try {
        await deleteOperationCostsUseCase(
          deleteOperationCostsParams,
          repository
        )
      } catch (error) {
        const err = error as CustomError
        expect(err).toBeTruthy()
        expect(err.message).toEqual(messages.noForeignKeyMatched)
      }
    })

    test('should throw an error when deleteOperationCosts throw an error', async () => {
      deleteSpy.mockImplementation(() => Promise.reject('Error'))
      try {
        await deleteOperationCostsUseCase([], repository)
      } catch (error) {
        expect(error).toBeTruthy()
      }
    })
  })
})
