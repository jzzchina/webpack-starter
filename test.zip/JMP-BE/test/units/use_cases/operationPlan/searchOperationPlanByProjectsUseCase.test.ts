import { OperationPlanRepositoryPort } from '../../../../src/application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { searchOperationPlanByProjectsUseCase } from '../../../../src/application/use_cases/operationPlan/searchOperationPlanByProjectsUseCase'
import { operationPlansFixture } from '../../../fixtures/expected/operationPlan/operationPlans.fixture'

describe('TEST searchOperationCostPlanByProjects UseCase', () => {
  const repository = {
    findOperationPlansByProject: () => jest.fn(),
  }

  let findOperationPlansByProjectSpy: jest.SpyInstance

  beforeEach(() => {
    findOperationPlansByProjectSpy = jest.spyOn(
      repository,
      'findOperationPlansByProject'
    )
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  const from = '2021-01-01'
  const to = '2023-12-01'
  const offset = 0
  const limit = 10
  const projectId = 1
  const companyId = 1
  const skills = {
    LeadDev: { level: 1 },
    'FrontEnd,Web(React)': { level: 2 },
    'BackEnd,Node.js': { level: 3 },
  }

  const operationPlanRepository = (repository as unknown) as OperationPlanRepositoryPort
  const findResult = operationPlansFixture.search.findResult
  test('should find operation Plans', async () => {
    // * Arrange
    findOperationPlansByProjectSpy.mockImplementation(() =>
      Promise.resolve(findResult)
    )

    // * Act
    const result = await searchOperationPlanByProjectsUseCase(
      to,
      from,
      offset,
      limit,
      projectId,
      companyId,
      skills,
      operationPlanRepository
    )

    // * Assert
    const expectedKeys = [
      'from',
      'to',
      'offset',
      'length',
      'totalLength',
      'items',
    ]
    const expectedItemsKeys = [
      'projectId',
      'projectName',
      'projectContact',
      'projectContact2',
      'projectContact3',
      'projectContact4',
      'projectStartDate',
      'projectEndDate',
      'note',
      'totals',
      'allPersonnelIds',
      'personnel',
    ]

    expect(findOperationPlansByProjectSpy).toHaveBeenCalledTimes(1)
    expect(Object.keys(result)).toEqual(expectedKeys)
    result.items.forEach((item) => {
      expect(Object.keys(item)).toEqual(expectedItemsKeys)
    })
  })
})
