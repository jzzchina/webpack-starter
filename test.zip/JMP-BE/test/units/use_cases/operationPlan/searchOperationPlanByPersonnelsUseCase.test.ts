import { OperationPlanRepositoryPort } from '../../../../src/application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { searchOperationPlanByPersonnelsUseCase } from '../../../../src/application/use_cases/operationPlan/searchOperationPlanByPersonnelsUseCase'
import { personnelsWithOperationPlans } from '../../../fixtures/expected/personnel/personnels.fixture'
import {
  invalidSearchOperationPlansParams,
  searchOperationPlansParams,
  skillList,
} from '../../../fixtures/inserts/operationPlans.fixture'

describe('SearchOperationPlanByPersonnelsUseCase', () => {
  const repository = ({
    findOperationPlansByPersonnel: () => jest.fn(),
  } as unknown) as Pick<
    OperationPlanRepositoryPort,
    'findOperationPlansByPersonnel'
  >
  let findOperationPlansByPersonnelSpy: jest.SpyInstance
  beforeEach(() => {
    findOperationPlansByPersonnelSpy = jest.spyOn(
      repository,
      'findOperationPlansByPersonnel'
    )
  })

  afterAll(() => {
    jest.resetAllMocks()
  })

  test('should findOperationPlansByPersonnel methods NOT be triggered by default', () => {
    expect(repository.findOperationPlansByPersonnel).not.toHaveBeenCalled()
  })

  test('should return personnel list when param is valid', async () => {
    findOperationPlansByPersonnelSpy.mockImplementation(() =>
      Promise.resolve({
        items: personnelsWithOperationPlans,
        totalItems: 2,
      })
    )

    const result = await searchOperationPlanByPersonnelsUseCase(
      searchOperationPlansParams.to,
      searchOperationPlansParams.from,
      searchOperationPlansParams.offset,
      searchOperationPlansParams.limit,
      searchOperationPlansParams.projectId,
      searchOperationPlansParams.companyId,
      skillList,
      repository
    )
    expect(repository.findOperationPlansByPersonnel).toHaveBeenCalled()
    expect(result.items).toHaveLength(2)
    expect(result.length).toBeLessThanOrEqual(searchOperationPlansParams.limit)
    result.items.forEach((item) => {
      expect(item).toHaveProperty('companyId')
      expect(item).toHaveProperty('contractPatternCode')
      expect(item).toHaveProperty('companyName')
      expect(item).toHaveProperty('personnelId')
      expect(item).toHaveProperty('name')
      expect(item).toHaveProperty('nameJpn')
      expect(item).toHaveProperty('registeredDate')
      expect(item).toHaveProperty('unregisteredDate')
      expect(item).toHaveProperty('skillList')
      expect(item).toHaveProperty('prices')
      expect(item).toHaveProperty('totals')
      expect(item).toHaveProperty('allProjectIds')
      expect(item).toHaveProperty('projects')
      expect(item).toHaveProperty('businessDays')
      expect(item.businessDays).toBeInstanceOf(Object)

      item.projects
        ? item.projects.forEach((project) => {
            expect(project).toHaveProperty('projectId')
            expect(project).toHaveProperty('projectName')
            expect(project).toHaveProperty('projectContact')
            expect(project).toHaveProperty('projectStartDate')
            expect(project).toHaveProperty('projectEndDate')
            expect(project).toHaveProperty('note')
            expect(project).toHaveProperty('roleId')
            expect(project).toHaveProperty('roleName')
            expect(project).toHaveProperty('operationPlans')
          })
        : null
    })
  })

  test('Should throw error when any param validation fails', async () => {
    findOperationPlansByPersonnelSpy.mockImplementation(() =>
      Promise.reject('Error')
    )

    try {
      await searchOperationPlanByPersonnelsUseCase(
        invalidSearchOperationPlansParams.to,
        invalidSearchOperationPlansParams.from,
        invalidSearchOperationPlansParams.offset,
        invalidSearchOperationPlansParams.limit,
        invalidSearchOperationPlansParams.projectId,
        invalidSearchOperationPlansParams.companyId,
        skillList,
        repository
      )
    } catch (error) {
      expect(error).toBeTruthy()
    }
  })

  test('should return empty list when personnels are not found', async () => {
    findOperationPlansByPersonnelSpy.mockImplementation(() =>
      Promise.resolve({ items: [], totalItems: 0 })
    )

    const result = await searchOperationPlanByPersonnelsUseCase(
      searchOperationPlansParams.to,
      searchOperationPlansParams.from,
      searchOperationPlansParams.offset,
      searchOperationPlansParams.limit,
      searchOperationPlansParams.projectId,
      searchOperationPlansParams.companyId,
      skillList,
      repository
    )
    expect(repository.findOperationPlansByPersonnel).toHaveBeenCalled()
    expect(result.items).toHaveLength(0)
  })

  test('should throw an error when findOperationPlansByPersonnel throws error', async () => {
    findOperationPlansByPersonnelSpy.mockImplementation(() =>
      Promise.reject('Error')
    )

    try {
      await searchOperationPlanByPersonnelsUseCase(
        searchOperationPlansParams.to,
        searchOperationPlansParams.from,
        searchOperationPlansParams.offset,
        searchOperationPlansParams.limit,
        searchOperationPlansParams.projectId,
        searchOperationPlansParams.companyId,
        skillList,
        repository
      )
    } catch (error) {
      expect(error).toBeTruthy()
    }
  })
})
