import CustomError from '../../../../src/application/errors/CustomError'
import messages from '../../../../src/application/errors/messages'
import { OperationCostRepositoryPort } from '../../../../src/application/port/repositories/operationCost/OperationCostRepositoryPort'
import { OperationPlanRepositoryPort } from '../../../../src/application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { deleteMultiOperationPlanUseCase } from '../../../../src/application/use_cases/operationPlan/deleteMultiOperationPlanUseCase'
import { operationPlans } from '../../../fixtures/expected/operationPlan/operationPlans.fixture'
import { deleteOperationPlansParams } from '../../../fixtures/inserts/operationPlans.fixture'

describe('deleteOperationPlansUseCase', () => {
  const operationPlanRepository = ({
    deleteOperationPlans: () => jest.fn(),
    findMany: () => jest.fn(),
  } as unknown) as Pick<
    OperationPlanRepositoryPort,
    'deleteOperationPlans' | 'findMany'
  >
  const operationCostRepository = ({
    findOperationBelongsToOperationPlan: () => jest.fn(),
  } as unknown) as Pick<
    OperationCostRepositoryPort,
    'findOperationBelongsToOperationPlan'
  >
  let deleteOperationPlansSpy: jest.SpyInstance
  let findManySpy: jest.SpyInstance
  let findOperationBelongsToOperationPlanSpy: jest.SpyInstance
  beforeEach(() => {
    findManySpy = jest.spyOn(operationPlanRepository, 'findMany')

    deleteOperationPlansSpy = jest.spyOn(
      operationPlanRepository,
      'deleteOperationPlans'
    )

    findOperationBelongsToOperationPlanSpy = jest.spyOn(
      operationCostRepository,
      'findOperationBelongsToOperationPlan'
    )
  })
  afterAll(() => {
    jest.resetAllMocks()
  })

  test('should deleteOperationsPlan and findMany methods are NOT triggered by default', () => {
    expect(operationPlanRepository.findMany).not.toHaveBeenCalled()
    expect(operationPlanRepository.deleteOperationPlans).not.toHaveBeenCalled()
    expect(
      operationCostRepository.findOperationBelongsToOperationPlan
    ).not.toHaveBeenCalled()
  })

  describe('deleteMultiOperationPlanUseCase is called', () => {
    test('should delete operation plan if data is valid', async () => {
      findManySpy.mockImplementation(() =>
        Promise.resolve([
          { ...operationPlans[0], hours_number: 0, man_month_number: 0 },
        ])
      )
      deleteOperationPlansSpy.mockImplementation(() => Promise.resolve([]))
      findOperationBelongsToOperationPlanSpy.mockImplementation(() =>
        Promise.resolve(false)
      )
      await deleteMultiOperationPlanUseCase(
        deleteOperationPlansParams,
        operationPlanRepository,
        operationCostRepository
      )

      expect(operationPlanRepository.deleteOperationPlans).toHaveBeenCalled()
      expect(operationPlanRepository.deleteOperationPlans).toHaveBeenCalledWith(
        deleteOperationPlansParams
      )
    })

    test('should return error when params is empty', async () => {
      // When composite key are empty findMany return empty data
      findManySpy.mockImplementation(() => Promise.resolve([]))

      try {
        // the composite keys is not provided
        await deleteMultiOperationPlanUseCase(
          [],
          operationPlanRepository,
          operationCostRepository
        )
      } catch (error) {
        expect(error).toBeTruthy()
      }
    })

    test('should return error when composite keys not found in database', async () => {
      // id not found when findMany return empty data
      findManySpy.mockImplementation(() => Promise.resolve([]))

      try {
        await deleteMultiOperationPlanUseCase(
          deleteOperationPlansParams,
          operationPlanRepository,
          operationCostRepository
        )
      } catch (error: unknown) {
        const expectedError = new CustomError(
          messages.recordsDoesNotExist,
          'Not Found'
        )
        expect(error).toEqual(expectedError)
      }
    })

    test('should throw an error when findMany throw an error', async () => {
      findManySpy.mockImplementation(() => Promise.reject('Error'))
      try {
        await deleteMultiOperationPlanUseCase(
          [],
          operationPlanRepository,
          operationCostRepository
        )
      } catch (error) {
        expect(error).toBeTruthy()
      }
    })

    test('should throw an error when deleteOperationPlans throw an error', async () => {
      deleteOperationPlansSpy.mockImplementation(() => Promise.reject('Error'))
      try {
        await deleteMultiOperationPlanUseCase(
          [],
          operationPlanRepository,
          operationCostRepository
        )
      } catch (error) {
        expect(error).toBeTruthy()
      }
    })

    test('should throw an error  if operation belong operationPlan', async () => {
      findManySpy.mockImplementation(() => Promise.resolve(operationPlans))
      deleteOperationPlansSpy.mockImplementation(() => Promise.resolve([]))

      findOperationBelongsToOperationPlanSpy.mockImplementation(() =>
        Promise.resolve(true)
      )
      try {
        await deleteMultiOperationPlanUseCase(
          deleteOperationPlansParams,
          operationPlanRepository,
          operationCostRepository
        )
        expect(operationPlanRepository.deleteOperationPlans).toHaveBeenCalled()
        expect(
          operationPlanRepository.deleteOperationPlans
        ).toHaveBeenCalledWith(deleteOperationPlansParams)
      } catch (error: unknown) {
        const expectedError = new CustomError(
          messages.operationPerformanceExist,
          'Method Not Allowed'
        )
        expect(error).toEqual(expectedError)
      }
    })
  })
})
