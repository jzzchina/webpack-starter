import { OperationPlanRepositoryPort } from '../../../../src/application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { createOperationPlanUseCase } from '../../../../src/application/use_cases/operationPlan/createOperationPlanUseCase'
import { CreateOperationPlanDto } from '../../../../src/interface/routes/operationPlan/dto/operationPlans.dto'
import {
  operationPlansCreate,
  operationPlansFindAllFixture,
  operationPlansUpdate,
} from '../../../fixtures/expected/operationPlan/operationPlans.fixture'
import {
  createOperationPlansParams,
  insertResult,
  updateOperationPlansParams,
  userInformation,
} from '../../../fixtures/inserts/operationPlans.fixture'

describe('CreateOperationPlansUseCase', () => {
  const repository = ({
    findMany: () => jest.fn(),
    create: () => jest.fn(),
    findAllOperationPlansByPersonnelId: () => jest.fn(),
  } as unknown) as Pick<
    OperationPlanRepositoryPort,
    'create' | 'findMany' | 'findAllOperationPlansByPersonnelId'
  >
  let createSpy: jest.SpyInstance
  let findManySpy: jest.SpyInstance
  let findAllOperationPlansByPersonnelIdSpy: jest.SpyInstance
  beforeEach(() => {
    createSpy = jest.spyOn(repository, 'create')
    findManySpy = jest.spyOn(repository, 'findMany').mockImplementation()
    findAllOperationPlansByPersonnelIdSpy = jest.spyOn(
      repository,
      'findAllOperationPlansByPersonnelId'
    )
  })

  afterAll(() => {
    jest.resetAllMocks()
  })

  test('should create, findMany methods NOT be triggered by default', () => {
    expect(repository.create).not.toHaveBeenCalled()
    expect(repository.findMany).not.toHaveBeenCalled()
  })

  describe('createOperationPlanUseCase is called', () => {
    test('should create new operation plan', async () => {
      createSpy.mockImplementation(() => Promise.resolve(insertResult))
      findManySpy.mockImplementation(() =>
        Promise.resolve(operationPlansCreate)
      )
      findAllOperationPlansByPersonnelIdSpy.mockImplementation(() =>
        Promise.resolve(operationPlansFindAllFixture)
      )
      const result = await createOperationPlanUseCase(
        createOperationPlansParams as CreateOperationPlanDto[],
        repository,
        userInformation
      )
      expect(repository.create).toHaveBeenCalled()
      expect(repository.findMany).toHaveBeenCalled()
      expect(result).toHaveLength(2)
      expect(result[0]).toHaveProperty('personnelId', 1)
      expect(result[0]).toHaveProperty('projectId', 1)
      expect(result[0]).toHaveProperty('manMonthNumber', 1)
      expect(result[0]).toHaveProperty('roleId', 1)
      expect(result[0]).toHaveProperty('hoursNumber', 2)
      expect(result[0]).toHaveProperty(
        'yearOfMonthDate',
        new Date('2022-01-01')
      )
      expect(result[1]).toHaveProperty('personnelId', 2)
      expect(result[1]).toHaveProperty('projectId', 1)
      expect(result[1]).toHaveProperty('manMonthNumber', 1)
      expect(result[1]).toHaveProperty('roleId', 1)
      expect(result[1]).toHaveProperty('hoursNumber', 2)
      expect(result[1]).toHaveProperty(
        'yearOfMonthDate',
        new Date('2022-01-01')
      )
    })

    test('should update an operation plan successfully', async () => {
      createSpy.mockImplementation(() => Promise.resolve(insertResult))
      findManySpy.mockImplementation(() =>
        Promise.resolve(operationPlansUpdate)
      )
      findAllOperationPlansByPersonnelIdSpy.mockImplementation(() =>
        Promise.resolve(operationPlansFindAllFixture)
      )
      const result = await createOperationPlanUseCase(
        updateOperationPlansParams as CreateOperationPlanDto[],
        repository,
        userInformation
      )
      expect(repository.create).toHaveBeenCalled()
      expect(repository.findMany).toHaveBeenCalled()
      expect(result).toHaveLength(1)
      expect(result[0]).toHaveProperty('personnelId', 1)
      expect(result[0]).toHaveProperty('projectId', 2)
      expect(result[0]).toHaveProperty('manMonthNumber', 1)
      expect(result[0]).toHaveProperty('roleId', 1)
      expect(result[0]).toHaveProperty('hoursNumber', 3)
      expect(result[0]).toHaveProperty(
        'yearOfMonthDate',
        new Date('2022-01-01')
      )
    })

    test('should throw error when param is empty', async () => {
      createSpy.mockImplementation(() => Promise.resolve({}))
      findManySpy.mockImplementation(() => Promise.resolve([]))

      try {
        await createOperationPlanUseCase([], repository, userInformation)
      } catch (error) {
        expect(error).toBeTruthy
      }
    })

    test('should throw an error when create throw an error', async () => {
      createSpy.mockImplementation(() => Promise.reject('Error'))
      try {
        await createOperationPlanUseCase([], repository, userInformation)
      } catch (error) {
        expect(error).toBeTruthy()
      }
    })

    test('should throw an error when findMany throw an error', async () => {
      findManySpy.mockImplementation(() => Promise.reject('Error'))
      try {
        await createOperationPlanUseCase([], repository, userInformation)
      } catch (error) {
        expect(error).toBeTruthy()
      }
    })
  })
})
