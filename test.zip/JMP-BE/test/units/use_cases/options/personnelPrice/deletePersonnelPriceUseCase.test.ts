import { PersonnelPriceRepositoryPort } from '../../../../../src/application/port/repositories/personnelPriceRepositoryPort.ts/PersonnelPriceRepositoryPort'
import { deletePersonnelPriceUseCase } from '../../../../../src/application/use_cases/options/personnelPrice/deletePersonnelPriceUseCase'

describe('TEST deletePersonnelPrice UseCase', () => {
  const repository = {
    delete: () => jest.fn(),
  }
  let deleteSpy: jest.SpyInstance

  beforeEach(() => {
    deleteSpy = jest.spyOn(repository, 'delete')
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  const personnelId = 1
  const priceStartDate = '2022-02-01'
  const personnelPriceRepo = (repository as unknown) as PersonnelPriceRepositoryPort

  test('should delete personnelPrice', async () => {
    // * Arrange
    deleteSpy.mockImplementation(() => Promise.resolve())

    // * Act
    const result = await deletePersonnelPriceUseCase(
      personnelId,
      priceStartDate,
      personnelPriceRepo
    )

    // * Assert
    expect(deleteSpy).toHaveBeenCalledTimes(1)
    expect(result).toBeUndefined()
  })
})
