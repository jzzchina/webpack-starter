const personnelPriceFixture = {
  findAll: {
    data: [
      {
        updated_by: null,
        update_at: null,
        process_id: null,
        contract_pattern_code: 0,
        price_start_date: '2022-02-01',
        price_amount: '100000.00',
        currency_type_code: 0,
        dw_m_personnel: {
          name_jpn: 'テスト４',
          unregistered_date: null,
          updated_by: null,
          update_at: '2022-10-07T22:07:00.000Z',
          process_id: null,
          personnel_id: 5,
          name: 'test4',
          registered_date: '2022-01-01',
          skill_list: {},
          created_by: 'Unit Test',
          create_at: '2022-10-07T22:07:00.000Z',
          process_at: '2022-10-07T22:07:00.000Z',
        },
      },
    ],
  },
  create: {
    createData: [
      {
        personnelId: 1,
        priceStartDate: new Date('2022-02-01'),
        priceAmount: 5625,
        currencyTypeCode: 0,
        contractPatternCode: 0,
      },
    ],
    creationResult: {
      identifiers: [
        { price_start_date: new Date('2022-02-01'), dw_m_personnel: 1 },
      ],
      generatedMaps: [{}],
      raw: {
        fieldCount: 0,
        affectedRows: 1,
        insertId: 0,
        info: '',
        serverStatus: 2,
        warningStatus: 3,
      },
    },
    findManyResult: [
      {
        updated_by: null,
        update_at: null,
        process_id: null,
        contract_pattern_code: 0,
        price_start_date: '2022-01-01',
        price_amount: '5625.00',
        currency_type_code: 0,
        dw_m_personnel: {
          name_jpn: 'テスト１',
          unregistered_date: '2022-05-01',
          updated_by: null,
          update_at: new Date(),
          process_id: null,
          personnel_id: 1,
          name: 'test 1',
          registered_date: '2022-01-01',
          skill_list: [Object],
          created_by: 'Unit Test',
          create_at: new Date(),
          process_at: new Date(),
        },
      },
    ],
    userInformation: {
      name: 'Test Name',
      roles: 'Test Role',
    },
  },
}

export default personnelPriceFixture
