import { PersonnelPriceRepositoryPort } from '../../../../../src/application/port/repositories/personnelPriceRepositoryPort.ts/PersonnelPriceRepositoryPort'
import { findByPersonnelIDUseCase } from '../../../../../src/application/use_cases/options/personnelPrice/findByPersonnelIDUseCase'
import fixture from './personnelPrice.fixture'

describe('TEST findPersonnelPriceByPersonnelID UseCase', () => {
  const repository = {
    findByPersonnelID: () => jest.fn(),
  }
  let findByPersonnelIDSpy: jest.SpyInstance

  beforeEach(() => {
    findByPersonnelIDSpy = jest.spyOn(repository, 'findByPersonnelID')
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  const foundPersonnelPrices = fixture.findAll.data
  const personnelPriceRepo = (repository as unknown) as PersonnelPriceRepositoryPort
  const personnelID = 1

  test('should return Personnel Prices', async () => {
    // * Arrange
    findByPersonnelIDSpy.mockImplementation(() =>
      Promise.resolve(foundPersonnelPrices)
    )

    // * Act
    const result = await findByPersonnelIDUseCase(
      personnelID,
      personnelPriceRepo
    )

    // * Assert
    const expectedItems = [
      'personnelId',
      'contractPatternCode',
      'currencyTypeCode',
      'priceAmount',
      'priceStartDate',
    ]

    expect(findByPersonnelIDSpy).toHaveBeenCalledTimes(1)
    expect(result).toHaveProperty('items')
    result.items.forEach((item) => {
      expectedItems.forEach((field) => {
        expect(item).toHaveProperty(field)
      })
    })
  })

  test('should return Personnel Prices without personnelID', async () => {
    // * Arrange
    const foundPersonnelPricesWithoutPersonnelID = foundPersonnelPrices.map(
      (item) => {
        return {
          ...item,
          personnelID: undefined,
        }
      }
    )

    findByPersonnelIDSpy.mockImplementation(
      () => foundPersonnelPricesWithoutPersonnelID
    )

    // * Act
    const result = await findByPersonnelIDUseCase(
      personnelID,
      personnelPriceRepo
    )

    // * Assert
    const expectedItems = [
      'contractPatternCode',
      'currencyTypeCode',
      'priceAmount',
      'priceStartDate',
    ]

    expect(findByPersonnelIDSpy).toHaveBeenCalledTimes(1)
    expect(result).toHaveProperty('items')
    result.items.forEach((item) => {
      expectedItems.forEach((field) => {
        expect(item).toHaveProperty(field)
      })
    })
  })
})
