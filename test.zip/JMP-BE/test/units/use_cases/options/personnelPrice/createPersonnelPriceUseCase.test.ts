import { InsertResult } from 'typeorm'
import { PersonnelPriceRepositoryPort } from '../../../../../src/application/port/repositories/personnelPriceRepositoryPort.ts/PersonnelPriceRepositoryPort'
import { createPersonnelPriceUseCase } from '../../../../../src/application/use_cases/options/personnelPrice/createPersonnelPriceUseCase'
import { PersonnelPrice } from '../../../../../src/domain/models/PersonnelPrice'
import fixture from './personnelPrice.fixture'
import { OperationCostRepositoryPort } from '../../../../../src/application/port/repositories/operationCost/OperationCostRepositoryPort'
import { updateOperationCost } from '../../../../../src/application/helpers/personnelPrice.helpers'
import { Dw_m_personnel_price } from '../../../../../src/infrastructure/orm/typeorm/entities/Dw_m_personnel_price'
import dateUtils from '../../../../../src/infrastructure/repositories/utils/dateUtils'

describe('TEST createPersonnelPrice UseCase', () => {
  const repository = {
    createPersonnelPrice: () => jest.fn(),
    findMany: () => jest.fn(),
  }
  const operationCostPlanRepository = ({
    updateCostAmountByPersonnelAndDate: () => jest.fn(),
  } as unknown) as OperationCostRepositoryPort

  let createPersonnelPriceSpy: jest.SpyInstance
  let findManySpy: jest.SpyInstance
  let updateCostAmountByPersonnelAndDateSpy: jest.SpyInstance

  beforeEach(() => {
    createPersonnelPriceSpy = jest.spyOn(repository, 'createPersonnelPrice')
    findManySpy = jest.spyOn(repository, 'findMany')
    updateCostAmountByPersonnelAndDateSpy = jest.spyOn(
      operationCostPlanRepository,
      'updateCostAmountByPersonnelAndDate'
    )
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  const personnelPriceRepo = (repository as unknown) as PersonnelPriceRepositoryPort
  const userInfo = fixture.create.userInformation

  const personnelPriceList: Partial<PersonnelPrice>[] =
    fixture.create.createData
  const creationResult: InsertResult = fixture.create.creationResult
  const findManyResult = fixture.create.findManyResult

  test('should create new Personnel Prices', async () => {
    // * Arrange
    createPersonnelPriceSpy.mockImplementation(() => creationResult)
    findManySpy.mockImplementation(() => findManyResult)
    updateCostAmountByPersonnelAndDateSpy.mockImplementation(() =>
      Promise.resolve()
    )
    // * Act
    const result = await createPersonnelPriceUseCase(
      personnelPriceList as PersonnelPrice[],
      userInfo,
      personnelPriceRepo,
      operationCostPlanRepository
    )

    // * Assert
    const expectedItems = [
      'personnelId',
      'contractPatternCode',
      'currencyTypeCode',
      'priceAmount',
      'priceStartDate',
    ]

    expect(createPersonnelPriceSpy).toHaveBeenCalledTimes(1)
    expect(findManySpy).toHaveBeenCalledTimes(1)

    expect(result).toHaveLength(personnelPriceList.length)
    result.forEach((item) => {
      expectedItems.forEach((field) => {
        expect(item).toHaveProperty(field)
      })
    })
  })

  it('should call updateCostAmountByPersonnelAndDate with correct arguments', async () => {
    // Arrange
    const mockPersonnelPrices = [
      {
        dw_m_personnel: 1 as number,
        price_start_date: new Date('2021-01-01'),
        price_amount: 100,
      },
    ]

    const mockOperationCostRepository = {
      updateCostAmountByPersonnelAndDate: jest.fn(),
    }

    // Act
    await updateOperationCost(
      (mockPersonnelPrices as unknown) as Partial<Dw_m_personnel_price>[],
      mockOperationCostRepository
    )
    const mockPersonnel = mockPersonnelPrices[0].dw_m_personnel as number
    // Assert
    expect(
      mockOperationCostRepository.updateCostAmountByPersonnelAndDate
    ).toHaveBeenCalledWith(
      mockPersonnel,
      dateUtils.extractDateFromDateTime(
        mockPersonnelPrices[0].price_start_date
      ),
      mockPersonnelPrices[0].price_amount
    )
  })
})
