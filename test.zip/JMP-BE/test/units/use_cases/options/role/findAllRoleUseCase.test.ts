import { RoleRepositoryPort } from '../../../../../src/application/port/repositories/role/RoleRepositoryPort'
import { findAllRolesUseCase } from '../../../../../src/application/use_cases/options/role/findAllRoleUseCase'
import { Dw_m_role } from '../../../../../src/infrastructure/orm/typeorm/entities/Dw_m_role'
import { roles } from '../../../../fixtures/expected/options/role/roles.fixture'

describe('findAllRoleUseCase', () => {
  const repository = ({
    findAll: () => jest.fn(),
  } as unknown) as Pick<RoleRepositoryPort, 'findAll'>
  let findAllSpy: jest.SpyInstance
  beforeEach(() => {
    findAllSpy = jest.spyOn(repository, 'findAll')
  })

  afterAll(() => {
    jest.resetAllMocks()
  })

  test('should findAll method is NOT triggered by default', () => {
    expect(repository.findAll).not.toHaveBeenCalled()
  })

  describe('findAllRolesUseCase is called', () => {
    test('should findAll method is triggered', async () => {
      findAllSpy.mockImplementation(() =>
        Promise.resolve(buildRolesOrderByName([]))
      )
      await findAllRolesUseCase(repository)

      expect(repository.findAll).toHaveBeenCalled()
    })

    test('should return empty roles if data is empty', async () => {
      findAllSpy.mockImplementation(() =>
        Promise.resolve(buildRolesOrderByName([]))
      )
      const results = await findAllRolesUseCase(repository)

      expect(results.items?.length).toEqual(0)
      expect(results.items).toEqual([])
    })

    test('should return roles when data is existed', async () => {
      findAllSpy.mockImplementation(() =>
        Promise.resolve(buildRolesOrderByName(roles))
      )
      const results = await findAllRolesUseCase(repository)

      expect(results.items?.length).toEqual(2)
      // Should re-order role name by ASC
      expect(results.items).toEqual([
        { roleId: 2, roleName: 'Admin' },
        { roleId: 1, roleName: 'Dev' },
      ])
    })

    test('should throw an error when an issue occurred', async () => {
      findAllSpy.mockImplementation(() => Promise.reject('error'))

      try {
        await findAllRolesUseCase(repository)
      } catch (error) {
        expect(error).toBeTruthy()
      }
    })

    function buildRolesOrderByName(roles?: Dw_m_role[]): Dw_m_role[] {
      if (!roles?.length) {
        return []
      }

      return roles.sort((a, b) => {
        return a.role_name > b.role_name ? 1 : -1
      })
    }
  })
})
