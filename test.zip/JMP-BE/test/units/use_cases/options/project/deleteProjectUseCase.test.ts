import { ProjectRepositoryPort } from '../../../../../src/application/port/repositories/project/ProjectRepositoryPort'
import { deleteProjectsUseCase } from '../../../../../src/application/use_cases/options/project/deleteProjectsUseCase'

describe('TEST - deleteProjectsUseCase', () => {
  const repository = ({
    deleteProjects: () => jest.fn(),
  } as unknown) as ProjectRepositoryPort

  let deleteSpy: jest.SpyInstance

  beforeEach(() => {
    deleteSpy = jest.spyOn(repository, 'deleteProjects')
  })

  afterEach(() => {
    jest.resetAllMocks()
  })
  const projectsIds: number[] = [1]

  test('Should delete projects', async () => {
    // * Arrange
    deleteSpy.mockImplementation(() => Promise.resolve(true))

    // * Act
    await deleteProjectsUseCase(projectsIds, repository)

    // * Assert
    expect(deleteSpy).toHaveBeenCalledTimes(1)
    expect(deleteSpy).toHaveBeenCalledWith(projectsIds)
  })

  test('Should throw error if project id doesnt exist', async () => {
    // * Arrange
    deleteSpy.mockImplementation(() => Promise.resolve(true))

    try {
      // * Act
      await deleteProjectsUseCase(projectsIds, repository)
    } catch (error) {
      // * Assert
      expect(error).toBeDefined()
      expect(deleteSpy).toHaveBeenCalledTimes(0)
    }
  })
})
