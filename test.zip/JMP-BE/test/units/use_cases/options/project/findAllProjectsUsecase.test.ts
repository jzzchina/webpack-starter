import { matchers } from 'jest-joi'
expect.extend(matchers)

import { ProjectRepositoryPort } from '../../../../../src/application/port/repositories/project/ProjectRepositoryPort'
import { findAllProjectsUseCase } from '../../../../../src/application/use_cases/options/project/findAllProjectsUseCase'
import {
  Project,
  ProjectListResponse,
} from '../../../../../src/interface/routes/options/project/dto/projects.dto'
import { projectValidator } from '../../../../../src/middlewares/validators/projectValidator'
import { OperationCostRepositoryPort } from '../../../../../src/application/port/repositories/operationCost/OperationCostRepositoryPort'

import fixture from './project.fixture'

describe('TEST - findAllProjectUseCase', () => {
  const repository = ({
    findAll: () => jest.fn(),
  } as unknown) as ProjectRepositoryPort
  const repository2 = ({
    searchOperationCostsByProjectId: () => jest.fn(),
  } as unknown) as OperationCostRepositoryPort

  // * Assert
  const expectedItems = [
    'projectId',
    'projectName',
    'status',
    'projectStartDate',
    'projectEndDate',
    'projectManager',
    'projectContact',
    'userPart',
    'note',
  ]

  let findAllSpy: jest.SpyInstance

  beforeEach(() => {
    findAllSpy = jest.spyOn(repository, 'findAll')
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  const foundProjects = fixture.findAll.foundProjects
  const foundProjectsExcludedStatueNumberFive =
    fixture.findAll.foundProjectsExcludedStatueNumberFive

  test('should return list of projects', async () => {
    const queryParams = fixture.findAll.queryParamatersTest1
    // * Arrange
    findAllSpy.mockImplementation(() => Promise.resolve(foundProjects))

    // * Act
    const result: Partial<ProjectListResponse> = await findAllProjectsUseCase(
      repository,
      repository2,
      queryParams
    )

    expect(findAllSpy).toHaveBeenCalledTimes(1)
    expect(result).toHaveProperty('items')
    expect(result).toHaveProperty('length', 50)
    expect(result).toHaveProperty('offset', 0)
    expect(result).toHaveProperty('totalLength', 2)
    result.items?.forEach((item: Project) => {
      expectedItems.forEach((field: string) => {
        expect(item).toHaveProperty(field)
      })
    })
    if (result.items) expect(result.items[1]).toHaveProperty('status', 5)
  })
  test('should return projects with undefined fields（limit, offset）', async () => {
    const queryParams = fixture.findAll.queryParamatersTest2
    // * Arrange
    findAllSpy.mockImplementation(() =>
      Promise.resolve(foundProjectsExcludedStatueNumberFive)
    )

    // * Act
    const result: Partial<ProjectListResponse> = await findAllProjectsUseCase(
      repository,
      repository2,
      queryParams
    )

    expect(findAllSpy).toHaveBeenCalledTimes(1)
    expect(result).toHaveProperty('items')
    expect(result).toHaveProperty('length', 2)
    expect(result).toHaveProperty('offset', 0)
    expect(result).toHaveProperty('totalLength', 2)

    result.items?.forEach((item) => {
      expectedItems.forEach((field) => {
        expect(item).toHaveProperty(field)
        expect(item.status).not.toBe(5)
      })
    })
  })

  test('should pass the validation and call api', () => {
    const query = fixture.findAll.queryParamatersTest3
    const options = {
      allowUnknown: false,
    }

    // All Query Parameter Check.
    expect(query).toMatchSchema(
      projectValidator.getProjectsQueryValidator,
      options
    )

    // offset, limit Undefined Check.
    const queryUndefinedLimitOffset = {
      query: {
        offset: undefined,
        limit: undefined,
      },
    }
    expect(queryUndefinedLimitOffset).toMatchSchema(
      projectValidator.getProjectsQueryValidator,
      options
    )

    // query minimum value status Check.
    const queryMinimumValueStatus = {
      query: {
        status: 0,
      },
    }
    expect(queryMinimumValueStatus).toMatchSchema(
      projectValidator.getProjectsQueryValidator,
      options
    )

    // query maximum value status Check.
    const queryMaximumValueStatus = {
      query: {
        status: 7,
      },
    }
    expect(queryMaximumValueStatus).toMatchSchema(
      projectValidator.getProjectsQueryValidator,
      options
    )
  })
})
