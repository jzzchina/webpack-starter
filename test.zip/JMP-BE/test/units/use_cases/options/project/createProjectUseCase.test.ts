import { ProjectRepositoryPort } from '../../../../../src/application/port/repositories/project/ProjectRepositoryPort'
import { WbsRepositoryPort } from '../../../../../src/application/port/repositories/wbs/wbsRepositoryPort'
import { createProjectsUseCase } from '../../../../../src/application/use_cases/options/project/createProjectsUseCase'
import { ProjectDtoResponse } from '../../../../../src/interface/routes/options/project/dto/projects.dto'
import fixture from './project.fixture'

describe('TEST - createProjectsUseCase', () => {
  const repository = ({
    createProjects: () => jest.fn(),
  } as unknown) as ProjectRepositoryPort
  const wbsRepository = ({
    createWbs: () => jest.fn(),
  } as unknown) as WbsRepositoryPort
  let createProjectsSpy: jest.SpyInstance
  let createWbsSpy: jest.SpyInstance

  beforeEach(() => {
    createProjectsSpy = jest.spyOn(repository, 'createProjects')
    createWbsSpy = jest.spyOn(wbsRepository, 'createWbs')
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  const userName = 'Test User'
  const createProjectDtoList = fixture.create
    .createProjectDtoList as ProjectDtoResponse[]
  const createWbsProjectFixture = fixture.create.wbsProjectFixture

  it('Should create new projects successfully', async () => {
    // * Arrange
    const createdProjects = fixture.create.createdProjects
    createProjectsSpy.mockImplementation(() => createdProjects)
    createWbsSpy.mockImplementation(() => createWbsProjectFixture)

    createWbsProjectFixture.forEach((project) => {
      expect(project.subject).toMatch(/^(CAPEX|OPEX)$/)
    })
    // * Act
    const result = await createProjectsUseCase(
      userName,
      createProjectDtoList,
      repository,
      wbsRepository
    )

    // * Assert
    const expectedFields = [
      'projectId',
      'projectName',
      'projectContact',
      'projectStartDate',
      'projectEndDate',
      'note',
      'createdBy',
      'createdAt',
      'updatedBy',
      'updateAt',
      'processAt',
      'processId',
    ]

    expect(result).toHaveLength(fixture.create.createdProjects.length)
    result.forEach((item) => {
      expectedFields.forEach((field) => {
        expect(item).toHaveProperty(field)
      })
    })
  })
})
