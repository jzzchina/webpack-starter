import { PersonnelRepositoryPort } from '../../../../../src/application/port/repositories/personnel/PersonnelRepositoryPort'
import fixture from './personnel.fixture'
import { OperationPlanRepositoryPort } from '../../../../../src/application/port/repositories/operationPlan/OperationPlanRepositoryPort'
import { OperationCostRepositoryPort } from '../../../../../src/application/port/repositories/operationCost/OperationCostRepositoryPort'
import { searchExistenceOfOperationUseCase } from '../../../../../src/application/use_cases/options/personnel/searchExistenceOfOperationUseCase'
import { SearchExistenceOfOperationResponse } from '../../../../../src/interface/routes/options/personnel/dto/personnel.dto'

describe('TEST - Find all operations by personnel', () => {
  const personnelRepositoryMock = {
    findOneById: () => jest.fn(),
  }
  const operationPlanRepositoryMock = {
    findOperationPlansByPersonnelId: () => jest.fn(),
  }
  const operationConstRepositoryMock = {
    searchOperationCostsByPersonnelId: () => jest.fn(),
  }

  const personnelRepository = (personnelRepositoryMock as unknown) as PersonnelRepositoryPort
  const operationPlanRepository = (operationPlanRepositoryMock as unknown) as OperationPlanRepositoryPort
  const operationCostRepository = (operationConstRepositoryMock as unknown) as OperationCostRepositoryPort

  let findOneByIdSpy: jest.SpyInstance
  let findOperationPlansByPersonnelIdSpy: jest.SpyInstance
  let searchOperationCostsByPersonnelIdSpy: jest.SpyInstance

  beforeEach(() => {
    findOneByIdSpy = jest.spyOn(personnelRepository, 'findOneById')
    findOperationPlansByPersonnelIdSpy = jest.spyOn(
      operationPlanRepository,
      'findOperationPlansByPersonnelId'
    )
    searchOperationCostsByPersonnelIdSpy = jest.spyOn(
      operationCostRepository,
      'searchOperationCostsByPersonnelId'
    )
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  test('Receive an basic result', async () => {
    // * Arrange
    const searchCriteria = fixture.searchExistenceOfOperation.searchCriteria
    const findResult = fixture.findAll.findResult
    findOneByIdSpy.mockResolvedValue(findResult)

    // * Act
    const response: SearchExistenceOfOperationResponse = await searchExistenceOfOperationUseCase(
      searchCriteria.to,
      searchCriteria.from,
      searchCriteria.personnelId,
      personnelRepository,
      operationPlanRepository,
      operationCostRepository
    )

    // * Assert
    expect(findOneByIdSpy).toHaveBeenCalledTimes(1)
    // * Check response fields
    expect(response).toHaveProperty('operationPlan')
    expect(response).toHaveProperty('operation')
  })

  test('Receive an basic result with Operation Plan and Operation Cost', async () => {
    // * Arrange
    const searchCriteria = fixture.searchExistenceOfOperation.searchCriteria
    const findResult = fixture.findAll.findResult
    findOneByIdSpy.mockResolvedValue(findResult)
    findOperationPlansByPersonnelIdSpy.mockResolvedValue(
      fixture.searchExistenceOfOperation.operationPlanResponse
    )
    searchOperationCostsByPersonnelIdSpy.mockResolvedValue(
      fixture.searchExistenceOfOperation.operationCostResponse
    )

    // * Act
    const response: SearchExistenceOfOperationResponse = await searchExistenceOfOperationUseCase(
      searchCriteria.to,
      searchCriteria.from,
      searchCriteria.personnelId,
      personnelRepository,
      operationPlanRepository,
      operationCostRepository
    )

    // * Assert
    expect(findOneByIdSpy).toHaveBeenCalledTimes(1)
    expect(findOperationPlansByPersonnelIdSpy).toHaveBeenCalledTimes(1)
    // * Check response fields
    expect(response.operationPlan).toBeTruthy()
    expect(response.operation).toBeTruthy()
  })

  test('Receive an basic result with Operation Plan only', async () => {
    // * Arrange
    const searchCriteria = fixture.searchExistenceOfOperation.searchCriteria
    const findResult = fixture.findAll.findResult
    findOneByIdSpy.mockResolvedValue(findResult)
    findOperationPlansByPersonnelIdSpy.mockResolvedValue(
      fixture.searchExistenceOfOperation.operationPlanResponse
    )
    searchOperationCostsByPersonnelIdSpy.mockResolvedValue([])

    // * Act
    const response: SearchExistenceOfOperationResponse = await searchExistenceOfOperationUseCase(
      searchCriteria.to,
      searchCriteria.from,
      searchCriteria.personnelId,
      personnelRepository,
      operationPlanRepository,
      operationCostRepository
    )

    // * Assert
    expect(findOneByIdSpy).toHaveBeenCalledTimes(1)
    expect(findOperationPlansByPersonnelIdSpy).toHaveBeenCalledTimes(1)
    // * Check response fields
    expect(response.operationPlan).toBeTruthy()
    expect(response.operation).toBeFalsy()
  })
})
