import CustomError from '../../../../../src/application/errors/CustomError'
import messages from '../../../../../src/application/errors/messages'
import { PersonnelRepositoryPort } from '../../../../../src/application/port/repositories/personnel/PersonnelRepositoryPort'
import { deletePersonnelsUseCase } from '../../../../../src/application/use_cases/options/personnel/deletePersonnelsUseCase'

describe('TEST deletePersonnels UseCase', () => {
  const repository = {
    deletePersonnels: () => jest.fn(),
    findPersonnelByAssignment: () => jest.fn(),
  }
  let deletePersonnelSpy: jest.SpyInstance
  let findPersonnelByAssignment: jest.SpyInstance

  beforeEach(() => {
    deletePersonnelSpy = jest.spyOn(repository, 'deletePersonnels')
    findPersonnelByAssignment = jest.spyOn(
      repository,
      'findPersonnelByAssignment'
    )
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  const personnelIds = [1, 2, 3]

  test('should delete personnel', async () => {
    // * Arrange
    deletePersonnelSpy.mockImplementation(undefined)
    findPersonnelByAssignment.mockImplementation(() => Promise.resolve(0))

    // * Act
    const result = await deletePersonnelsUseCase(
      personnelIds,
      (repository as unknown) as PersonnelRepositoryPort
    )
    // * Assert
    expect(deletePersonnelSpy).toHaveBeenCalledTimes(1)
    expect(deletePersonnelSpy).toHaveBeenCalledWith(personnelIds)
    expect(result).toBeUndefined()
  })
  test('should  throw 400 Bad Request when personnel are assigned to project(s)', async () => {
    // * Arrange
    findPersonnelByAssignment.mockImplementation(() => Promise.resolve(1))

    // * Act
    try {
      await deletePersonnelsUseCase(
        personnelIds,
        (repository as unknown) as PersonnelRepositoryPort
      )
    } catch (error) {
      const err = error as Error
      // * Assert
      expect(err).toEqual(
        new CustomError(messages.personnelIsAssigned, 'Method Not Allowed')
      )
    }
  })
})
