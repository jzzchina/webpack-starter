import { PersonnelRepositoryPort } from '../../../../../src/application/port/repositories/personnel/PersonnelRepositoryPort'
import { findAllPersonnelUseCase } from '../../../../../src/application/use_cases/options/personnel/findAllPersonnelsUseCase'
import { PaginatedPersonnelList } from '../../../../../src/domain/models/Personnel'
import fixture from './personnel.fixture'

describe('TEST - Find all personnel use case', () => {
  const repositoryMock = {
    findAll: () => jest.fn(),
  }

  const repository = (repositoryMock as unknown) as PersonnelRepositoryPort

  let findAllSpy: jest.SpyInstance

  beforeEach(() => {
    findAllSpy = jest.spyOn(repository, 'findAll')
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  test('Find all personnel use case with search criteria', async () => {
    // * Arrange
    const searchCriteria = fixture.findAll.searchCriteriaWithPagination
    const findResult = fixture.findAll.findResult
    findAllSpy.mockResolvedValue(findResult)

    // * Act
    const response: PaginatedPersonnelList = await findAllPersonnelUseCase(
      searchCriteria,
      repository
    )

    // * Assert
    const expectedResponseFields = ['offset', 'length', 'totalLength', 'items']
    expect(findAllSpy).toHaveBeenCalledTimes(1)
    expect(findAllSpy).toHaveBeenCalledWith(searchCriteria)
    // * Check response fields
    expectedResponseFields.forEach((field) => {
      expect(response).toHaveProperty(field)
    })
  })
  test('should find all personnel with includes closed assigned project ', async () => {
    // * Arrange
    const searchCriteria =
      fixture.findAll.searchCriteriaWithPaginationWithIncludesClosedProject
    const findResult = fixture.findAll.findResultWithClosedProjects
    findAllSpy.mockResolvedValue(findResult)

    // * Act
    const response: PaginatedPersonnelList = await findAllPersonnelUseCase(
      searchCriteria,
      repository
    )

    // * Assert
    const expectedResponseFields = ['offset', 'length', 'totalLength', 'items']
    expect(findAllSpy).toHaveBeenCalledTimes(1)
    expect(findAllSpy).toHaveBeenCalledWith(searchCriteria)
    // * Check response fields
    expectedResponseFields.forEach((field) => {
      expect(response).toHaveProperty(field)
    })
    response.items.forEach((item) => {
      expect(item).toHaveProperty('allAssignedProjects')
      expect(item.allAssignedProjects).toBeInstanceOf(Array)
      expect(item.allAssignedProjects?.length).toEqual(3)
      expect(item.allAssignedProjects).toEqual([
        'Unit Test Project Name',
        'Unit Test Project Name 2',
        'Unit Test Project Name 3',
      ])
    })
  })
  test('Find all personnel use case without search criteria', async () => {
    // * Arrange
    const searchCriteria = fixture.findAll.searchCriteriaWithoutPagination
    const findResult = fixture.findAll.findResult
    findAllSpy.mockResolvedValue(findResult)

    // * Act
    const response: PaginatedPersonnelList = await findAllPersonnelUseCase(
      searchCriteria,
      repository
    )

    // * Assert
    const expectedResponseFields = ['offset', 'length', 'totalLength', 'items']
    expect(findAllSpy).toHaveBeenCalledTimes(1)
    expect(findAllSpy).toHaveBeenCalledWith(searchCriteria)
    // * Check response fields
    expectedResponseFields.forEach((field) => {
      expect(response).toHaveProperty(field)
    })
    response.items.forEach((item) => {
      expect(item).toHaveProperty('allAssignedProjects')
      expect(item.allAssignedProjects).toBeInstanceOf(Array)
      expect(item.allAssignedProjects?.length).toEqual(2)
      expect(item.allAssignedProjects).toEqual([
        'Unit Test Project Name',
        'Unit Test Project Name 2',
      ])
    })
  })
})
