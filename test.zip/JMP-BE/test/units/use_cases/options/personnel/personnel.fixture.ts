const personnelFixture = {
  create: {
    personnelList: [
      {
        personnelId: 1,
        name: 'Test User',
        nameJpn: 'テストユーザー',
        email: 'jeraUser@mail.com',
        registeredDate: '2022-01-01',
        unregisteredDate: '2022-01-02',
        skillList: {
          LeadDev: {
            level: 1,
          },
          'FrontEnd,Web(React)': {
            level: 2,
          },
          'BackEnd,Node.js': {
            level: 3,
          },
        },
        companyId: 1234,
      },
    ],
    insertResult: [
      {
        personnel_id: 1,
        name: 'Test User',
        name_jpn: 'テストユーザー',
        email: 'jeraUser@mail.com',
        registered_date: '2022-01-01',
        unregistered_date: null,
        skill_list: {
          LeadDev: { level: 1 },
          'FrontEnd,Web(React)': { level: 2 },
          'BackEnd,Node.js': { level: 3 },
        },
        dw_m_partner_company: 1,
        created_by: 'Unit Test',
        updated_by: 'Unit Test',
        update_at: '2023-02-13T21:48:01.507Z',
        process_id: null,
        create_at: '2023-02-13T21:48:01.507Z',
        process_at: '2023-02-13T21:48:01.507Z',
      },
    ],
    foundResult: [
      {
        name_jpn: '見本 太郎',
        unregistered_date: null,
        updated_by: null,
        update_at: null,
        process_id: null,
        personnel_id: 128,
        name: 'Test Personnel',
        registered_date: '2022-01-01',
        skill_list: {
          LeadDev: { level: 1 },
          'BackEnd,Node.js': { level: 3 },
          'FrontEnd,Web(React)': { level: 2 },
        },
        dw_m_partner_company: {
          updated_by: null,
          update_at: null,
          process_id: null,
          company_id: 1,
          company_name: 'Company 1',
          contract_pattern_code: 1,
        },
        dw_m_personnel_price: [],
      },
    ],
    userInformation: {
      name: 'Test Name',
      roles: 'Test Role',
    },
  },

  findAll: {
    searchCriteriaWithPagination: {
      limit: 100,
      offset: 0,
      personnel_id: 2,
      name: '3',
      name_jpn: 'テスト',
      project_id: 112,
      company_id: 1,
      search_name: 'test41 テスト８',
      skills: {
        LeadDev: { level: 1 },
        'FrontEnd,Web(React)': { level: 2 },
        'BackEnd,Node.js': { level: 3 },
      },
      include_status_closed: false,
    },
    searchCriteriaWithPaginationWithIncludesClosedProject: {
      limit: 100,
      offset: 0,
      personnel_id: 2,
      name: '3',
      name_jpn: 'テスト',
      project_id: 112,
      company_id: 1,
      search_name: 'test41 テスト８',
      skills: {
        LeadDev: { level: 1 },
        'FrontEnd,Web(React)': { level: 2 },
        'BackEnd,Node.js': { level: 3 },
      },
      include_status_closed: true,
    },
    searchCriteriaWithoutPagination: {
      limit: undefined,
      offset: undefined,
      personnel_id: 2,
      name: '3',
      name_jpn: 'テスト',
      project_id: 112,
      company_id: 1,
      search_name: 'test41 テスト８',
      skills: {
        LeadDev: { level: 1 },
        'FrontEnd,Web(React)': { level: 2 },
        'BackEnd,Node.js': { level: 3 },
      },
    },
    findResult: {
      result: [
        {
          name_jpn: '単体テスト',
          unregistered_date: null,
          updated_by: null,
          update_at: null,
          process_id: null,
          personnel_id: 100,
          name: 'Unit Test name',
          registered_date: '2022-01-01',
          skill_list: {
            LeadDev: {
              level: 1,
            },
            'BackEnd,Node.js': {
              level: 3,
            },
            'FrontEnd,Web(React)': {
              level: 2,
            },
          },
          dw_m_partner_company: {
            updated_by: null,
            update_at: null,
            process_id: null,
            company_id: 1,
            company_name: 'Unit Test Company Name',
            contract_pattern_code: 1,
          },
          dw_m_personnel_price: [],
          dw_t_operation_plan: [
            {
              dw_m_project: {
                project_name: 'Unit Test Project Name',
                status: '1',
                project_start_date: '2022-01-01',
              },
            },
            {
              dw_m_project: {
                project_name: 'Unit Test Project Name 2',
                status: '0',
                project_start_date: '2022-02-01',
              },
            },
            {
              dw_m_project: {
                project_name: 'Unit Test Project Name 2',
                status: '0',
                project_start_date: '2022-02-01',
              },
            },
            {
              dw_m_project: null,
            },
          ],
        },
      ],
      count: 1,
    },
    findResultWithClosedProjects: {
      result: [
        {
          name_jpn: '単体テスト',
          unregistered_date: null,
          updated_by: null,
          update_at: null,
          process_id: null,
          personnel_id: 100,
          name: 'Unit Test name',
          registered_date: '2022-01-01',
          skill_list: {
            LeadDev: {
              level: 1,
            },
            'BackEnd,Node.js': {
              level: 3,
            },
            'FrontEnd,Web(React)': {
              level: 2,
            },
          },
          dw_m_partner_company: {
            updated_by: null,
            update_at: null,
            process_id: null,
            company_id: 1,
            company_name: 'Unit Test Company Name',
            contract_pattern_code: 1,
          },
          dw_m_personnel_price: [],
          dw_t_operation_plan: [
            {
              dw_m_project: {
                project_name: 'Unit Test Project Name',
                status: '1',
                project_start_date: '2022-01-01',
              },
            },
            {
              dw_m_project: {
                project_name: 'Unit Test Project Name 2',
                status: '0',
                project_start_date: '2022-02-01',
              },
            },
            {
              dw_m_project: {
                project_name: 'Unit Test Project Name 3',
                status: '5',
                project_start_date: '2022-03-01',
              },
            },
          ],
        },
      ],
      count: 1,
    },
  },

  searchExistenceOfOperation: {
    searchCriteria: {
      from: '2022-01-01',
      to: '2024-01-31',
      personnelId: 100,
    },
    operationPlanResponse: [
      {
        updated_by: 'okazaki-junki@tepsys.co.jp',
        update_at: '2022-10-07T20:07:00.000Z',
        process_id: null,
        month_of_year_date: '2022-05-01',
        man_month_number: '0.40',
        hours_number: '64.000',
        created_by: 'okazaki-junki@tepsys.co.jp',
        create_at: '2022-10-07T20:07:00.000Z',
        process_at: '2022-10-07T20:07:00.000Z',
      },
    ],
    operationCostResponse: [
      {
        updated_by: '岡崎 純己(Junki Okazaki_tps)',
        update_at: '2023-03-02T12:51:16.061Z',
        process_id: null,
        month_of_year_date: '2022-04-01',
        hours_number: '150.000',
        cost_amount: '900000.000',
        created_by: '岡崎 純己(Junki Okazaki_tps)',
        create_at: '2023-03-02T12:51:16.061Z',
        process_at: '2023-03-02T12:51:16.061Z',
      },
    ],
  },
}

export default personnelFixture
