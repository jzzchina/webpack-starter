import { createPersonnelUseCase } from '../../../../../src/application/use_cases/options/personnel/createPersonnelUseCase'
import fixture from './personnel.fixture'
import { PersonnelRepositoryPort } from '../../../../../src/application/port/repositories/personnel/PersonnelRepositoryPort'
import { Personnel } from '../../../../../src/interface/routes/options/personnel/dto/personnel.dto'

describe('TEST - Create Personnel UseCase', () => {
  const repository = {
    findMany: () => jest.fn(),
    create: () => jest.fn(),
  }
  let findManySpy: jest.SpyInstance
  let createSpy: jest.SpyInstance

  beforeEach(() => {
    findManySpy = jest.spyOn(repository, 'findMany')
    createSpy = jest.spyOn(repository, 'create')
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  const personnelList: Personnel[] = fixture.create.personnelList
  const userInformation = fixture.create.userInformation
  const expectedFields = [
    'personnelId',
    'name',
    'nameJpn',
    'email',
    'registeredDate',
    'unregisteredDate',
    'companyId',
    'companyName',
    'contractPatternCode',
    'skillList',
    'prices',
  ]

  it('Should create personnel successfully', async () => {
    // * Arrange
    createSpy.mockImplementation(() =>
      Promise.resolve(fixture.create.insertResult)
    )
    findManySpy.mockImplementation(() =>
      Promise.resolve(fixture.create.foundResult)
    )

    // * Act
    const result = await createPersonnelUseCase(
      personnelList,
      userInformation,
      (repository as unknown) as PersonnelRepositoryPort
    )

    // * Assert
    expect(createSpy).toHaveBeenCalledTimes(1)
    expect(findManySpy).toHaveBeenCalledTimes(1)

    expect(result).toHaveLength(fixture.create.insertResult.length)
    result.forEach((item) => {
      expectedFields.forEach((field) => {
        expect(item).toHaveProperty(field)
      })
    })
  })

  test('should call createPersonnel with undefined userInformation and return undefined', async () => {
    // * Arrange
    const emptyUserInformation = (undefined as unknown) as Record<
      string,
      unknown
    >
    const undefinedArray = Array.from({
      length: fixture.create.personnelList.length,
    })

    createSpy.mockImplementation(() =>
      Promise.resolve(fixture.create.insertResult)
    )
    findManySpy.mockImplementation(() => undefinedArray)

    // * Act
    const result = await createPersonnelUseCase(
      (undefinedArray as unknown) as Personnel[],
      emptyUserInformation,
      (repository as unknown) as PersonnelRepositoryPort
    )
    // * Assert
    expect(createSpy).toHaveBeenCalledTimes(1)
    expect(findManySpy).toHaveBeenCalledTimes(1)

    expect(result).toHaveLength(fixture.create.insertResult.length)
    result.forEach((item) => {
      expectedFields.forEach((field) => {
        expect(item).toHaveProperty(field)
      })
    })
  })
})
