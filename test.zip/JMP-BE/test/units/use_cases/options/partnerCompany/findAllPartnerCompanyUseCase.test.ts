import { PartnerCompanyRepositoryPort } from '../../../../../src/application/port/repositories/partnerCompany/PartnerCompanyRepositoryPort'
import { findAllPartnerCompanyUseCase } from '../../../../../src/application/use_cases/options/partnerCompany/findAllPartnerCompanyUseCase'
import { PartnerCompanyListResponse } from '../../../../../src/interface/routes/options/partnerCompany/dto/partnerCompany.dto'
import fixture from './partnerCompany.fixture'

describe('TEST getAllPartnerCompaniesUseCase', () => {
  const repository = {
    findAll: () => jest.fn(),
  }
  let findAllSpy: jest.SpyInstance

  beforeEach(() => {
    findAllSpy = jest.spyOn(repository, 'findAll')
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  const foundPartnerCompanies = fixture.testCreate.foundPartnerCompanies

  const singlePartnerCompanies = fixture.testCreate.singlePartnerCompany
  const pCompanyRepo = (repository as unknown) as PartnerCompanyRepositoryPort

  test('should return partnerCompanies successfully ', async () => {
    const queryParams = {
      companyId: 1,
      companyName: 'JERA',
      contractPatternCode: 1,
      limit: 10,
      offset: 0,
    }

    // * Arrange
    findAllSpy.mockImplementation(() => Promise.resolve(singlePartnerCompanies))

    // * Act
    const result = (await findAllPartnerCompanyUseCase(
      pCompanyRepo,
      queryParams.companyId,
      queryParams.companyName,
      queryParams.contractPatternCode,
      queryParams.limit,
      queryParams.offset
    )) as PartnerCompanyListResponse
    // * Assert
    const expectedItems = [
      'companyId',
      'contractPatternCode',
      'companyName',
      'numberOfPersonnel',
    ]

    expect(findAllSpy).toHaveBeenCalledTimes(1)
    expect(result).toHaveProperty('items')
    expect(result).toHaveProperty('length', 1)
    expect(result).toHaveProperty('offset', 0)
    expect(result).toHaveProperty('totalLength', 1)
    expect(result.items[0].companyName).toEqual('JERA')
    result.items.forEach((item) => {
      expectedItems.forEach((field) => {
        expect(item).toHaveProperty(field)
      })
    })
  })

  test('should return partnerCompanies successfully without pagination ', async () => {
    const queryParams = {
      companyId: 1,
      companyName: 'JERA',
      contractPatternCode: 1,
      limit: undefined,
      offset: undefined,
    }

    // * Arrange
    findAllSpy.mockImplementation(() => Promise.resolve(foundPartnerCompanies))

    // * Act
    const result = (await findAllPartnerCompanyUseCase(
      pCompanyRepo,
      queryParams.companyId,
      queryParams.companyName,
      queryParams.contractPatternCode,
      Number(queryParams.limit),
      Number(queryParams.offset)
    )) as PartnerCompanyListResponse

    // * Assert
    const expectedItems = [
      'companyId',
      'contractPatternCode',
      'companyName',
      'numberOfPersonnel',
    ]

    expect(findAllSpy).toHaveBeenCalledTimes(1)
    expect(result).toHaveProperty('items')
    expect(result).toHaveProperty('length', 2)
    expect(result).toHaveProperty('offset', 0)
    expect(result).toHaveProperty('totalLength', 2)
    expect(result.length).toEqual(result.totalLength)
    expect(result.items[0].companyName).toEqual('AVAXIA')
    expect(result.items[1].companyName).toEqual('JERA')
    result.items.forEach((item) => {
      expectedItems.forEach((field) => {
        expect(item).toHaveProperty(field)
      })
    })
  })
  test('should return partnerCompanies with undefined fields', async () => {
    // * Arrange
    const undefinedObject = {
      result: Array.from({ length: 3 }, () => undefined),
      count: 3,
    }
    const queryParams = {
      companyId: 1,
      companyName: 'JERA',
      contractPatternCode: 1,
      limit: 10,
      offset: 0,
    }
    findAllSpy.mockImplementation(() => undefinedObject)

    // * Act
    const result = (await findAllPartnerCompanyUseCase(
      pCompanyRepo,
      queryParams.companyId,
      queryParams.companyName,
      queryParams.contractPatternCode,
      queryParams.limit,
      queryParams.offset
    )) as PartnerCompanyListResponse

    // * Assert
    const expectedItems = ['companyId', 'contractPatternCode', 'companyName']

    expect(findAllSpy).toHaveBeenCalledTimes(1)
    expect(result).toHaveProperty('items')
    expect(result).toHaveProperty('length', 3)
    expect(result).toHaveProperty('offset', 0)
    expect(result).toHaveProperty('totalLength', 3)
    result.items.forEach((item) => {
      expectedItems.forEach((field) => {
        expect(item).toHaveProperty(field)
      })
    })
  })
})
