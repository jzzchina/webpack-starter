import { PartnerCompanyRepositoryPort } from '../../../../../src/application/port/repositories/partnerCompany/PartnerCompanyRepositoryPort'
import { SalesManRepositoryPort } from '../../../../../src/application/port/repositories/salesMan/SalesManRepositoryPort'
import { createPartnerCompanyUseCase } from '../../../../../src/application/use_cases/options/partnerCompany/createPartnerCompanyUseCase'
import { PartnerCompanyBodyRequest } from '../../../../../src/interface/routes/options/partnerCompany/dto/partnerCompany.dto'
import fixture from './partnerCompany.fixture'

describe('TEST - CreatePartnerCompanyUseCase', () => {
  const repository = {
    findMany: () => jest.fn(),
    create: () => jest.fn(),
  }
  const salesManRepository = ({
    createSalesMan: () => jest.fn(),
    findSalesManByIds: () => jest.fn(),
  } as unknown) as Pick<
    SalesManRepositoryPort,
    'createSalesMan' | 'findSalesManByIds'
  >
  let findManySpy: jest.SpyInstance
  let createSpy: jest.SpyInstance
  let salesManCreateSpy: jest.SpyInstance
  let salesManFindSpy: jest.SpyInstance
  beforeEach(() => {
    findManySpy = jest.spyOn(repository, 'findMany')
    createSpy = jest.spyOn(repository, 'create')
    salesManCreateSpy = jest.spyOn(salesManRepository, 'createSalesMan')
    salesManFindSpy = jest.spyOn(salesManRepository, 'findSalesManByIds')
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  const userInformation = fixture.testCreate.userInformation
  const companyList = (fixture.testCreate
    .companyList as unknown) as PartnerCompanyBodyRequest[]

  test('should create new partner companies', async () => {
    // * Arrange
    createSpy.mockImplementation(() =>
      Promise.resolve(fixture.testCreate.insertResult)
    )
    findManySpy.mockImplementation(() =>
      Promise.resolve(fixture.testCreate.foundResult)
    )
    salesManCreateSpy.mockImplementation(() =>
      Promise.resolve(fixture.testCreate.salesManInsertResult)
    )
    salesManFindSpy.mockImplementation(() =>
      Promise.resolve(fixture.testCreate.salesManFoundResult)
    )

    // * Act
    const result = await createPartnerCompanyUseCase(
      companyList,
      userInformation,
      (repository as unknown) as PartnerCompanyRepositoryPort,
      salesManRepository
    )

    // * Assert
    const expectedFields = [
      'companyId',
      'contractPatternCode',
      'companyName',
      'salesMan',
      'createdBy',
      'createAt',
      'updatedBy',
      'updateAt',
      'processAt',
      'processId',
    ]

    expect(createSpy).toHaveBeenCalledTimes(1)
    expect(findManySpy).toHaveBeenCalledTimes(1)

    expect(result).toHaveLength(fixture.testCreate.insertResult.length)
    result.forEach((item) => {
      expectedFields.forEach((field) => {
        expect(item).toHaveProperty('salesMan')
        expect(item.salesMan).toHaveLength(
          fixture.testCreate.salesManFoundResult.length
        )
        expect(item).toHaveProperty(field)
      })
    })
  })

  test('should return empty array when no partner company is created', async () => {
    // * Arrange
    const undefinedCompanyList = (Array.from(
      { length: 3 },
      () => undefined
    ) as unknown) as PartnerCompanyBodyRequest[]
    createSpy.mockImplementation(() => Promise.resolve(undefined))
    findManySpy.mockImplementation(() => Promise.resolve([]))
    salesManCreateSpy.mockImplementation(() => Promise.resolve(undefined))
    salesManFindSpy.mockImplementation(() => Promise.resolve([]))

    // * Act
    const result = await createPartnerCompanyUseCase(
      undefinedCompanyList,
      userInformation,
      (repository as unknown) as PartnerCompanyRepositoryPort,
      salesManRepository
    )

    // * Assert
    expect(createSpy).toHaveBeenCalledTimes(1)
    expect(findManySpy).toHaveBeenCalledTimes(0)

    expect(result).toHaveLength(0)
  })

  test('should create new partner companies with empty user information', async () => {
    // * Arrange
    createSpy.mockImplementation(() =>
      Promise.resolve(fixture.testCreate.insertResult)
    )
    findManySpy.mockImplementation(() =>
      Promise.resolve(fixture.testCreate.foundResult)
    )
    salesManCreateSpy.mockImplementation(() =>
      Promise.resolve(fixture.testCreate.salesManInsertResult)
    )
    salesManFindSpy.mockImplementation(() =>
      Promise.resolve(fixture.testCreate.salesManFoundResult)
    )

    // * Act
    const result = await createPartnerCompanyUseCase(
      companyList,
      (undefined as unknown) as Record<string, unknown>,
      (repository as unknown) as PartnerCompanyRepositoryPort,
      salesManRepository
    )

    // * Assert
    const expectedFields = [
      'companyId',
      'contractPatternCode',
      'companyName',
      'createdBy',
      'createAt',
      'updatedBy',
      'updateAt',
      'processAt',
      'processId',
    ]

    expect(createSpy).toHaveBeenCalledTimes(1)
    expect(findManySpy).toHaveBeenCalledTimes(1)

    expect(result).toHaveLength(fixture.testCreate.insertResult.length)
    result.forEach((item) => {
      expectedFields.forEach((field) => {
        expect(item).toHaveProperty(field)
      })
    })
  })

  test('should return corrupted data when create partner company is failed', async () => {
    const undefinedArray = Array.from({ length: 3 }, () => undefined)
    // * Arrange
    createSpy.mockImplementation(() =>
      Promise.resolve(fixture.testCreate.insertResult)
    )
    findManySpy.mockImplementation(() => undefinedArray)
    salesManCreateSpy.mockImplementation(() =>
      Promise.resolve(fixture.testCreate.salesManInsertResult)
    )
    salesManFindSpy.mockImplementation(() =>
      Promise.resolve(fixture.testCreate.salesManFoundResult)
    )

    // * Act
    const result = await createPartnerCompanyUseCase(
      companyList,
      userInformation,
      (repository as unknown) as PartnerCompanyRepositoryPort,
      salesManRepository
    )

    // * Assert
    const expectedFields = [
      'companyId',
      'contractPatternCode',
      'companyName',
      'createdBy',
      'createAt',
      'updatedBy',
      'updateAt',
      'processAt',
      'processId',
    ]

    expect(createSpy).toHaveBeenCalledTimes(1)
    expect(findManySpy).toHaveBeenCalledTimes(1)

    result.forEach((item) => {
      expectedFields.forEach((field) => {
        expect(item).toHaveProperty(field, undefined)
      })
    })
  })
})
