import { PartnerCompanyRepositoryPort } from '../../../../../src/application/port/repositories/partnerCompany/PartnerCompanyRepositoryPort'
import { deletePartnerCompaniesUseCase } from '../../../../../src/application/use_cases/options/partnerCompany/deletePartnerCompaniesUseCase'

describe('TEST deletePartnerCompaniesUseCase', () => {
  const repository = {
    deletePartnerCompanies: () => jest.fn(),
  }
  let deletePCSpy: jest.SpyInstance

  beforeEach(() => {
    deletePCSpy = jest.spyOn(repository, 'deletePartnerCompanies')
  })

  afterEach(() => {
    jest.resetAllMocks()
  })

  const companyIds = [1, 2, 3]

  test('should delete partner companies if data is valid', async () => {
    // * Arrange
    deletePCSpy.mockImplementation(undefined)

    // * Act
    const result = await deletePartnerCompaniesUseCase(
      companyIds,
      (repository as unknown) as PartnerCompanyRepositoryPort
    )
    // * Assert
    expect(deletePCSpy).toHaveBeenCalledTimes(1)
    expect(deletePCSpy).toHaveBeenCalledWith(companyIds)
    expect(result).toBeUndefined()
  })
})
