const partnerCompanyFixture = {
  testCreate: {
    companyList: [
      {
        companyId: 1,
        companyName: 'JMP',
        contractPatternCode: 1,
        numberOfPersonnel: 1,
        salesMan: [
          {
            salesManId: 1,
            name: 'John Doe',
            emailAddress: 'jhonDoe@company.com',
            phoneNumber: '0123456789',
          },
        ],
      },
      {
        companyId: 2,
        companyName: 'VNG',
        contractPatternCode: 1,
        numberOfPersonnel: 1,
        salesMan: [
          {
            salesManId: 2,
            name: 'John Doe',
            emailAddress: 'jhonDoe@company.com',
            phoneNumber: '0123456789',
          },
        ],
      },
    ],
    insertResult: [
      {
        company_id: 167,
        contract_pattern_code: 3,
        company_name: 'Test company 1',
        created_by: 'Unit Test',
        updated_by: 'Unit Test',
        update_at: '2023-02-10T19:14:00.413Z',
        process_id: null,
        create_at: '2023-02-10T19:14:00.413Z',
        process_at: '2023-02-10T19:14:00.413Z',
      },
    ],
    salesManInsertResult: [
      {
        sales_man_id: 1,
        nam: 'John Doe',
        email: 'jhonDoe@company.com',
        phone_number: '0123456789',
        created_by: 'Test Agent',
        updated_by: 'Test Agent',
        update_at: '2023-02-10T19:14:00.413Z',
        process_id: null,
        create_at: '2023-02-10T19:14:00.413Z',
        process_at: '2023-02-10T19:14:00.413Z',
      },
    ],
    salesManFoundResult: [
      {
        sales_man_id: 1,
        nam: 'John Doe',
        email: 'jhonDoe@company.com',
        phone_number: '0123456789',
      },
    ],
    foundResult: [
      {
        company_id: 167,
        contract_pattern_code: 3,
        company_name: 'Test company 1',
        created_by: 'Unit Test',
        create_at: '2023-02-10T19:33:47.595Z',
        updated_by: 'Unit Test',
        update_at: '2023-02-10T19:33:47.595Z',
        process_at: '2023-02-10T19:33:47.595Z',
        process_id: null,
      },
    ],
    userInformation: {
      name: 'Test Name',
      roles: 'Test Role',
    },
    foundPartnerCompanies: {
      result: [
        {
          company_id: 107,
          contract_pattern_code: 1,
          company_name: 'AVAXIA',
          dw_m_personnel: [
            {
              personnel_id: 1,
            },
            {
              personnel_id: 1,
            },
          ],
        },
        {
          company_id: 108,
          contract_pattern_code: 1,
          company_name: 'JERA',
          dw_m_personnel: [
            {
              personnel_id: 1,
            },
            {
              personnel_id: 1,
            },
          ],
        },
      ],
      count: 2,
    },
    singlePartnerCompany: {
      result: [
        {
          company_id: 107,
          contract_pattern_code: 1,
          company_name: 'JERA',
          dw_m_personnel: [
            {
              personnel_id: 1,
            },
            {
              personnel_id: 1,
            },
          ],
        },
      ],
      count: 1,
    },
  },
}

export default partnerCompanyFixture
