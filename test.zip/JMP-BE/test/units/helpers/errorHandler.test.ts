import { Request, Response, NextFunction } from 'express'
import CustomError from '../../../src/application/errors/CustomError'
import errorHandler from '../../../src/application/errors/ErrorHandler'
import statusCodes from '../../../src/application/errors/statusCodes'

const createMockRequest = (): Partial<Request> => ({})

const createMockResponse = (): Partial<Response> & {
  status: jest.Mock
  json: jest.Mock
  send: jest.Mock
} => ({
  status: jest.fn().mockReturnThis(),
  json: jest.fn(),
  send: jest.fn(),
})

describe('ErrorHandler', () => {
  let mockRequest: Partial<Request>
  let mockResponse: Partial<Response> & {
    status: jest.Mock
    json: jest.Mock
    send: jest.Mock
  }
  const nextFunction: NextFunction = jest.fn()

  beforeEach(() => {
    mockRequest = createMockRequest()
    mockResponse = createMockResponse()
  })

  it('should handle CustomError correctly', () => {
    const customError = new CustomError('Record not found', 'Bad Request')
    errorHandler(
      customError,
      mockRequest as Request,
      mockResponse as Response,
      nextFunction
    )

    expect(mockResponse.status).toHaveBeenCalledWith(400)
    expect(mockResponse.json).toHaveBeenCalledWith({
      message: 'Record not found',
    })
  })

  it('should handle generic Error correctly', () => {
    const genericError = new Error('Generic error message')
    errorHandler(
      genericError,
      mockRequest as Request,
      mockResponse as Response,
      nextFunction
    )

    expect(mockResponse.status).toHaveBeenCalledWith(
      statusCodes['Internal Server Error']
    )
    expect(mockResponse.send).toHaveBeenCalledWith({
      message: 'Generic error message',
    })
  })
})
