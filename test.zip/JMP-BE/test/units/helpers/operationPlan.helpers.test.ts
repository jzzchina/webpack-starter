import {
  buildCreateOperationPlanResponse,
  buildOperationPlanCreateQueryParams,
  buildOperationPlanPersonnelResponseObject,
  buildOperationPlanProjectResponseObject,
} from '../../../src/application/helpers/operationPlan.helpers'
import { Dw_t_operation_plan } from '../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation_plan'
import {
  OperationPlanPersonnelResponse,
  OperationPlanProjectResponse,
} from '../../../src/infrastructure/repositories/operationPlan/interface'
import {
  CreateOperationPlanDto,
  CreateOperationPlanResponse,
} from '../../../src/interface/routes/operationPlan/dto/operationPlans.dto'
import {
  buildCreateOperationPlanResponseFixture,
  buildOperationPlanCreateQueryParamsFixture,
  buildOperationPlanProjectExpect,
  operationPlanPersonnelResFixture,
} from '../../fixtures/expected/operationPlan/operationPlans.fixture'
import {
  arrayBodyOperationPlanDto,
  buildOperationPlanProjectPayload,
  dwOperationPlanFixture,
  jwtPayload,
  operationPlanPersonnelInputFixture,
} from '../../fixtures/inserts/operationPlans.fixture'

describe('Test operationPlan helpers', () => {
  describe('Test buildOperationPlanPersonnelsResponseObject helper function', () => {
    test('should build a OperationPlanByPersonnelsResponse from a list of Dw_m_personnel', () => {
      const {
        databasePersonnel,
        foundTotalItems,
        from,
        to,
        offset,
      } = operationPlanPersonnelInputFixture

      const result: OperationPlanPersonnelResponse = buildOperationPlanPersonnelResponseObject(
        databasePersonnel,
        foundTotalItems,
        from,
        to,
        offset
      )

      expect(result).toBeInstanceOf(Object)
      expect(Object.keys(result)).toEqual([
        'from',
        'to',
        'offset',
        'length',
        'totalLength',
        'items',
      ])
      expect(result).toEqual(
        operationPlanPersonnelResFixture.expectedOperationResponse
      )
    })
    test('should return an empty OperationPlanPersonnelResponse if no personnels are found', () => {
      const {
        emptyPersonnel,
        notFoundTotalItems,
        from,
        to,
        offset,
      } = operationPlanPersonnelInputFixture

      const result: OperationPlanPersonnelResponse = buildOperationPlanPersonnelResponseObject(
        emptyPersonnel,
        notFoundTotalItems,
        from,
        to,
        offset
      )

      expect(result).toBeInstanceOf(Object)
      expect(Object.keys(result)).toEqual([
        'from',
        'to',
        'offset',
        'length',
        'totalLength',
        'items',
      ])
      expect(result).toEqual(
        operationPlanPersonnelResFixture.emptyOperationResponse
      )
    })
  })

  describe('Test buildOperationPlanProjectResponseObject helper function', () => {
    test('should build a OperationPlanProjectResponse from a list of Dw_m_project', () => {
      const {
        databaseProjects,
        foundTotalItems,
        from,
        to,
        offset,
      } = buildOperationPlanProjectPayload

      const result: OperationPlanProjectResponse = buildOperationPlanProjectResponseObject(
        databaseProjects,
        foundTotalItems,
        from,
        to,
        offset
      )

      expect(result).toBeInstanceOf(Object)
      expect(Object.keys(result)).toEqual([
        'from',
        'to',
        'offset',
        'length',
        'totalLength',
        'items',
      ])
      expect(result).toEqual(
        buildOperationPlanProjectExpect.expectedOperationResponse
      )
    })
    test('should return an empty OperationPlanProjectResponse if no projects are found', () => {
      const {
        emptyProject,
        notFoundTotalItems,
        from,
        to,
        offset,
      } = buildOperationPlanProjectPayload

      const result: OperationPlanProjectResponse = buildOperationPlanProjectResponseObject(
        emptyProject,
        notFoundTotalItems,
        from,
        to,
        offset
      )

      expect(result).toBeInstanceOf(Object)
      expect(Object.keys(result)).toEqual([
        'from',
        'to',
        'offset',
        'length',
        'totalLength',
        'items',
      ])
      expect(result).toEqual(
        buildOperationPlanProjectExpect.expectedEmptyOperationResponse
      )
    })
  })

  describe('Test buildCreateOperationPlanResponse helper function', () => {
    test('should build a buildCreateOperationPlanResponse from a list of Dw_t_operation_plan', () => {
      const result: CreateOperationPlanResponse[] = buildCreateOperationPlanResponse(
        dwOperationPlanFixture
      )

      expect(result).toBeInstanceOf(Array)
      expect(Object.keys(result[0])).toEqual([
        'operationPlanId',
        'costAmount',
        'manMonthNumber',
        'hoursNumber',
        'personnelId',
        'projectId',
        'yearOfMonthDate',
        'roleId',
        'roleName',
        'createdBy',
        'createdAt',
        'updatedBy',
        'updateAt',
        'processAt',
        'processId',
      ])
      expect(result).toEqual(buildCreateOperationPlanResponseFixture)
    })
    test('should return an empty OperationPlanPersonnelResponse if no personnels are found', () => {
      const result: CreateOperationPlanResponse[] = buildCreateOperationPlanResponse(
        []
      )
      expect(result).toBeInstanceOf(Array)
      expect(result).toEqual([])
    })
  })

  describe('Test buildOperationPlanCreateQueryParams helper function', () => {
    test('should build a buildOperationPlanCreateQueryParams from a list of Dw_t_operation_plan', () => {
      const result: Partial<Dw_t_operation_plan>[] = buildOperationPlanCreateQueryParams(
        arrayBodyOperationPlanDto,
        jwtPayload
      )
      expect(result).toBeInstanceOf(Array)
      expect(Object.keys(result[0])).toEqual([
        'operation_plan_id',
        'man_month_number',
        'dw_m_personnel',
        'dw_m_project',
        'dw_m_role',
        'month_of_year_date',
        'hours_number',
        'created_by',
        'updated_by',
      ])
      expect(result).toEqual(buildOperationPlanCreateQueryParamsFixture)
    })
    test('should return an empty Dw_t_operation_plan', () => {
      const result: Partial<Dw_t_operation_plan>[] = buildOperationPlanCreateQueryParams(
        ([] as unknown) as CreateOperationPlanDto[],
        jwtPayload
      )
      expect(result).toBeInstanceOf(Array)
      expect(result).toEqual([])
    })
  })
})
