import { WbsRepositoryPort } from '../../../src/application/port/repositories/wbs/wbsRepositoryPort'
import { searchWbsCostsUseCase } from '../../../src/application/use_cases/wbs/searchWbsCostsUseCase'
import { wbsCosts } from '../../fixtures/expected/wbs/wbsCost.fixture'
import { searchWbsCostsParams } from '../../fixtures/inserts/wbs.fixture'

describe('searchWbsCostsUseCase.test', () => {
  const repository = ({
    searchWbsCosts: () => jest.fn(),
  } as unknown) as WbsRepositoryPort
  let findManySpy: jest.SpyInstance
  beforeEach(() => {
    findManySpy = jest.spyOn(repository, 'searchWbsCosts')
  })

  afterAll(() => {
    jest.resetAllMocks()
  })

  test('should return wbs cost list grouped by month', async () => {
    findManySpy.mockImplementation(() =>
      Promise.resolve({ personnel: wbsCosts })
    )

    const result = await searchWbsCostsUseCase(
      100,
      searchWbsCostsParams.offset,
      searchWbsCostsParams.from,
      searchWbsCostsParams.to,
      searchWbsCostsParams.companyId,
      repository
    )

    expect(result.items).toHaveLength(10)

    result.items.forEach((item) => {
      const total = item.total
      const sumAmounts = item.wbs.reduce((sum, w) => {
        if (!sum[w.currency_type_code]) {
          sum[w.currency_type_code] = 0
        }
        sum[w.currency_type_code] += w.amount
        return sum
      }, {} as { [key: number]: number })

      Object.keys(sumAmounts).forEach((currencyType) => {
        const currencyTypeNumber = parseInt(currencyType)
        const totalItem = total.find(
          (t) => t.currency_type_code === currencyTypeNumber
        )
        expect(totalItem).toBeDefined()
        expect(totalItem!.amount).toEqual(sumAmounts[currencyTypeNumber])
      })
    })
  })
})
