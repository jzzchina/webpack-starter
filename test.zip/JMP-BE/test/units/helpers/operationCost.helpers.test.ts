import {
  buildCreateOperationCostResponse,
  buildOperationCostListResponse,
  buildOperationCreateQueryParams,
  getUniqueListOfOperationCosts,
} from '../../../src/application/helpers/operationCost.helpers'
import { OperationCostCreateRequest } from '../../../src/infrastructure/repositories/operationCost/interface'
import {
  CreateOperationCostResponse,
  OperationCostListResponse,
} from '../../../src/interface/routes/operationCost/dto/operationCost.dto'
import { Dw_t_operation } from '../../../src/infrastructure/orm/typeorm/entities/Dw_t_operation'
import {
  buildCreateOperationCostResponseFixture,
  buildOperationCostListResponseResultFixture,
  expectedResultGetUniqueListOfOperationCosts,
  OperationCreateQueryParamsObjectFixture,
} from '../../fixtures/expected/operationCost/operationCosts.fixture'
import {
  commonFields,
  CreateOperationCostResponseInputFixture,
  inputArrayBody,
  jwtPayload,
  projectsFixture,
} from '../../fixtures/inserts/operationCosts.fixture'
import { Dw_m_project } from '../../../src/infrastructure/orm/typeorm/entities/Dw_m_project'

describe('Test operationCost helpers', () => {
  describe('Test buildOperationCreateQueryParamsObject helper function', () => {
    test('should build a OperationCreateQueryParams from a Array of CreateOperationCostDto', () => {
      const result: OperationCostCreateRequest[] = buildOperationCreateQueryParams(
        inputArrayBody,
        jwtPayload
      )

      expect(result).toBeInstanceOf(Array)
      result.forEach((data) => {
        expect(data).toHaveProperty('operation_id')
        expect(data).toHaveProperty('hours_number')
        expect(data).toHaveProperty('cost_amount')
        expect(data).toHaveProperty('dw_m_personnel')
        expect(data).toHaveProperty('dw_m_project')
        expect(data).toHaveProperty('month_of_year_date')
      })

      expect(result).toEqual(OperationCreateQueryParamsObjectFixture)
    })
    test('should return an empty OperationCreateQueryParams ', () => {
      const result: OperationCostCreateRequest[] = buildOperationCreateQueryParams(
        [],
        jwtPayload
      )
      expect(result).toBeInstanceOf(Array)
      expect(result).toEqual([])
    })
  })

  describe('Test buildCreateOperationCostResponseObject helper function', () => {
    test('should build a CreateOperationCostResponse from a list of Dw_t_operation', () => {
      const result: CreateOperationCostResponse[] = buildCreateOperationCostResponse(
        CreateOperationCostResponseInputFixture as Dw_t_operation[]
      )

      expect(result).toBeInstanceOf(Array)
      result.forEach((data) => {
        expect(data).toHaveProperty('costAmount')
        expect(data).toHaveProperty('createdAt')
        expect(data).toHaveProperty('createdBy')
        expect(data).toHaveProperty('hoursNumber')
        expect(data).toHaveProperty('operationId')
        expect(data).toHaveProperty('personnelId')
        expect(data).toHaveProperty('processAt')
        expect(data).toHaveProperty('processId')
        expect(data).toHaveProperty('updateAt')
        expect(data).toHaveProperty('updatedBy')
        expect(data).toHaveProperty('yearOfMonthDate')
      })
      expect(result).toEqual(buildCreateOperationCostResponseFixture)
    })
    test('should return an empty CreateOperationCostResponse if no operations are found', () => {
      const result: CreateOperationCostResponse[] = buildCreateOperationCostResponse(
        []
      )

      expect(result).toBeInstanceOf(Array)

      expect(result).toEqual([])
    })
  })

  describe('Test buildOperationCostListResponseObject helper function', () => {
    test('should build a OperationCreateQueryParams from a Array of CreateOperationCostDto', () => {
      const { totalItems, from, to, offset, limit } = commonFields
      const result: OperationCostListResponse = buildOperationCostListResponse(
        projectsFixture,
        totalItems,
        from,
        to,
        offset,
        limit
      )
      expect(result).toBeInstanceOf(Object)
      expect(Object.keys(result)).toEqual([
        'from',
        'to',
        'offset',
        'length',
        'totalLength',
        'items',
      ])

      expect(result).toEqual(buildOperationCostListResponseResultFixture)
    })
    test('should return an empty OperationCreateQueryParams ', () => {
      const { totalItems, from, to, offset, limit } = commonFields
      const result: OperationCostListResponse = buildOperationCostListResponse(
        [],
        totalItems,
        from,
        to,
        offset,
        limit
      )
      expect(result).toBeInstanceOf(Object)
      expect(Object.keys(result)).toEqual([
        'from',
        'to',
        'offset',
        'length',
        'totalLength',
        'items',
      ])
      expect(result.items).toEqual([])
    })
  })

  describe('Test getUniqueListOfOperationCostsObject helper function', () => {
    test('should build a getUniqueListOfOperationCosts from a list of Dw_t_operation', () => {
      const result: Partial<Dw_m_project>[] = getUniqueListOfOperationCosts(
        projectsFixture
      )

      expect(result).toBeInstanceOf(Array)
      expect(result).toEqual(expectedResultGetUniqueListOfOperationCosts)
    })
    test('should return an empty getUniqueListOfOperationCostsObject ', () => {
      const result: Partial<Dw_m_project>[] = getUniqueListOfOperationCosts([])

      expect(result).toBeInstanceOf(Array)

      expect(result).toEqual([])
    })
  })
})
