import {
  buildBusinessDaysListDTO,
  buildBusinessDaysListResponse,
} from '../../../src/application/helpers/businessDays.helpers'
import { BusinessDaysDBList } from '../../../src/infrastructure/repositories/businessDays/interface'
import { BusinessDaysList } from '../../../src/interface/routes/businessDays/dto/businessDays.dto'
import payloadFixture, {
  buildBusinessDaysListDTOResult,
  businessDaysList,
  findAllBusinessDaysPayload,
} from '../../fixtures/inserts/businessDays.fixture'
import expectedFixture, {
  buildBusinessDaysListResponseResultFixture,
} from '../../fixtures/expected/businessDays/businessDays.fixture'
import { buildBusinessDaysObject } from '../../../src/application/helpers/businessDays.helpers'
import { BusinessDaysObject } from '../../../src/interface/routes/businessDays/dto/businessDays.dto'

describe('Test businessDays helpers', () => {
  describe('Test buildBusinessDaysListDTOObject helper function', () => {
    test('should build a buildBusinessDaysListDTOResponse from a list of BusinessDaysList', () => {
      const userName = 'UnitTest User'

      const result: BusinessDaysDBList = buildBusinessDaysListDTO(
        (businessDaysList as unknown) as BusinessDaysList,
        userName
      )

      expect(result).toBeInstanceOf(Array)
      result.forEach((data) => {
        expect(data).toHaveProperty('business_days_id')
        expect(data).toHaveProperty('business_days_number')
        expect(data).toHaveProperty('dw_m_partner_company')
        expect(data).toHaveProperty('month_of_year_date')
      })
      expect(result).toEqual(buildBusinessDaysListDTOResult)
    })

    test('should return an empty buildBusinessDaysListDTOResponse if no businessDaysList are found', () => {
      const userName = 'UnitTest User'

      const result: BusinessDaysDBList = buildBusinessDaysListDTO(
        [] as BusinessDaysList,
        userName
      )

      expect(result).toBeInstanceOf(Array)
      expect(result).toEqual([])
    })
  })

  describe('Test buildBusinessDaysListResponseObject helper function', () => {
    test('should build a BusinessDaysListResponse from a list of Dw_m_business_days ', () => {
      const result: BusinessDaysList = buildBusinessDaysListResponse(
        (findAllBusinessDaysPayload.result
          .foundBusinessDays as unknown) as BusinessDaysDBList
      )

      expect(result).toBeInstanceOf(Array)
      result.forEach((data) => {
        expect(data).toHaveProperty('businessDaysNumber')
        expect(data).toHaveProperty('companyId')
        expect(data).toHaveProperty('monthOfYearDate')
      })
      expect(result).toEqual(buildBusinessDaysListResponseResultFixture)
    })
    test('should return an empty BusinessDaysListResponse if no projects are found', () => {
      const result: BusinessDaysList = buildBusinessDaysListResponse(
        [] as BusinessDaysDBList
      )
      expect(result).toBeInstanceOf(Array)
      expect(result).toEqual([])
    })
  })

  describe('Test buildBusinessDaysObject helper function', () => {
    test('should build a BusinessDaysObject from a list of Dw_m_business_days', () => {
      const result: BusinessDaysObject = buildBusinessDaysObject(
        payloadFixture.databaseBusinessDays
      )
      expect(result).toEqual(expectedFixture.expectedBusinessDaysObject)
    })

    test('should return an empty BusinessDaysObject from an empty list of Dw_m_business_days', () => {
      const result: BusinessDaysObject = buildBusinessDaysObject(
        payloadFixture.emptyDatabaseBusinessDays
      )
      expect(result).toEqual(expectedFixture.expectedEmptyBusinessDaysObject)
    })
  })
})
