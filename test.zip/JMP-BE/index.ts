import { projectRepositoryMySQL } from './src/infrastructure/repositories/options/project/projectRepositoryMySQL'
import { operationPlanRepositoryMySQL } from './src/infrastructure/repositories/operationPlan/operationPlanRepositoryMySQL'
import { createConnection } from './src/infrastructure/orm/typeorm/connection'
import { roleRepositoryMySQL } from './src/infrastructure/repositories/options/role/roleRepositoryMySQL'
import { partnerCompanyRepositoryMySQL } from './src/infrastructure/repositories/options/partnerCompany/partnerCompanyRepositoryMySQL'
import { operationCostPlanRepositoryMySQL } from './src/infrastructure/repositories/operationCostPlan/operationCostPlanRepositoryMySQL'
import { personnelRepositoryMySQL } from './src/infrastructure/repositories/options/personnel/personnelRepositoryMySQL'
import { personnelPriceRepositoryMySQL } from './src/infrastructure/repositories/options/personnelPrice/personnelPriceRepositoryMySQL'
import { operationCostRepositoryMySQL } from './src/infrastructure/repositories/operationCost/operationCostRepositoryMySQL'
import { createServer } from './src/infrastructure/webserver/express'
import { businessDaysRepositoryMySQL } from './src/infrastructure/repositories/businessDays/businessDaysRepositoryMySQL'
import { wbsRepositoryMySQL } from './src/infrastructure/repositories/wbs/wbsRepositoryMySQL'
import { salesManRepositoryMySQL } from './src/infrastructure/repositories/salesMan/salesManRepositoryMySQL'
;(async () => {
  const connection = await createConnection()
  const operationPlanRepository = await operationPlanRepositoryMySQL(connection)
  const roleRepository = await roleRepositoryMySQL(connection)
  const personnelRepository = await personnelRepositoryMySQL(connection)
  const personnelPriceRepository = await personnelPriceRepositoryMySQL(
    connection
  )
  const projectRepository = await projectRepositoryMySQL(connection)
  const partnerCompanyRepository = await partnerCompanyRepositoryMySQL(
    connection
  )
  const operationCostPlanRepository = await operationCostPlanRepositoryMySQL(
    connection
  )
  const operationCostRepository = await operationCostRepositoryMySQL(connection)
  const businessDaysRepository = await businessDaysRepositoryMySQL(connection)
  const wbsRepository = await wbsRepositoryMySQL(connection)
  const salesManRepository = await salesManRepositoryMySQL(connection)
  createServer({
    operationPlanRepository: operationPlanRepository,
    roleRepository: roleRepository,
    personnelRepository: personnelRepository,
    personnelPriceRepository,
    projectRepository: projectRepository,
    partnerCompanyRepository: partnerCompanyRepository,
    operationCostPlanRepository: operationCostPlanRepository,
    operationCostRepository: operationCostRepository,
    businessDaysRepository,
    wbsRepository,
    salesManRepository,
  })
})()
